import pathlib, json
src = open('/home/claude/gen/groupe.py').read().split("past = lambda")[0]
exec(src)
ENV = lambda kind: {
 'sealed': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',
 'open': '<path d="M3 10v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-9l-9-6z"/><path d="m3 10 9 6 9-6"/>',
 'wait': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 'list': '<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',
 'gear': I['gear'], 'users': I['users'],
}[kind]
def mini(icon, tone='quiet'):
    bg, fg = {'primary': ('#f6e2dd', '#a43a2f'), 'quiet': ('#f1e8d8', '#57534e'), 'ok': ('#dbe9dd', '#274e34')}[tone]
    return f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(ENV(icon), 18)}</span>'
def inrow(lead, title, sub, trail=None, first=False, href='#'):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li>
          <a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            {lead}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{title}</span>
              <span style="font-size: 14px; line-height: 1.35; color: #57534e">{sub}</span>
            </span>
            {trail or CHEV}
          </a>
        </li>
'''
PILL = lambda label: f'<span style="height: 36px; padding: 0 14px; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 14px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">{label}</span>'
BADGE = '<span style="padding: 2px 8px; border-radius: 999px; background: #f1e8d8; color: #57534e; font-size: 12px; font-weight: 700">Organisateur</span>'
def group(name, meta, rows, orga=False):
    return f'''<section style="{CARD} overflow: hidden">
      <div style="padding: 14px 16px 10px; display: flex; flex-direction: column; gap: 2px">
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap"><h3 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 19px; line-height: 1.2">{name}</h3>{BADGE if orga else ''}</div>
        <p style="margin: 0; font-size: 14px; color: #57534e">{meta}</p>
      </div>
      <ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid #e9dcc5">
{rows}      </ul>
    </section>'''
def greet(name, emoji='🦌', color='plum'):
    bg, ring = SH[color]
    return f'''<div style="display: flex; align-items: center; gap: 14px">
      <a href="#compte" aria-label="Mon compte" style="position: relative; width: 56px; height: 56px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: 26px; text-decoration: none; flex-shrink: 0"><span aria-hidden="true">{emoji}</span></a>
      <h1 style="{H1}">Bonjour {name}</h1>
    </div>'''
H2L = "margin: 0; padding: 0 4px; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 20px"
SEALED = '''<svg aria-hidden="true" width="150" height="104" viewBox="0 0 184 128" fill="none">
        <rect x="6" y="14" width="172" height="108" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
        <path d="M7 118 70 66M177 118 114 66" stroke="#cdb48a" stroke-width="2" stroke-linecap="round"/>
        <path d="M8 18 84 74a13 13 0 0 0 16 0l76-56" fill="#f1e8d8" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
        <circle cx="92" cy="78" r="22" fill="#b8483a"/>
        <path d="M92 65l2.900 10.100L105 78l-10.100 2.900L92 91l-2.900-10.100L79 78l10.100-2.900z" fill="#f9eecb"/>
      </svg>'''

# A1 participant seul
build('Accueil.dc.html', 'Accueil — un seul tirage', f'''<main style="{MAIN}">
    {greet('Hugo', '🐧', 'mustard')}
    <section style="{CARD} padding: 24px 20px 20px; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
      {SEALED}
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">Famille Camille · Noël 2026</p>
        <h2 style="{CT}">Le tirage est fait !</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Fête le 25 décembre, dans 40 jours.</p>
      </div>
      <a href="TirageDecouvrir.dc.html" style="{BTN}; width: 100%">Découvrir à qui j'offre un cadeau</a>
    </section>
    {section('', inrow(mini('list', 'primary'), 'Ma liste de souhaits', 'Aucune idée pour l’instant', first=True) + inrow(mini('wait'), 'Tirages passés', 'Noël 2025, Noël 2024'))}
    {section('', inrow(bubble('plus', 'quiet'), 'Organiser mon propre tirage', 'Pour ta famille ou tes amis', first=True))}
  </main>''', 844)

# A2 organisateur + participant
build('AccueilOrganisateur.dc.html', 'Accueil — plusieurs groupes', f'''<main style="{MAIN}">
    {greet('Camille')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant · Famille Camille</p>
        <h2 style="{CT}">Préviens chacun que le tirage est fait</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">3 personnes sur 5 n'ont pas encore reçu leur lien.</p>
      </div>
      <a href="Suivi.dc.html" style="{BTN}">Ouvrir l'édition</a>
    </section>
    <h2 style="{H2L}">Mes groupes</h2>
    {group('Famille Camille', 'Noël 2026 · fête dans 40 jours', inrow(mini('open', 'ok'), 'Mon tirage', 'Tu sais à qui tu offres', first=True, href='TirageRevoir.dc.html') + inrow(mini('gear', 'primary'), 'Gérer le tirage', 'Tirage fait · 3 à prévenir', href='Groupe.dc.html'), True)}
    {group('Amis de Camille', 'Noël 2026 · fête dans 34 jours', inrow(mini('wait'), 'Mon tirage', 'Pas encore tiré · ajoute tes idées', first=True, href='TirageAttente.dc.html') + inrow(mini('gear', 'primary'), 'Gérer le tirage', 'À préparer · 4 participants', href='Main.dc.html'), True)}
    {group('Famille Démo', 'Noël 2026 · fête dans 40 jours', inrow(mini('wait'), 'Mon tirage', 'Pas encore tiré · ajoute tes idées', first=True, href='TirageAttente.dc.html'))}
    {section('', inrow(bubble('plus', 'quiet'), 'Créer un groupe', 'Tu peux encore en créer 1', first=True) + inrow(mini('wait'), 'Tirages passés', '3 éditions clôturées'))}
  </main>''', 1330)

# A3 compte neuf
build('AccueilVide.dc.html', 'Accueil — rien pour l\'instant', f'''<main style="{MAIN}">
    {greet('Léa', '🧦', 'brick')}
    <section style="{CARD} padding: 24px 20px; display: flex; flex-direction: column; gap: 10px">
      <h2 style="{CT}">Aucun tirage pour l'instant</h2>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Dès qu'un organisateur t'ajoute avec cette adresse email, ton tirage apparaît ici.</p>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Tu as reçu un lien personnel ? Ouvre-le : tu pourras l'ajouter à ton compte.</p>
    </section>
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <h2 style="{CT}">Organiser un Secret Santa</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Dis-nous en deux lignes pour qui c'est. On te répond par email.</p>
      </div>
      <a href="#demande" style="height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Demander à créer un groupe</a>
    </section>
  </main>''', 844)

# A4 connexion
t = (P/'TirageLienInvalide.dc.html').read_text()
i = t.index('<main'); j = t.index('</main>') + len('</main>')
LOGO = '<svg role="img" aria-label="Under the Tree" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#a43a2f"/><path fill="#fffdf9" d="M32 15 44 30h-6l10 13H36v7h-8v-7H16l10-13h-6z"/><path fill="#e6b94a" d="m32 5 2.400 5 5.400.700-4 3.800 1 5.400-4.800-2.600-4.800 2.600 1-5.400-4-3.800 5.400-.700z"/></svg>'
main = f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 24px 16px 24px">
    <div style="display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center">
      {LOGO}
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 34px; line-height: 1.05; color: #a43a2f">Under the Tree</h1>
      <p style="margin: 0; font-size: 16px; line-height: 1.4; color: #57534e">Le Secret Santa de la famille : chacun découvre en secret à qui il offre un cadeau.</p>
    </div>
    <a href="#aide" style="display: flex; align-items: flex-start; gap: 12px; padding: 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; text-decoration: none">
      <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(I['link'], 18)}</span>
      <span style="display: flex; flex-direction: column; gap: 2px; font-size: 14px; line-height: 1.4"><strong style="font-size: 15px">Tu as reçu un lien personnel ?</strong>Ouvre-le directement : il fonctionne sans compte.</span>
    </a>
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 16px">
      {seg(['Se connecter', 'Créer un compte'], 0, '#f1e8d8')}
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="email" style="font-size: 15px; font-weight: 600">Adresse email</label>
        <input id="email" type="email" autocomplete="email" placeholder="toi@exemple.fr" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
        <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Pas de mot de passe : tu reçois un lien valable 15 minutes.</p>
      </div>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{ic('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>')}Recevoir mon lien de connexion</button>
    </section>
  </main>'''
(P/'Connexion.dc.html').write_text(t[:i] + main + t[j:].replace('', '') if False else (t[:i] + main + t[j:]).replace('<title>Lien invalide</title>', '<title>Connexion</title>'))
print('ok')
