import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
PILLB = lambda label: f'<span style="height: 36px; padding: 0 14px; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 14px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">{label}</span>'
def nohback(name):
    p = P/name; t = p.read_text()
    a = t.index('<button aria-label="Retour"'); b = t.index('</button>', a) + 9
    p.write_text(t[:a] + t[b:])

# 1 plusieurs tirages, sans organiser
build('AccueilPlusieurs.dc.html', 'Accueil — plusieurs tirages, participant', f'''<main style="{MAIN}">
    {greet('Hugo', '🐧', 'mustard')}
    <section style="{CARD} padding: 24px 20px 20px; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
      {SEALED}
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant · Famille Camille</p>
        <h2 style="{CT}">Le tirage est fait !</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Fête le 25 décembre, dans 40 jours.</p>
      </div>
      <a href="TirageDecouvrir.dc.html" style="{BTN}; width: 100%">Découvrir à qui j'offre un cadeau</a>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="{H2L}">Mes tirages</h2>
      <ul style="{LIST}">
{inrow(mini('sealed', 'primary'), 'Famille Camille', 'À découvrir · fête dans 40 jours', first=True, href='TirageDecouvrir.dc.html')}{inrow(mini('wait'), 'Les copains du foot', 'Pas encore tiré · fête dans 34 jours', PILLB('Mes idées'), href='TirageAttente.dc.html')}{inrow(mini('open', 'ok'), 'Bureau, 3e étage', 'Tu sais à qui tu offres · fête dans 33 jours', href='TirageRevoir.dc.html')}      </ul>
    </section>
    {section('', inrow(mini('wait'), 'Tirages passés', '4 éditions clôturées', first=True, href='TiragesPasses.dc.html') + inrow(bubble('plus', 'quiet'), 'Organiser mon propre tirage', 'Pour ta famille ou tes amis', href='PanneauDemandeGroupe.dc.html'))}
  </main>''', 1010)
nohback('AccueilPlusieurs.dc.html')

# 2 menu ouvert
t = (P/'AccueilPlusieurs.dc.html').read_text()
CHK = ic(I['check'], 18, 2.6)
def mi(label, lead='', trail='', bold=False, top=False):
    bt = ' border-top: 1px solid #e9dcc5;' if top else ''
    return f'<li role="none"><button role="menuitem" style="width: 100%; min-height: 48px; padding: 0 14px; border: 0;{bt} background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: {700 if bold else 500}; display: flex; align-items: center; gap: 10px; text-align: left">{lead}<span style="flex-grow: 1">{label}</span>{trail}</button></li>'
menu = f'''<div style="position: absolute; top: 52px; right: 12px; width: 230px; background: #fffdf9; border-radius: 12px; box-shadow: 0 8px 24px rgba(60, 30, 10, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.06); overflow: hidden">
    <p style="margin: 0; padding: 10px 14px 4px; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Langue</p>
    <ul role="menu" aria-label="Menu" style="list-style: none; margin: 0; padding: 0">
      {mi('Français', trail=f'<span style="color: #a43a2f; display: flex">{CHK}</span>', bold=True)}{mi('English')}{mi('Deutsch')}
      {mi('Mon compte', lead=ic('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.500 18.500a6.500 6.500 0 0 1 11 0"/>', 18), top=True)}{mi('Se déconnecter', lead=ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>', 18))}
    </ul>
  </div>'''
t = t.replace('display: flex; flex-direction: column">\n  <header', 'display: flex; flex-direction: column; position: relative">\n  <header', 1)
assert 'position: relative">\n  <header' in t
k = t.index('</header>') + 9
t = t[:k] + '\n  ' + menu + t[k:]
t = t.replace('<title>Accueil — plusieurs tirages, participant</title>', '<title>Accueil — menu ouvert</title>').replace('aria-label="Menu" style="justify-self', 'aria-label="Menu" aria-expanded="true" style="justify-self')
(P/'AccueilMenu.dc.html').write_text(t)

# 3 tirages passés
build('TiragesPasses.dc.html', 'Tirages passés', f'''<main style="{MAIN}">
    {head('Tirages passés', 'Les éditions clôturées auxquelles tu as participé.')}
    {section('2025', inrow(mini('open', 'ok'), 'Famille Camille', 'Noël 2025', first=True, href='TirageCloture.dc.html') + inrow(mini('open', 'ok'), 'Les copains du foot', 'Noël 2025', href='TirageCloture.dc.html') + inrow(mini('open', 'ok'), 'Bureau, 3e étage', 'Secret Santa 2025', href='TirageCloture.dc.html'))}
    {section('2024', inrow(mini('open', 'ok'), 'Famille Camille', 'Noël 2024', first=True, href='TirageCloture.dc.html'), 'Chaque ligne ouvre la page de ce tirage, en lecture seule.')}
  </main>''', 844)

# sheets
tplsheet = (P/'ConfirmerTirage.dc.html').read_text()
H1S = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15"
def sheet(name, title, back, filler, heading, desc, inner, ok, cancel_href, h=844):
    t = tplsheet
    a = t.index('<section aria-label="Lancer le tirage"'); b = t.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="{heading}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1S}">{heading}</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{desc}</p>
    </div>
{inner}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">{ok}</button>
      <a href="{cancel_href}" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    </div>
  </section>'''
    t = t[:a] + sec + t[b:]
    for old, new in [('<title>Confirmation du tirage</title>', f'<title>{title}</title>'), ('height: 150px', f'height: {filler}px'), ('font-size: 30px; color: #5c554c">Noël 2026', f'font-size: 30px; color: #5c554c">{back}'), ('height: 844px', f'height: {h}px'), ('"height":844', f'"height":{h}')]:
        assert old in t, old; t = t.replace(old, new)
    (P/name).write_text(t)

sheet('PanneauDemandeGroupe.dc.html', 'Panneau — demander un groupe', 'Bonjour Hugo', 280, 'Organiser un tirage', 'Dis-nous pour qui c’est. Un administrateur te répond par email.',
 '''    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="req" style="font-size: 15px; font-weight: 600">Ta demande</label>
      <textarea id="req" rows="4" placeholder="Le Noël de ma famille, une douzaine de personnes." style="box-sizing: border-box; width: 100%; padding: 10px 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.4; resize: none"></textarea>
      <p style="margin: 0; text-align: right; font-size: 13px; color: #57534e">0 / 500</p>
    </div>''', 'Envoyer ma demande', 'AccueilPlusieurs.dc.html')

EMOJIS = ['🎅','🤶','🧝','🦌','⛄','🎄','🎁','🌟','❄️','🍪','🥛','🧦','🧣','🧤','🍬','🍭','🎀','🐧','🦊','🦉','🍫','🥨','🍷','🌰','🍎','🍊','🫕','🎠','⛸️','🛷']
cells = ''
for e in EMOJIS:
    on = e == '🐧'
    st = 'background: #f6e3ad; box-shadow: 0 0 0 2px #b8483a;' if on else 'background: #f1e8d8;'
    cells += f'<button role="radio" aria-checked="{str(on).lower()}" aria-label="{e}" style="width: 48px; height: 48px; padding: 0; border: 0; border-radius: 50%; {st} font-size: 22px; justify-self: center">{e}</button>'
cols = ''
NAMES = {'brick': 'Rouge brique', 'pine': 'Vert sapin', 'mustard': 'Moutarde', 'kraft': 'Kraft', 'frost': 'Givre', 'plum': 'Prune'}
for k, (bg, ring) in SH.items():
    on = k == 'mustard'
    sh = f'box-shadow: 0 0 0 2px #fffdf9, 0 0 0 4px #b8483a;' if on else f'box-shadow: 0 0 0 1px {ring};'
    cols += f'<button role="radio" aria-checked="{str(on).lower()}" aria-label="{NAMES[k]}" style="width: 44px; height: 44px; padding: 0; border: 0; border-radius: 50%; background: {bg}; {sh} justify-self: center"></button>'
OV = 'margin: 0 0 8px; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
sheet('PanneauAvatar.dc.html', 'Panneau — mon icône', 'Bonjour Hugo', 40, 'Mon icône', 'Choisis ton emoji et ta couleur.',
 f'''    <div><p style="{OV}">Emoji</p><div role="radiogroup" aria-label="Emoji" style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 10px 4px">{cells}</div></div>
    <div><p style="{OV}">Couleur</p><div role="radiogroup" aria-label="Couleur" style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 4px">{cols}</div></div>''', 'Valider', 'AccueilPlusieurs.dc.html', 900)

build('GroupeNouveau.dc.html', 'Nouveau groupe', f'''<main style="{MAIN}">
    {head('Nouveau groupe', 'Une famille, une bande d’amis, une équipe : un groupe par cercle.')}
    {field('gn', 'Nom du groupe', '', 'Tu pourras le voir, toi et les membres, en haut de chaque tirage.', 'Famille Rabin', req=True)}
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; color: #274e34; margin-top: 1px">{ic(I['check'], 18, 2.600)}</span>
      <span>Tu en seras l’organisateur. Tu ajoutes les membres juste après, ou tu leur envoies un lien pour qu’ils s’inscrivent.</span>
    </div>
    <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Créer le groupe</button>
    <p style="margin: 0; text-align: center; font-size: 13px; color: #57534e">Tu peux encore créer 1 groupe.</p>
  </main>''', 844)

# links on existing home screens
for f, pairs in [('Accueil.dc.html', [('href="#" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration: none; color: #292524">\n            <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f1e8d8; color: #57534e', 'href="TiragesPasses.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration: none; color: #292524">\n            <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f1e8d8; color: #57534e')])]:
    p = P/f; t = p.read_text()
    for o, n in pairs:
        if o in t: t = t.replace(o, n, 1)
    p.write_text(t)
print('ok')
