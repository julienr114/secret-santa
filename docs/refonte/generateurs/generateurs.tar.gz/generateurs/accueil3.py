# Pistes pour un nouvel accueil, tirages et listes ensemble (Julien, 20 novembre 2026). À part, propositions.
# « Quoi de neuf » devient un onglet de la barre du bas quand on la garde.
import json,re
PJ='/home/claude/utt/project/'
base=open(PJ+'NotifAccueil.dc.html',encoding='utf-8').read()
PRE=base[:base.index('<header')]; POST=base[base.index('</nav>')+6:]
F="'Fraunces', Georgia, serif"
INK='#292524'; MUT='#57534e'; CARD='#fffdf9'; LINE='#dccbad'; SOFT='#e9dcc5'; RED='#b8483a'; DRED='#8a2f27'
def ic(p,sz=20,sw=2): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
I_TIR='<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>'
I_LIS='<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>'
I_HOME='<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>'
I_BELL='<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>'
CHEV=ic('<path d="m9 6 6 6-6 6"/>',18)
CHECK=ic('<path d="m5 12.5 4.5 4.5L19 7.5"/>',16,2.6)
AV={'🦌':('#ead2e2','#c493b4'),'🎸':('#cfe2d3','#8db898'),'🧶':('#f3d3cc','#e09e92'),'❄️':('#d6e6ef','#94bbd0'),'🐧':('#f6e3ad','#e6b94a'),'🚀':('#d6e6ef','#94bbd0'),'🦄':('#ead2e2','#c493b4'),'🎂':('#f6e3ad','#e6b94a')}
def av(e,sz=40):
    bg,bd=AV.get(e,('#f1e8d8','#dccbad'))
    return f'<span aria-hidden="true" style="width: {sz}px; height: {sz}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {bd}; display: flex; align-items: center; justify-content: center; font-size: {round(sz*0.45)}px; flex-shrink: 0">{e}</span>'
def kind(k):
    lab,i=('Tirage',I_TIR) if k=='t' else ('Liste',I_LIS)
    return f'<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 12px; font-weight: 700; color: {MUT}">{ic(i,13,2.2)}{lab}</span>'
def dot(): return f'<span aria-hidden="true" style="width: 9px; height: 9px; border-radius: 50%; background: {RED}; flex-shrink: 0"></span>'
HEADER=f'''<header style="height: 56px; flex-shrink: 0; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 0 12px">
    <div></div>
    <div style="display: flex; align-items: center; gap: 6px; font-family: {F}; font-weight: 700; font-size: 18px; color: #a43a2f">Under the Tree</div>
    <button aria-label="Mon compte" aria-haspopup="menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; display: flex; align-items: center; justify-content: center; padding: 0"><span aria-hidden="true" style="width: 34px; height: 34px; border-radius: 50%; background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 18px">🐧</span></button>
  </header>'''
def nav(active='home'):
    def tab(key,label,i,href,badge=''):
        on=key==active
        b=f'<span aria-hidden="true" style="position: absolute; top: -5px; left: 13px; min-width: 18px; height: 18px; padding: 0 5px; box-sizing: border-box; border-radius: 999px; background: {RED}; color: #ffffff; font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 2px {CARD}">{badge}</span>' if badge else ''
        return (f'<a href="{href}"{" aria-current=\"page\"" if on else ""} style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: {DRED if on else MUT}; font-size: 12px; font-weight: {700 if on else 600}">'
                f'<span style="position: relative; display: flex">{ic(i,22)}{b}</span>{label}{"<span style=\"position: absolute; width: 1px; height: 1px; overflow: hidden\">, 3 nouveautés</span>" if badge else ""}</a>')
    return f'<nav aria-label="Sections" style="margin-top: auto; position: sticky; bottom: 0; flex-shrink: 0; display: flex; background: {CARD}; border-top: 1px solid {LINE}">{tab("home","Accueil",I_HOME,"#")}{tab("news","Quoi de neuf",I_BELL,"NotifCentre.dc.html","3")}</nav>'
def page(title,main,h,withnav=True):
    p=PRE.replace('height: 844px;',f'min-height: {h}px;',1)
    p=re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',p,count=1)
    po=re.sub(r'"\$preview":\{[^}]*\}','"$preview":{"width":390,"height":%d}'%h,POST)
    return p+'\n  '+HEADER+'\n  '+main+'\n  '+(nav() if withnav else '')+po
H1=lambda t,sub='':f'<div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{t}</h1>{f"<p style=\"margin: 0; font-size: 15px; color: {MUT}\">{sub}</p>" if sub else ""}</div>'
SEC=lambda t:f'<h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {MUT}">{t}</h2>'
BTN=f'height: 48px; border: 0; border-radius: 6px; background: {RED}; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center'
BTN2=f'height: 44px; padding: 0 16px; box-sizing: border-box; border: 1px solid {LINE}; border-radius: 6px; background: {CARD}; color: {INK}; font-family: inherit; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 6px'
CARDS=f'background: {CARD}; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'
UL=f'list-style: none; margin: 0 -16px; padding: 0; background: {CARD}; border-top: 1px solid {LINE}; border-bottom: 1px solid {LINE}'
def row(lead,title,sub,first=False,right='',href='#'):
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 14px; line-height: 1.35; color: {MUT}">{sub}</span></span>{right}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>')
def date(d,m,near=False):
    return f'<span aria-hidden="true" style="width: 44px; flex-shrink: 0; display: flex; flex-direction: column; align-items: center; line-height: 1"><span style="font-family: {F}; font-weight: 700; font-size: 22px; color: {DRED if near else INK}">{d}</span><span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: {MUT}">{m}</span></span>'
TODO_CAMILLE=f'''<section style="{CARDS}; padding: 18px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; flex-direction: column; gap: 4px"><p style="margin: 0; display: flex; align-items: center; gap: 8px">{kind('t')}<span style="font-size: 12px; font-weight: 700; color: {MUT}">· Famille Camille</span></p><h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">Camille te demande des pistes</h2><p style="margin: 0; font-size: 14px; line-height: 1.45; color: {MUT}">Elle ne sait pas quoi t’offrir. Trente secondes suffisent.</p></div><a href="Pistes.dc.html" style="{BTN}">Donner des pistes</a></section>'''
FOOT=f'''<div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="ListeNouvelle.dc.html" style="{BTN2}">{ic('<path d="M12 5v14M5 12h14"/>',16,2.4)}Nouvelle liste</a><a href="GroupeNouveau.dc.html" style="{BTN2}">{ic('<path d="M12 5v14M5 12h14"/>',16,2.4)}Organiser un tirage</a></div>'''
P={}
# ---------- A. Le fil : ce qui presse, puis tout ce qui arrive, par date ----------
fil=''.join([
  row(date('19','déc'),'Bureau, 3e étage',kind('t')+' · tu sais à qui tu offres',True),
  row(date('21','déc'),'Les copains du foot',kind('t')+' · pas encore tiré'),
  row(date('24','déc'),'Noël chez Mamie',kind('l')+' · tu offres 2 cadeaux'),
  row(date('25','déc',True),'Famille Camille',kind('t')+' · le tirage est fait',right=dot()),
  row(date('25','déc',True),'Ma liste « Noël 2026 »',kind('l')+' · 9 cadeaux prévus'),
  row(date('8','fév'),'Les 40 ans de Tonton',kind('l')+' · 3 nouvelles idées',right=dot()),
])
P['AccueilPisteFil']=(page('Accueil · piste A, le fil',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 22px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    <section style="display: flex; flex-direction: column; gap: 8px">{SEC('À faire')}{TODO_CAMILLE}
      <a href="#" style="{CARDS}; padding: 14px 16px; display: flex; align-items: center; gap: 12px; text-decoration: none; color: {INK}">{av('🎸',36)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="display: flex; align-items: center; gap: 8px">{kind('l')}<span style="font-size: 12px; font-weight: 700; color: {MUT}">· Les 40 ans de Tonton</span></span><span style="font-weight: 600">Tonton a ajouté 3 idées</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Ce qui arrive')}<ul style="{UL}">{fil}</ul>
      <a href="#" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: {DRED}">Ce qui est passé</a></section>
    {FOOT}
  </main>''',1180),1180,'Piste A · Le fil : ce qui presse, puis tout ce qui arrive, tirages et listes mêlés, par date')
# ---------- B. Par fête : une carte par occasion, qui réunit son tirage et ses listes ----------
def fete(title,when,rows,big=False):
    inner=''.join(f'<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; box-sizing: border-box;{"" if i==0 else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}">{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 15px">{t}</span><span style="font-size: 13px; line-height: 1.35; color: {MUT}">{s}</span></span>{r}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>' for i,(lead,t,s,r) in enumerate(rows))
    return (f'<section style="{CARDS}; overflow: hidden"><div style="padding: 16px 16px 10px; display: flex; align-items: baseline; justify-content: space-between; gap: 12px"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: {24 if big else 19}px; line-height: 1.15">{title}</h2><span style="font-size: 13px; font-weight: 700; color: {DRED if big else MUT}; white-space: nowrap">{when}</span></div>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">{inner}</ul></section>')
tl=lambda: f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(I_TIR,18)}</span>'
ll=lambda: f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8fc; color: #5f37a6; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(I_LIS,18)}</span>'
P['AccueilPisteFetes']=(page('Accueil · piste B, par fête',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {fete('Noël en famille','dans 34 jours',[(tl(),'Tirage Famille Camille','Camille te demande des pistes',dot()),(ll(),'Ma liste « Noël 2026 »','Léo, Zoé et moi · 9 cadeaux prévus',''),(ll(),'La liste de Mamie','Le 24 décembre · tu offres 2 cadeaux','')],True)}
    {fete('Les copains du foot','21 décembre',[(tl(),'Tirage','Pas encore tiré : Karim s’en occupe','')])}
    {fete('Bureau, 3e étage','19 décembre',[(tl(),'Tirage','Tu sais à qui tu offres','')])}
    {fete('Les 40 ans de Tonton','8 février',[(ll(),'La liste de Tonton','3 nouvelles idées',dot())])}
    <a href="#" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: {DRED}">Les fêtes passées</a>
    {FOOT}
  </main>''',1260),1260,'Piste B · Par fête : une carte par occasion, avec son tirage et ses listes')
# ---------- C. Le switch : ce qui presse en commun, puis Tirages | Listes ----------
def switch(on):
    def seg(k,lab,n,d=False):
        a=k==on
        return f'<button role="tab" aria-selected="{"true" if a else "false"}" style="flex: 1; height: 40px; border: 0; border-radius: 999px; background: {CARD if a else "transparent"}; box-shadow: {"0 1px 3px rgba(60, 30, 10, 0.15)" if a else "none"}; color: {INK if a else MUT}; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 6px">{lab}<span style="font-size: 13px; font-weight: 700; color: {MUT}">{n}</span>{dot() if d else ""}</button>'
    return f'<div role="tablist" aria-label="Tirages ou listes" style="position: sticky; top: 8px; z-index: 2; display: flex; gap: 4px; padding: 4px; border-radius: 999px; background: #ece2d0">{seg("t","Tirages","3",on!="t")}{seg("l","Listes","3",on!="l")}</div>'
tir=''.join([row(av('🦌'),'Famille Camille','Le tirage est fait · fête le 25 décembre',True,dot()),row(av('🎸'),'Les copains du foot','Pas encore tiré · fête le 21 décembre'),row(av('🧶'),'Bureau, 3e étage','Tu sais à qui tu offres · fête le 19 décembre')])
lis=''.join([row(av('🧶'),'Noël chez Mamie','Le 24 décembre · tu offres 2 cadeaux',True),row(av('❄️'),'Ma liste « Noël 2026 »','Le 25 décembre · 9 cadeaux prévus'),row(av('🎸'),'Les 40 ans de Tonton','Le 8 février · 3 nouvelles idées',right=dot())])
for k,on,body,extra,t in (('AccueilPisteSwitchTirages','t',tir,f'<a href="GroupeNouveau.dc.html" style="{BTN2}; align-self: flex-start">Organiser un tirage</a>','Piste C · Le switch, sur « Tirages » : ce qui presse reste au-dessus, pour les deux'),
                          ('AccueilPisteSwitchListes','l',lis,f'<div style="display: flex; gap: 10px"><a href="ListeNouvelle.dc.html" style="{BTN2}">Nouvelle liste</a><a href="Famille.dc.html" style="{BTN2}">Mes proches</a></div>','Piste C · Le même accueil, sur « Listes »')):
    P[k]=(page('Accueil · piste C, le switch',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {TODO_CAMILLE}
    {switch(on)}
    <section style="display: flex; flex-direction: column; gap: 6px"><ul style="{UL}">{body}</ul></section>
    {extra}
  </main>''',1020),1020,t)
# ---------- D. La saison : la prochaine fête, et où j'en suis ----------
def step(state,title,sub,act=''):
    box={'done':f'<span aria-hidden="true" style="width: 26px; height: 26px; border-radius: 50%; background: #2f613f; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{CHECK}</span>',
         'todo':f'<span aria-hidden="true" style="width: 26px; height: 26px; box-sizing: border-box; border-radius: 50%; border: 2px solid {RED}; flex-shrink: 0"></span>',
         'wait':f'<span aria-hidden="true" style="width: 26px; height: 26px; box-sizing: border-box; border-radius: 50%; border: 2px dashed #a8a29e; flex-shrink: 0"></span>'}[state]
    a=f'<a href="#" style="margin-top: 8px; align-self: flex-start; {BTN}; height: 40px; padding: 0 16px; font-size: 15px">{act}</a>' if act else ''
    return (f'<li style="display: flex; gap: 12px; padding: 14px 16px; border-top: 1px solid {SOFT}">{box}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 600; font-size: 16px;{" color: #78716c;" if state=="done" else ""}">{title}</span><span style="font-size: 14px; line-height: 1.4; color: {MUT}">{sub}</span>{a}</span></li>')
P['AccueilPisteSaison']=(page('Accueil · piste D, la saison',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <section style="padding: 8px 4px 0; display: flex; flex-direction: column; gap: 2px"><p style="margin: 0; font-size: 15px; color: {MUT}">Bonjour Hugo. Noël arrive dans</p><p style="margin: 0; font-family: {F}; font-weight: 700; font-size: 56px; line-height: 1; color: {DRED}">34 jours</p></section>
    <section style="{CARDS}; overflow: hidden"><div style="padding: 14px 16px 12px; display: flex; align-items: center; justify-content: space-between"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 20px">Ton Noël</h2><span style="font-size: 13px; font-weight: 700; color: {MUT}">2 sur 5</span></div>
      <div aria-hidden="true" style="height: 4px; margin: 0 16px 12px; border-radius: 999px; background: #ece2d0"><div style="width: 40%; height: 100%; border-radius: 999px; background: #2f613f"></div></div>
      <ul style="list-style: none; margin: 0; padding: 0">
        {step('todo','Donner tes pistes à Camille','Tirage Famille Camille · elle ne sait pas quoi t’offrir','Donner des pistes')}
        {step('done','Savoir à qui tu offres au bureau','Tirage Bureau, 3e étage · fête le 19 décembre')}
        {step('done','Choisir tes cadeaux pour Mamie','Liste de Mamie · tu en offres 2, le 24 décembre')}
        {step('todo','Ajouter tes idées à ta liste','Ta liste « Noël 2026 » · rien encore pour toi')}
        {step('wait','Découvrir à qui tu offres au foot','Tirage Les copains du foot · pas encore tiré')}
      </ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Après Noël')}<ul style="{UL}">{row(date('8','fév'),'Les 40 ans de Tonton',kind('l')+' · 3 nouvelles idées',True,dot())}</ul></section>
    {FOOT}
  </main>''',1240),1240,'Piste D · La saison : la prochaine fête en grand, et où j’en suis, étape par étape')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in P.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); json.dump({k:(ht,t) for k,(h,ht,t) in P.items()},open('/tmp/accueil3.json','w'),ensure_ascii=False)
print(list(P))
