# Pistes A et C sans la grosse carte « À faire » ni son gros bouton (Julien, 20 novembre 2026). Après accueil3.py.
import json
src=open('/home/claude/gen/accueil3.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))")[0])
P2={}
def urgent(lead,title,what,first=False,href='#'):
    # une ligne comme les autres, mais ce qu'il faut faire est écrit en rouge, avec le point
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 14px; line-height: 1.35; font-weight: 700; color: {DRED}">{what}</span></span>{dot()}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>')
# ---------- C sans carte : le switch juste sous le bonjour ; ce qui presse remonte en tête de chaque côté ----------
tir2=''.join([urgent(av('🦌'),'Famille Camille','Camille te demande des pistes',True,'Pistes.dc.html'),row(av('🎸'),'Les copains du foot','Pas encore tiré · fête le 21 décembre'),row(av('🧶'),'Bureau, 3e étage','Tu sais à qui tu offres · fête le 19 décembre')])
lis2=''.join([urgent(av('🎸'),'Les 40 ans de Tonton','3 nouvelles idées',True),row(av('🧶'),'Noël chez Mamie','Le 24 décembre · tu offres 2 cadeaux'),row(av('❄️'),'Ma liste « Noël 2026 »','Le 25 décembre · 9 cadeaux prévus')])
for k,on,body,extra,t in (('AccueilPisteSwitchSansCarte','t',tir2,f'<a href="GroupeNouveau.dc.html" style="{BTN2}; align-self: flex-start">Organiser un tirage</a>','Piste C sans grosse carte · sur « Tirages » : ce qui presse remonte en tête, écrit en rouge'),
                          ('AccueilPisteSwitchSansCarteListes','l',lis2,f'<div style="display: flex; gap: 10px"><a href="ListeNouvelle.dc.html" style="{BTN2}">Nouvelle liste</a><a href="Famille.dc.html" style="{BTN2}">Mes proches</a></div>','Piste C sans grosse carte · sur « Listes »')):
    P2[k]=(page('Accueil · piste C sans grosse carte',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {switch(on)}
    <section style="display: flex; flex-direction: column; gap: 6px"><ul style="{UL}">{body}</ul></section>
    {extra}
  </main>''',900),900,t)
# ---------- A sans carte : « À faire » devient deux lignes, comme le reste ----------
fil2=''.join([
  row(date('19','déc'),'Bureau, 3e étage',kind('t')+' · tu sais à qui tu offres',True),
  row(date('21','déc'),'Les copains du foot',kind('t')+' · pas encore tiré'),
  row(date('24','déc'),'Noël chez Mamie',kind('l')+' · tu offres 2 cadeaux'),
  row(date('25','déc',True),'Famille Camille',kind('t')+' · le tirage est fait'),
  row(date('25','déc',True),'Ma liste « Noël 2026 »',kind('l')+' · 9 cadeaux prévus'),
  row(date('8','fév'),'Les 40 ans de Tonton',kind('l')+' · 3 nouvelles idées'),
])
todo2=urgent(av('🦌'),'Famille Camille','Camille te demande des pistes',True,'Pistes.dc.html')+urgent(av('🎸'),'Les 40 ans de Tonton','Tonton a ajouté 3 idées')
P2['AccueilPisteFilSansCarte']=(page('Accueil · piste A sans grosse carte',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 22px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('À faire')}<ul style="{UL}">{todo2}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Ce qui arrive')}<ul style="{UL}">{fil2}</ul>
      <a href="#" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: {DRED}">Ce qui est passé</a></section>
    {FOOT}
  </main>''',1060),1060,'Piste A sans grosse carte · « À faire » en deux lignes, comme le reste')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in P2.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P2))
