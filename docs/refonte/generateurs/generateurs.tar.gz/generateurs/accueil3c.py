# Piste B retenue (Julien, 20 novembre 2026) : la fête comme lien entre tirages et listes. Après accueil3b.py.
# 1. l'accueil : une section par saison (Noël), une carte par fête ; 2. « Nouvelle liste » demande pour quelle fête ; 3. la page d'une fête.
import json,re
src=open('/home/claude/gen/accueil3.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))")[0])
P3={}
PLUS=ic('<path d="M12 5v14M5 12h14"/>',16,2.4)
def irow(lead,t,s,r='',first=False,href='#'):
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 15px">{t}</span><span style="font-size: 13px; line-height: 1.35; color: {MUT}">{s}</span></span>{r}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>')
def addrow(t,href='#'):
    return f'<li><a href="{href}" style="display: flex; align-items: center; gap: 8px; min-height: 48px; padding: 0 16px 0 22px; border-top: 1px solid {SOFT}; text-decoration: none; color: {DRED}; font-size: 14px; font-weight: 700">{PLUS}{t}</a></li>'
def fcard(title,when,rows,add='',href='FetePage.dc.html'):
    return (f'<section style="{CARDS}; overflow: hidden"><a href="{href}" style="padding: 14px 16px 10px; display: flex; align-items: baseline; justify-content: space-between; gap: 12px; text-decoration: none; color: {INK}"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 19px; line-height: 1.15">{title}</h3><span style="font-size: 13px; font-weight: 700; color: {MUT}; white-space: nowrap">{when}</span></a>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">{rows}{(addrow(add).replace("border-top: 1px solid "+SOFT+"; ","",1) if not rows else addrow(add)) if add else ""}</ul></section>')
def season(title,when):
    return f'<div style="display: flex; align-items: baseline; justify-content: space-between; gap: 12px; padding: 6px 4px 0"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 26px; line-height: 1.1">{title}</h2><span style="font-size: 14px; font-weight: 700; color: {DRED}; white-space: nowrap">{when}</span></div>'
NOEL=(season('Noël 2026','dans 34 jours')
  +fcard('Famille Camille','25 décembre',irow(tl(),'Le tirage','Camille te demande des pistes',dot(),True)+irow(ll(),'Ma liste','Léo, Zoé et moi · 9 cadeaux prévus'))
  +fcard('Chez Mamie','24 décembre',irow(ll(),'La liste de Mamie','Tu offres 2 cadeaux','',True))
  +fcard('Les copains du foot','21 décembre',irow(tl(),'Le tirage','Pas encore tiré : Karim s’en occupe','',True),'Ma liste pour cette fête')
  +fcard('Bureau, 3e étage','19 décembre',irow(tl(),'Le tirage','Tu sais à qui tu offres','',True)))
LATER=(f'<div style="padding-top: 10px">{SEC("Plus tard")}</div>'
  +fcard('Les 40 ans de Tonton','8 février',irow(ll(),'La liste de Tonton','3 nouvelles idées',dot(),True))
  +fcard('L’anniversaire de Léo','12 mars · tous les ans','',add='Reprendre sa liste de l’an dernier'))
MAINF=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {NOEL}
    {LATER}
    <a href="#" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: {DRED}">Les fêtes passées</a>
    {FOOT.replace('href="ListeNouvelle.dc.html"','href="FeteChoisir.dc.html"')}
  </main>'''
P3['AccueilFetes2']=(page('Accueil · piste B, par fête',MAINF,1500),1500,'Piste B · une section « Noël 2026 », une carte par fête ; ce qui est relié est dans la même carte')
# ---------- 2. « Nouvelle liste » : pour quelle fête ? ----------
def opt(lead,t,s,first=False,sel=False):
    r=f'<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 50%; border: {"7px solid "+RED if sel else "2px solid #a8a29e"}; flex-shrink: 0"></span>'
    return (f'<li><button role="radio" aria-checked="{"true" if sel else "false"}" style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border: 0;{"" if first else f" border-top: 1px solid {SOFT};"} background: transparent; font-family: inherit; text-align: left; color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 13px; color: {MUT}">{s}</span></span>{r}</button></li>')
SHEET=f'''<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>
  <div role="dialog" aria-label="Pour quelle fête ?" style="position: absolute; left: 0; right: 0; bottom: 0; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">
    <span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>
    <div style="padding: 0 20px; display: flex; flex-direction: column; gap: 4px"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px">Une liste pour quelle fête ?</h2></div>
    <ul role="radiogroup" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">
      {opt(av('🦌',36),'Famille Camille','Noël, tous les ans · ton tirage',True,True)}
      {opt(av('🎸',36),'Les copains du foot','Tous les ans en décembre · ton tirage')}
      {opt(av('🧶',36),'Bureau, 3e étage','Tous les ans en décembre · ton tirage')}
      {opt(av('🚀',36),'L’anniversaire de Léo','12 mars, tous les ans · ta liste de l’an dernier')}
      {opt(f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; border: 2px dashed #a8a29e; box-sizing: border-box; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{PLUS}</span>','Une autre fête','Un anniversaire, un mariage, une crémaillère…')}
    </ul>
    <div style="padding: 0 16px"><a href="ListeNouvelle.dc.html" style="{BTN}">Continuer</a></div>
  </div>'''
h=page('Nouvelle liste · pour quelle fête ?',MAINF,1500)
h=h.replace('min-height: 1500px;','min-height: 1500px; position: relative;',1)
h=h.replace('\n  <nav aria-label="Sections"',SHEET+'\n  <nav aria-label="Sections"',1)
# l'écran visible : le panneau doit être en bas du premier écran, pas de la page entière
h=h.replace('position: absolute; left: 0; right: 0; bottom: 0; z-index: 5;','position: absolute; left: 0; right: 0; top: 400px; z-index: 5;',1)
P3['FeteChoisir']=(h,1500,'« Nouvelle liste » : pour quelle fête ? Un toucher, et le titre et la date sont déjà remplis')
# ---------- 3. la page d'une fête ----------
BACK=f'<a href="AccueilFetes2.dc.html" aria-label="Retour" style="width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; color: {INK}">{ic("<path d=\"m15 18-6-6 6-6\"/>",22)}</a>'
hd=HEADER.replace('<div></div>',f'<div>{BACK}</div>',1)
mainp=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><p style="margin: 0; font-size: 14px; font-weight: 700; color: {DRED}">Noël 2026 · 25 décembre · dans 35 jours</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Famille Camille</h1></div>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le tirage')}<ul style="{UL}">{irow(tl(),'Noël 2026','Camille te demande des pistes',dot(),True,'Pistes.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes')}<ul style="{UL}">{irow(ll(),'Ma liste','Léo, Zoé et moi · 9 cadeaux prévus','',True,'ListeTeneur.dc.html')}{irow(ll(),'La liste de Camille','Toi seul la vois ici : elle te l’a envoyée','',False)}{addrow('Ajouter une liste à cette fête','FeteChoisir.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Tous les ans à Noël')}<ul style="{UL}">{irow(f'<span aria-hidden="true" style="width: 36px; flex-shrink: 0; text-align: center; font-family: {F}; font-weight: 700; font-size: 15px; color: {MUT}">2025</span>','Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts sur les listes','',True)}{irow(f'<span aria-hidden="true" style="width: 36px; flex-shrink: 0; text-align: center; font-family: {F}; font-weight: 700; font-size: 15px; color: {MUT}">2024</span>','Noël 2024','Tu offrais à Camille')}</ul></section>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: {MUT}">Ranger une liste ici ne la montre à personne de plus : seuls ceux qui ont son lien la voient.</p>
  </main>'''
hp=page('Une fête : son tirage et ses listes',mainp,900).replace(HEADER,hd,1)
P3['FetePage']=(hp,900,'La page d’une fête : son tirage, ses listes, « Ajouter une liste à cette fête »')
FIELD=f'height: 52px; box-sizing: border-box; padding: 0 14px; border: 1px solid {LINE}; border-radius: 8px; background: {CARD}; font-family: inherit; font-size: 16px; color: {INK}; display: flex; align-items: center; justify-content: space-between'
LAB=f'font-size: 14px; font-weight: 700; color: {INK}'
SW='<span role="switch" aria-checked="true" aria-label="Elle revient chaque année" style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 23px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>'
mainn=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Une autre fête</h1>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son nom</label><div style="{FIELD}">L’anniversaire de Léo</div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Sa date</span><a href="#" style="{FIELD}; text-decoration: none">12 mars<span style="color: #78716c; display: flex">{CHEV}</span></a></div>
    <div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 4px"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Elle revient chaque année</span>{SW}</div>
    <a href="ListeNouvelle.dc.html" style="{BTN}; margin-top: 8px">Continuer</a>
  </main>'''
hn=page('Une autre fête : son nom, sa date, et si elle revient',mainn,844,withnav=False).replace(HEADER,hd,1)
P3['FeteNouvelle']=(hn,844,'« Une autre fête » : son nom, sa date, et si elle revient chaque année')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in P3.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P3))
