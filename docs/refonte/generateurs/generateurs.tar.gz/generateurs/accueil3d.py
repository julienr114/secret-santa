# La fête, deuxième version (Julien, 20 novembre 2026) : tirages et listes au même niveau, dans une fête ;
# pas de personnes dans la fête ; une catégorie à la création ; les listes partagées restent sur l'accueil. Après accueil3c.py.
import json,re
src=open('/home/claude/gen/accueil3c.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))\nfor k,(h,ht,t) in P3.items():")[0])
CAT={'Noël':('🎄','#dcefe0'),'Anniversaire':('🎂','#f6e3ad'),'Mariage':('💍','#ead2e2'),'Naissance':('🍼','#d6e6ef'),'Pot de départ':('🥂','#f3d3cc'),'Autre':('✨','#ece2d0')}
def cat(c,sz=32): e,bg=CAT[c]; return f'<span aria-hidden="true" style="width: {sz}px; height: {sz}px; border-radius: 9px; background: {bg}; display: flex; align-items: center; justify-content: center; font-size: {round(sz*0.5)}px; flex-shrink: 0">{e}</span>'
def fcard2(c,title,when,rows,add='',href='FetePage.dc.html'):
    body=rows+((addrow(add).replace(f"border-top: 1px solid {SOFT}; ","",1) if not rows else addrow(add)) if add else '')
    return (f'<section style="{CARDS}; overflow: hidden"><a href="{href}" style="padding: 12px 16px; display: flex; align-items: center; gap: 10px; text-decoration: none; color: {INK}">{cat(c)}<h3 style="flex-grow: 1; min-width: 0; margin: 0; font-family: {F}; font-weight: 700; font-size: 18px; line-height: 1.2">{title}</h3><span style="font-size: 13px; font-weight: 700; color: {MUT}; white-space: nowrap">{when}</span></a>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">{body}</ul></section>')
P4={}
NOEL2=(season('Noël 2026','dans 34 jours')
  +fcard2('Noël','Noël chez Camille','25 déc.',irow(tl(),'Famille Camille','Camille te demande des pistes',dot(),True)+irow(ll(),'Ma liste','Léo, Zoé et moi · 9 cadeaux prévus')+irow(ll(),'La liste de Camille','Elle te l’a envoyée · tu offres 1 cadeau'))
  +fcard2('Noël','Le réveillon chez Mamie','24 déc.',irow(ll(),'La liste de Mamie','Elle te l’a envoyée · tu offres 2 cadeaux','',True))
  +fcard2('Noël','Noël du foot','21 déc.',irow(tl(),'Les copains du foot','Pas encore tiré','',True),'Ajouter une liste')
  +fcard2('Noël','Noël du bureau','19 déc.',irow(tl(),'Bureau, 3e étage','Tu sais à qui tu offres','',True)))
LATER2=(f'<div style="padding-top: 10px">{SEC("Plus tard")}</div>'
  +fcard2('Anniversaire','Les 40 ans de Tonton','8 févr.',irow(ll(),'La liste de Tonton','Il te l’a envoyée · 3 nouvelles idées',dot(),True))
  +fcard2('Anniversaire','L’anniversaire de Léo','12 mars','',add='Reprendre sa liste de l’an dernier'))
NOFETE=(f'<div style="padding-top: 10px">{SEC("Sans fête")}</div><ul style="{UL}">{irow(ll(),"La liste de Zoé","Elle te l’a envoyée · aucune fête choisie","",True)}</ul>')
MAIN2=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {NOEL2}
    {LATER2}
    {NOFETE}
    <a href="#" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: {DRED}">Les fêtes passées</a>
    <div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="FeteChoisir.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="GroupeNouveau.dc.html" style="{BTN2}">{PLUS}Organiser un tirage</a></div>
  </main>'''
P4['AccueilFetes2']=(page('Accueil · piste B, par fête',MAIN2,1720),1720,'Piste B · 1. l’accueil : tirages et listes au même niveau dans chaque fête ; les listes qu’on m’a envoyées restent là')
# ---------- 2. pour quelle fête ? ----------
def opt2(lead,t,s,first=False,sel=False): return opt(lead,t,s,first,sel)
DASH=f'<span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 9px; border: 2px dashed #a8a29e; box-sizing: border-box; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{PLUS}</span>'
SHEET2=f'''<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>
  <div role="dialog" aria-label="Pour quelle fête ?" style="position: absolute; left: 0; right: 0; top: 300px; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">
    <span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>
    <h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px">Une liste pour quelle fête ?</h2>
    <ul role="radiogroup" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">
      {opt2(cat('Noël'),'Noël chez Camille','25 décembre · tous les ans',True,True)}
      {opt2(cat('Noël'),'Le réveillon chez Mamie','24 décembre · tous les ans')}
      {opt2(cat('Noël'),'Noël du foot','21 décembre · tous les ans')}
      {opt2(cat('Anniversaire'),'L’anniversaire de Léo','12 mars · tous les ans')}
      {opt2(DASH,'Une nouvelle fête','Noël, anniversaire, mariage, naissance…')}
    </ul>
    <div style="padding: 0 16px; display: flex; flex-direction: column; gap: 4px"><a href="ListeNouvelle.dc.html" style="{BTN}">Continuer</a><a href="ListeNouvelle.dc.html" style="min-height: 44px; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 700; color: {MUT}">Sans fête</a></div>
  </div>'''
h=page('Nouvelle liste · pour quelle fête ?',MAIN2,1720).replace('min-height: 1720px;','min-height: 1720px; position: relative;',1)
h=h.replace('\n  <nav aria-label="Sections"',SHEET2+'\n  <nav aria-label="Sections"',1)
P4['FeteChoisir']=(h,1720,'Piste B · 2. « Nouvelle liste » (ou « Organiser un tirage ») : pour quelle fête ? Les fêtes que je vois déjà, ou une nouvelle')
# ---------- 3. une nouvelle fête : la catégorie d'abord ----------
def tile(c,sel=False):
    e,bg=CAT[c]
    return (f'<button role="radio" aria-checked="{"true" if sel else "false"}" style="height: 84px; border: 0; border-radius: 14px; background: {bg if sel else CARD}; box-shadow: {"0 0 0 2px "+RED if sel else "0 0 0 1px "+LINE}; font-family: inherit; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; color: {INK}">'
            f'<span aria-hidden="true" style="font-size: 26px; line-height: 1">{e}</span><span style="font-size: 13px; font-weight: 700">{c}</span></button>')
mainn2=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Une nouvelle fête</h1>
    <div role="radiogroup" aria-label="C’est pour" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px">{tile('Noël')}{tile('Anniversaire',True)}{tile('Mariage')}{tile('Naissance')}{tile('Pot de départ')}{tile('Autre')}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son nom</label><div style="{FIELD}; justify-content: flex-start">L’anniversaire de Léo<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; margin-left: 1px; background: {RED}"></span></div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Sa date</span><a href="#" style="{FIELD}; text-decoration: none">12 mars<span style="color: #78716c; display: flex">{CHEV}</span></a></div>
    <div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 4px"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Elle revient chaque année</span>{SW}</div>
    <a href="ListeNouvelle.dc.html" style="{BTN}; margin-top: 4px">Continuer</a>
  </main>'''
P4['FeteNouvelle']=(page('Une nouvelle fête : la catégorie, son nom, sa date, si elle revient',mainn2,900,withnav=False).replace(HEADER,hd,1),900,'Piste B · 3. « Une nouvelle fête » : la catégorie d’abord, qui remplit le reste')
# ---------- 4. la page d'une fête : tirages et listes au même niveau ----------
yr=lambda y: f'<span aria-hidden="true" style="width: 36px; flex-shrink: 0; text-align: center; font-family: {F}; font-weight: 700; font-size: 15px; color: {MUT}">{y}</span>'
mainp2=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 8px; padding: 4px 4px 0"><span style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px 0 8px; border-radius: 999px; background: {CAT['Noël'][1]}; font-size: 13px; font-weight: 700; color: #274e34">🎄 Noël · tous les ans</span><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Noël chez Camille</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: {DRED}">25 décembre 2026 · dans 35 jours</p></div>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Dans cette fête')}<ul style="{UL}">{irow(tl(),'Famille Camille','Tirage · Camille te demande des pistes',dot(),True,'Pistes.dc.html')}{irow(ll(),'Ma liste','Liste · Léo, Zoé et moi · 9 cadeaux prévus','',False,'ListeTeneur.dc.html')}{irow(ll(),'La liste de Camille','Liste · elle te l’a envoyée')}</ul>
      <div style="display: flex; gap: 10px; flex-wrap: wrap; padding-top: 8px"><a href="ListeNouvelle.dc.html" style="{BTN2}">{PLUS}Ajouter une liste</a><a href="GroupeNouveau.dc.html" style="{BTN2}">{PLUS}Organiser un tirage</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts sur les listes','',True)}{irow(yr('2024'),'Noël 2024','Tu offrais à Camille')}</ul></section>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: {MUT}">Ranger une liste dans une fête ne la montre à personne de plus : seuls ceux qui ont son lien la voient.</p>
  </main>'''
P4['FetePage']=(page('Une fête : ses tirages et ses listes',mainp2,1000).replace(HEADER,hd,1),1000,'Piste B · 4. la page d’une fête : tirages et listes au même niveau, les années passées')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in P4.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P4))
