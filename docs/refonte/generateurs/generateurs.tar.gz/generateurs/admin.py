import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
WHY = 'Under the Tree est en bêta : la création de groupes se fait sur demande, le temps de vérifier que tout fonctionne bien.'

# ---- why closed: demande sheet ----
p = P/'PanneauDemandeGroupe.dc.html'; t = p.read_text()
old = 'Dis-nous pour qui c’est. Un administrateur te répond par email.</p>\n    </div>'
assert old in t
new = f'''Pour qui veux-tu organiser un tirage ?</p>
    </div>
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #66431d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #79511d">{ic('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.010"/>', 18)}</span>
      <span><strong style="color: #3a240c">Pourquoi une demande ?</strong> {WHY} Un administrateur lit chaque demande et te répond par email.</span>
    </div>'''
t = t.replace(old, new).replace('height: 280px', 'height: 170px')
p.write_text(t)
p = P/'AccueilVide.dc.html'; t = p.read_text()
old = "Dis-nous en deux lignes pour qui c'est. On te répond par email."
assert old in t
p.write_text(t.replace(old, WHY + ' Dis-nous pour qui c’est, on te répond par email.'))

# ---- admin screens ----
BTNO = 'height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center'
def quote(txt): return f'<p style="margin: 0; padding: 10px 12px; border-radius: 10px; background: #f1e8d8; font-size: 15px; line-height: 1.45">{txt}</p>'
def bar(v, mx, label):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px">
        <div role="progressbar" aria-valuenow="{v}" aria-valuemin="0" aria-valuemax="{mx}" aria-label="{label}" style="height: 8px; border-radius: 999px; background: #e9dcc5; overflow: hidden"><div style="width: {round(v/mx*100)}%; height: 100%; border-radius: 999px; background: #2f613f"></div></div>
      </div>'''
def arow(emoji, color, name, sub, trail='', first=False, dim=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    op = ' opacity: 0.6;' if dim else ''
    return f'''        <li>
          <a href="AdminCompte.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}{op} text-decoration: none; color: #292524">
            {av(emoji, color)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{name}</span>
              <span style="font-size: 13px; line-height: 1.35; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{sub}</span>
            </span>
            {trail}{CHEV}
          </a>
        </li>
'''
TAG = lambda label, tone='quiet': f'<span style="padding: 2px 8px; border-radius: 999px; background: {"#f9eecb" if tone == "warn" else "#f1e8d8"}; color: {"#66431d" if tone == "warn" else "#57534e"}; font-size: 12px; font-weight: 700; flex-shrink: 0">{label}</span>'
SEARCH = lambda ph: f'''<div style="position: relative">
      <label for="q" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%)">{ph}</label>
      <span aria-hidden="true" style="position: absolute; left: 14px; top: 15px; color: #57534e; display: flex">{ic('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500"/>', 18, 2.2)}</span>
      <input id="q" type="search" placeholder="{ph}" style="width: 100%; height: 48px; box-sizing: border-box; padding: 0 12px 0 42px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>'''

# 1 hub
build('Admin.dc.html', 'Administration — accueil', f'''<main style="{MAIN}">
    {head('Administration', 'Réservé aux super-admins')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À traiter · 1 demande de groupe</p>
        <div style="display: flex; align-items: center; gap: 10px">{av('🧣', 'frost')}<div style="display: flex; flex-direction: column; min-width: 0"><h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 20px; line-height: 1.2">Léa Martin</h2><p style="margin: 0; font-size: 13px; color: #57534e">lea-demo@example.com · le 14 novembre</p></div></div>
      </div>
      {quote('Le Noël de ma famille, une douzaine de personnes.')}
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">
        <a href="AdminDemande.dc.html" style="{BTNO}; text-decoration: none">Refuser</a>
        <a href="AdminDemande.dc.html" style="{BTN}">Accepter</a>
      </div>
    </section>
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 10px">
      <div style="display: flex; align-items: baseline; justify-content: space-between; gap: 8px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 20px">Capacité</h2>
        <p style="margin: 0; font-size: 14px; font-weight: 700">4 groupes sur 50 environ</p>
      </div>
      {bar(4, 50, 'Groupes dans l’application')}
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Au-delà, les offres gratuites ne suffisent plus (3 000 emails par mois).</p>
    </section>
    {section('Tout voir', inrow(bubble('users'), 'Comptes', '6 comptes · 1 désactivé', first=True, href='AdminComptes.dc.html') + inrow(bubble('doc'), 'Groupes', '4 groupes · 3 tirages en cours', href='AdminGroupes.dc.html') + inrow(bubble('gear', 'quiet'), 'Guide de style', 'Outil du développeur'))}
  </main>''', 1010)

# 2 comptes
build('AdminComptes.dc.html', 'Administration — comptes', f'''<main style="{MAIN}">
    {head('Comptes', '5 comptes actifs · 1 demande en attente')}
    {SEARCH('Chercher un nom ou une adresse')}
    {section('', arow('🧣', 'frost', 'Léa Martin', 'lea-demo@example.com · aucun groupe', TAG('À traiter', 'warn'), True) + arow('🦌', 'plum', 'Camille', 'camille-demo@example.com · 2 groupes · vue le 15 nov.') + arow('🎄', 'pine', 'Julien Rabin', 'Super-admin · 2 groupes · vu le 15 nov.') + arow('🦊', 'brick', 'Paul', 'paul-demo@example.com · 1 groupe · vu le 14 nov.') + arow('🍪', 'kraft', 'Marc', 'marc-demo@example.com · peut créer 1 groupe') + arow('🥨', 'mustard', 'Nora', 'nora-demo@example.com · demande refusée'), 'Les demandes à traiter sont en premier, la plus ancienne d’abord.')}
    {section('', inrow(bubble('archive', 'quiet'), 'Comptes désactivés', '1 compte', first=True))}
  </main>''', 900)

# 3 compte
build('AdminCompte.dc.html', 'Administration — un compte', f'''<main style="{MAIN}">
    <div style="display: flex; align-items: center; gap: 14px">
      {av('🦌', 'plum', 64, 28)}
      <div style="display: flex; flex-direction: column; gap: 2px; min-width: 0">
        <h1 style="{H1}">Camille</h1>
        <p style="margin: 0; font-size: 14px; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">camille-demo@example.com</p>
        <p style="margin: 0; font-size: 13px; color: #57534e">Dernière visite le 15 novembre</p>
      </div>
    </div>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Groupes</h2>
      <ul style="{LIST}">
        <li style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box">
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Peut en créer 3</span><span style="font-size: 14px; color: #57534e">2 déjà créés · il lui en reste 1</span></span>
          <span role="group" aria-label="Groupes qu’il peut créer" style="display: flex; align-items: center; gap: 6px; flex-shrink: 0">
            <button aria-label="Un groupe de moins" style="width: 44px; height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: #fffdf9; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0">{ic('<path d="M5 12h14"/>', 18, 2.2)}</button>
            <output style="min-width: 20px; text-align: center; font-size: 18px; font-weight: 700">3</output>
            <button aria-label="Un groupe de plus" style="width: 44px; height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: #fffdf9; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0">{ic(I['plus'], 18, 2.2)}</button>
          </span>
        </li>
{inrow(bubble('users', 'quiet'), 'Famille Camille', 'Organisatrice · 5 membres · tirage fait', href='Groupe.dc.html')}{inrow(bubble('users', 'quiet'), 'Amis de Camille', 'Organisatrice · 4 membres · à préparer', href='Groupe.dc.html')}{inrow(bubble('users', 'quiet'), 'Famille Démo', 'Participante', href='Groupe.dc.html')}      </ul>
    </section>
    {section('Accès', inrow(bubble('x', 'danger'), '<span style="color: #961d35">Désactiver le compte</span>', 'Elle ne pourra plus se connecter ; ses sessions seront fermées', first=True), 'Son profil (prénom, icône, langue) lui appartient : il ne se modifie pas d’ici.')}
  </main>''', 900)

# 4 groupes
def grow(name, sub, first=False):
    return inrow(bubble('users', 'quiet'), name, sub, first=first, href='Groupe.dc.html')
build('AdminGroupes.dc.html', 'Administration — groupes', f'''<main style="{MAIN}">
    {head('Groupes', '4 groupes · 3 tirages en cours')}
    {section('', grow('Famille Camille', 'Camille · 5 membres · tirage fait, 1 sur 5 a consulté', True) + grow('Amis de Camille', 'Camille · 4 membres · à préparer') + grow('Famille Démo', 'orga-demo@example.com · 8 membres · à préparer') + grow('Amis Démo', 'Paul · 3 membres · pas de tirage en cours') + inrow(bubble('plus'), 'Créer un groupe pour quelqu’un', 'Avec l’adresse de son organisateur', href='GroupeNouveau.dc.html'), 'Un champ de recherche apparaît au-delà de 10 groupes.')}
  </main>''', 844)

# 5 demande sheet
tpl = (P/'ConfirmerTirage.dc.html').read_text()
a = tpl.index('<section aria-label="Lancer le tirage"'); b = tpl.index('</section>', a) + len('</section>')
ARR = ic('<path d="M5 12h14M13 6l6 6-6 6"/>', 14)
def chg(label, before, after): return f'<li style="display: flex; align-items: center; gap: 10px; font-size: 14px"><span style="flex-grow: 1; color: #57534e">{label}</span><span style="color: #57534e">{before}</span><span aria-hidden="true" style="color: #78716c; display: flex">{ARR}</span><strong style="font-size: 15px">{after}</strong></li>'
sec = f'''<section aria-label="Demande de Léa Martin" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 16px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px">{av('🧣', 'frost', 48, 22)}<div style="display: flex; flex-direction: column; gap: 2px"><h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.15">Demande de Léa Martin</h1><p style="margin: 0; font-size: 14px; color: #57534e">Envoyée le 14 novembre</p></div></div>
    {quote('Le Noël de ma famille, une douzaine de personnes.')}
    <div style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Si tu acceptes</h2>
      <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px">{chg('Groupes qu’elle peut créer', '0', '1')}{chg('Groupes dans l’application', '4', '5')}</ul>
      {bar(5, 50, 'Capacité')}
      <p style="margin: 0; font-size: 13px; color: #57534e">5 sur environ 50 groupes couverts par les offres gratuites.</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="reply" style="font-size: 15px; font-weight: 600">Un mot pour elle <span style="font-weight: 400; color: #57534e">(facultatif)</span></label>
      <textarea id="reply" rows="2" placeholder="Bienvenue ! Dis-moi si tu bloques." style="box-sizing: border-box; width: 100%; padding: 10px 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.4; resize: none"></textarea>
      <p style="margin: 0; font-size: 13px; color: #57534e">Ajouté à l’email qui la prévient de ta réponse.</p>
    </div>
    <div style="margin-top: auto; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">
      <button style="{BTNO}; height: 52px">Refuser</button>
      <button style="height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Accepter</button>
    </div>
  </section>'''
t = tpl[:a] + sec + tpl[b:]
for old, new in [('<title>Confirmation du tirage</title>', '<title>Administration — répondre à une demande</title>'), ('height: 150px', 'height: 110px'), ('font-size: 30px; color: #5c554c">Noël 2026', 'font-size: 30px; color: #5c554c">Administration')]:
    assert old in t; t = t.replace(old, new)
(P/'AdminDemande.dc.html').write_text(t)
print('ok')
