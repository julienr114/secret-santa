import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
SHIELD = '<path d="M12 3 4 6v6c0 5 3.500 8 8 9 4.500-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>'
COUNT = '<span aria-label="1 demande à traiter" style="min-width: 24px; height: 24px; padding: 0 7px; box-sizing: border-box; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 13px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0">1</span>'
adminrow = inrow(f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(SHIELD, 18)}</span>', 'Administration', 'Comptes, groupes, demandes', COUNT + CHEV, first=True, href='Admin.dc.html')
main = f'''<main style="{MAIN}">
    {greet('Julien', '🎄', 'pine')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant · Administration</p>
        <h2 style="{CT}">1 demande de groupe à traiter</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Léa Martin attend ta réponse depuis le 14 novembre.</p>
      </div>
      <a href="Admin.dc.html" style="{BTN}">Voir la demande</a>
    </section>
    <h2 style="{H2L}">Mes groupes</h2>
    {group('Famille Démo', 'Noël 2026 · fête dans 40 jours', inrow(mini('wait'), 'Mon tirage', 'Pas encore tiré · ajoute tes idées', first=True))}
    {section('Super-admin', adminrow, 'Visible seulement par les super-admins.')}
  </main>'''
build('AdminAcces.dc.html', 'Administration — accès depuis l\'accueil', main, 844)
p = P/'AdminAcces.dc.html'; t = p.read_text()
a = t.index('<button aria-label="Retour"'); b = t.index('</button>', a) + 9
t = t[:a] + t[b:]
p.write_text(t)

# menu ouvert
CHK = ic(I['check'], 18, 2.6)
def mi(label, lead='', trail='', bold=False, top=False):
    bt = ' border-top: 1px solid #e9dcc5;' if top else ''
    return f'<li role="none"><button role="menuitem" style="width: 100%; min-height: 48px; padding: 0 14px; border: 0;{bt} background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: {700 if bold else 500}; display: flex; align-items: center; gap: 10px; text-align: left">{lead}<span style="flex-grow: 1">{label}</span>{trail}</button></li>'
menu = f'''<div style="position: absolute; top: 52px; right: 12px; width: 240px; background: #fffdf9; border-radius: 12px; box-shadow: 0 8px 24px rgba(60, 30, 10, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.06); overflow: hidden">
    <ul role="menu" aria-label="Menu" style="list-style: none; margin: 0; padding: 0">
      {mi('Administration', lead=ic(SHIELD, 18), trail=COUNT, bold=True)}
      {mi('Mon compte', lead=ic('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.500 18.500a6.500 6.500 0 0 1 11 0"/>', 18), top=True)}{mi('Se déconnecter', lead=ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>', 18))}
    </ul>
    <p style="margin: 0; padding: 10px 14px 4px; border-top: 1px solid #e9dcc5; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Langue</p>
    <ul role="menu" aria-label="Langue" style="list-style: none; margin: 0; padding: 0">
      {mi('Français', trail=f'<span style="color: #a43a2f; display: flex">{CHK}</span>', bold=True)}{mi('English')}{mi('Deutsch')}
    </ul>
  </div>'''
t = t.replace('display: flex; flex-direction: column">\n  <header', 'display: flex; flex-direction: column; position: relative">\n  <header', 1)
assert 'position: relative">\n  <header' in t
k = t.index('</header>') + 9
t = t[:k] + '\n  ' + menu + t[k:]
t = t.replace("<title>Administration — accès depuis l'accueil</title>", '<title>Administration — accès par le menu</title>').replace('aria-label="Menu" style="justify-self', 'aria-label="Menu, 1 demande à traiter" aria-expanded="true" style="justify-self')
(P/'AdminAccesMenu.dc.html').write_text(t)
print('ok')
