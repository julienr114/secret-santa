import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
BTNO = 'height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center'
quote = lambda txt: f'<p style="margin: 0; padding: 10px 12px; border-radius: 10px; background: #f1e8d8; font-size: 15px; line-height: 1.45">{txt}</p>'
def req(e, c, name, sub, first=False):
    return inrow(av(e, c), name, sub, first=first, href='AdminDemande.dc.html')
build('AdminPlusieursDemandes.dc.html', 'Administration — plusieurs demandes', f'''<main style="{MAIN}">
    {head('Administration', 'Réservé aux super-admins')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À traiter · 3 demandes · la plus ancienne</p>
        <div style="display: flex; align-items: center; gap: 10px">{av('🧣', 'frost')}<div style="display: flex; flex-direction: column; min-width: 0"><h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 20px; line-height: 1.2">Léa Martin</h2><p style="margin: 0; font-size: 13px; color: #57534e">lea-demo@example.com · le 12 novembre</p></div></div>
      </div>
      {quote('Le Noël de ma famille, une douzaine de personnes.')}
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">
        <a href="AdminDemande.dc.html" style="{BTNO}; text-decoration: none">Refuser</a>
        <a href="AdminDemande.dc.html" style="{BTN}">Accepter</a>
      </div>
    </section>
    {section('Les 2 suivantes', req('🦊', 'brick', 'Samir', 'Le 13 novembre · « Secret Santa de l’équipe, 8 personnes »', True) + req('🍊', 'mustard', 'ines.b@example.com', 'Le 14 novembre · « Pour ma coloc »'), 'Dès qu’une demande est traitée, la suivante prend sa place dans la carte.')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 10px">
      <div style="display: flex; align-items: baseline; justify-content: space-between; gap: 8px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 20px">Capacité</h2>
        <p style="margin: 0; font-size: 14px; font-weight: 700">4 groupes sur 50 environ</p>
      </div>
      <div role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="50" aria-label="Groupes dans l’application" style="height: 8px; border-radius: 999px; background: #e9dcc5; overflow: hidden"><div style="width: 8%; height: 100%; border-radius: 999px; background: #2f613f"></div></div>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Avec ces 3 demandes acceptées : 7 groupes.</p>
    </section>
    {section('Tout voir', inrow(bubble('users'), 'Comptes', '8 comptes · 1 désactivé', first=True, href='AdminComptes.dc.html') + inrow(bubble('doc'), 'Groupes', '4 groupes · 3 tirages en cours', href='AdminGroupes.dc.html') + inrow(bubble('gear', 'quiet'), 'Guide de style', 'Outil du développeur'))}
  </main>''', 1230)
print('ok')
