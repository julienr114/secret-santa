# « Aide à écrire » et le partage par lien : pas d'interrupteur, mais « Partager » quand c'est activé (Julien, 20 novembre 2026). Tout dernier, après lienpuce.py.
import json,re
PJ='/home/claude/utt/project/'
s=open(PJ+'ListeTeneur.dc.html',encoding='utf-8').read()
i=s.index('<div data-pub="1"')
# fin du bloc : compter les div
j=i; d=0
for m in re.finditer(r'<div\b|</div>',s[i:]):
    d+=1 if m.group(0)!='</div>' else -1
    if d==0: j=i+m.end(); break
old=s[i:j]
head=old[:old.index('>')+1]
GLOBE='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>'
LOCK='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'
SHARE='<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3"/><path d="m7 8 5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/></svg>'
T='<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; min-height: 44px"><span style="font-size: 14px; font-weight: 700; color: #292524">Partage par lien</span>{sub}</span>'
SUB='<span style="font-size: 13px; line-height: 1.3; color: #57534e">{t}</span>'
on=(head+'<div style="min-height: 48px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 8px"><span style="display: flex; color: #274e34">'+GLOBE+'</span>'
    +T.format(sub=SUB.format(t='Activé par Camille'))
    +'<button style="height: 36px; padding: 0 14px; border: 0; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; flex-shrink: 0">'+SHARE+'Partager</button></div></div>')
off=(head+'<div style="min-height: 48px; padding: 0 14px; display: flex; align-items: center; gap: 8px"><span style="display: flex; color: #57534e">'+LOCK+'</span>'
    +T.format(sub=SUB.format(t='Pas encore activé par Camille'))+'</div></div>')
names=json.load(open('/tmp/names.json'))
for k,blk in (('ListeAidePartage',on),('ListeAideSansPartage',off)):
    h=s[:i]+blk+s[j:]
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print('ok',len(old))
