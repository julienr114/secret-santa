# Plus d'air (Julien, 20 novembre 2026) : le lien à la taille du texte (16 px), 13 px au lieu de 10 au-dessus et au-dessous de chaque idée, 16 px de plus entre deux personnes. Après typo.py.
import glob,json,re
PJ='/home/claude/utt/project/'
UL='<ul style="list-style: none; margin: 6px 0 0; padding: 0 0 0 6px">'
SEC='<section style="display: flex; flex-direction: column; gap: 2px">'
out={}
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read()
    if UL not in s and 'data-lien="3"' not in s: continue
    t=s; d=0
    # le lien
    k=t.count('<span data-lien="3" style="display: flex; align-items: center; gap: 5px; margin-top: 2px; font-size: 13px; line-height: 18px;')
    t=t.replace('<span data-lien="3" style="display: flex; align-items: center; gap: 5px; margin-top: 2px; font-size: 13px; line-height: 18px;','<span data-lien="3" style="display: flex; align-items: center; gap: 6px; margin-top: 1px; font-size: 16px; line-height: 22px;')
    t=re.sub(r'(<span data-lien="3"[^>]*><svg aria-hidden="true" )width="12" height="12"',r'\1width="14" height="14"',t)
    d+=4*k
    # les idées : seulement dans les listes d'idées
    parts=t.split(UL); res=[parts[0]]
    for p in parts[1:]:
        e=p.index('</ul>'); body=p[:e]
        c=body.count('min-height: 44px; padding: 10px 0;')+body.count('min-height: 44px; padding: 10px 0 6px;')
        body=body.replace('min-height: 44px; padding: 10px 0;','min-height: 44px; padding: 13px 0;').replace('min-height: 44px; padding: 10px 0 6px;','min-height: 44px; padding: 13px 0 6px;')
        d+=6*c; res.append(body+p[e:])
    t=UL.join(res)
    # les personnes
    c=len(re.findall(r'</section>\s*'+re.escape(SEC),t))
    t=re.sub(r'(</section>\s*)'+re.escape(SEC),r'\1<section style="display: flex; flex-direction: column; gap: 2px; margin-top: 16px">',t)
    d+=16*c
    if t==s: continue
    m=re.search(r'"\$preview":\{"width":(\d+),"height":(\d+)\}',t)
    if m and d:
        h=int(m.group(2)); nh=h+d; t=t.replace(m.group(0),'"$preview":{"width":%s,"height":%d}'%(m.group(1),nh)); out[f.split('/')[-1]]=(h,nh)
    else: out[f.split('/')[-1]]=None
    open(f,'w',encoding='utf-8').write(t)
print(len(out)); json.dump(out,open('/tmp/air.json','w')); print(out)
