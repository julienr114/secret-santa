# Beaucoup plus d'espace entre deux personnes (Julien, 20 novembre 2026) : 16 -> 44 px de plus. Après toucher.py.
import glob,json,re
PJ='/home/claude/utt/project/'
A='<section style="display: flex; flex-direction: column; gap: 2px; margin-top: 16px">'
B='<section style="display: flex; flex-direction: column; gap: 2px; margin-top: 44px">'
out={}
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read(); c=s.count(A)
    if not c: continue
    t=s.replace(A,B); m=re.search(r'"\$preview":\{"width":(\d+),"height":(\d+)\}',t)
    h=int(m.group(2)); t=t.replace(m.group(0),'"$preview":{"width":%s,"height":%d}'%(m.group(1),h+28*c))
    open(f,'w',encoding='utf-8').write(t); out[f.split('/')[-1]]=28*c
print(len(out),out); json.dump(out,open('/tmp/air2.json','w'))
