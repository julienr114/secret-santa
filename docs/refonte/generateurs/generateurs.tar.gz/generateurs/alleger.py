import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
src = (P/'Envoi.dc.html').read_text()
a0 = src.index('<div style="width: 390px'); b0 = src.index('</x-dc>')
body = src[a0:b0]
def cut(s, start, end_marker, from_=0):
    i = s.index(start, from_); j = s.index(end_marker, i); return s[i:j], j
header, p = cut(body, '<div style="display: flex; align-items: center; gap: 12px">\n      <span aria-hidden="true" style="width: 48px;', '<div role="radiogroup"')
i = body.index('<button style="width: 100%; min-height: 56px;'); j = body.index('</button>', i) + 9
primary = body[i:j]
i = body.index('<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">'); j = body.index('</div>', body.index('Copier', i)) + 6
grid = body[i:j]
PASS = '<button style="height: 44px; padding: 0 8px; border: 0; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 700">Passer</button>'
header2 = header  # no « Passer »: the chaining from one person to the next is dropped
def sheet(name, title, top, inner):
    html = f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; color: #5c554c">Noël 2026</div>
  <section aria-label="Envoyer à Inès" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    {header2}
{inner}
  </section>
</div>
'''
    save(name, src[:a0] + html + src[b0:], title, 844)
LINK = 'min-height: 44px; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px'
orow = lambda t, s_, first=False, up=False: f'''    <button style="margin: 0 -16px; min-height: 56px; padding: 6px 16px; box-sizing: border-box; border: 0;{'' if first else ' border-top: 1px solid #e9dcc5;'} background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left">
      <span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 600">{t}</span><span style="font-size: 13px; color: #57534e">{s_}</span></span>{CHEV}
    </button>'''
MORE_SEND = '    <div style="margin: 0 0 -24px; display: flex; flex-direction: column">\n' + orow('Autre moyen, ou un souci ?', 'Copier le lien seul, corriger l’adresse, régénérer le lien') + '\n    </div>'
# A — aperçu de deux lignes, le reste derrière « Personnaliser »
sheet('FuturEnvoiA.dc.html', 'Idée — panneau d’envoi, piste A : personnaliser', 400, f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; font-size: 15px; line-height: 1.45"><p style="margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden">Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau : under-the-tree.party/p/aIFR…</p></div>
      <button style="{LINK}; align-self: flex-start">Personnaliser{ic('<path d="m6 9 6 6 6-6"/>', 16, 2.4)}</button>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">
      {primary}
      {grid}
    </div>
{MORE_SEND}''')
# B — d'abord les boutons, le message en une ligne
sheet('FuturEnvoiB.dc.html', 'Idée — panneau d’envoi, piste B : les boutons d’abord', 520, f'''    <div style="display: flex; flex-direction: column; gap: 10px">
      {primary}
      {grid}
    </div>
    <button style="margin: auto -16px -24px; min-height: 56px; padding: 0 16px; box-sizing: border-box; border: 0; border-top: 1px solid #e9dcc5; background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left">
      <span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 600">Message « Tirage fait », en français</span><span style="font-size: 13px; color: #57534e">Le lire, le changer, ajouter un mot</span></span>{CHEV}
    </button>''')
# C — un écran entier, des lignes de réglage
vrow = lambda t, v, first=False: f'''        <li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{'' if first else ' border-top: 1px solid #e9dcc5;'} text-decoration: none; color: #292524"><span style="flex-grow: 1; font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 15px; color: #57534e">{v}</span>{CHEV}</a></li>\n'''
page = (P/'AnnulerTirage.dc.html').read_text()
i = page.index('<main'); j = page.index('</x-dc>')
k = page.rindex('</div>', 0, j)
main = f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 20px 16px 24px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      <p style="margin: 0; font-size: 14px; font-weight: 600; color: #57534e">Famille Camille · Noël 2026</p>
      <div style="display: flex; align-items: center; gap: 12px">{av('🍭', 'mustard', 48, 22)}<div style="display: flex; flex-direction: column; gap: 2px"><h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 28px; line-height: 1.1">Envoyer à Inès</h1><p style="margin: 0; font-size: 14px; color: #57534e">Encore 3 personnes à prévenir</p></div></div>
    </div>
    <div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.45">
      <p style="margin: 0">Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :</p>
      <p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/p/aIFR…</p>
    </div>
    <ul style="{LIST}">
{vrow('Message', 'Tirage fait', True)}{vrow('Langue', 'Français')}{vrow('Un mot en plus', 'Aucun')}    </ul>
  </main>
  <footer style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 14px 16px 20px; display: flex; flex-direction: column; gap: 10px">
    {primary}
    {grid}
  </footer>
'''
t = page[:i] + main + page[k:]
t = t.replace('flex-direction: column">\n  <header', 'flex-direction: column">\n  <header', 1)
save('FuturEnvoiC.dc.html', t, 'Idée — panneau d’envoi, piste C : un écran entier', 844)
cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
for k2, (n, ti) in enumerate([('FuturEnvoiA', 'Envoi allégé · A, « Personnaliser »'), ('FuturEnvoiB', 'Envoi allégé · B, les boutons d’abord'), ('FuturEnvoiC', 'Envoi allégé · C, un écran entier')]):
    f = n + '.dc.html'
    if f not in B:
        B[f] = {'x': 940 + 470 * k2, 'y': B['FuturAccueil.dc.html']['y'], 'w': 390, 'h': 844, 'title': ti, 'page': 'divers'}; cv['order'].append(f)
cv['notes']['t21']['maxW'] = 2270
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)

# ---------- le renvoi, même principe (piste B) ----------
rs = (P/'Renvoi.dc.html').read_text(); ra = rs.index('<div style="width: 390px'); rb = rs.index('</x-dc>'); rbody = rs[ra:rb]
rheader, _ = cut(rbody, '<div style="display: flex; align-items: center; gap: 12px">\n      <span aria-hidden="true" style="width: 48px;', '<div role="radiogroup"')
i = rbody.index('<button style="width: 100%; min-height: 56px;'); j = rbody.index('</button>', i) + 9
rprimary = rbody[i:j]
def rsheet(name, title, top, inner, h=844):
    html = f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; color: #5c554c">Noël 2026</div>
  <section aria-label="Renvoyer à Hugo" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    {rheader}
{inner}
  </section>
</div>
'''
    save(name, rs[:ra] + html + rs[rb:], title, h)
rsheet('FuturRenvoi.dc.html', 'Idée — renvoi allégé', 560, f'''    {rprimary}
    <div style="margin: auto 0 -24px; display: flex; flex-direction: column">
{orow('Message « Relance », en français', 'Le lire, le changer, ajouter un mot')}
{orow('Autre moyen, ou un souci ?', 'Partager, copier, corriger l’adresse, régénérer le lien')}
    </div>''')
li = lambda t, s_='', first=False, danger=False: f'''      <li><button style="width: 100%; min-height: 56px; padding: 8px 16px; box-sizing: border-box; border: 0;{'' if first else ' border-top: 1px solid #e9dcc5;'} background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">{t}</span>{f'<span style="font-size: 13px; color: #57534e">{s_}</span>' if s_ else ''}</span></button></li>\n'''
H2s = "margin: 0; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e"
BACKIC = ic('<path d="m15 18-6-6 6-6"/>', 16, 2.4)
BACK = '<button style="align-self: flex-start; min-height: 44px; margin: -8px 0; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px">' + BACKIC + 'Retour</button>'
rsheet('FuturRenvoiOptions.dc.html', 'Idée — renvoi allégé, « Autre moyen, ou un souci ? »', 250, f'''    {BACK}
    <div style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2s}">L’email n’arrive pas</h2>
      <ul style="list-style: none; margin: 0 -16px; padding: 0; border-top: 1px solid #e9dcc5; border-bottom: 1px solid #e9dcc5">
{li('Partager par WhatsApp, SMS…', first=True)}{li('Copier le message')}{li('Copier le lien seul')}{li('Corriger son adresse email', 'hugo-demo@example.com')}      </ul>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2s}">Dépannage</h2>
      <ul style="list-style: none; margin: 0 -16px; padding: 0; border-top: 1px solid #e9dcc5; border-bottom: 1px solid #e9dcc5">
{li('Pas envoyé finalement ?', 'Remet Hugo dans « à prévenir »', True)}{li('Régénérer son lien', 'S’il a été transféré par erreur')}      </ul>
    </div>''')
cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
for k2, (n, ti) in enumerate([('FuturRenvoi', 'Renvoi allégé (piste B)'), ('FuturRenvoiOptions', 'Renvoi allégé, autres options')]):
    f = n + '.dc.html'
    if f not in B:
        B[f] = {'x': 2350 + 470 * k2, 'y': B['FuturAccueil.dc.html']['y'], 'w': 390, 'h': 844, 'title': ti, 'page': 'divers'}; cv['order'].append(f)
cv['notes']['t21']['maxW'] = 3210
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)

# ---------- A, « Personnaliser » déplié ----------
i = body.index('<div role="radiogroup"'); j = body.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">', i)
middle = body[i:j].rstrip()
sheet('FuturEnvoiADeplie.dc.html', 'Idée — panneau d’envoi, piste A : « Personnaliser » déplié', 110, f'''    <button aria-expanded="true" style="{LINK}; align-self: flex-start; margin: -8px 0">Personnaliser{ic('<path d="m6 15 6-6 6 6"/>', 16, 2.4)}</button>
    {middle}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">
      {primary}
      {grid}
    </div>
{MORE_SEND}''')
# le renvoi selon la piste A
rsheet('FuturRenvoiA.dc.html', 'Idée — renvoi allégé, piste A', 440, f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; font-size: 15px; line-height: 1.45"><p style="margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden">Petit rappel Hugo : ton lien t'attend, pense à l'ouvrir. Ton lien : under-the-tree.party/p/k9Qd…</p></div>
      <button style="{LINK}; align-self: flex-start">Personnaliser{ic('<path d="m6 9 6 6 6-6"/>', 16, 2.4)}</button>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">
      {rprimary}
    </div>
    <div style="margin: 0 0 -24px; display: flex; flex-direction: column">
{orow('Autre moyen, ou un souci ?', 'Partager, copier, corriger l’adresse, dépannage')}
    </div>''')
cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
if 'FuturRenvoiA.dc.html' not in B:
    for n in ['FuturEnvoiB', 'FuturEnvoiC', 'FuturRenvoi', 'FuturRenvoiOptions']: B[n + '.dc.html']['x'] += 470
    B['FuturRenvoiA.dc.html'] = {'x': 1880, 'y': B['FuturAccueil.dc.html']['y'], 'w': 390, 'h': 844, 'title': 'Renvoi allégé · A', 'page': 'divers'}
    cv['order'].insert(cv['order'].index('FuturEnvoiADeplie.dc.html') + 1, 'FuturRenvoiA.dc.html'); cv['notes']['t21']['maxW'] = 4150
    (P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
f = 'FuturEnvoiADeplie.dc.html'
if f not in B:
    for n in ['FuturEnvoiB', 'FuturEnvoiC', 'FuturRenvoi', 'FuturRenvoiOptions']: B[n + '.dc.html']['x'] += 470
    B[f] = {'x': 1410, 'y': B['FuturAccueil.dc.html']['y'], 'w': 390, 'h': 844, 'title': 'Envoi allégé · A, « Personnaliser » déplié', 'page': 'divers'}
    cv['order'].insert(cv['order'].index('FuturEnvoiA.dc.html') + 1, f); cv['notes']['t21']['maxW'] = 3680
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(sorted((v['x'], k) for k, v in B.items() if v['page'] == 'divers' and v['y'] == B['FuturAccueil.dc.html']['y']))

# ---------- B : ce qui s'ouvre en touchant la ligne « Message » ----------
i = rbody.index('<div role="radiogroup"'); j = rbody.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 14px">', i)
rmiddle = rbody[i:j].rstrip()
rsheet('FuturRenvoiMessage.dc.html', 'Idée — renvoi allégé, la ligne « Message » ouverte', 330, f'''    {BACK}
    {rmiddle}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
    </div>''')
cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
f = 'FuturRenvoiMessage.dc.html'
if f not in B:
    B['FuturRenvoiOptions.dc.html']['x'] += 470
    B[f] = {'x': B['FuturRenvoi.dc.html']['x'] + 470, 'y': B['FuturAccueil.dc.html']['y'], 'w': 390, 'h': 844, 'title': 'Renvoi B · « Message » ouvert', 'page': 'divers'}
    cv['order'].insert(cv['order'].index('FuturRenvoi.dc.html') + 1, f); cv['notes']['t21']['maxW'] = 4620
    (P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(B[f], B['FuturRenvoiOptions.dc.html']['x'])
