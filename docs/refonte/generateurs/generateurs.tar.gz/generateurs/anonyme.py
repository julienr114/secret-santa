# Sur la liste de quelqu'un d'autre : le mode anonyme, bien visible en haut, comme une navigation privée (Julien, 19 novembre 2026).
# Retouche les sources des listes vues par leur lien. À lancer en dernier, juste avant sorbet_all.py.
NO_WRITE=True
import io,contextlib,json
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
MASK=ic('<path d="M3 10c0-1.700 1.300-3 3-3h12c1.700 0 3 1.300 3 3v1c0 2.800-2.200 5-5 5-1.600 0-2.600-.900-3.200-2-.300-.500-.600-.800-.800-.800s-.500.300-.800.800C10.600 15.100 9.600 16 8 16c-2.800 0-5-2.200-5-5z"/><circle cx="8" cy="11" r="1.300"/><circle cx="16" cy="11" r="1.300"/>',22)
EYE=ic('<path d="M2 12s3.500-7 10-7 10 7 10 7-3.500 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',22)
def switch(on,locked=False):
    bg='#ffffff' if on else '#d6d3d1'; knob='#5b3a55' if on else '#ffffff'
    return (f'<span role="switch" aria-checked="{"true" if on else "false"}" aria-label="Mode anonyme"{" aria-disabled=\"true\"" if locked else ""} style="width: 48px; height: 28px; border-radius: 999px; background: {bg}; position: relative; flex-shrink: 0;{" opacity: 0.7;" if locked else ""}">'
            f'<span style="position: absolute; top: 3px; left: {23 if on else 3}px; width: 22px; height: 22px; border-radius: 50%; background: {knob}; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>')
HELP=ic('<circle cx="12" cy="12" r="9"/><path d="M9.500 9a2.500 2.500 0 1 1 3.500 2.300c-.600.300-1 .900-1 1.600V14M12 17h.01"/>',20)
def bar(mode,qui=None,aide=False):
    # une ligne, bords arrondis comme la barre « Publier », collée en haut quand on fait défiler ; « ? » déplie l'explication
    anon=mode!='nom'; forced=mode=='perenoel'
    bg='#5b3a55' if anon else '#fffdf9'; fg='#ffffff' if anon else '#292524'; sub='#ead2e2' if anon else '#57534e'
    # le même titre dans les deux cas : c'est un mode, activé ou non (Julien, 19 novembre 2026)
    t='Mode anonyme'
    expl={'nom':'Désactivé : quand tu coches un cadeau, ceux qui tiennent la liste voient ton prénom. Les autres voient seulement que c’est pris.',
          'anon':'Activé : quand tu coches un cadeau, personne ne voit ton prénom, pas même ceux qui tiennent la liste. Ils voient « Anonyme ». Le réglage vaut pour toute cette liste.',
          'perenoel':'Attention : tu offres un cadeau dans un tirage à quelqu’un de cette liste. Pour ne rien dévoiler, on a activé le mode anonyme. Tu offres aussi un cadeau sous ton prénom ? Désactive-le le temps de le cocher, ou touche « Changer » sous ce cadeau.'}[mode]
    row=(f'<span style="display: flex; color: {"#ffffff" if anon else "#57534e"}">{MASK if anon else EYE}</span><span style="flex-grow: 1; font-size: 14px; font-weight: 700">{t}</span>'
         f'<button aria-expanded="{"true" if aide else "false"}" aria-label="Pourquoi ?" style="width: 36px; height: 36px; border: 0; background: transparent; color: {sub}; display: flex; align-items: center; justify-content: center; padding: 0">{HELP}</button>{switch(anon)}')
    more=f'<p style="margin: 0; padding: 0 16px 14px 16px; font-size: 13px; line-height: 1.45; color: {sub}">{expl}</p>' if aide else ''
    return (f'<div data-mode="anonyme" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {bg}; color: {fg}; box-shadow: {"0 4px 14px rgba(91, 58, 85, 0.3)" if anon else "0 0 0 1px #dccbad"}">'
            f'<label style="min-height: 48px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 8px">{row}</label>{more}</div>')
M='padding: 8px 16px 24px">\n    '
OLDBAR=re.compile(r'<(?:label|div) data-mode="anonyme".*?</label>(?:<div data-note="tirage".*?Compris</button></div></div>)?(?:<p [^>]*>[^<]*</p>)?(?:</div>)?',re.S)
fait=[]
def put(n,mode,qui=None,extra=None,aide=False):
    p=PJ+n+'.dc.html'; h=open(p).read()
    if 'data-mode="anonyme"' in h: h=OLDBAR.sub(lambda m:bar(mode,qui,aide),h,count=1)
    else:
        assert h.count(M)==1,n; h=h.replace(M,M+bar(mode,qui,aide)+'\n    ',1)
        m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+80
        h=h.replace(m.group(0),f'width: 390px; height: {H}px',1); h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,h)
    if extra: h=extra(h)
    open(p,'w').write(h); fait.append(n)
put('ListeVisiteurMes','nom')
p=PJ+'ListeVisiteur.dc.html'; h=open(p).read()
if 'data-mode="anonyme"' in h:
    h=OLDBAR.sub('',h,count=1).replace(M+'\n    ',M,1); open(p,'w').write(h)
p=PJ+'ListeConnexion.dc.html'; h=open(p).read()
a='<label for="f"'; i=h.find(a)
if i>=0 and '(facultatif)' not in h[i:i+400]:
    h=re.sub(r'(<label for="f"[^>]*>)Ton prénom(</label>)',r'\1Ton prénom (facultatif)\2',h,count=1)
    h=h.replace('placeholder="Celui que Camille verra"','placeholder="Pour que Camille sache que c’est toi"',1)
    h=re.sub(r'(<input id="f"[^>]*>)',r'\1<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Sans prénom, tu coches en anonyme : personne ne saura que c’est toi.</p>',h,count=1)
    open(p,'w').write(h)
# l'avertissement est à part de la barre (Julien, 19 novembre 2026) : une note sous elle, avec une pointe vers l'interrupteur,
# qui ne bloque rien et s'en va avec « Compris ». La barre, elle, reste la même que partout.
NOTE=('<div data-note="tirage" style="position: absolute; top: 100%; left: 0; right: 0; z-index: 1; padding-top: 10px">'
      # le halo prune : un voile qui descend sur la liste, derrière la note (Julien, 19 novembre 2026)
      '<span aria-hidden="true" style="position: absolute; top: 4px; left: -16px; right: -16px; height: 480px; z-index: -1; background: linear-gradient(to bottom, rgba(91, 58, 85, 0.3), rgba(91, 58, 85, 0.22) 55%, rgba(91, 58, 85, 0)); pointer-events: none"></span>'
      '<div role="status" style="position: relative; padding: 14px 16px 6px; border-radius: 16px; background: #fffdf9; color: #292524; box-shadow: 0 0 0 1.5px #5b3a55, 0 14px 44px 6px rgba(91, 58, 85, 0.45); display: flex; flex-direction: column; gap: 6px">'
      '<span aria-hidden="true" style="position: absolute; top: -7px; right: 26px; width: 12px; height: 12px; background: #fffdf9; border-left: 1.5px solid #5b3a55; border-top: 1.5px solid #5b3a55; transform: rotate(45deg)"></span>'
      '<p style="margin: 0; font-size: 15px; font-weight: 700; line-height: 1.35; color: #292524">On a activé le mode anonyme pour toi</p>'
      '<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Tu offres un cadeau dans un tirage à quelqu’un de cette liste : tes coches ne diront pas ton prénom. Tu peux le désactiver là-haut, par exemple pour offrir aussi un cadeau sous ton prénom.</p>'
      '<button style="align-self: flex-end; min-height: 40px; padding: 0 4px; border: 0; background: transparent; color: #5b3a55; font-family: inherit; font-size: 15px; font-weight: 700">Compris</button></div></div>')
# la note est DANS la barre collée en haut : elle survole la liste sans la pousser, et suit la barre
def note(h):
    h=re.sub(r'\n    <div data-note="tirage".*?Compris</button></div>(</div>)?','',h,flags=re.S)
    i=h.index('data-mode="anonyme"'); j=h.index('</label>',i)+8
    assert h[j:j+6]=='</div>'
    return h[:j]+NOTE+h[j:]
put('ListeVisiteurTirage','anon',extra=note)
put('ListeSansPersonneVisiteur','nom')
# une liste où l'on a choisi le mode anonyme
src=open(PJ+'ListeVisiteurMes.dc.html').read()
h=OLDBAR.sub(lambda m:bar('anon'),src,count=1)
h=h.replace('Tu offres 2 cadeaux : seule Camille sait que c’est toi.','Tu offres 2 cadeaux.').replace('Tu l’offres · seul, sous ton prénom · ','Tu l’offres · anonyme · ',1)
h=re.sub(r'<title>[^<]*</title>','<title>Listes — en mode anonyme</title>',h,count=1)
open(PJ+'ListeVisiteurAnonyme.dc.html','w').write(h)
h2=OLDBAR.sub(lambda m:bar('nom',None,True),src,count=1)
h2=re.sub(r'<title>[^<]*</title>','<title>Listes — sous ton prénom (pas anonyme), l’aide dépliée</title>',h2,count=1)
open(PJ+'ListeVisiteurPrenom.dc.html','w').write(h2)
names=json.load(open('/tmp/names.json'))
if 'ListeVisiteurPrenom.dc.html' not in names: names.append('ListeVisiteurPrenom.dc.html')
json.dump(names,open('/tmp/names.json','w'))
if 'ListeVisiteurAnonyme.dc.html' not in names: names.append('ListeVisiteurAnonyme.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print(fait+['ListeVisiteurAnonyme'])
