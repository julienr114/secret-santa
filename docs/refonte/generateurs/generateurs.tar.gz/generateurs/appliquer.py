import re, shutil, os, json
exec(open('devine.py').read().split("# --- Organisateur : le réglage")[0])
exec(open('clarte.py').read().split("# 1. Suivi")[0].split("OUT2=")[1].split("\n",1)[1])
OUT3='/mnt/user-data/outputs/applique/'; os.makedirs(OUT3,exist_ok=True)
done=[]
def wide_tile(icon,title,state,todo,href):
    if todo:
        box='background: #fffdf9; box-shadow: 0 0 0 2px #b8483a'; ib,ifg='#b8483a','#ffffff'
        st=f'<span style="font-size: 14px; font-weight: 700; color: #8a2f27">{state}</span>'
    else:
        box='background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'; ib,ifg='#dbe9dd','#274e34'
        st=f'<span style="font-size: 14px; color: #57534e; display: flex; align-items: center; gap: 4px"><span style="color: #274e34; display: flex">{CHECK}</span>{state}</span>'
    return (f'<a href="{href}" style="{box}; border-radius: 16px; padding: 14px 16px; text-decoration: none; color: #292524; display: flex; align-items: center; gap: 12px">'
            f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {ib}; color: {ifg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span>'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="{F}; font-weight: 700; font-size: 18px; line-height: 1.15">{title}</span>{st}</span>{CHEV}</a>')
DOC16=DOC.replace('width="20" height="20"','width="16" height="16"')
JOURNAL=f'<a href="Journal.dc.html" style="align-self: center; min-height: 44px; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 600; color: #57534e; text-decoration: none">{DOC16}Journal du groupe</a>'
ALERT=(f'<a href="Journal.dc.html" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 16px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #3a240c; text-decoration: none">'
       f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #e6b94a; color: #3a240c; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{DOC}</span>'
       f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="{F}; font-weight: 700; font-size: 18px; line-height: 1.15">Journal du groupe</span><span style="font-size: 14px; font-weight: 700; color: #66431d">1 alerte depuis ta dernière visite</span></span>{CHEV}</a>')
tir=['TirageAttente','TirageAttenteBudgetLong','TirageDecouvrir','TirageResultat','TirageRevoir','TirageRevoirNouvelles','TirageRevoirSansPistes','TirageAlerteJournal','TirageCloture','PistesResultat','PistesResultatNouvelles','PistesResultatVide','PistesResultatDemande','ManuelTirageDeclarer','ManuelTirageAttente']
for f in tir:
    s=open(P+f+'.dc.html').read()
    k=s.index('Mes pistes de cadeaux</span>'); u=s.rfind('<ul',0,k); e=s.index('</ul>',u)+5
    sub=re.search(r'Mes pistes de cadeaux</span>\s*<span[^>]*>([^<]+)</span>',s[u:e]).group(1)
    todo=sub.startswith('Rien')
    state='À remplir' if todo else sub.replace(' · ',', ')
    block=''
    if '1 alerte' in s[u:e]: block=ALERT+'\n    '
    block+=wide_tile(LISTI,'Mes pistes de cadeaux',state,todo,'Pistes.dc.html')
    if '1 alerte' not in s[u:e]: block+='\n    '+JOURNAL
    s=s[:u]+block+s[e:]
    open(P+f+'.dc.html','w').write(s); shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append(f)
H={}
for f,sub,dh in [('Suivi','Budget 30 € · petit mot',-200),('SuiviSansDate','Date, budget, petit mot',-84),('Suivi100','Date, budget, petit mot',-84),('Suivi100Deplie','Date, budget, petit mot',-84)]:
    s=open(P+f+'.dc.html').read()
    i=s.index('Plus tard, ou en cas de pépin'); a=s.rfind('<section',0,i); b=s.index('</section>',i)+10
    new=f'''<ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
      {nav(GEAR,'Réglages de l’édition',sub,first=True,href='EditionReglages.dc.html')}
      {nav(HELP,'Un souci ?','Désistement, lien perdu, erreur de tirage',href='Souci.dc.html')}
    </ul>
    <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Personne, organisateur compris, ne voit les résultats ici.</p>'''
    s=s[:a]+new+s[b:]
    h=int(re.search(r'"height":(\d+)',s).group(1))
    s=s.replace(f'height: {h}px',f'height: {h+dh}px',1).replace(f'"height":{h}',f'"height":{h+dh}')
    open(P+f+'.dc.html','w').write(s); shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append(f); H[f]=(h,h+dh)
page('EditionReglages','Réglages de l’édition', intro('Réglages de l’édition','Ce que voient les participants de Noël 2026.')+'\n'
  +ul([val(CAL,'Date de la fête','25 décembre',first=True),val(EURO,'Budget','30 €'),val(MSG,'Petit mot','On ouvre les cadeaux…')]))
s=open(P+'PropSouci.dc.html').read().replace('<title>Proposition — un souci','<title>Un souci')
open(P+'Souci.dc.html','w').write(s)
for f in ['EditionReglages','Souci']: shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append(f)
print(H); print(len(done))
print(json.dumps([{"as":f"project/{n}.dc.html","path":P+n+".dc.html"} for n in done]))
print(json.dumps([{"stagedPath":OUT3+n+".html","devicePath":"/Users/julien.rabin/Workspace/personnal/secret-santa/docs/refonte/maquettes/"+n+".html"} for n in done]))
