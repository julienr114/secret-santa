import re, shutil, os, json
exec(open('devine.py').read().split("# --- Organisateur : le réglage")[0])
exec(open('clarte.py').read().split("# 1. Suivi")[0].split("OUT2=")[1].split("\n",1)[1])
OUT3='/mnt/user-data/outputs/applique/'; os.makedirs(OUT3,exist_ok=True)
def val(icon,title,value,first=False,href='#'):
    bt='' if first else ' border-top: 1px solid #e9dcc5;'
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">'
            f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span>'
            f'<span style="flex-grow: 1; min-width: 0; font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 15px; color: #57534e; max-width: 150px; text-align: right">{value}</span>{CHEV}</a></li>')
DOC16=DOC.replace('width="20" height="20"','width="16" height="16"')
OLDJ=f'<a href="Journal.dc.html" style="align-self: center; min-height: 44px; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 600; color: #57534e; text-decoration: none">{DOC16}Journal du groupe</a>'
NEWJ=(f'<a href="Journal.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box; border-radius: 16px; box-shadow: 0 0 0 1px #dccbad; text-decoration: none; color: #292524">'
      f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{DOC}</span>'
      f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Journal du groupe</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">Tout ce qui s’est passé, à la vue de tous</span></span>{CHEV}</a>')
tir=['TirageAttente','TirageAttenteBudgetLong','TirageDecouvrir','TirageResultat','TirageRevoir','TirageRevoirNouvelles','TirageRevoirSansPistes','TirageAlerteJournal','TirageCloture','PistesResultat','PistesResultatNouvelles','PistesResultatVide','PistesResultatDemande','ManuelTirageDeclarer','ManuelTirageAttente','PropTirage']
done=[]
for f in tir:
    s=open(P+f+'.dc.html').read()
    n=s.count(OLDJ)
    assert n==1 or f=='TirageAlerteJournal',(f,n)
    s=s.replace(OLDJ,NEWJ)
    assert 'Mes pistes de cadeaux' in s
    h=int(re.search(r'"height":(\d+)',s).group(1))
    if n: s=s.replace(f'height: {h}px',f'height: {h+24}px',1).replace(f'"height":{h}',f'"height":{h+24}')
    open(P+f+'.dc.html','w').write(s); shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append((f,h+24 if n else h))
for f in ['Suivi','SuiviSansDate','Suivi100','Suivi100Deplie']:
    s=open(P+f+'.dc.html').read(); assert 'Un souci ?' in s and 'en cas de pépin' not in s
    shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append((f,int(re.search(r'"height":(\d+)',s).group(1))))
page('EditionReglages','Réglages de l’édition', intro('Réglages de l’édition','Ce que voient les participants de Noël 2026.')+'\n'
  +ul([val(CAL,'Date de la fête','25 décembre',first=True),val(EURO,'Budget','30 €'),val(MSG,'Petit mot','On ouvre les cadeaux…')]))
s=open(P+'PropSouci.dc.html').read().replace('<title>Proposition — un souci','<title>Un souci')
open(P+'Souci.dc.html','w').write(s)
for f in ['EditionReglages','Souci']: shutil.copy(P+f+'.dc.html',OUT3+f+'.html'); done.append((f,844))
print(done)
json.dump([{"as":f"project/{n}.dc.html","path":P+n+".dc.html"} for n,_ in done],open('pub.json','w'))
json.dump([{"stagedPath":OUT3+n+".html","devicePath":"/Users/julien.rabin/Workspace/personnal/secret-santa/docs/refonte/maquettes/"+n+".html"} for n,_ in done],open('dep.json','w'))
