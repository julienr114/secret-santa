# « Qui a fait ça, et pourquoi ? » : Julien se présente, et le café (19 novembre 2026). Les textes sont un brouillon à réécrire par Julien.
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
H=1400
P='margin: 0; font-size: 16px; line-height: 1.5'
CUP=ic('<path d="M17 8h1a4 4 0 0 1 0 8h-1M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4zM6 2v2M10 2v2M14 2v2"/>',20)
OUT=ic('<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',16)
me='<span aria-hidden="true" style="width: 80px; height: 80px; border-radius: 50%; background: #d6e6ef; box-shadow: 0 0 0 1px #94bbd0; display: flex; align-items: center; justify-content: center; font-size: 36px; flex-shrink: 0">🎅</span>'
main=f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center">
      {me}
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Salut, moi c’est Julien</h1>
      <p style="margin: 0; font-size: 16px; line-height: 1.4; color: #57534e">Je suis développeur, et chaque Noël j’organise le Secret Santa de deux familles.</p>
    </div>
    <section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">Pourquoi j’ai fait ça</h2>
      <p style="{P}">Chez moi, tout le monde triche un peu. Il me fallait un tirage que même l’organisateur ne peut pas regarder, et un journal où tout se voit.</p>
      <p style="{P}">Pour les listes de cadeaux, je tenais une page à la main chaque année. Elle est devenue l’onglet « Listes ».</p>
      <p style="{P}">Je l’ai faite pour les miens. Si elle sert aussi chez toi, tant mieux.</p>
    </section>
    <section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">Mon métier</h2>
      <p style="{P}">Je conçois et je développe des applications web. Celle-ci est aussi ma vitrine : elle montre ce que je sais faire.</p>
      <p style="{P}">Tu as un projet ? Parlons-en.</p>
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px"><a href="#" style="{BTN2}">LinkedIn<span style="display: flex">{OUT}</span></a><a href="#" style="{BTN2}">GitHub<span style="display: flex">{OUT}</span></a></div>
    </section>
    <section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">Un café ?</h2><p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">L’application ne montre aucune publicité. Un café paie le nom de domaine et, si elle grandit, l’hébergement.</p></div>
      <a href="#" style="{BTN}">{CUP}M’offrir un café<span style="display: flex; opacity: 0.85">{OUT}</span></a>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Le paiement se fait sur un autre site. Rien n’est demandé dans l’application.</p>
    </section>
    <p style="margin: 0; text-align: center; font-size: 15px; line-height: 1.45; color: #57534e">Une idée, un souci ? <a href="#" style="{A}; font-weight: 600">Écris-moi</a></p>'''
s=HEAD+f'''<div style="width: 390px; height: {H}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header('FR')}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 16px 16px 24px">
    {main}
  </main>
</div>
'''+TAIL
s=re.sub(r'<title>[^<]*</title>','<title>Under the Tree — qui a fait ça, et pourquoi</title>',s)
s=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,s)
open(PJ+'APropos.dc.html','w').write(s)
names=json.load(open('/tmp/names.json'))
if 'APropos.dc.html' not in names: names.append('APropos.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print(len(s))
