# Lot 40 : brancher un assistant (MCP). L'écran d'autorisation, et « Mes assistants » dans le compte (19 novembre 2026)
import io,contextlib,json
NO_WRITE=True
src=open('/home/claude/gen/garde2.py').read()
with contextlib.redirect_stdout(io.StringIO()): exec(src.split("# ---------- Lot 39 : signaler")[0])
M={}
BTNN='height: 48px; box-sizing: border-box; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
CK='<path d="m5 12 5 5 9-10"/>'; XX='<path d="M6 6l12 12M18 6 6 18"/>'
YES=f'<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px">{ic(CK,14,3)}</span>'
NOI=f'<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px">{ic(XX,12,3)}</span>'
def li(i,t): return f'<li style="display: flex; align-items: flex-start; gap: 10px; font-size: 15px; line-height: 1.45">{i}<span>{t}</span></li>'
LS='list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px'
def chk(t,d,on,top=True):
    b=f'<span role="checkbox" aria-checked="{"true" if on else "false"}" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 6px; border: 2px solid {"#b8483a" if on else "#a8a29e"}; background: {"#b8483a" if on else "#fffdf9"}; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(CK,14,3) if on else ""}</span>'
    return f'<label style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 14px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}">{b}<span style="display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 16px">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span></label>'
M['AssistantAutoriser']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 10px"><p style="{SM}">Connecté : Camille Morel</p><h1 style="{H1}">Brancher un assistant ?</h1><p style="{P}">« Mon assistant » demande à accéder à ton compte Under the Tree.</p></div>
    <div role="group" aria-label="Ce que tu autorises" style="{RGS}">{chk('Lire','Tes listes, tes pistes, où en sont tes tirages',True,False)}{chk('Modifier','Ajouter et changer des idées sur tes listes, tes pistes',True)}</div>
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Ce qu’il ne pourra jamais faire</h2><ul style="{LS}">{li(NOI,'<strong>Savoir qui offre à qui.</strong> Aucun résultat de tirage ne lui est donné, pas même le tien.')}{li(NOI,'Voir qui a coché un cadeau.')}{li(NOI,'Envoyer un email, partager une liste, lancer un tirage, supprimer quoi que ce soit.')}</ul></section>
    <div role="note" style="{NOTE}"><span><strong>Ce qu’il lit part chez son éditeur.</strong> Les prénoms et les âges de ta famille, tes idées de cadeaux : c’est toi qui choisis de les lui confier. Tu peux le débrancher à tout moment dans « Mon compte ».</span></div>
    <div style="display: flex; flex-direction: column; gap: 10px"><a href="CompteAssistants.dc.html" style="{BTN}">Autoriser</a><a href="#" style="{BTNN}">Refuser</a></div>
    <p style="{SM}; text-align: center"><a href="Confidentialite.dc.html" style="{A}">Tes données, en clair</a></p>''','Assistant — l’écran d’autorisation'),900,'Brancher un assistant : ce qu’on autorise, ce qui reste interdit')
def arow(n,d,top=True): return f'<li style="display: flex; align-items: center; gap: 12px; min-height: 72px; padding: 10px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}"><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 700; font-size: 16px">{n}</span><span style="font-size: 14px; color: #57534e">{d}</span></span><button style="height: 40px; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">Débrancher</button></li>'
def jrow(t,d,top=True): return f'<li style="display: flex; flex-direction: column; gap: 2px; min-height: 52px; justify-content: center; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}"><span style="font-size: 15px">{t}</span><span style="font-size: 13px; color: #57534e">{d}</span></li>'
M['CompteAssistants']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Mon compte</p><h1 style="{H1}">Mes assistants</h1><p style="{P}">Les assistants que tu as branchés à ton compte.</p></div>
    <ul style="{UL}">{arow('Mon assistant','Lire et modifier · branché le 12 janvier · utilisé hier',False)}</ul>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Ce qu’il a fait, ces 30 derniers jours</h2>
      <ul style="{UL}">{jrow('A ajouté « Un vélo 16 pouces » à la liste « Noël 2027 »','hier, 18 h 42',False)}{jrow('A lu la liste « Noël 2027 »','hier, 18 h 41')}{jrow('A lu où en est « Famille Camille · Noël 2027 »','le 14 janvier')}</ul>
      <p style="{SM}">Tout ce qu’un assistant change est noté ici, et peut être défait depuis la liste.</p></section>
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Brancher un assistant</h2><p style="{P}">Dans ton assistant, ajoute un connecteur avec cette adresse. Il te ramènera ici pour autoriser.</p>
      <div style="display: flex; align-items: center; gap: 10px; padding: 8px 8px 8px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 15px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/mcp</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">Copier</button></div></section>
    <p style="{SM}">Aucun assistant ne peut savoir qui offre à qui.</p>''','Compte — mes assistants branchés'),844,'« Mes assistants » : débrancher, voir ce qu’il a fait')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in M.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h); open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(M))
