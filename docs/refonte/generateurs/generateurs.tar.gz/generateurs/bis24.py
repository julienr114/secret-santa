# Lot 24 bis : les états qui n'avaient pas de maquette (19 novembre 2026). À lancer après personnemenu.py.
import re,json
PJ='/home/claude/utt/project/'
exec(open('/home/claude/gen/personnemenu.py').read().split("HEAD=re.compile")[0].split("import re,glob,os,json")[1])  # DOTS, btn
def toast(t): return f'<div role="status" style="position: sticky; bottom: 16px; margin-top: auto; align-self: stretch; min-height: 52px; padding: 0 8px 0 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; justify-content: space-between; gap: 12px; font-size: 15px; font-weight: 600">{t}<button style="min-height: 44px; padding: 0 10px; border: 0; background: transparent; color: #f6c9c0; font-family: inherit; font-size: 15px; font-weight: 700">Annuler</button></div>\n  '
def title(h,t): return re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
def add_toast(h,t):
    k=h.rindex('</main>'); return h[:k]+'  '+toast(t)+h[k:]
out={}
# 1. changer de lien : la confirmation sur place
h=open(PJ+'ListeEtatPubliee.dc.html').read()
m=re.search(r'<p style="margin: 0; display: flex; flex-wrap: wrap; gap: 4px 16px; font-size: 14px; font-weight: 700">.*?Changer de lien</a></p>',h,re.S); assert m
conf=('<div role="alertdialog" aria-label="Changer de lien" style="padding: 12px 14px; border-radius: 14px; background: #f1e8d8; display: flex; flex-direction: column; gap: 10px">'
 '<p style="margin: 0; font-size: 15px; line-height: 1.45"><strong>Changer de lien ?</strong> L’ancien lien ne marchera plus : il faudra renvoyer le nouveau. Ceux qui ont un compte et ont déjà ouvert la liste la gardent.</p>'
 '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><button style="height: 44px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700">Annuler</button><button style="height: 44px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 700">Changer</button></div></div>')
out['ListeChangerLien']=(title(h.replace(m.group(0),conf),'Listes — changer de lien, la confirmation sur place'),'Changer de lien : la confirmation, dans la barre')
# 2. le partage arrêté
h=open(PJ+'ListeEtatBrouillon.dc.html').read()
out['ListePartageArrete']=(title(add_toast(h,'Partage par lien arrêté'),'Listes — le partage vient d’être arrêté'),'On éteint l’interrupteur : c’est fait, avec « Annuler »')
# 3. retirer quelqu'un : immédiat, avec « Annuler »
h=open(PJ+'ListeTeneur.dc.html').read()
k=h.index('>Hugo</h2>'); a=h.rindex('<section',0,k); b=h.index('</section>',k)+10
out['ListePersonneRetiree']=(title(add_toast(h[:a]+h[b:],'Hugo retiré de la liste'),'Listes — une personne vient d’être retirée'),'Retirer quelqu’un qui n’a aucune idée cochée : immédiat')
# 4. retirer quelqu'un dont des idées sont cochées : un second appui
h=open(PJ+'ListeTeneur.dc.html').read(); b0=btn('Léo'); assert h.count(b0)==1,h.count(b0)
pop=(f'<div style="position: relative; margin-left: auto; flex-shrink: 0">{btn("Léo",True).replace("margin-left: auto; ","")}'
 '<div role="alertdialog" aria-label="Retirer Léo" style="position: absolute; top: 44px; right: 0; z-index: 3; width: 280px; padding: 14px; border-radius: 16px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad, 0 12px 28px rgba(41, 37, 36, 0.18); display: flex; flex-direction: column; gap: 10px">'
 '<p style="margin: 0; font-size: 15px; line-height: 1.45"><strong>Retirer Léo de la liste ?</strong> Ses idées partent avec lui, et 3 cadeaux déjà prévus pour lui seront perdus. Il reste dans ta famille.</p>'
 '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><button style="height: 44px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700">Annuler</button><button style="height: 44px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 15px; font-weight: 700">Retirer Léo</button></div></div></div>')
out['ListePersonneRetirer']=(title(h.replace(b0,pop),'Listes — retirer quelqu’un dont des cadeaux sont prévus'),'Retirer quelqu’un dont des cadeaux sont prévus : un second appui')
names=json.load(open('/tmp/names.json')); meta={}
for k,(h,t) in out.items():
    open(PJ+k+'.dc.html','w').write(h); meta[k]=[int(re.search(r'width: 390px; height: (\d+)px',h).group(1)),t]
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); json.dump(meta,open('/tmp/bis24.json','w'),ensure_ascii=False); print(meta)
