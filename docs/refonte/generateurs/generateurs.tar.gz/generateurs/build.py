import re, pathlib
P = pathlib.Path('/home/claude/utt/project')
src = (P/'TirageAttente.dc.html').read_text()

def sub(text, tag_open_prefix, close, new):
    i = text.index(tag_open_prefix); j = text.index(close, i) + len(close)
    return text[:i] + new + text[j:]

CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
STAR = '<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
def step(kind, label, line=None, current=False):
    dots = {
      'done': f'<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; border-radius: 50%; background: #2f613f; color: #ffffff; display: flex; align-items: center; justify-content: center">{CHECK}</span>',
      'now': f'<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 4px #f6e2dd; color: #ffffff; display: flex; align-items: center; justify-content: center">{STAR}</span>',
      'todo': '<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; background: #f7f2e9; border: 2px solid #dccbad"></span>',
    }
    ln = f'<span aria-hidden="true" style="position: absolute; top: 11px; left: 50%; width: 100%; height: 2px; background: {line}"></span>' if line else ''
    lab = ('font-weight: 700; color: #8a2f27' if current else 'font-weight: 600; color: #57534e')
    cur = ' aria-current="step"' if current else ''
    return f'''      <li{cur} style="display: flex; flex-direction: column; align-items: center; gap: 6px; position: relative">
        {ln}
        {dots[kind]}
        <span style="font-size: 12px; {lab}; text-align: center">{label}</span>
      </li>
'''
def stepper(items):
    return '<ol aria-label="Étapes de l\'édition" style="list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr))">\n' + ''.join(items) + '    </ol>'
DRAWN = stepper([step('done','Invitation','#2f613f'), step('now','Tirage fait','#e9dcc5',True), step('todo','Fête · dans 40 jours')])
CLOSED = stepper([step('done','Invitation','#2f613f'), step('done','Tirage fait','#2f613f'), step('done','Fête passée')])

CARD = 'background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05);'
GIFT = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/></svg>'
SEALED = '''<svg aria-hidden="true" width="184" height="128" viewBox="0 0 184 128" fill="none">
        <rect x="6" y="14" width="172" height="108" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
        <path d="M7 118 70 66M177 118 114 66" stroke="#cdb48a" stroke-width="2" stroke-linecap="round"/>
        <path d="M8 18 84 74a13 13 0 0 0 16 0l76-56" fill="#f1e8d8" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
        <circle cx="92" cy="78" r="22" fill="#b8483a"/>
        <circle cx="92" cy="78" r="17" fill="none" stroke="#8a2f27" stroke-width="1.5"/>
        <path d="M92 65l2.9 10.1L105 78l-10.1 2.9L92 91l-2.9-10.1L79 78l10.1-2.9z" fill="#f9eecb"/>
      </svg>'''
OPENED = '''<svg aria-hidden="true" width="184" height="128" viewBox="0 0 184 128" fill="none">
        <rect x="38" y="4" width="108" height="84" rx="6" fill="#fffdf9" stroke="#cdb48a" stroke-width="2"/>
        <path d="M92 16l2.6 9.4L104 28l-9.4 2.6L92 40l-2.6-9.4L80 28l9.4-2.600z" fill="#b8483a"/>
        <path d="M58 50h68" stroke="#dccbad" stroke-width="3" stroke-linecap="round"/>
        <rect x="6" y="46" width="172" height="76" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
        <path d="M8 50 92 102l84-52" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
      </svg>'''
def card(svg, title, body, btn, btn_style, foot):
    styles = {
      'solid': 'border: 0; background: #b8483a; color: #ffffff;',
      'outline': 'box-sizing: border-box; border: 1px solid #b8483a; background: transparent; color: #8a2f27;',
    }
    return f'''<section style="{CARD} padding: 28px 24px 24px; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">
      {svg}
      <div style="display: flex; flex-direction: column; gap: 6px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.2">{title}</h2>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{body}</p>
      </div>
      <button style="width: 100%; height: 48px; border-radius: 6px; {styles[btn_style]} font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">
        {GIFT}
        {btn}
      </button>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">{foot}</p>
    </section>'''

def make(name, title, steps, cardhtml, wishes_sub, height=844):
    t = src.replace('<title>Mon tirage — avant le tirage</title>', f'<title>{title}</title>')
    t = sub(t, '<ol aria-label', '</ol>', steps)
    t = sub(t, '<section style="background', '</section>', cardhtml)
    t = t.replace("Aucune idée pour l'instant", wishes_sub)
    t = t.replace('height: 844px', f'height: {height}px').replace('"height":844', f'"height":{height}')
    (P/name).write_text(t)

make('TirageDecouvrir.dc.html', 'Mon tirage — à découvrir', DRAWN,
     card(SEALED, "Ton enveloppe t'attend", "Le tirage est fait. Assure-toi que personne ne regarde ton écran avant de l'ouvrir.", "Découvrir à qui j'offre un cadeau", 'solid', "Ton résultat se referme dès que tu quittes la page."),
     "3 idées · modifiable jusqu'à la fête")
make('TirageRevoir.dc.html', 'Mon tirage — déjà découvert', DRAWN,
     card(OPENED, "Tu sais déjà à qui tu offres", "Un trou de mémoire ? Assure-toi que personne ne regarde ton écran.", "Revoir à qui j'offre un cadeau", 'outline', "Sa liste contient 3 idées de cadeaux."),
     "3 idées · modifiable jusqu'à la fête")
make('TirageCloture.dc.html', 'Mon tirage — édition clôturée', CLOSED,
     card(OPENED, "La fête est passée", "Cette édition est clôturée. Tu peux encore revoir à qui tu as offert un cadeau.", "Revoir à qui j'offre un cadeau", 'outline', "Rendez-vous l'an prochain !"),
     "3 idées · plus modifiable")

# Résultat
RES = f'''<section aria-live="polite" style="{CARD} padding: 14px 24px 24px; display: flex; flex-direction: column; gap: 20px">
      <span aria-hidden="true" style="align-self: center; width: 18px; height: 18px; box-sizing: border-box; border-radius: 50%; background: #f7f2e9; border: 2px solid #cdb48a"></span>
      <div style="display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center">
        <p style="margin: 0; font-size: 15px; color: #57534e">Tu offres un cadeau à</p>
        <span aria-hidden="true" style="width: 80px; height: 80px; border-radius: 50%; background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 36px">🍭</span>
        <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 52px; line-height: 1; color: #a43a2f">Inès</p>
      </div>
      <dl style="margin: 0; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px">
        <div style="display: flex; flex-direction: column; gap: 2px; padding: 10px 12px; border-radius: 10px; background: #f1e8d8">
          <dt style="font-size: 12px; font-weight: 600; color: #57534e">Budget</dt>
          <dd style="margin: 0; font-size: 16px; font-weight: 700">30 €</dd>
        </div>
        <div style="display: flex; flex-direction: column; gap: 2px; padding: 10px 12px; border-radius: 10px; background: #f1e8d8">
          <dt style="font-size: 12px; font-weight: 600; color: #57534e">Date</dt>
          <dd style="margin: 0; font-size: 16px; font-weight: 700">Ven. 25 décembre</dd>
        </div>
      </dl>
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Le mot de l'organisateur</p>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; font-style: italic">On ouvre les cadeaux après le dessert !</p>
      </div>
      <div style="height: 0; border-top: 2px dashed #dccbad"></div>
      <div style="display: flex; flex-direction: column; gap: 12px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 20px">Ses idées de cadeaux</h2>
        <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 12px">
          <li style="display: flex; align-items: flex-start; gap: 10px">
            <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#d9a62e" style="flex-shrink: 0; margin-top: 4px"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>
            <span style="font-size: 16px; line-height: 1.4">Un roman policier</span>
          </li>
          <li style="display: flex; align-items: flex-start; gap: 10px">
            <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#d9a62e" style="flex-shrink: 0; margin-top: 4px"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>
            <span style="display: flex; flex-direction: column; gap: 2px; min-width: 0">
              <span style="font-size: 16px; line-height: 1.4">Un jeu de société pour deux</span>
              <a href="#lien" style="min-height: 32px; display: flex; align-items: center; gap: 5px; font-size: 14px; font-weight: 600; color: #8a2f27">
                Voir le lien
                <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
              </a>
            </span>
          </li>
          <li style="display: flex; align-items: flex-start; gap: 10px">
            <svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#d9a62e" style="flex-shrink: 0; margin-top: 4px"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>
            <span style="font-size: 16px; line-height: 1.4">Des chaussettes bien chaudes</span>
          </li>
        </ul>
      </div>
    </section>

    <div style="display: flex; flex-direction: column; gap: 8px">
      <button style="width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: #f1e8d8; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.4 5.2A9.500 9.500 0 0 1 12 5c6 0 9.500 7 9.500 7a15 15 0 0 1-2.600 3.500M6.200 6.200A15 15 0 0 0 2.500 12S6 19 12 19a9.400 9.400 0 0 0 4-.900"/></svg>
        Cacher mon résultat
      </button>
      <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Il se referme tout seul quand tu quittes la page.</p>
    </div>'''
make('TirageResultat.dc.html', 'Mon tirage — résultat affiché', DRAWN, RES, "3 idées · modifiable jusqu'à la fête", 1100)

# Lien invalide
t = src.replace('<title>Mon tirage — avant le tirage</title>', '<title>Lien invalide</title>')
i = t.index('<main'); j = t.index('</main>') + len('</main>')
INV = '''<main style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 96px 32px 24px; text-align: center">
    <svg aria-hidden="true" width="184" height="128" viewBox="0 0 184 128" fill="none">
      <rect x="6" y="14" width="172" height="108" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
      <path d="M8 18 84 74a13 13 0 0 0 16 0l76-56" fill="#f1e8d8" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
      <circle cx="92" cy="78" r="24" fill="#fffdf9" stroke="#cdb48a" stroke-width="2"/>
      <rect x="82" y="76" width="20" height="15" rx="3" fill="#57534e"/>
      <path d="M86 76v-5a6 6 0 0 1 12 0v5" stroke="#57534e" stroke-width="3" stroke-linecap="round"/>
    </svg>
    <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 28px; line-height: 1.15">Oups, ce lien ne marche plus</h1>
    <p role="alert" style="margin: 0; font-size: 16px; line-height: 1.5; color: #57534e">Ce lien n'est plus valable. Demande-en un nouveau à ton organisateur.</p>
    <a href="#connexion" style="margin-top: 8px; min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 600; color: #8a2f27">J'ai un compte : me connecter</a>
  </main>'''
(P/'TirageLienInvalide.dc.html').write_text(t[:i] + INV + t[j:])
