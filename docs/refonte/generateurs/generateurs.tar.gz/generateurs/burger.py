# Une personne connectée a le menu (burger) en haut à droite, plus le bouton de langue (Correction 19). À lancer après anonyme.py.
import re,json
PJ='/home/claude/utt/project/'
BURGER='<button aria-label="Menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>'
FR=re.compile(r'<button aria-label="Langue : français"[^>]*>FR</button>')
CONNECTES=['ListeTeneur','ListeNouvelle','ListeNouvelleReprendre','ListeReprise','ListeLiveTeneur','ListeTeneurs','ListePersonneCompte','ListeVueReliee','ListeIdee','ListeIdeeLien','ListeIdeeLienFait','ListeHorsListe',
  'ListeEtatBrouillon','ListeEtatPubliee','ListeSansPersonne','ListeSansPersonneVisiteur','ListeVisiteurMes','ListeVisiteurPrenom','ListeVisiteurAnonyme','ListeVisiteurTirage','ListeSuivre',
  'ListesAccueil','ListesVide','ListeIcone','ListePersonne','PistesListe','PistesResultatListe','CompteDonnees','StopSaisie','StopEnvoi']
fait=[]
for n in CONNECTES:
    p=PJ+n+'.dc.html'
    try: h=open(p).read()
    except FileNotFoundError: continue
    g=FR.sub(BURGER,h)
    if g!=h: open(p,'w').write(g); fait.append(n)
print(fait)
