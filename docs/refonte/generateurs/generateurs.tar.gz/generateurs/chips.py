# Vue du visiteur : plus de texte volant sous une idée, tout en pastilles, avec des icônes (Julien, 20 novembre 2026). Après souscase.py.
import glob,json,re
PJ='/home/claude/utt/project/'
def ic(p): return f'<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
GIFT=ic('<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8"/><path d="M12 8c-1.5-4-6-4.500-6-1.500C6 8 9 8 12 8zm0 0c1.500-4 6-4.500 6-1.500C18 8 15 8 12 8z"/>')
EYEOFF=ic('<path d="M3 3l18 18"/><path d="M10.600 6.200A9.500 9.500 0 0 1 12 6c5 0 8.500 4.500 9.500 6a14 14 0 0 1-2.600 3.200M6.300 7.700A14 14 0 0 0 2.500 12c1 1.500 4.500 6 9.500 6 1.300 0 2.500-.300 3.600-.800"/><path d="M9.900 9.900a3 3 0 0 0 4.200 4.200"/>')
MASK=ic('<path d="M2.500 9.500c0-1.500 1-2.500 2.500-2.500 2.500 0 4.500 1.500 7 1.500s4.500-1.500 7-1.500c1.500 0 2.500 1 2.500 2.500 0 4.500-2.500 7.500-5.500 7.500-2 0-2.700-1.800-4-1.800s-2 1.800-4 1.800c-3 0-5.500-3-5.500-7.500z"/><path d="M7 11.500h2.500M14.500 11.500H17"/>')
USER=ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>')
USERS=ic('<circle cx="9" cy="8" r="3.500"/><path d="M2.500 20a6.500 6.500 0 0 1 13 0"/><path d="M16 4.800a3.500 3.500 0 0 1 0 6.400M18 14.500a6.500 6.500 0 0 1 3.500 5.500"/>')
PEN=ic('<path d="M4 20h4L19.500 8.500a2.100 2.100 0 0 0-3-3L5 17z"/>')
PLUS=ic('<path d="M12 5v14M5 12h14"/>')
CHECK=ic('<path d="m5 12.500 4.500 4.500L19 7.500"/>')
CLOCK=ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>')
B='display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 700; border-radius: 999px; text-decoration: none; white-space: nowrap; '
def info(t,i=''): return f'<span data-chip="info" style="{B}color: #57534e; background: #f1e8d8; padding: 1px 8px{" 1px 6px" if i else ""}">{i}{t}</span>'
def state(t,i): return f'<span data-chip="etat" style="{B}color: #274e34; background: #dcefe0; padding: 1px 8px 1px 6px">{i}{t}</span>'
def anon(t,i): return f'<span data-chip="anonyme" style="{B}color: #ffffff; background: #5b3a55; padding: 1px 8px 1px 6px">{i}{t}</span>'
def act(t,i): return f'<span data-chip="action" role="button" style="{B}color: #292524; background: #fffdf9; box-shadow: inset 0 0 0 1.500px #a8a29e; padding: 1px 9px 1px 6px">{i}{t}</span>'
ROW='<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px; text-decoration: none">'
# 1. « Tu l'offres · … · Changer »
MINE=re.compile(r'(?:(<span data-par="1"[^>]*>(?:(?!</span></span>).)*</span>)</span>)?<span style="display: block; font-size: 13px;[^>]*>Tu l’offres · ([^<]*?) · <span[^>]*>Changer</span></span>',re.S)
def mine(m):
    # une seule pastille d'état (Julien, 20 novembre 2026) : aubergine et masque en anonyme, menthe et cadeau sous son prénom
    chips=(anon('Tu l’offres en anonyme',MASK) if 'anonyme' in m.group(2) else state('Tu l’offres',GIFT))+act('Changer',PEN)
    return (m.group(1) if m.group(1) else ROW)+chips+'</span>'
# 2. les cadeaux à plusieurs
GRP=re.compile(r'<span style="display: flex; align-items: center; gap: 8px"><span style="display: flex; flex-shrink: 0">(?:<span aria-hidden="true"[^>]*>[^<]*</span>)+</span><span style="flex-grow: 1; min-width: 0; font-size: 13px; line-height: 1\.35; color: #57534e">([^<]*)</span>(?:<span[^>]*>([^<]*)</span>)?</span>')
def names(t): return [n for n in re.split(r', | et ',t) if n and n!='toi']
def grp(m):
    t,r=m.group(1),m.group(2) or ''
    if t=='7 personnes': c=info('7 personnes',USERS)
    elif t.startswith('Mamie l’offre'): c=info('Mamie')
    elif 'au complet' in t: c=info('Au complet',USERS)
    elif t.startswith('À plusieurs : '): c=''.join(info(n) for n in names(t[len('À plusieurs : '):]))
    elif t.startswith('À plusieurs'): c=info('À plusieurs',USERS)
    else: c=''.join(info(n) for n in names(t))
    if r=='Se joindre': c+=act('Se joindre',PLUS)
    elif r=='Tu participes': c+=state('Tu participes',CHECK)
    return '<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; text-decoration: none">'+c+'</span>'
# 3. le direct
LIVE=re.compile(r'<span style="display: block; font-size: 13px;[^>]*>Pris à l’instant, juste avant toi\.</span>')
n=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read()
    t=MINE.sub(mine,s); t=GRP.sub(grp,t); t=LIVE.sub(ROW+info('Pris à l’instant',CLOCK)+'</span>',t)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n),n); json.dump(n,open('/tmp/chips.json','w'))
