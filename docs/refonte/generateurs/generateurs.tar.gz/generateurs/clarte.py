"""Propositions : pages du suivi et du tirage, plus claires."""
import re, shutil, os, sys
sys.argv=['x']
exec(open('devine.py').read().split("# --- Organisateur : le réglage")[0])   # helpers only
OUT2='/mnt/user-data/outputs/clarte/'; os.makedirs(OUT2,exist_ok=True)
def keep(name, s, h_old, h_new, title):
    s=s.replace(f'height: {h_old}px',f'height: {h_new}px',1).replace(f'"height":{h_old}',f'"height":{h_new}').replace('<title>','<title>'+title+' — ',1)
    open(P+name+'.dc.html','w').write(s); shutil.copy(P+name+'.dc.html',OUT2+name+'.html'); print(name,h_new)

def nav(icon, title, sub, first=False, danger=False, href='#'):
    bt='' if first else ' border-top: 1px solid #e9dcc5;'
    bg,fg=('#fbe1e5','#961d35') if danger else ('#f1e8d8','#57534e')
    tc=' color: #961d35;' if danger else ''
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">'
            f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span>'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px;{tc}">{title}</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">{sub}</span></span>{CHEV}</a></li>')
def ic(d): return f'<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{d}</svg>'
GEAR=ic('<path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h10M18 18h2"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/>')
HELP=ic('<circle cx="12" cy="12" r="9"/><path d="M9.500 9.500a2.500 2.500 0 0 1 4.300 1.700c0 1.300-1.800 1.800-1.800 2.800M12 17h.010"/>')
EYE=ic('<path d="M2.500 12S6 5 12 5s9.500 7 9.500 7-3.500 7-9.500 7-9.500-7-9.500-7z"/><circle cx="12" cy="12" r="3"/>')
STARI=ic('<path d="M12 3l2 6.500L20.500 12 14 14l-2 7-2-7-6.500-2L10 9.500z"/>')
UNDO=ic('<path d="M3 12a9 9 0 1 0 3-6.700L3 8M3 3v5h5"/>')
CAL=ic('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>')
EURO=ic('<circle cx="12" cy="12" r="9"/><path d="M15 9a4 4 0 1 0 0 6M8 11h5M8 13h5"/>')
MSG=ic('<path d="M21 12a8 8 0 0 1-11.800 7L4 20l1-4.500A8 8 0 1 1 21 12z"/>')
LISTI=ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>')
DOC=ic('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h6"/>')

# 1. Suivi
s=open(P+'Suivi.dc.html').read()
i=s.index('Plus tard, ou en cas de pépin'); a=s.rfind('<section',0,i); b=s.index('</section>',i)+10
game=f'''<section style="{CARD}; padding: 16px 20px; display: flex; align-items: center; gap: 14px">
      <span aria-hidden="true" style="width: 48px; height: 48px; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{MASK}</span>
      <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px">
        <p style="{LABEL}; color: #8a2f27">Le jeu de cette édition</p>
        <h2 style="margin: 0; {F}; font-weight: 700; font-size: 20px; line-height: 1.2">Devine qui</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">4 sur 5 ont fait un pronostic. Fin le 25 décembre à 18 h.</p>
      </div>
      {CHEV}
    </section>
    <ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
      {nav(GEAR,'Réglages de l’édition','Budget 30 € · petit mot · jeu',first=True,href='PropEditionReglages.dc.html')}
      {nav(HELP,'Un souci ?','Désistement, lien perdu, erreur de tirage',href='PropSouci.dc.html')}
    </ul>
    <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Personne, organisateur compris, ne voit les résultats ici.</p>'''
keep('PropSuivi', s[:a]+game+s[b:], 1492, 1360, 'Proposition')

# 2. Réglages de l'édition
def val(icon,title,value,first=False,href='#'):
    bt='' if first else ' border-top: 1px solid #e9dcc5;'
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">'
            f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span>'
            f'<span style="flex-grow: 1; min-width: 0; font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 15px; color: #57534e; max-width: 150px; text-align: right">{value}</span>{CHEV}</a></li>')
page('PropEditionReglages','Proposition — réglages de l’édition', intro('Réglages de l’édition','Ce que voient les participants de Noël 2026.')+'\n'
  +section('La fête',[val(CAL,'Date','25 décembre',first=True),val(EURO,'Budget','30 €'),val(MSG,'Petit mot','On ouvre les cadeaux…')])+'\n'
  +section('Le jeu',[val(MASK,'Devine qui','Toutes les paires',first=True,href='DevineReglage.dc.html')]))
shutil.copy(P+'PropEditionReglages.dc.html',OUT2+'PropEditionReglages.html')

# 3. Un souci ?
panel('PropSouci','Proposition — un souci','Noël 2026','Un souci ?',f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; {F}; font-weight: 700; font-size: 24px; line-height: 1.15">Un souci ?</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Chacune de ces actions est inscrite au journal du groupe.</p>
    </div>
    <ul style="list-style: none; margin: 0 -16px; padding: 0; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
      {nav(EYE,'Voir un seul résultat','Quelqu’un a perdu son lien et n’a pas d’autre moyen',first=True)}
      {nav(STARI,'Dévoiler avant la fête','Tout le monde saura qui offre à qui')}
      {nav(UNDO,'Annuler et relancer le tirage','Désistement, erreur… tout le monde retire',danger=True)}
    </ul>
    <a href="#" style="margin-top: auto; height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Fermer</a>''', top=330)
shutil.copy(P+'PropSouci.dc.html',OUT2+'PropSouci.html')

# 4. Page du tirage
r=open(P+'TirageRevoir.dc.html').read()
m=r.index('<main'); u=r.index('<ul',m); e=r.index('</ul>',u)+5
def tile(icon,title,state,todo=False,href='#'):
    if todo:
        box='background: #fffdf9; box-shadow: 0 0 0 2px #b8483a'; ib,ifg='#b8483a','#ffffff'
        st=f'<span style="font-size: 14px; font-weight: 700; color: #8a2f27">{state}</span>'
    else:
        box='background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'; ib,ifg='#dbe9dd','#274e34'
        st=f'<span style="font-size: 14px; color: #57534e; display: flex; align-items: center; gap: 4px"><span style="color: #274e34; display: flex">{CHECK}</span>{state}</span>'
    return (f'<a href="{href}" style="{box}; border-radius: 16px; padding: 14px; min-height: 132px; box-sizing: border-box; text-decoration: none; color: #292524; display: flex; flex-direction: column; gap: 8px">'
            f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {ib}; color: {ifg}; display: flex; align-items: center; justify-content: center">{icon}</span>'
            f'<span style="margin-top: auto; {F}; font-weight: 700; font-size: 18px; line-height: 1.15">{title}</span>{st}</a>')
tiles=f'''<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px">
      {tile(LISTI,'Mes pistes de cadeaux','Remplies',href='Pistes.dc.html')}
      {tile(MASK,'Devine qui','Fais ton pronostic',todo=True,href='DevinePaires.dc.html')}
    </div>
    <a href="Journal.dc.html" style="align-self: center; min-height: 44px; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 600; color: #57534e; text-decoration: none">{DOC.replace('width="20" height="20"','width="16" height="16"')}Journal du groupe</a>'''
keep('PropTirage', r[:u]+tiles+r[e:], 982, 982, 'Proposition')
