# Après avoir coché : dire que c'est noté, et montrer qu'on peut l'offrir à plusieurs (Julien, 20 novembre 2026). Deux propositions. Après offrir.py.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.8): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
CHEVR=ic('<path d="m9 6 6 6-6 6"/>')
v=open(PJ+'ListeVisiteurMes.dc.html',encoding='utf-8').read()
i=v.index('>Tu l’offres<'); a=v.rfind('<li',0,i); b=v.index('</li>',i)+5; L=v[a:b]
# la pastille retenue : un filet et une flèche
LA=re.sub(r'(<span data-chip="etat" style=")([^"]*)(">)(.*?)Tu l’offres</span>',lambda m:m.group(1)+m.group(2).replace('padding: 1px 9px 1px 7px','padding: 1px 6px 1px 7px; box-shadow: inset 0 0 0 1.5px #8fc39c')+m.group(3)+m.group(4)+'Tu l’offres'+CHEVR+'</span>',L,count=1,flags=re.S)
assert LA!=L
P={}
# G. la première fois seulement : une note pointée sur la pastille, avec le halo, qui ne pousse rien
NOTE=('<div data-note="coche" style="position: absolute; top: calc(100% - 6px); left: 22px; right: 0; z-index: 3">'
      '<div role="status" style="position: relative; padding: 14px 16px 6px; border-radius: 16px; background: #fffdf9; color: #292524; box-shadow: 0 0 0 1.5px #292524, 0 14px 44px 6px rgba(43, 27, 61, 0.4); display: flex; flex-direction: column; gap: 6px">'
      '<span aria-hidden="true" style="position: absolute; top: -7px; left: 42px; width: 12px; height: 12px; background: #fffdf9; border-left: 1.5px solid #292524; border-top: 1.5px solid #292524; transform: rotate(45deg)"></span>'
      '<p style="margin: 0; font-size: 15px; font-weight: 700; line-height: 1.35; color: #292524">C’est noté</p>'
      '<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Touche « Tu l’offres » pour proposer de l’offrir à plusieurs, ou passer en anonyme.</p>'
      '<button style="align-self: flex-end; min-height: 40px; padding: 0 4px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700">Compris</button></div></div>')
# la ligne cochée et sa note restent dans la lumière ; le voile couvre toute l'application, en-tête compris, et laisse passer les touchers
LG=LA.replace('<li>','<li style="position: relative; z-index: 5; margin: 0 -10px; padding: 0 10px; border-radius: 10px; background: #f7f2e9">',1).replace('</a></li>','</a>'+NOTE.replace('left: 22px; right: 0;','left: 32px; right: 10px;')+'</li>',1)
assert 'data-note="coche"' in LG and 'z-index: 5' in LG
def veil(h,color):
    k=h.index('<x-dc>'); k=h.index('<div style="width: 390px;',k); e=h.index('">',k)
    h=h[:e]+'; position: relative'+h[e:]
    z=h.rindex('</div>\n</x-dc>')
    return h[:z]+f'<span aria-hidden="true" data-voile="1" style="position: absolute; inset: 0; z-index: 4; background: {color}; pointer-events: none"></span>'+h[z:]
P['ListeCocheGuide']=(veil(v[:a]+LG+v[b:],'rgba(43, 27, 61, 0.35)'),'Après avoir coché, la première fois : une note pointée sur « Tu l’offres › », le voile sur toute l’application')
t=open(PJ+'ListeVisiteurTirage.dc.html',encoding='utf-8').read()
if 'data-voile="1"' not in t:
    t2=re.sub(r'<span aria-hidden="true" style="position: absolute; top: 4px; left: -16px; right: -16px; height: 480px;[^>]*></span>','',t,count=1)
    assert t2!=t
    t2=t2.replace('<div data-mode="anonyme" style="position: sticky; top: 8px; z-index: 2;','<div data-mode="anonyme" style="position: sticky; top: 8px; z-index: 5;',1)
    P['ListeVisiteurTirage']=(veil(t2,'rgba(91, 58, 85, 0.35)'),re.search(r'<title>([^<]*)</title>',t).group(1))
names=json.load(open('/tmp/names.json'))
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P), re.search(r'"\$preview":\{[^}]*\}',h).group(0))
