import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
base = (P/'Connexion.dc.html').read_text()
def lbuild(name, title, main):
    i = base.index('<main'); j = base.index('</main>') + len('</main>')
    t = base[:i] + main + base[j:]
    (P/name).write_text(t.replace('<title>Connexion</title>', f'<title>{title}</title>'))
LOGO = '<svg role="img" aria-label="Under the Tree" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#a43a2f"/><path fill="#fffdf9" d="M32 15 44 30h-6l10 13H36v7h-8v-7H16l10-13h-6z"/><path fill="#e6b94a" d="m32 5 2.400 5 5.400.700-4 3.800 1 5.400-4.800-2.600-4.800 2.600 1-5.400-4-3.800 5.400-.700z"/></svg>'
BRAND = f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center">
      {LOGO}
      <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 26px; line-height: 1.05; color: #a43a2f">Under the Tree</p>
    </div>'''
LM = 'flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 24px 16px 24px'
INP = 'height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px'
MAILI = '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>'
# L1 créer un compte
lbuild('ConnexionCreer.dc.html', 'Connexion — créer un compte', f'''<main style="{LM}">
    {BRAND}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 16px">
      {seg(['Se connecter', 'Créer un compte'], 1, '#f1e8d8')}
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="fn" style="font-size: 15px; font-weight: 600">Prénom</label>
        <input id="fn" type="text" autocomplete="given-name" style="{INP}">
        <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Celui que verront les autres dans tes tirages.</p>
      </div>
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="email" style="font-size: 15px; font-weight: 600">Adresse email</label>
        <input id="email" type="email" autocomplete="email" placeholder="toi@exemple.fr" style="{INP}">
        <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Pas de mot de passe : tu reçois un lien valable 15 minutes.</p>
      </div>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{ic(I['userplus'])}Créer mon compte</button>
    </section>
    <p style="margin: 0; text-align: center; font-size: 14px; line-height: 1.45; color: #57534e">Si un organisateur t’a déjà ajouté avec cette adresse, tes tirages t’attendent dans ton compte.</p>
  </main>''')
# L2 regarde ta boîte mail
SENT = '''<svg aria-hidden="true" width="150" height="104" viewBox="0 0 184 128" fill="none">
        <rect x="6" y="14" width="172" height="108" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
        <path d="M7 118 70 66M177 118 114 66" stroke="#cdb48a" stroke-width="2" stroke-linecap="round"/>
        <path d="M8 18 84 74a13 13 0 0 0 16 0l76-56" fill="#f1e8d8" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
        <circle cx="150" cy="26" r="20" fill="#2f613f"/>
        <path d="m141 26 6 6 12-12" stroke="#ffffff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>'''
lbuild('ConnexionEnvoye.dc.html', 'Connexion — regarde ta boîte mail', f'''<main style="{LM}">
    {BRAND}
    <section role="status" style="{CARD} padding: 24px 20px 20px; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
      {SENT}
      <div style="display: flex; flex-direction: column; gap: 6px">
        <h1 style="{CT}">Regarde ta boîte mail</h1>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Lien envoyé à <strong style="color: #292524">hugo-demo@example.com</strong>. Il est valable 15 minutes et ne sert qu’une fois.</p>
      </div>
      <ul style="list-style: none; margin: 0; padding: 0; align-self: stretch; text-align: left; border-top: 1px solid #e9dcc5; display: flex; flex-direction: column">
        <li style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 0; font-size: 14px; line-height: 1.45; color: #57534e"><span aria-hidden="true" style="display: flex; margin-top: 1px">{ic(MAILI, 18)}</span>Rien reçu ? Regarde dans les indésirables.</li>
        <li style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 0; border-top: 1px solid #e9dcc5; font-size: 14px; line-height: 1.45; color: #57534e"><span aria-hidden="true" style="display: flex; margin-top: 1px">{ic('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>', 18)}</span>Ouvre le lien sur cet appareil : c’est lui qui sera connecté.</li>
      </ul>
      <button style="width: 100%; height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700">Utiliser une autre adresse</button>
    </section>
  </main>''')
# L3 confirmation
lbuild('ConnexionConfirmer.dc.html', 'Connexion — confirmer sur cet appareil', f'''<main style="{LM}">
    {BRAND}
    <section style="{CARD} padding: 24px 20px 20px; display: flex; flex-direction: column; gap: 14px; text-align: center">
      <div style="display: flex; flex-direction: column; gap: 6px">
        <h1 style="{CT}">Se connecter sur cet appareil ?</h1>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Tu vas être connecté avec <strong style="color: #292524">hugo-demo@example.com</strong> pendant 30 jours.</p>
      </div>
      <button style="height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{ic('<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>')}Se connecter</button>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Ce n’est pas ton appareil ? Ferme simplement cette page.</p>
    </section>
  </main>''')
# L4 lien invalide
lbuild('ConnexionLienInvalide.dc.html', 'Connexion — lien expiré', f'''<main style="{LM}">
    {BRAND}
    <section style="{CARD} padding: 24px 20px 20px; display: flex; flex-direction: column; gap: 14px; text-align: center">
      <div style="display: flex; flex-direction: column; gap: 6px">
        <h1 style="{CT}">Ce lien ne marche plus</h1>
        <p role="alert" style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Un lien de connexion est valable 15 minutes et ne sert qu’une fois. Demandes-en un nouveau, ça prend dix secondes.</p>
      </div>
      <a href="Connexion.dc.html" style="{BTN}">{ic(MAILI)}Demander un nouveau lien</a>
    </section>
  </main>''')
# L5 mon compte
def dev(icon, name, sub, current=False, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    trail = '<span style="padding: 2px 8px; border-radius: 999px; background: #dbe9dd; color: #274e34; font-size: 12px; font-weight: 700; flex-shrink: 0">Cet appareil</span>' if current else f'<button aria-label="Déconnecter {name}" style="height: 44px; padding: 0 12px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 999px; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Déconnecter</button>'
    return f'''        <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">
          <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(icon)}</span>
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{name}</span><span style="font-size: 14px; color: #57534e">{sub}</span></span>
          {trail}
        </li>
'''
PHONE = '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'
LAPTOP = '<rect x="4" y="5" width="16" height="11" rx="2"/><path d="M2 20h20"/>'
def valrow(title, value, first=False, sub=''):
    return inrow('', title, sub, f'<span style="font-size: 15px; color: #57534e; flex-shrink: 0">{value}</span>{CHEV}', first) if sub else f'''        <li>
          <a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{'' if first else ' border-top: 1px solid #e9dcc5;'} text-decoration: none; color: #292524">
            <span style="flex-grow: 1; font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 15px; color: #57534e; flex-shrink: 0">{value}</span>{CHEV}
          </a>
        </li>
'''
build('Compte.dc.html', 'Mon compte', f'''<main style="{MAIN}">
    <div style="display: flex; align-items: center; gap: 16px">
      <button aria-label="Changer mon icône" style="position: relative; width: 72px; height: 72px; padding: 0; border: 0; border-radius: 50%; background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; font-size: 32px; flex-shrink: 0"><span aria-hidden="true">🐧</span><span aria-hidden="true" style="position: absolute; right: -2px; bottom: -2px; width: 26px; height: 26px; box-sizing: border-box; border-radius: 50%; background: #fffdf9; border: 1px solid #dccbad; color: #57534e; display: flex; align-items: center; justify-content: center">{ic(I['pen'], 13)}</span></button>
      <div style="display: flex; flex-direction: column; gap: 2px; min-width: 0">
        <h1 style="{H1}">Mon compte</h1>
        <p style="margin: 0; font-size: 14px; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">hugo-demo@example.com</p>
      </div>
    </div>
    {section('Mon profil', valrow('Prénom', 'Hugo', True) + valrow('Nom de famille', 'Ajouter') + valrow('Langue', 'Français'), 'Ton prénom et ton icône sont repris dans tes tirages. La langue est celle de tes emails.')}
    {section('Mes appareils', dev(PHONE, 'iPhone · Safari', 'Connecté le 14 novembre', True, True) + dev(LAPTOP, 'Mac · Chrome', 'Vu le 12 novembre'), 'Une connexion dure 30 jours.')}
    {section('', inrow(bubble('x', 'danger'), '<span style="color: #961d35">Déconnecter partout</span>', 'Y compris cet appareil', first=True) )}
    <a href="#deconnexion" style="height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Se déconnecter de cet appareil</a>
  </main>''', 960)
print('ok')
