# « Tes données, en clair » (la page publique) et « Mes données » (dans Mon compte) — 19 novembre 2026
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
C={}
H1=f'margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1'
P='margin: 0; font-size: 15px; line-height: 1.5'
SM='margin: 0; font-size: 14px; line-height: 1.45; color: #57534e'
def scr(h,main,title):
    s=HEAD+f"""<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header('FR')}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    {main}
  </main>
</div>
"""+TAIL
    s=re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
    return re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%h,s)
def h2(t): return f'<h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 20px; line-height: 1.2">{t}</h2>'
def sec(t,inner): return f'<section style="{CARD}; padding: 18px; display: flex; flex-direction: column; gap: 12px">{h2(t)}{inner}</section>'
def what(t,who,top=True): return f'<li style="display: flex; flex-direction: column; gap: 2px; padding: 10px 0;{" border-top: 1px solid #e9dcc5;" if top else ""}"><span style="font-size: 15px; font-weight: 600">{t}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{who}</span></li>'
C['Confidentialite']=(scr(2520,f'''<div style="display: flex; flex-direction: column; gap: 8px"><h1 style="{H1}">Tes données, en clair</h1><p style="{P}">Under the Tree est fait par une personne, Julien, pour ses familles. Aucune publicité, aucun traceur, aucune revente. Voici tout ce que l’application sait, et qui le voit.</p></div>
    {sec('Ce que l’application sait, et qui le voit',f"""<ul style="list-style: none; margin: 0; padding: 0">{what('Ton prénom et ton icône','Ton groupe, et ceux qui ouvrent une liste où tu figures.',False)}{what('Ton adresse email','Les organisateurs des groupes que tu rejoins. Elle sert à te connecter et à te prévenir.')}{what('À qui tu offres','Toi seul. L’organisateur ne le voit pas. En dernier recours, il peut regarder un résultat, un seul à la fois : tout le groupe le lit alors dans le journal, avec le prénom concerné. Il peut aussi dévoiler le tirage à tout le groupe, et le journal le dit.')}{what('Tes pistes de cadeaux','Seulement celui qui t’offre un cadeau.')}{what('Ce que tu coches sur une liste','Ceux qui tiennent la liste voient ton prénom, ou « Anonyme » si tu le choisis.')}{what('Le journal du groupe','Tout le groupe : qui a ouvert son enveloppe, et quand. Jamais qui a tiré qui.')}</ul><p style="{SM}"><strong>Jamais demandé :</strong> un mot de passe, un numéro de téléphone, ta position.</p>""")}
    {sec('Ce qu’il faut savoir, sans détour',f"""<p style="{P}">Les résultats du tirage sont chiffrés, mais la clé est sur le serveur. Celui qui héberge l’application, Julien, pourrait techniquement les lire. Il s’engage à ne pas le faire.</p><p style="{P}">En tant qu’administrateur, il voit les comptes : l’adresse, les groupes, la date de la dernière visite.</p>""")}
    {sec('Si quelqu’un d’autre t’a ajouté',f"""<p style="{P}">Le premier email te dit qui, et pourquoi. Tu peux refuser tous les emails d’un geste, et demander qu’on retire ton prénom et ton adresse.</p>""")}
    {sec('Les enfants',f"""<p style="{P}">Une liste peut contenir le prénom, l’âge et les tailles d’un enfant. Seuls ceux qui ont le lien les voient, et celui qui tient la liste peut changer ce lien à tout moment. Les moteurs de recherche ne lisent pas les listes.</p>""")}
    {sec('Où sont les données',f"""<p style="{P}">Chez deux prestataires, et nulle part ailleurs : Cloudflare pour l’application et sa base, Resend pour l’envoi des emails.</p>""")}
    {sec('Combien de temps',f"""<p style="{P}">Un compte sans visite depuis trois ans est supprimé, après un email qui prévient. Des anciens tirages, il ne reste que ce qui sert à ne pas retomber sur la même personne.</p>""")}
    {sec('Tes droits',f"""<p style="{P}">Tu peux à tout moment télécharger tes données, supprimer ton compte et refuser les emails, depuis « Mon compte ». Pour le reste, écris à Julien : il répond sous un mois.</p><p style="{P}">Si sa réponse ne te convient pas, tu peux saisir la CNIL, l’autorité française qui protège les données personnelles : <a href="#" style="{A}">cnil.fr</a>.</p><a href="CompteDonnees.dc.html" style="{BTN2}">Ouvrir « Mes données »</a>""")}''','Tes données, en clair'),2520,'« Tes données, en clair » : la page publique (durées et textes à valider)')
def row(t,d,right='',top=True,danger=False): return f'<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: {"#8a2f27" if danger else "#292524"}"><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{d}</span></span>{right}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
C['CompteDonnees']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Mon compte</p><h1 style="{H1}">Mes données</h1></div>
    <ul style="{UL}">{row('Ce que l’application sait de moi','Et qui le voit, en clair.','',False)}{row('Télécharger mes données','Un fichier, tout de suite : mon profil, mes groupes, mes pistes, mes listes.')}{row('Les emails','Un résumé le matin. Tout arrêter, c’est ici aussi.')}</ul>
    <ul style="{UL}">{row('Supprimer mon compte','Mon adresse, mes pistes et mes listes sont effacées. Dans les groupes, il reste mon prénom, sans rien d’autre.','',False,True)}</ul>
    <p style="{SM}">Une question ? Écris à Julien : il répond sous un mois.</p>
    <p style="{SM}">Si sa réponse ne te convient pas, tu peux saisir la CNIL : <a href="#" style="{A}">cnil.fr</a>.</p>''','Mon compte — mes données'),900,'Mon compte : « Mes données »')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in C.items():
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
print(list(C))
