import pathlib, re, shutil, os
P = pathlib.Path('/home/claude/utt/project')
H1 = '''<h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">'''
PCTX = '<p style="margin: 0; font-size: 15px; color: #57534e">'
A = 'min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 600; color: #57534e; text-decoration: none'
def crumbs(parts):
    links = '<span aria-hidden="true">·</span>'.join(f'<a href="#" style="{A}">{p}</a>' for p in parts)
    return f'<nav aria-label="Tu es ici" style="margin: -14px 0 -12px; display: flex; align-items: center; gap: 6px; color: #57534e">{links}</nav>'
changed = []
def head(name, parts, drop=None, desc=None):
    t = (P/f'{name}.dc.html').read_text()
    if 'aria-label="Tu es ici"' in t: return
    i = t.index(H1); t = t[:i] + crumbs(parts) + '\n      ' + t[i:]
    if drop is not None:
        old = '\n      ' + PCTX + drop + '</p>'; assert t.count(old) == 1, (name, drop)
        t = t.replace(old, ('\n      ' + PCTX + desc + '</p>') if desc else '')
    (P/f'{name}.dc.html').write_text(t); changed.append(name)
G, E = 'Famille Camille', 'Noël 2026'
head('AnnulerTirage', [G, E], 'Noël 2026 · Famille Camille')
head('VoirResultat', [G, E], 'Famille Camille · Noël 2026')
head('VoirResultatAffiche', [G, E], 'Famille Camille · Noël 2026')
head('AjouterParticipants', [G, E], 'Noël 2026 · coche ceux qui participent', 'Coche ceux qui participent.')
for n in ['GroupeMembres', 'GroupeExclusions', 'GroupeReglages', 'EditionNouvelle', 'Journal', 'JournalTout', 'JournalPersonne']:
    head(n, [G], G)
head('GroupeMembres100', ['Comité d’entreprise'], 'Comité d’entreprise')
head('GroupeInvitation', [G])
# the email screen: its title sits in the top bar, the context goes under it
for n, g in [('SelectionEmail', G), ('SelectionEmail100', 'Comité d’entreprise')]:
    t = (P/f'{n}.dc.html').read_text()
    old = '''<h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 18px">Envoyer par email</h1>'''
    if t.count(old) == 1:
        t = t.replace(old, f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 1px"><h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 18px; line-height: 1.15">Envoyer par email</h1><p style="margin: 0; font-size: 12px; font-weight: 600; line-height: 1.2; color: #57534e">{g} · Noël 2026</p></div>''')
        (P/f'{n}.dc.html').write_text(t); changed.append(n)
t = (P/'PistesQuestion.dc.html').read_text()
old = 'Moi et les cadeaux · 2 sur 6</p>'
if t.count(old) == 1:
    (P/'PistesQuestion.dc.html').write_text(t.replace(old, 'Famille Camille · Noël 2026 · question 2 sur 6</p>')); changed.append('PistesQuestion')
print(changed)
