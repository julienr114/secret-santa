# Celui qui tient la liste décoche pour quelqu'un d'autre (Julien, 19 novembre 2026). Après proches.py.
# Deuxième dessin : plus de bulle qui demande « sûr ? ». Le prénom se déplie dans la ligne, « Décocher » agit tout de suite, et « Annuler » rattrape.
import re,json
PJ='/home/claude/utt/project/'
src=open(PJ+'ListeTeneur.dc.html').read()
CHIP='padding: 1px 8px; margin-left: 4px">Mamie</span>'
def title(h,t): return re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
# 1. le prénom touché : la ligne se déplie
h=src; k=h.index('Circuit de billes'); c=h.index(CHIP,k); e=c+len(CHIP)
row=('<span data-dec="1" style="display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 6px; padding: 6px 6px 6px 12px; border-radius: 12px; background: #f1e8d8; text-decoration: none; font-size: 14px; line-height: 1.35; color: #57534e">'
 '<span>Coché par <strong style="color: #292524">Mamie</strong>, le 12 novembre</span>'
 '<button style="min-height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Décocher</button></span>')
h=h[:e]+row+h[e:]
h=h.replace(CHIP,'padding: 1px 8px; margin-left: 4px; background: #292524; color: #ffffff" aria-expanded="true">Mamie</span>',1)
open(PJ+'ListeDecocher.dc.html','w').write(title(h,'Listes — celui qui tient la liste décoche pour quelqu’un : le prénom déplié'))
# 2. c'est fait : l'idée est libre, « Annuler » rattrape
h=src; k=h.index('Circuit de billes'); a=h.rindex('<li',0,k); b=h.index('</li>',k)+5
li=h[a:b]
free=re.sub(r'<span aria-hidden="true" style="width: 22px; height: 22px;[^>]*>.*?</svg></span>','<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; border: 2px solid #a8a29e; background: #fffdf9; flex-shrink: 0; margin-top: 1px"></span>',li,count=1,flags=re.S)
free=free.replace('color: #78716c; text-decoration: line-through','color: #292524',1)
free=re.sub(r' <span style="display: inline-block; text-decoration: none; font-size: 13px;[^>]*>Mamie</span>','',free,count=1)
assert free!=li and 'Mamie' not in free
h=h[:a]+free+h[b:]
toast='<div role="status" style="position: sticky; bottom: 16px; margin-top: auto; align-self: stretch; min-height: 52px; padding: 0 8px 0 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; justify-content: space-between; gap: 12px; font-size: 15px; font-weight: 600">Coche de Mamie retirée<button style="min-height: 44px; padding: 0 10px; border: 0; background: transparent; color: #f6c9c0; font-family: inherit; font-size: 15px; font-weight: 700">Annuler</button></div>\n  '
k=h.rindex('</main>'); h=h[:k]+'  '+toast+h[k:]
open(PJ+'ListeDecocheFait.dc.html','w').write(title(h,'Listes — la coche de quelqu’un vient d’être retirée'))
names=json.load(open('/tmp/names.json'))
for n in ['ListeDecocher.dc.html','ListeDecocheFait.dc.html']:
    if n not in names: names.append(n)
json.dump(names,open('/tmp/names.json','w')); print('ok')
