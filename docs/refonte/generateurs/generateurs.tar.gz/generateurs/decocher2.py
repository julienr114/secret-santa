# Décocher pour quelqu'un : le fond englobe toute la ligne, case comprise (Julien, 20 novembre 2026). Après lienpuce2.py.
PJ='/home/claude/utt/project/'
f=PJ+'ListeDecocher.dc.html'; s=open(f,encoding='utf-8').read()
i=s.index('data-dec="1"'); a=s.rfind('<li>',0,i); assert a>0
old=' style="display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 6px; padding: 6px 6px 6px 12px; border-radius: 12px; background: #f1e8d8; text-decoration: none;'
assert s.count('data-dec="1"'+old)==1
s=s.replace('data-dec="1"'+old,'data-dec="2" style="display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 8px; text-decoration: none;')
s=s[:a]+'<li style="margin: 4px -10px; padding: 0 10px 2px; border-radius: 16px; background: #f1e8d8">'+s[a+4:]
open(f,'w',encoding='utf-8').write(s); print('ok')
