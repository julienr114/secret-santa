"""Maquettes du jeu « Devine qui » (pronostics)."""
import os
import re
import shutil

P = '/home/claude/utt/project/'
OUT = '/mnt/user-data/outputs/devine/'
os.makedirs(OUT, exist_ok=True)

F = "font-family: 'Fraunces', Georgia, serif"
CARD = 'background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'
LABEL = 'margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
CHEV = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
PEN = '<svg aria-hidden="true" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>'
CHECK = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg>'
CROSS = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
MASK = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500M9 9.500a2.500 2.500 0 0 1 4.200 1.800c0 1.200-1.700 1.700-1.700 2.700M11.500 16h.010"/></svg>'

PEOPLE = {
    'Camille': ('🦌', '#ead2e2', '#c493b4'),
    'Hugo': ('🐧', '#f6e3ad', '#e6b94a'),
    'Inès': ('🍭', '#f3d3cc', '#e09e92'),
    'Lou': ('🌰', '#ecdfc6', '#cdb48a'),
    'Sacha': ('🍷', '#d6e6ef', '#94bbd0'),
    'Yanis': ('🦉', '#cfe2d3', '#8db898'),
}


def av(name, size=40):
    e, bg, bd = PEOPLE[name]
    return (f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; '
            f'box-shadow: 0 0 0 1px {bd}; display: flex; align-items: center; justify-content: center; '
            f'font-size: {round(size * 0.45)}px; flex-shrink: 0">{e}</span>')


_page = open(P + 'Pistes.dc.html').read()
_a = _page.index('<div style="width: 390px')
_m = _page.index('<main', _a)
HEAD = _page[:_a]
PAGE_TOP = _page[_a:_m]
TAIL = _page[_page.index('</x-dc>'):]
_h = re.search(r'"height":(\d+)', TAIL).group(1)


def finish(name, body, height, title):
    head = re.sub(r'<title>[^<]*</title>', f'<title>{title}</title>', HEAD)
    tail = TAIL.replace(f'"height":{_h}', f'"height":{height}')
    open(P + name + '.dc.html', 'w').write(head + body + '\n' + tail)
    shutil.copy(P + name + '.dc.html', OUT + name + '.html')
    return name, height


def page(name, title, inner, height=844):
    top = PAGE_TOP.replace('height: 1500px', f'height: {height}px')
    body = (top + '<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">\n'
            + inner + '\n  </main>\n</div>')
    return finish(name, body, height, title)


def panel(name, title, back, label, inner, top=160, height=844):
    body = f'''<div style="width: 390px; height: {height}px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; {F}; font-weight: 700; font-size: 30px; color: #5c554c">{back}</div>
  <section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 16px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
{inner}
  </section>
</div>'''
    return finish(name, body, height, title)


def intro(h1, p, ctx='Famille Camille · Noël 2026'):
    return f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <p style="margin: 0; font-size: 14px; color: #57534e">{ctx}</p>
      <h1 style="margin: 0; {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{h1}</h1>
      <p style="margin: 4px 0 0; font-size: 15px; line-height: 1.45; color: #57534e">{p}</p>
    </div>'''


def pick(name=None, big=False):
    """The value of a bet: a chip with the person, or a dashed « + Choisir »."""
    if name is None:
        return ('<span style="min-height: 36px; box-sizing: border-box; padding: 0 12px; border-radius: 999px; border: 1px dashed #b8483a; '
                'color: #8a2f27; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 4px; flex-shrink: 0">'
                '<span aria-hidden="true">+</span>Choisir</span>')
    return ('<span style="min-height: 36px; box-sizing: border-box; padding: 0 12px 0 4px; border-radius: 999px; background: #f1e8d8; '
            'box-shadow: 0 0 0 1px #dccbad; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px; flex-shrink: 0">'
            f'{av(name, 28)}{name}{PEN}</span>')


def bet_row(who, question, chosen, first=False, href='DevineChoisirPaire.dc.html'):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; '
            f'box-sizing: border-box;{bt} text-decoration: none; color: #292524">{av(who)}'
            f'<span style="flex-grow: 1; min-width: 0; font-weight: 600; font-size: 16px">{question}</span>{pick(chosen)}</a></li>')


def ul(rows):
    return ('    <ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; '
            'border-bottom: 1px solid #dccbad">\n      ' + '\n      '.join(rows) + '\n    </ul>')


def section(label, rows):
    return f'''    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{LABEL}; padding: 0 4px">{label}</h2>
  {ul(rows)}
    </section>'''


QUIET = 'margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e'
DEADLINE = 'jusqu’au 25 décembre à 18 h'
made = []

# --- Organisateur : le réglage ------------------------------------------------
def radio(title, sub, checked=False, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    bg = ' background: #fbf3f1;' if checked else ''
    return f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 10px 14px; box-sizing: border-box;{bt}{bg}">
        <input type="radio" name="g"{' checked' if checked else ''} style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
        <span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{title}</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span></span>
      </label>'''

made.append(panel('DevineReglage', 'Devine qui — réglage', 'Noël 2026', 'Devine qui', f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; {F}; font-weight: 700; font-size: 24px; line-height: 1.15">Devine qui</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Un jeu de pronostics : qui offre à qui ? Les réponses tombent à la fête.</p>
    </div>
    <div role="radiogroup" aria-label="Devine qui" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">{radio('Aucun pronostic', 'Le jeu est éteint', first=True)}{radio('Qui m’offre ?', 'Chacun devine son propre Père Noël')}{radio('Toutes les paires', 'Chacun pronostique aussi pour les autres, autant qu’il veut', checked=True)}</div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="h" style="font-size: 15px; font-weight: 600">Fin des pronostics, le 25 décembre à</label>
      <input id="h" type="time" value="18:00" style="height: 48px; width: 140px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>
    <p style="margin: 0; padding: 10px 12px; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #66431d; font-size: 14px; line-height: 1.4">Les réponses tombent quand tu dévoiles le tirage à la fête, ou toutes seules le lendemain.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
      <a href="#" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    </div>''', top=110))

# --- Organisateur : le suivi --------------------------------------------------
s = open(P + 'Suivi.dc.html').read()
i = s.index('Petit mot'); a = s.rfind('<li', 0, i); b = s.index('</li>', i) + 5
li = s[a:b]
new = li.replace('PanneauTexte.dc.html', 'DevineReglage.dc.html').replace('Petit mot pour les participants', 'Devine qui').replace(
    'On ouvre les cadeaux après le dessert !', 'Toutes les paires · 4 sur 5 ont fait un pronostic')
new = re.sub(r'<svg width="20" height="20".*?</svg>', MASK.replace(' aria-hidden="true"', ''), new, count=1, flags=re.S)
assert new != li
s2 = s[:b] + '\n        ' + new + s[b:]
h = int(re.search(r'"height":(\d+)', s2).group(1))
s2 = s2.replace(f'height: {h}px', f'height: {h + 60}px', 1).replace(f'"height":{h}', f'"height":{h + 60}')
s2 = s2.replace('<title>', '<title>Devine qui — ', 1)
open(P + 'DevineSuivi.dc.html', 'w').write(s2); shutil.copy(P + 'DevineSuivi.dc.html', OUT + 'DevineSuivi.html')
made.append(('DevineSuivi', h + 60))

# --- Participant : l'accueil --------------------------------------------------
a_ = open(P + 'Accueil.dc.html').read()
for x, y in [('Le tirage est fait !</h2>', 'Devine qui t’offre ton cadeau</h2>'),
             ('Fête le 25 décembre, dans 40 jours.', f'Un pronostic, {DEADLINE}. Réponse à la fête.'),
             ('<a href="TirageDecouvrir.dc.html"', '<a href="DevineUnique.dc.html"'),
             ("Découvrir à qui j'offre un cadeau</a>", 'Faire mon pronostic</a>')]:
    assert a_.count(x) == 1, x
    a_ = a_.replace(x, y)
a_ = a_.replace('<title>', '<title>Devine qui — ', 1)
open(P + 'DevineAccueil.dc.html', 'w').write(a_); shutil.copy(P + 'DevineAccueil.dc.html', OUT + 'DevineAccueil.html')
made.append(('DevineAccueil', 844))

# --- Participant : la page du tirage -----------------------------------------
r = open(P + 'TirageRevoir.dc.html').read()
i = r.index('Journal du groupe'); a = r.rfind('<li', 0, i); b = r.index('</li>', i) + 5
li = r[a:b]
new = li.replace('#journal', 'DevinePaires.dc.html').replace('Journal du groupe', 'Devine qui').replace(
    "Tout ce qui s'est passé, à la vue de tous", f'3 pronostics · {DEADLINE}')
new = re.sub(r'<svg width="20" height="20".*?</svg>', MASK.replace(' aria-hidden="true"', ''), new, count=1, flags=re.S)
r2 = r[:a] + new + '\n      ' + r[a:]
h = int(re.search(r'"height":(\d+)', r2).group(1))
r2 = r2.replace(f'height: {h}px', f'height: {h + 64}px', 1).replace(f'"height":{h}', f'"height":{h + 64}')
r2 = r2.replace('<title>', '<title>Devine qui — ', 1)
open(P + 'DevineTirage.dc.html', 'w').write(r2); shutil.copy(P + 'DevineTirage.dc.html', OUT + 'DevineTirage.html')
made.append(('DevineTirage', h + 64))

# --- Participant : un seul pronostic -----------------------------------------
def single(name, chosen):
    if chosen:
        inner = f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 8px">{av(chosen, 80)}
        <p style="margin: 0; {F}; font-weight: 700; font-size: 36px; line-height: 1; color: #a43a2f">{chosen}</p></div>
      <a href="DevineChoisir.dc.html" style="width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Changer d’avis</a>'''
        lab = 'Mon pronostic'
    else:
        inner = f'''<span aria-hidden="true" style="width: 80px; height: 80px; border-radius: 50%; border: 2px dashed #cdb48a; color: #a8916a; display: flex; align-items: center; justify-content: center; {F}; font-weight: 700; font-size: 36px">?</span>
      <a href="DevineChoisir.dc.html" style="width: 100%; height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Faire mon pronostic</a>'''
        lab = 'Qui t’offre ton cadeau ?'
    return page(name, 'Devine qui — un pronostic', intro('Devine qui', f'Un seul pronostic, que tu peux changer {DEADLINE}.') + f'''
    <section style="{CARD}; padding: 24px 20px 20px; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">
      <p style="{LABEL}; color: #8a2f27">{lab}</p>
      {inner}
    </section>
    <p style="{QUIET}">Personne ne voit ton pronostic avant la fête.</p>''')

made.append(single('DevineUnique', None))
made.append(single('DevineUniqueFait', 'Sacha'))

# --- Le choix d'une personne --------------------------------------------------
def option(name, selected=False, note='', first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    bg = '#fbeeea' if selected else 'transparent'
    end = (f'<span aria-hidden="true" style="width: 24px; height: 24px; border-radius: 50%; background: #b8483a; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{CHECK}</span>'
           if selected else '')
    sub = f'<span style="font-size: 13px; font-weight: 400; color: #57534e">{note}</span>' if note else ''
    return (f'<li role="option" aria-selected="{str(selected).lower()}"><button style="width: 100%; min-height: 56px; padding: 8px 14px; box-sizing: border-box; border: 0;{bt} '
            f'background: {bg}; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 12px; text-align: left">'
            f'{av(name)}<span style="flex-grow: 1; display: flex; flex-direction: column">{name}{sub}</span>{end}</button></li>')

def chooser(name, title, sub, options, top):
    return panel(name, 'Devine qui — choisir', 'Devine qui', title, f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <h1 style="margin: 0; {F}; font-weight: 700; font-size: 22px; line-height: 1.15">{title}</h1>
      <p style="margin: 0; font-size: 14px; color: #57534e">{sub}</p>
    </div>
    <ul role="listbox" aria-label="Participants" style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden">
      {''.join(options)}
    </ul>
    <a href="#" style="margin-top: auto; min-height: 44px; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 600; color: #57534e">Effacer ce pronostic</a>''', top=top)

made.append(chooser('DevineChoisir', 'Qui t’offre ton cadeau ?', 'Tu pourras changer d’avis.', [
    option('Hugo', first=True), option('Inès'), option('Lou'), option('Sacha', selected=True), option('Yanis')], 300))
made.append(chooser('DevineChoisirPaire', 'Qui offre à Yanis ?', 'Une personne n’offre qu’un cadeau.', [
    option('Hugo', first=True), option('Inès'), option('Lou', note='Ton pronostic pour Hugo : le choisir le déplace ici'),
    option('Sacha', note='Ton pronostic pour toi : le choisir le déplace ici')], 330))

# --- Participant : toutes les paires -----------------------------------------
made.append(page('DevinePaires', 'Devine qui — toutes les paires',
    intro('Devine qui', f'Qui offre à qui ? Autant de pronostics que tu veux, {DEADLINE}.') + '\n'
    + section('Mon Père Noël', [bet_row('Camille', 'Qui t’offre ?', 'Sacha', first=True, href='DevineChoisir.dc.html')]) + '\n'
    + section('Les autres', [bet_row('Hugo', 'Qui offre à Hugo ?', 'Lou', first=True), bet_row('Inès', 'Qui offre à Inès ?', None),
                             bet_row('Lou', 'Qui offre à Lou ?', 'Yanis'), bet_row('Sacha', 'Qui offre à Sacha ?', None),
                             bet_row('Yanis', 'Qui offre à Yanis ?', None)]) + f'''
    <p style="{QUIET}">3 pronostics. Personne ne les voit avant la fête.</p>''', height=900))

# --- Fermés, en attente -------------------------------------------------------
def closed_row(who, question, chosen, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    val = (f'<span style="display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 600; flex-shrink: 0">{av(chosen, 28)}{chosen}</span>'
           if chosen else '<span style="font-size: 14px; color: #78716c; flex-shrink: 0">Pas de pronostic</span>')
    return (f'<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">{av(who)}'
            f'<span style="flex-grow: 1; min-width: 0; font-weight: 600; font-size: 16px">{question}</span>{val}</li>')

made.append(page('DevineFerme', 'Devine qui — pronostics fermés',
    intro('Devine qui', 'Les pronostics sont fermés depuis le 25 décembre à 18 h.') + f'''
    <section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 6px; text-align: center">
      <h2 style="margin: 0; {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Réponse à la fête</h2>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Les résultats et le palmarès arrivent quand ton organisateur dévoile le tirage.</p>
    </section>
''' + section('Mes pronostics', [closed_row('Camille', 'Qui t’offre ?', 'Sacha', first=True), closed_row('Hugo', 'Qui offre à Hugo ?', 'Lou'),
                                closed_row('Inès', 'Qui offre à Inès ?', None), closed_row('Lou', 'Qui offre à Lou ?', 'Yanis'),
                                closed_row('Sacha', 'Qui offre à Sacha ?', None), closed_row('Yanis', 'Qui offre à Yanis ?', None)]), height=940))

# --- Le palmarès --------------------------------------------------------------
def verdict(ok):
    bg, fg, ic = ('#dbe9dd', '#274e34', CHECK) if ok else ('#f6e2dd', '#a43a2f', CROSS)
    return f'<span aria-hidden="true" style="width: 24px; height: 24px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic}</span>'

def result_row(who, mine, truth, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    ok = mine == truth
    sub = f'Tu disais {mine}' if not ok else 'Bien vu'
    label = 'Ton Père Noël' if who == 'Camille' else f'Celui de {who}'
    return (f'<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">{verdict(ok)}'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{label} : {truth}</span>'
            f'<span style="font-size: 14px; line-height: 1.35; color: #57534e">{sub}</span></span>{av(truth, 32)}</li>')

def award(title, names, why):
    faces = ''.join(av(n, 36) for n in names)
    who = names[0] if len(names) == 1 else ', '.join(names[:-1]) + ' et ' + names[-1]
    return f'''      <li style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #e9dcc5">
        <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="{LABEL}; color: #8a2f27">{title}</span><span style="font-weight: 700; font-size: 17px">{who}</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">{why}</span></span>
        <span style="display: flex; flex-shrink: 0">{faces}</span>
      </li>'''

def award_text(title, text):
    return f'''      <li style="display: flex; flex-direction: column; gap: 2px; padding: 12px 16px; border-top: 1px solid #e9dcc5">
        <span style="{LABEL}; color: #8a2f27">{title}</span><span style="font-size: 15px; line-height: 1.4">{text}</span>
      </li>'''

made.append(page('DevinePalmares', 'Devine qui — le palmarès',
    intro('Devine qui : les réponses', 'Le tirage est dévoilé. Voici ce que valaient les pronostics.') + f'''
    <section style="{CARD}; padding: 24px 20px 20px; display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center">
      <p style="{LABEL}; color: #274e34">Tu avais deviné</p>
      {av('Sacha', 80)}
      <p style="margin: 0; {F}; font-weight: 700; font-size: 26px; line-height: 1.15">C’est bien Sacha qui t’offrait ton cadeau</p>
      <p style="margin: 0; font-size: 15px; color: #57534e">2 bons pronostics sur 3.</p>
    </section>
''' + section('Mes pronostics', [result_row('Camille', 'Sacha', 'Sacha', first=True), result_row('Hugo', 'Lou', 'Lou'), result_row('Lou', 'Yanis', 'Inès')]) + f'''
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{LABEL}; padding: 0 4px">Le palmarès du groupe</h2>
      <ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
      <li style="display: flex; flex-direction: column; gap: 2px; padding: 12px 16px">
        <span style="{LABEL}; color: #8a2f27">Démasqués</span><span style="font-weight: 700; font-size: 17px">3 sur 6 ont deviné leur Père Noël</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">Toi, Hugo et Yanis</span>
      </li>
{award('Le détective', ['Lou'], '4 bons pronostics sur 5')}
{award('Les mieux cachés', ['Hugo', 'Inès'], 'Personne ne les a démasqués')}
{award('Le suspect idéal', ['Sacha'], 'Cité 4 fois à tort')}
{award_text('Le plus transparent', '4 Pères Noël à égalité, démasqués par 2 personnes chacun.')}
      </ul>
    </section>''', height=1340))

for n, h in made:
    print(n, h)


# --- Les stories du palmarès --------------------------------------------------
STAR = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
CLOSE = '<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
TOTAL = 7


def big(name, size=128):
    e, bg, bd = PEOPLE[name]
    return (f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; '
            f'box-shadow: 0 0 0 4px rgba(255, 253, 249, 0.9), 0 12px 30px rgba(0, 0, 0, 0.25); display: flex; align-items: center; '
            f'justify-content: center; font-size: {round(size * 0.5)}px; flex-shrink: 0">{e}</span>')


def story(name, index, bg, fg, soft, kicker, body, foot='Touche pour continuer'):
    bars = ''.join(
        f'<span style="flex: 1; height: 3px; border-radius: 999px; background: {fg}; opacity: {1 if k <= index else 0.3}"></span>'
        for k in range(TOTAL))
    html = f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: {bg}; color: {fg}; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; padding: 14px 16px 28px">
  <div role="img" aria-label="Écran {index + 1} sur {TOTAL}" style="display: flex; gap: 4px">{bars}</div>
  <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 10px">
    <span style="display: flex; align-items: center; gap: 6px; {F}; font-weight: 700; font-size: 16px">{STAR}Devine qui · Noël 2026</span>
    <button aria-label="Fermer" style="width: 44px; height: 44px; margin-right: -10px; border: 0; background: transparent; color: {fg}; display: flex; align-items: center; justify-content: center; padding: 0">{CLOSE}</button>
  </div>
  <div style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 22px; text-align: center">
    <p style="margin: 0; font-size: 14px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; color: {soft}">{kicker}</p>
{body}
  </div>
  <p style="margin: 0; text-align: center; font-size: 14px; color: {soft}">{foot}</p>
</div>'''
    return finish(name, html, 844, 'Devine qui — le palmarès en images')


def h(text, size=44):
    return f'    <p style="margin: 0; {F}; font-weight: 700; font-size: {size}px; line-height: 1.08">{text}</p>'


def sub(text, color):
    return f'    <p style="margin: 0; max-width: 300px; font-size: 18px; line-height: 1.4; color: {color}">{text}</p>'


PINE, CREAM, MINT = '#274e34', '#fffdf9', '#cfe2d3'
BRICK, ROSE = '#a43a2f', '#f6d9d3'
MUST, INK, BROWN = '#e6b94a', '#3a240c', '#66431d'
PLUM, LILAC = '#5b3a55', '#ead2e2'

stories = [
    story('DevineStory1', 0, PINE, CREAM, MINT, 'Les réponses sont là',
          h('Qui offrait<br>à qui ?', 52) + '\n' + sub('6 joueurs, 19 pronostics. Voyons ce qu’ils valaient.', MINT), 'Touche pour commencer'),
    story('DevineStory2', 1, BRICK, CREAM, ROSE, 'Ton Père Noël',
          f'''    <span aria-hidden="true" style="width: 128px; height: 128px; border-radius: 50%; border: 3px dashed {ROSE}; display: flex; align-items: center; justify-content: center; {F}; font-weight: 700; font-size: 64px">?</span>
''' + h('Tu avais dit<br>Sacha…') + '\n' + sub('Alors, bien vu ?', ROSE)),
    story('DevineStory3', 2, BRICK, CREAM, ROSE, 'Ton Père Noël',
          '    ' + big('Sacha') + '\n' + h('C’était<br>bien Sacha !', 48) + '\n' + sub('Démasqué. Tu fais partie des 3 sur 6 qui ont deviné.', ROSE)),
    story('DevineStory4', 3, MUST, INK, BROWN, 'Le détective',
          '    ' + big('Lou') + '\n' + h('Lou', 64) + '\n' + sub('4 bons pronostics sur 5. Personne n’a fait mieux.', BROWN)),
    story('DevineStory5', 4, PLUM, CREAM, LILAC, 'Les mieux cachés',
          f'    <div style="display: flex">{big("Hugo", 112)}<span style="margin-left: -24px; display: flex">{big("Inès", 112)}</span></div>\n'
          + h('Hugo et Inès', 44) + '\n' + sub('Personne ne les a démasqués. Du grand art.', LILAC)),
    story('DevineStory6', 5, PINE, CREAM, MINT, 'Le suspect idéal',
          '    ' + big('Sacha') + '\n' + h('Sacha', 64) + '\n' + sub('Cité 4 fois à tort. On se demande pourquoi.', MINT)),
    story('DevineStory7', 6, '#f7f2e9', '#292524', '#57534e', 'C’est tout pour cette année',
          h('Joyeux Noël,<br>Camille', 46) + '\n'
          + '    <a href="DevinePalmares.dc.html" style="width: 100%; max-width: 320px; height: 52px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Voir tous les résultats</a>\n'
          + '    <a href="DevineStory1.dc.html" style="min-height: 44px; display: flex; align-items: center; font-size: 16px; font-weight: 600; color: #57534e">Revoir depuis le début</a>', ''),
]
for n, hh in stories:
    print(n, hh)
