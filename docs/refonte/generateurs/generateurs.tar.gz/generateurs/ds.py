import pathlib, json
R = pathlib.Path('/home/claude/ds/project')
def w(path, text):
    f = R/path; f.parent.mkdir(parents=True, exist_ok=True); f.write_text(text)

# ---------------- tokens ----------------
C = [
 ('page', '#f7f2e9', "Fond de page (kraft-50). Jamais de carte de cette couleur."),
 ('surface', '#fffdf9', "Cartes, lignes de liste, panneaux du bas, champs. Blanc cassé posé sur page."),
 ('surface-muted', '#f1e8d8', "Aperçu d'un message, pastille d'icône neutre, pavés budget/date (kraft-100). Texte ink dessus."),
 ('track', '#e9dcc5', "Partie vide d'une barre de progression, trait de frise à venir, séparateur entre deux lignes (kraft-200)."),
 ('border', '#dccbad', "Bord haut et bas d'une liste, bord d'un bouton contour neutre, poignée d'un panneau (kraft-300)."),
 ('field-border', '#a8a29e', "Bord d'un champ de saisie au repos (3:1 sur surface)."),
 ('ink', '#292524', "Texte courant et titres sur page et surface. Fond du bouton neutre fort (« Voir le résultat »)."),
 ('ink-muted', '#57534e', "Texte secondaire : sous-titres, statuts neutres, aides. 4.5:1 sur page, surface et surface-muted."),
 ('ink-dim', '#78716c', "Chevrons et icônes décoratives uniquement, jamais du texte."),
 ('on-primary', '#ffffff', "Texte et icônes sur primary, success et ink."),
 ('primary', '#b8483a', "Rouge brique (brick-500). Fond de l'action principale, étape en cours de la frise, bord du champ actif. Une seule action pleine par écran."),
 ('primary-text', '#a43a2f', "Brique en texte ou en icône sur page et surface : logo, prénom du résultat, icône des lignes d'action (brick-600)."),
 ('primary-strong', '#8a2f27', "Brique foncé : libellé d'un bouton contour ou lien, étiquette « À faire maintenant », libellé de l'étape en cours (brick-700)."),
 ('primary-soft', '#f6e2dd', "Pastille d'icône d'une ligne d'action, bouton rond « à envoyer », halo de l'étape en cours (brick-100)."),
 ('primary-softer', '#fbf3f1', "Ligne sélectionnée dans une liste de choix, pavé de compteur « à prévenir » (brick-50)."),
 ('success', '#2f613f', "Vert sapin (pine-600). Étapes faites de la frise, barre de progression, coche d'un statut, bouton sûr « Attendre la fête »."),
 ('success-strong', '#274e34', "Texte et icône sur success-soft et success-softer (pine-700)."),
 ('success-soft', '#dbe9dd', "Pastille d'une ligne validée dans un récapitulatif (pine-100)."),
 ('success-softer', '#f0f6f1', "Bandeau d'information positive, pavé de compteur « a découvert » (pine-50)."),
 ('warning', '#94651c', "Moutarde lisible en texte sur surface (mustard-700, jeton --ui-warning du code)."),
 ('warning-strong', '#79511d', "Statut « Envoyé, pas encore consulté » et son icône (mustard-800)."),
 ('warning-deep', '#66431d', "Texte courant dans un encadré warning-softer (mustard-900)."),
 ('warning-ink', '#3a240c', "Titre dans un encadré warning-softer (mustard-950)."),
 ('warning-soft', '#f9eecb', "Pastille d'une ligne d'attention, surlignage d'une recherche (mustard-100)."),
 ('warning-softer', '#fdf8ea', "Fond d'un encadré d'attention (mustard-50)."),
 ('warning-border', '#ebc762', "Bord d'un encadré d'attention (mustard-300). Décoratif."),
 ('star', '#e6b94a', "L'étoile du logo et des puces d'idées de cadeaux (mustard-400). Jamais du texte."),
 ('danger', '#b3243f', "Canneberge (cranberry-600, jeton --ui-error). Bord d'un encadré irréversible, libellé d'un bouton dangereux. Plus froid que primary pour ne pas se confondre avec l'action."),
 ('danger-strong', '#961d35', "Titre et icône d'une ligne dangereuse (cranberry-700)."),
 ('danger-deep', '#6b1c2e', "Texte dans un encadré danger-softer (cranberry-900)."),
 ('danger-soft', '#fbe1e5', "Pastille d'icône d'une ligne dangereuse (cranberry-100)."),
 ('danger-softer', '#fdf2f4', "Fond d'un encadré irréversible (cranberry-50)."),
 ('scrim', '#8f877b', "Page assombrie derrière un panneau du bas. Proposition des maquettes, à remplacer par le voile de UDrawer dans le code."),
]
for name, bg, ring in [('brick', '#f3d3cc', '#e09e92'), ('pine', '#cfe2d3', '#8db898'), ('mustard', '#f6e3ad', '#e6b94a'), ('kraft', '#ecdfc6', '#cdb48a'), ('frost', '#d6e6ef', '#94bbd0'), ('plum', '#ead2e2', '#c493b4')]:
    C.append((f'avatar-{name}', bg, f"Fond du rond d'avatar « {name} » (app/utils/avatars.ts). L'emoji de la personne se pose dessus."))
    C.append((f'avatar-{name}-ring', ring, f"Liseré 1px du rond d'avatar « {name} », pour qu'il se lise sur page comme sur surface."))
tokens = {
 "name": "Under the Tree", "version": 1,
 "color": {"themes": [{"id": "light", "name": "Clair"}], "tokens": [{"name": n, "value": v, "usage": u} for n, v, u in C]},
 "type": {
  "fonts": [],
  "families": {"display": "\"Fraunces\", ui-serif, Georgia, serif", "sans": "\"Nunito\", ui-sans-serif, system-ui, sans-serif"},
  "groups": [
   {"name": "Titres (Fraunces)", "family": "display", "styles": [
     {"name": "result-name", "fontSize": "52px", "lineHeight": 1, "fontWeight": 700, "sample": "Inès", "usage": "Le prénom révélé au participant, en primary-text."},
     {"name": "page-title", "fontSize": "30px", "lineHeight": 1.1, "fontWeight": 700, "sample": "Noël 2026", "usage": "Titre d'écran, un seul par page (h1)."},
     {"name": "sheet-title", "fontSize": "24px", "lineHeight": 1.15, "fontWeight": 700, "sample": "Lancer le tirage ?", "usage": "Titre d'un panneau du bas et de la carte centrale du participant."},
     {"name": "card-title", "fontSize": "22px", "lineHeight": 1.2, "fontWeight": 600, "sample": "Vérifie la liste, puis lance le tirage", "usage": "Titre de la carte « À faire maintenant »."},
     {"name": "wordmark", "fontSize": "18px", "lineHeight": 1.2, "fontWeight": 700, "sample": "Under the Tree", "usage": "Nom de l'app dans la barre du haut, précédé de l'étoile, en primary-text."},
     {"name": "journal-line", "fontSize": "16px", "lineHeight": 1.35, "fontWeight": 600, "sample": "Le tirage a été effectué pour 5 participants", "usage": "Étape clé du journal, phrase citée telle que le groupe la lira."}]},
   {"name": "Texte (Nunito)", "family": "sans", "styles": [
     {"name": "button", "fontSize": "16px", "lineHeight": 1.2, "fontWeight": 700, "sample": "Lancer le tirage", "usage": "Libellé de bouton. 17px dans le pied d'un panneau du bas."},
     {"name": "row-title", "fontSize": "16px", "lineHeight": 1.3, "fontWeight": 600, "sample": "Camille", "usage": "Titre d'une ligne de liste."},
     {"name": "body", "fontSize": "15px", "lineHeight": 1.45, "fontWeight": 400, "sample": "Assure-toi que personne ne regarde ton écran.", "usage": "Texte courant, sous-titre d'écran."},
     {"name": "hint", "fontSize": "14px", "lineHeight": 1.45, "fontWeight": 400, "sample": "Tout ce qui s'est passé, à la vue de tous", "usage": "Sous-titre d'une ligne d'action, texte d'un encadré."},
     {"name": "status", "fontSize": "13px", "lineHeight": 1.4, "fontWeight": 400, "sample": "Envoyé, pas encore consulté", "usage": "Statut sous un prénom, aide sous un champ ou une liste."},
     {"name": "overline", "fontSize": "12px", "lineHeight": 1.3, "fontWeight": 700, "letterSpacing": "0.04em", "sample": "5 PARTICIPANTS", "usage": "Petit titre en capitales au-dessus d'une liste ou d'un groupe de champs (UiSectionTitle)."},
     {"name": "step-label", "fontSize": "12px", "lineHeight": 1.3, "fontWeight": 600, "sample": "Préparer", "usage": "Libellé sous un point de la frise ; 700 et primary-strong pour l'étape en cours."}]}]},
 "spacing": {"tokens": [
   {"name": "space-1", "value": "4px", "usage": "Entre un titre et son sous-titre."},
   {"name": "space-2", "value": "8px", "usage": "Entre une icône et son libellé dans un bouton, entre deux pavés."},
   {"name": "space-3", "value": "12px", "usage": "Entre l'avatar et le texte d'une ligne."},
   {"name": "space-4", "value": "16px", "usage": "Marge latérale de l'écran et des lignes de liste."},
   {"name": "space-5", "value": "20px", "usage": "Intérieur d'une carte."},
   {"name": "space-6", "value": "24px", "usage": "Entre deux blocs d'un écran."},
   {"name": "touch-target", "value": "44px", "usage": "Hauteur et largeur minimales de toute cible tactile (le code dit 40px au minimum ; les maquettes prennent 44)."},
   {"name": "row-min", "value": "60px", "usage": "Hauteur minimale d'une ligne de liste avec avatar."},
   {"name": "column-max", "value": "448px", "usage": "Largeur de la colonne de contenu et des panneaux du bas sur grand écran (max-w-md)."}]},
 "radius": {"tokens": [
   {"name": "radius-control", "value": "6px", "usage": "Boutons et champs (--ui-radius du code, 0.375rem)."},
   {"name": "radius-inset", "value": "10px", "usage": "Pavés et bandeaux posés dans une carte, contrôle segmenté."},
   {"name": "radius-panel", "value": "12px", "usage": "Encadrés d'avertissement, listes encadrées dans un panneau."},
   {"name": "radius-card", "value": "16px", "usage": "Cartes (UiCard, rounded-2xl)."},
   {"name": "radius-sheet", "value": "20px", "usage": "Coins hauts d'un panneau du bas."},
   {"name": "radius-pill", "value": "999px", "usage": "Avatars, boutons ronds, pastilles, barres de progression."}]},
 "shadow": {"tokens": [
   {"name": "shadow-card", "value": "0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)", "usage": "Relief d'une carte sur page : ombre chaude très courte et liseré."}]},
 "meta": {"source": "app/assets/css/main.css, app/app.config.ts, app/utils/avatars.ts et les maquettes du 15 novembre 2026"}
}
w('tokens.json', json.dumps(tokens, ensure_ascii=False, indent=1))

# ---------------- previews ----------------
FONTS = '<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Nunito:wght@400;500;600;700&display=swap" rel="stylesheet">'
BASE = '''*{box-sizing:border-box}
body{margin:0;padding:16px;background:var(--page);color:var(--ink);font-family:var(--font-sans,"Nunito",system-ui,sans-serif);font-size:16px;line-height:1.4}
.display{font-family:var(--font-display,"Fraunces",Georgia,serif)}
.col{max-width:390px;display:flex;flex-direction:column;gap:12px}
.rowx{display:flex;flex-wrap:wrap;gap:12px;align-items:center}
button,a{font-family:inherit}
.btn{height:48px;padding:0 18px;border:0;border-radius:var(--radius-control);font-size:16px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;gap:8px;text-decoration:none}
.btn-primary{background:var(--primary);color:var(--on-primary)}
.btn-outline{background:transparent;border:1px solid var(--primary);color:var(--primary-strong)}
.btn-ghost{background:transparent;color:var(--primary-strong);font-weight:600;font-size:15px;height:44px}
.btn-neutral{background:var(--ink);color:var(--on-primary)}
.btn-safe{background:var(--success);color:var(--on-primary)}
.btn-quiet{background:var(--surface-muted);border:1px solid var(--border);color:var(--ink)}
.over{margin:0;font-size:12px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--ink-muted)}
.list{list-style:none;margin:0;padding:0;background:var(--surface);border-top:1px solid var(--border);border-bottom:1px solid var(--border)}
.list>li{display:flex;align-items:center;gap:12px;min-height:60px;padding:8px 16px}
.list>li+li{border-top:1px solid var(--track)}
.av{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.t{flex-grow:1;min-width:0;display:flex;flex-direction:column}
.t b{font-weight:600;font-size:16px}
.st{display:flex;align-items:center;gap:5px;font-size:13px;color:var(--ink-muted)}
.card{background:var(--surface);border-radius:var(--radius-card);box-shadow:var(--shadow-card);padding:20px}
svg{flex-shrink:0}'''
def doc(marker, body, css=''):
    return f'''<!-- @dsCard {marker} -->
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
{FONTS}
<style>
{BASE}
{css}
</style>
</head>
<body>
{body}
</body>
</html>
'''
def ic(inner, s=20, sw=2, extra=''):
    return f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"{extra}>{inner}</svg>'
I = {
 'mail': '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
 'send': '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
 'check': '<path d="M20 6 9 17l-5-5"/>',
 'clock': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 'dash': '<circle cx="12" cy="12" r="9" stroke-dasharray="3.5 4"/>',
 'chev': '<path d="m9 18 6-6-6-6"/>',
 'eye': '<path d="M2.5 12S6 5 12 5s9.5 7 9.5 7-3.5 7-9.5 7-9.5-7-9.5-7z"/><circle cx="12" cy="12" r="3"/>',
 'undo': '<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5"/>',
 'cal': '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
 'pen': '<path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.500-5.500z"/>',
 'lock': '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
 'alert': '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.700-3L13.700 3.900a2 2 0 0 0-3.400 0zM12 9v4M12 17h.01"/>',
 'bang': '<path d="M12 7v6M12 17h.01"/>',
 'search': '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500"/>',
 'userplus': '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
}
STAR = '<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.800 2.200L12 22l-2.200-7.800L2 12l7.800-2.200z"/></svg>'
def av(e, c, cls=''):
    return f'<span class="av {cls}" aria-hidden="true" style="background:var(--avatar-{c});box-shadow:0 0 0 1px var(--avatar-{c}-ring)">{e}</span>'

comps = {}
# Button
comps['Button'] = ('Actions', 250, f'''<div class="col">
<div class="rowx"><button class="btn btn-primary">{ic(I['mail'])}Prévenir par email</button><button class="btn btn-outline">Revoir à qui j'offre un cadeau</button></div>
<div class="rowx"><button class="btn btn-ghost">Clôturer sans dévoiler</button><button class="btn btn-neutral">{ic(I['eye'])}Voir le résultat de Hugo</button></div>
<div class="rowx"><button class="btn btn-safe">Attendre la fête</button><button class="btn btn-quiet">Cacher mon résultat</button>
<button class="round todo" aria-label="Envoyer le lien de Lou">{ic(I['send'], 18)}</button><button class="round done" aria-label="Renvoyer le lien de Camille">{ic(I['send'], 18)}</button></div>
<div class="rowx"><a href="#" class="chip">{ic(I['cal'], 16)}Fête le 25 décembre{ic(I['pen'], 14)}</a></div>
</div>''', '''.round{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;padding:0}
.todo{border:0;background:var(--primary-soft);color:var(--primary-text)}
.done{border:1px solid var(--border);background:transparent;color:var(--ink-muted)}
.chip{min-height:44px;padding:0 12px;border:1px solid var(--border);border-radius:var(--radius-pill);background:var(--surface);color:var(--ink);font-size:15px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:8px}''',
'''Les actions de l'app : une seule action pleine (primary) par écran, les autres en contour, en lien ou en neutre.

- **Pleine (primary)** : l'action du moment (« Lancer le tirage », « Prévenir par email », « Dévoiler les résultats »). Envoyer par email est toujours l'action principale d'un envoi.
- **Contour** : une action déjà faite une fois ou secondaire (« Revoir à qui j'offre un cadeau »).
- **Lien** : l'alternative à l'action pleine, juste dessous (« Clôturer sans dévoiler »).
- **Neutre fort (ink)** : un accès de dernier recours qui ne doit pas ressembler à l'action normale (« Voir le résultat de Hugo »).
- **Sûr (success)** : la sortie conseillée d'un panneau irréversible (« Attendre la fête »).
- **Discret** : cacher, fermer.
- **Rond d'envoi** : sur une ligne de participant. Plein et clair (primary-soft) tant que ce n'est pas envoyé, contour gris ensuite. Toujours un `aria-label` avec le prénom.
- **Pastille modifiable** : une valeur que l'on change sur place (date de la fête), avec un crayon.

Hauteur 48px (52px dans le pied d'un panneau), jamais moins que touch-target. Rayon radius-control. Le libellé commence par un verbe et tutoie.''')

# Frise
def stp(kind, label, line=None, num=''):
    dot = {'done': f'<span class="dot d-done">{ic(I["check"], 14, 3)}</span>', 'now': f'<span class="dot d-now">{num or STAR.format(s=12)}</span>', 'todo': f'<span class="dot d-todo">{num}</span>'}[kind]
    ln = f'<span class="ln" style="background:var(--{line})"></span>' if line else ''
    cur = ' aria-current="step"' if kind == 'now' else ''
    return f'<li{cur}>{ln}{dot}<span class="lb{" now" if kind == "now" else ""}">{label}</span></li>'
def frise(items): return '<ol class="frise" aria-label="Étapes de l\'édition">' + ''.join(items) + '</ol>'
FCSS = '''.frise{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr))}
.frise li{position:relative;display:flex;flex-direction:column;align-items:center;gap:6px}
.ln{position:absolute;top:11px;left:50%;width:100%;height:2px}
.dot{position:relative;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700}
.d-done{background:var(--success);color:var(--on-primary)}
.d-now{background:var(--primary);color:var(--on-primary);box-shadow:0 0 0 4px var(--primary-soft)}
.d-todo{background:var(--page);border:2px solid var(--border);color:var(--ink-muted)}
.lb{font-size:12px;font-weight:600;color:var(--ink-muted);text-align:center}
.lb.now{font-weight:700;color:var(--primary-strong)}'''
comps['Frise'] = ('Navigation', 250, f'''<div class="col" style="gap:28px">
{frise([stp('now', 'Préparer', 'track', '1'), stp('todo', 'Tirer', 'track', '2'), stp('todo', 'Fêter', None, '3')])}
{frise([stp('done', 'Préparer', 'success'), stp('now', 'Tirage fait', 'track'), stp('todo', 'Fêter', None, '3')])}
{frise([stp('done', 'Préparer', 'success'), stp('done', 'Tirage fait', 'success'), stp('done', 'Fêté')])}
</div>''', FCSS,
'''La frise situe une édition en trois étapes, en haut de l'écran de l'organisateur comme de la page du participant.

- **Organisateur** : Préparer, Tirer, Fêter. **Participant** : Invitation, Tirage, Fête (avec le compte à rebours dans le libellé).
- **Faite** : rond success avec une coche, trait success vers la suivante.
- **En cours** : rond primary avec son numéro ou l'étoile, halo primary-soft, libellé en gras primary-strong, `aria-current="step"`.
- **À venir** : rond vide bordé de border, trait track.
- Le libellé change quand l'étape est passée (« Tirer » devient « Tirage fait », « Fêter » devient « Fêté »).
- Trois étapes, pas plus : la frise n'est pas une navigation, on ne clique pas dessus.

Proposition des maquettes du 15 novembre 2026, pas encore dans le code.''')

# ActionCard
comps['ActionCard'] = ('Contenu', 330, f'''<div class="col"><section class="card" style="display:flex;flex-direction:column;gap:14px">
<div style="display:flex;flex-direction:column;gap:4px">
<p style="margin:0;font-size:12px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--primary-strong)">À faire maintenant</p>
<h2 class="display" style="margin:0;font-weight:600;font-size:22px;line-height:1.2">Préviens chacun que le tirage est fait</h2>
</div>
<div style="display:flex;flex-direction:column;gap:6px">
<div role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" aria-label="Résultats consultés" style="height:8px;border-radius:999px;background:var(--track);overflow:hidden"><div style="width:20%;height:100%;border-radius:999px;background:var(--success)"></div></div>
<p style="margin:0;font-size:13px;color:var(--ink-muted)">1 sur 5 a consulté son résultat</p>
</div>
<button class="btn btn-primary" style="width:100%">{ic(I['mail'])}Prévenir par email</button>
<p style="margin:0;font-size:13px;color:var(--ink-muted);text-align:center">Sans adresse email ? Le bouton de chaque ligne partage le lien par WhatsApp ou SMS.</p>
</section></div>''', '',
'''La carte « À faire maintenant » dit à l'organisateur la seule chose à faire à cette étape, avec l'unique bouton plein de l'écran.

- Placée juste sous la frise. Une par écran.
- **Étiquette** « À faire maintenant » en overline primary-strong, puis un titre card-title à l'impératif, tutoyé.
- **Preuve** facultative : une coche et une phrase (« 4 participants, toutes les règles sont respectées »), une barre de progression success sur track, ou trois compteurs.
- **Action** : un bouton plein, pleine largeur. Une alternative éventuelle en lien dessous.
- **Aide** : une ligne status centrée qui dit où trouver l'autre chemin.
- Quand il n'y a plus rien à faire (édition clôturée), la carte devient discrète : pastille success-soft, titre, une phrase, pas de bouton.

Remplace `AdminStatusCard` du code (emoji dans un rond). Proposition des maquettes.''')

# ListRow
def row(avatar, name, st_html, trailing):
    return f'<li>{avatar}<span class="t"><b>{name}</b>{st_html}</span>{trailing}</li>'
todo_btn = lambda n: f'<button class="round todo" aria-label="Envoyer le lien de {n}">{ic(I["send"], 18)}</button>'
done_btn = lambda n: f'<button class="round done" aria-label="Renvoyer le lien de {n}">{ic(I["send"], 18)}</button>'
RCSS = '''.round{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;padding:0;flex-shrink:0}
.todo{border:0;background:var(--primary-soft);color:var(--primary-text)}
.done{border:1px solid var(--border);background:transparent;color:var(--ink-muted)}
.ico{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}'''
chev = f'<span style="color:var(--ink-dim);display:flex">{ic(I["chev"])}</span>'
comps['ListRow'] = ('Contenu', 470, f'''<div class="col" style="gap:6px;max-width:390px">
<h2 class="over" style="padding:0 4px">5 participants</h2>
<ul class="list" style="margin:0 -16px">
{row(av('🍭', 'mustard'), 'Inès', f'<span class="st">{ic(I["dash"], 14, 2.2)}Pas encore envoyé</span>', todo_btn('Inès'))}
{row(av('🐧', 'mustard'), 'Hugo', f'<span class="st" style="color:var(--warning-strong)">{ic(I["clock"], 14, 2.2)}Envoyé, pas encore consulté</span>', done_btn('Hugo'))}
{row(av('🦌', 'plum'), 'Camille', f'<span class="st"><span style="color:var(--success);display:flex">{ic(I["check"], 14, 2.5)}</span>Résultat consulté · 2×</span>', done_btn('Camille'))}
{row(f'<span class="ico" style="background:var(--primary-soft);color:var(--primary-text)">{ic(I["userplus"])}</span>', 'Ajouter des participants', '<span class="st" style="font-size:14px">Léa ne participe pas encore</span>', chev)}
{row(f'<span class="ico" style="background:var(--surface-muted);color:var(--ink-muted)">{ic(I["eye"])}</span>', 'Voir un seul résultat', '<span class="st" style="font-size:14px">Dernier recours, inscrit au journal</span>', chev)}
{row(f'<span class="ico" style="background:var(--danger-soft);color:var(--danger-strong)">{ic(I["undo"])}</span>', '<span style="color:var(--danger-strong)">Annuler et relancer le tirage</span>', '<span class="st" style="font-size:14px">Désistement, oubli… journalisé</span>', chev)}
</ul>
<p style="margin:0;padding:0 4px;font-size:13px;color:var(--ink-muted)">Ceux qui restent à prévenir sont en premier.</p>
</div>''', RCSS,
'''La ligne de liste porte presque tout le contenu de l'app : une personne avec son statut, ou une action qui ouvre un autre écran.

- **Liste** : pleine largeur sur téléphone (bords border en haut et en bas, séparateurs track), encadrée sur grand écran. Un petit titre overline au-dessus, une aide status dessous.
- **Une seule liste de participants, jamais découpée en sections.** Le statut est écrit sous le prénom et les lignes sont ordonnées : ce qui reste à faire en premier.
- **Statuts** (texte + icône, jamais la couleur seule) : « Pas encore envoyé » (cercle pointillé, ink-muted), « Envoyé, pas encore consulté » (horloge, warning-strong), « Résultat consulté · 2× » (coche success, texte ink-muted). Avant le tirage, rien du tout, ou « Invitation envoyée ».
- **À droite** : le rond d'envoi (voir Button) quand on peut envoyer, sinon un chevron ink-dim si la ligne ouvre un écran.
- **Ligne d'action** : icône dans un rond primary-soft (action courante), surface-muted (action rare) ou danger-soft (dangereuse), titre, sous-titre hint.
- **Danger** : titre danger-strong, toujours la dernière ligne de la dernière liste.
- « Ajouter » ferme une liste de personnes ; il ouvre une liste de règles (exclusions).
- Hauteur row-min, marges space-4, avatar à space-3 du texte.

Correspond à `UiList` et `UiListItem` du code.''')

# Avatar
comps['Avatar'] = ('Contenu', 230, f'''<div class="col" style="gap:20px">
<div class="rowx">{av('🦌', 'plum')}{av('🌰', 'mustard')}{av('🦉', 'pine')}{av('🧦', 'brick')}{av('⛄', 'frost')}{av('🕯️', 'kraft')}</div>
<div class="rowx" style="align-items:flex-end">{av('🍭', 'mustard', 'sm')}{av('🍭', 'mustard')}{av('🍭', 'mustard', 'lg')}</div>
<div class="rowx"><span class="stack">{av('🦌', 'plum', 'xs')}{av('🌰', 'mustard', 'xs')}{av('🍷', 'plum', 'xs')}{av('🦉', 'pine', 'xs')}</span>
<span class="stack">{av('🦌', 'plum', 'xs')}{av('🌰', 'mustard', 'xs')}{av('🍷', 'plum', 'xs')}{av('🦉', 'pine', 'xs')}<span class="more">+96</span></span></div>
</div>''', '''.sm{width:32px;height:32px;font-size:14px}.lg{width:80px;height:80px;font-size:36px}
.stack{display:flex;align-items:center}
.stack .xs{width:30px;height:30px;font-size:14px;box-shadow:0 0 0 2px var(--surface)!important}
.stack .xs+.xs,.more{margin-left:-8px}
.more{height:30px;min-width:30px;padding:0 8px;border-radius:999px;background:var(--track);box-shadow:0 0 0 2px var(--surface);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:var(--ink)}''',
'''L'avatar d'une personne : son emoji de Noël dans un rond de couleur, choisi par elle.

- **Six couleurs** : brick, pine, mustard, kraft, frost, plum. Fond `avatar-<couleur>`, liseré 1px `avatar-<couleur>-ring`.
- **Trois tailles** : 32px (dans une ligne dense, à droite d'une paire), 40px (ligne de liste), 80px (en-tête, résultat). 56px dans l'en-tête de la page d'un tirage.
- L'emoji est le seul endroit de l'interface où un emoji est permis : c'est le choix de la personne, pas une icône. Toujours `aria-hidden`, le prénom est à côté.
- **Pile** : quatre avatars au plus, qui se recouvrent de 8px, puis une pastille « +96 » sur track. Jusqu'à quatre personnes, on les montre toutes. La largeur ne change donc pas de 5 à 100 participants.
- Modifiable : un petit crayon rond en bas à droite, et le rond devient un bouton avec `aria-label` « Changer mon icône ».

Correspond à `UiAvatar` (app/utils/avatars.ts). La pile est une proposition des maquettes.''')

# Notice
comps['Notice'] = ('Contenu', 520, f'''<div class="col" style="gap:16px">
<div class="n-line">{ic(I['lock'])}<p>Le tirage est définitif : la liste des participants sera verrouillée. Personne, toi compris, ne verra les résultats.</p></div>
<div class="n-ok"><p>Une fois envoyé, le panneau passe à <strong>Louis</strong>.</p></div>
<section class="n-warn"><h2 class="display">À n'utiliser qu'en dernier recours</h2><p>Tout le groupe le saura : c'est inscrit au journal, avec le prénom.</p></section>
<ul class="recap"><li><span class="b ok">{ic(I['check'], 16, 3)}</span><span><b>Toutes les règles sont respectées</b><small>Aucune exclusion · personne ne se tire soi-même</small></span></li>
<li class="w"><span class="b wa">{ic(I['bang'], 16, 2.6)}</span><span><b>Léa ne participe pas encore</b><small>Après le tirage, il faudra l'annuler pour l'ajouter.</small></span></li></ul>
<div role="alert" class="n-danger"><p class="display">{ic(I['alert'], 24)}Le secret s'arrête ici, pour de bon</p><ul><li>Tu connaîtras tous les résultats avant la fête.</li><li>Impossible de revenir en arrière.</li></ul></div>
</div>''', '''p{margin:0}
.n-line{display:flex;gap:10px;align-items:flex-start;color:var(--ink-muted);font-size:14px;line-height:1.45}
.n-ok{padding:10px 12px;border-radius:var(--radius-inset);background:var(--success-softer);color:var(--success-strong);font-size:14px}
.n-warn{background:var(--warning-softer);border-radius:var(--radius-card);box-shadow:0 0 0 1px var(--warning-border);padding:16px;display:flex;flex-direction:column;gap:8px;color:var(--warning-deep);font-size:14px}
.n-warn h2{margin:0;font-weight:600;font-size:19px;line-height:1.2;color:var(--warning-ink)}
.recap{list-style:none;margin:0;padding:0;border:1px solid var(--border);border-radius:var(--radius-panel);overflow:hidden;background:var(--surface)}
.recap li{display:flex;gap:12px;align-items:flex-start;padding:12px 14px}
.recap li+li{border-top:1px solid var(--track)}
.recap li.w{background:var(--warning-softer);color:var(--warning-deep)}
.recap span span,.recap li>span:last-child{display:flex;flex-direction:column;gap:2px}
.recap b{font-size:15px;font-weight:600}.recap small{font-size:13px;line-height:1.4;color:var(--ink-muted)}.recap li.w small{color:var(--warning-deep)}
.b{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.ok{background:var(--success-soft);color:var(--success-strong)}.wa{background:var(--warning-soft);color:var(--warning-strong)}
.n-danger{border:2px solid var(--danger);border-radius:var(--radius-panel);background:var(--danger-softer);padding:14px;display:flex;flex-direction:column;gap:10px;color:var(--danger-deep)}
.n-danger p{display:flex;align-items:center;gap:8px;font-size:19px;font-weight:700;line-height:1.2}
.n-danger ul{margin:0;padding-left:18px;font-size:14px;line-height:1.4;display:flex;flex-direction:column;gap:6px}''',
'''Les messages qui accompagnent une décision, du plus discret au plus fort. Chacun correspond à un niveau de conséquence.

- **Ligne d'information** : une icône ink-muted et une phrase hint. Pour rappeler une règle sans alarmer (« Le tirage est définitif… »).
- **Bandeau positif** : success-softer, texte success-strong. Pour annoncer la suite (« le panneau passe à Louis »).
- **Encadré d'attention** : warning-softer, liseré warning-border, titre warning-ink en Fraunces, texte warning-deep. Pour une action permise mais visible de tous (dernier recours), ou une information manquante (date de la fête).
- **Récapitulatif** : liste encadrée dans un panneau de confirmation. Une ligne par vérification, pastille success-soft avec coche ou warning-soft avec point d'exclamation ; la ligne d'attention prend le fond warning-softer.
- **Encadré irréversible** : bord 2px danger, fond danger-softer, texte danger-deep, `role="alert"`. Réservé à ce qui ne se rattrape pas ET qui casse le secret (dévoiler avant la fête). Toujours suivi d'une phrase à recopier.

Jamais la couleur seule : chaque niveau a son icône et sa phrase. Une action dangereuse demande une confirmation (deuxième appui), une action irréversible une phrase à recopier.''')

# Counters
comps['Counters'] = ('Contenu', 110, '''<div class="col"><dl class="ct">
<div style="background:var(--primary-softer)"><dd class="display" style="color:var(--primary-strong)">3</dd><dt style="color:var(--primary-strong)">à prévenir</dt></div>
<div style="background:var(--warning-softer)"><dd class="display" style="color:var(--warning-strong)">1</dd><dt style="color:var(--warning-deep)">pas encore ouvert</dt></div>
<div style="background:var(--success-softer)"><dd class="display" style="color:var(--success-strong)">1</dd><dt style="color:var(--success-strong)">a découvert</dt></div>
</dl></div>''', '''.ct{margin:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.ct div{display:flex;flex-direction:column;gap:2px;padding:10px;border-radius:var(--radius-inset)}
.ct dd{margin:0;font-weight:700;font-size:26px;line-height:1}.ct dt{font-size:12px;font-weight:600;line-height:1.25}''',
'''Trois compteurs qui résument où en sont les participants après le tirage, dans la carte « À faire maintenant ».

- Toujours les trois, dans cet ordre : à prévenir (primary-softer), pas encore ouvert (warning-softer), a découvert (success-softer).
- Le chiffre en Fraunces 26px, le libellé en 12px dessous, en minuscules.
- Ils remplacent les titres de sections : la liste dessous reste d'un seul tenant, ordonnée dans le même ordre.
- Pas de compteur avant le tirage (README 13.2 : l'écran reste discret).

Proposition des maquettes.''')

# Segmented
comps['Segmented'] = ('Saisie', 80, '''<div class="col"><div role="radiogroup" aria-label="Message" class="seg">
<button role="radio" aria-checked="true" class="on">Tirage fait</button><button role="radio" aria-checked="false">Relance</button><button role="radio" aria-checked="false">Nouveau tirage</button>
</div></div>''', '''.seg{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px;padding:4px;border-radius:var(--radius-inset);background:var(--surface-muted)}
.seg button{height:40px;border:0;border-radius:7px;background:transparent;color:var(--ink-muted);font-size:14px;font-weight:600}
.seg .on{background:var(--surface);box-shadow:0 1px 2px rgba(60,30,10,.12);color:var(--ink);font-weight:700}''',
'''Le contrôle segmenté choisit le message à envoyer, en haut d'un panneau d'envoi ou de l'écran de sélection par email.

- Deux ou trois choix, jamais plus : « Invitation / Relance » avant le tirage, « Tirage fait / Relance / Nouveau tirage » après.
- Le choix par défaut suit l'étape de l'édition ; « Relance » quand on rouvre le panneau d'une personne déjà prévenue.
- Fond surface-muted sur une surface, track sur la page. Le segment choisi est une pastille surface avec une ombre courte.
- `role="radiogroup"` et `aria-checked` sur chaque segment.

Sert aussi à « Se connecter / Créer un compte » sur l'écran de connexion (déjà dans le code).''')

# Field
comps['Field'] = ('Saisie', 330, f'''<div class="col" style="gap:18px">
<div class="f"><label for="a">Recopie : JE VEUX VOIR LE TIRAGE</label><input id="a" type="text"></div>
<div class="f"><label for="b">Date de la fête</label><input id="b" type="text" value="25/12/2026" class="act"><small>Vendredi 25 décembre 2026 · dans 40 jours</small></div>
<div class="f" style="position:relative"><label for="c" class="vh">Chercher un prénom</label><span style="position:absolute;left:14px;top:15px;color:var(--ink-muted);display:flex">{ic(I['search'], 18, 2.2)}</span><input id="c" type="search" placeholder="Chercher un prénom" style="padding-left:42px"><small>Affiché à partir de 11 participants.</small></div>
<label class="ck"><input type="checkbox" checked>Je comprends que tout le groupe saura que j'ai regardé</label>
</div>''', '''.f{display:flex;flex-direction:column;gap:6px}
.f label{font-size:15px;font-weight:600}
.f input{height:48px;padding:0 12px;border:1px solid var(--field-border);border-radius:var(--radius-control);background:var(--surface);color:var(--ink);font-family:inherit;font-size:16px;width:100%}
.f input.act{border:2px solid var(--primary);font-weight:600}
.f small{font-size:13px;color:var(--ink-muted)}
.vh{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}
.ck{display:flex;align-items:flex-start;gap:12px;min-height:44px;font-size:15px;line-height:1.4}
.ck input{width:22px;height:22px;margin:1px 0 0;accent-color:var(--primary);flex-shrink:0}''',
'''Les champs de saisie : texte, date, recherche, case à cocher.

- Hauteur 48px, rayon radius-control, bord field-border, fond surface. Le champ actif prend un bord 2px primary.
- Le libellé est au-dessus, en 15px gras ; l'aide dessous en status. Jamais de libellé en placeholder seul.
- **Phrase à recopier** : le libellé donne la phrase exacte. Réservée aux actions irréversibles.
- **Date** : une vraie date (jour/mois/année) avec un calendrier ; l'aide redit le jour de la semaine et le délai.
- **Recherche** : loupe à gauche, croix pour effacer. Elle n'apparaît que dans une liste de plus de 10 personnes, ignore accents et majuscules, et surligne les lettres trouvées en warning-soft.
- **Case à cocher** : 22px, accent primary, le texte entier est cliquable.
- Taille de police 16px au minimum dans un champ, pour éviter le zoom automatique d'iOS.

Dans le code : `UInput`, `UTextarea`, `UCheckbox` de Nuxt UI en taille lg, et `AdminDateField`.''')

# Sheet
comps['Sheet'] = ('Panneaux', 470, f'''<div class="scr"><div class="sh" role="dialog" aria-label="Lancer le tirage">
<span class="grip" aria-hidden="true"></span>
<div><h1 class="display">Lancer le tirage ?</h1><p class="sub">Un dernier coup d'œil avant de tirer au sort.</p></div>
<div class="n-line">{ic(I['lock'])}<p>Le tirage est définitif : la liste des participants sera verrouillée.</p></div>
<div class="foot"><button class="btn btn-primary" style="height:52px;font-size:17px;width:100%">Tirer au sort</button><button class="btn" style="background:transparent;color:var(--ink);font-weight:600;width:100%;height:46px">Pas encore</button></div>
</div></div>''', '''body{padding:0}
.scr{max-width:390px;height:440px;background:var(--scrim);display:flex;flex-direction:column;justify-content:flex-end}
.sh{background:var(--surface);border-radius:var(--radius-sheet) var(--radius-sheet) 0 0;padding:10px 16px 24px;display:flex;flex-direction:column;gap:18px}
.grip{align-self:center;width:44px;height:5px;border-radius:999px;background:var(--border)}
h1{margin:0;font-weight:700;font-size:24px;line-height:1.15}.sub{margin:4px 0 0;font-size:15px;color:var(--ink-muted)}
p{margin:0}.n-line{display:flex;gap:10px;align-items:flex-start;color:var(--ink-muted);font-size:14px;line-height:1.45}
.foot{display:flex;flex-direction:column;gap:6px;margin-top:8px}''',
'''Le panneau du bas porte toute action courte sur un élément : envoyer à quelqu'un, confirmer le tirage, choisir une personne, changer la date.

- **Quand** : une action courte s'ouvre dans un panneau ; un formulaire long a son propre écran (« Voir un seul résultat », la sélection par email).
- **Structure**, de haut en bas : poignée, titre sheet-title (souvent une question), une phrase de contexte, le contenu, puis le pied avec l'action pleine (52px) et la sortie en lien dessous.
- **Confirmer** : le panneau enregistre avec son bouton ; le fermer autrement abandonne.
- **Ordre du pied** : l'action, puis « Pas encore » ou « Annuler ». Pour une action irréversible, l'ordre s'inverse : la sortie sûre d'abord (bouton success), l'action dangereuse dessous et inactive tant que la phrase n'est pas recopiée.
- Coins hauts radius-sheet, fond surface, largeur column-max au plus sur grand écran.
- Le voile derrière est celui de `UDrawer` ; le jeton scrim n'est qu'une approximation des maquettes.

Dans le code : `UDrawer` de Nuxt UI (un composant `UiSheet` est prévu, README 23.4).''')

for name, (group, height, body, css, readme) in comps.items():
    w(f'components/{name}/preview.html', doc(f'group="{group}" height={height}', body, css))
    w(f'components/{name}/README.md', readme + '\n')

# ---------------- Cover ----------------
cover = '''<!-- @dsCard height=320 -->
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
''' + FONTS + '''
<style>
body{margin:0;background:var(--page)}
.cover{position:relative;width:960px;height:320px;overflow:hidden;background:var(--page)}
svg{position:absolute;inset:0}
.brand{fill:var(--primary)}.pine{fill:var(--success)}.star{fill:var(--star)}.kraft{fill:var(--track)}.ink{fill:var(--ink)}.hole{fill:var(--page)}
.txt{position:absolute;left:48px;bottom:40px;width:440px}
.name{margin:0;font-family:var(--font-display,"Fraunces",Georgia,serif);font-weight:700;font-size:88px;line-height:.95;color:var(--ink)}
.tag{margin:16px 0 0;font-family:var(--font-sans,"Nunito",system-ui,sans-serif);font-size:14px;color:var(--ink-muted)}
</style>
</head>
<body>
<div class="cover">
<!--
blocks: primary 176x256 (slab), success 256x112, star 112 disc, track 128x128, ink 176x48 pill — sides are multiples of space-4 (16px)
arrangement: one tall brick slab bleeding off the top, with satellites stacked to its right and bleeding off the right edge
pattern: discs, from "soft, friendly, large radii" — the avatar round and the punched hole of a gift tag, cut out of the blocks in the page colour
scales: pitch 48px (3 x space-4), disc radius 12px (space-3), block corners radius-card 16px, pill and disc = half the short side
-->
<svg width="960" height="320" viewBox="0 0 960 320" aria-hidden="true">
<rect class="brand" x="528" y="-16" width="176" height="256" rx="16"/>
<rect class="pine" x="720" y="64" width="256" height="112" rx="16"/>
<rect class="star" x="720" y="192" width="112" height="112" rx="56"/>
<rect class="kraft" x="848" y="192" width="128" height="128" rx="16"/>
<rect class="ink" x="528" y="256" width="176" height="48" rx="24"/>
<g class="hole">
<circle cx="568" cy="48" r="12"/><circle cx="616" cy="48" r="12"/><circle cx="664" cy="48" r="12"/>
<circle cx="568" cy="96" r="12"/><circle cx="616" cy="96" r="12"/><circle cx="664" cy="96" r="12"/>
<circle cx="568" cy="144" r="12"/><circle cx="616" cy="144" r="12"/><circle cx="664" cy="144" r="12"/>
<circle cx="568" cy="192" r="12"/><circle cx="616" cy="192" r="12"/><circle cx="664" cy="192" r="12"/>
<circle cx="760" cy="96" r="12"/><circle cx="808" cy="96" r="12"/><circle cx="856" cy="96" r="12"/><circle cx="904" cy="96" r="12"/>
<circle cx="760" cy="144" r="12"/><circle cx="808" cy="144" r="12"/><circle cx="856" cy="144" r="12"/><circle cx="904" cy="144" r="12"/>
</g>
</svg>
<div class="txt"><p class="name">Under the Tree</p><p class="tag">Le Secret Santa de la famille, simple et chaleureux.</p></div>
</div>
</body>
</html>
'''
w('components/Cover/preview.html', cover)

# ---------------- README ----------------
w('README.md', '''# Under the Tree

Le design system de **Under the Tree**, une petite application web qui organise le Secret Santa d'une famille ou d'un groupe d'amis. Elle sert un mois par an, presque toujours sur téléphone, à des gens qui ne l'ont jamais vue : elle doit se comprendre sans mode d'emploi et garder l'esprit de Noël sans décor.

## D'où ça vient

- **Du code** (valeurs exactes) : `app/assets/css/main.css` (palettes brick, pine, mustard, cranberry, kraft et jetons de surface), `app/app.config.ts` (rôles des couleurs dans Nuxt UI 4), `app/utils/avatars.ts` (six couleurs d'avatar), `app/components/ui/*` (carte, liste, avatar, titres).
- **Des maquettes du 15 novembre 2026** (propositions, pas encore codées) : la frise en trois étapes, la carte « À faire maintenant », les compteurs, la pile d'avatars, les panneaux de confirmation, l'encadré irréversible, la recherche au-delà de 10 personnes.

Chaque composant dit dans son guide s'il existe déjà dans le code ou s'il est une proposition. Un seul thème : l'app est en clair uniquement (`colorMode: false`).

## Principes

1. **Une seule chose à faire par écran.** La carte « À faire maintenant » porte l'unique bouton plein (`primary`). Tout le reste est en contour, en lien ou dans une liste.
2. **Le statut s'écrit, il ne se devine pas.** Une ligne dit « Envoyé, pas encore consulté » avec une icône ; la couleur ne fait que confirmer.
3. **Le secret se voit.** Ce qui touche au secret (voir un résultat, dévoiler) est annoncé avant, inscrit au journal, et montre la phrase exacte que le groupe lira.
4. **Plus c'est irréversible, plus c'est lent.** Confirmation simple pour ce qui se rattrape, phrase à recopier pour ce qui ne se rattrape pas, et la sortie sûre mise en avant.
5. **Tenir de 4 à 100 personnes.** Listes d'un seul tenant et ordonnées, pile d'avatars plafonnée à quatre, recherche à partir de 11.
6. **Noël par la matière, pas par le décor.** Papier kraft, rouge brique, vert sapin, moutarde de l'étoile, une serif ronde pour les titres. Pas de flocons, pas de guirlandes.

## Voix

- **Tutoiement**, phrases courtes, pas de jargon : « Assure-toi que personne ne regarde ton écran. »
- Un bouton commence par un verbe et dit ce qui va se passer : « Lancer le tirage », « Prévenir par email », « Dévoiler quand même ».
- Une question en titre de panneau : « Lancer le tirage ? », « Le résultat de qui ? ».
- Une erreur dit quoi faire : « Ce lien n'est plus valable. Demande-en un nouveau à ton organisateur. »
- On dit **organisateur** (plus « gardien »), **tirage**, **fête**, **liste de souhaits**, **journal du groupe**.
- Trois langues (français, anglais, allemand) : aucun texte en dur, tout passe par les dictionnaires.

## Couleurs

| Rôle | Jetons | Emploi |
|---|---|---|
| Papier | `page`, `surface`, `surface-muted`, `track`, `border` | Le fond kraft et les cartes blanc cassé posées dessus |
| Encre | `ink`, `ink-muted`, `ink-dim` | Texte, texte secondaire, chevrons |
| Action | `primary`, `primary-text`, `primary-strong`, `primary-soft`, `primary-softer` | Rouge brique : l'action du moment, l'étape en cours, le logo |
| Fait | `success`, `success-strong`, `success-soft`, `success-softer` | Vert sapin : étapes faites, progression, coche, sortie sûre |
| Attention | `warning`, `warning-strong`, `warning-deep`, `warning-ink`, `warning-soft`, `warning-softer`, `warning-border`, `star` | Moutarde : en attente, dernier recours, information manquante, l'étoile |
| Danger | `danger`, `danger-strong`, `danger-deep`, `danger-soft`, `danger-softer` | Canneberge, plus froid que la brique pour ne jamais se confondre avec l'action |
| Avatars | `avatar-<couleur>`, `avatar-<couleur>-ring` | brick, pine, mustard, kraft, frost, plum |

Règles :
- Un écran nomme un **rôle**, jamais une teinte.
- `primary` plein : une fois par écran. `on-primary` dessus.
- Le texte passe par `ink` ou `ink-muted` ; sur un fond teinté, par le jeton `-strong` ou `-deep` de la même famille. `ink-dim` et `star` ne portent jamais de texte.
- Brique et sapin ne sont jamais le seul moyen de distinguer deux états : toujours une icône ou un mot avec.

## Typographie

- **Fraunces** (serif, 600 et 700) pour ce qui se lit comme une carte : titres d'écran, titre de la carte du moment, prénom révélé, phrases du journal, nom de l'app.
- **Nunito** (400, 600, 700) pour tout le reste.
- Les deux sont chargées depuis Google Fonts ; il n'y a pas de fichier de police dans ce système.
- Un seul titre d'écran (`page-title`) par page. Les petits titres de liste sont en `overline`, en capitales.

## Forme et espace

- Une **colonne de la largeur d'un téléphone** sur tous les écrans (`column-max`), marges `space-4`, blocs séparés de `space-6`.
- Cartes `radius-card` avec `shadow-card` ; boutons et champs `radius-control` ; avatars et pastilles ronds.
- Listes pleine largeur sur téléphone, à bords `border` et séparateurs `track`.
- Toute cible tactile fait au moins `touch-target`.

## Icônes et images

- Icônes au trait **Lucide** (`@iconify-json/lucide` dans le code), 2px, extrémités rondes, 18 à 20px, dans la couleur du texte voisin.
- **Aucun emoji comme icône.** Deux exceptions voulues : l'avatar choisi par chaque personne, et l'unique 🎁 des messages envoyés.
- L'**étoile à quatre branches** précède le nom de l'app et marque l'étape en cours ; en `star`, elle sert de puce aux idées de cadeaux.
- L'**enveloppe** est l'illustration de la page d'un tirage : en pointillés avant le tirage, cachetée de brique quand il est fait, ouverte une fois le résultat vu, verrouillée si le lien n'est plus valable.
- Le logo est dans le groupe d'assets « Logos » (`favicon.svg`, copié tel quel de `public/`).

## Composants

| Composant | Rôle | Dans le code ? |
|---|---|---|
| `Button` | Actions : pleine, contour, lien, neutre, sûre, rond d'envoi, pastille modifiable | Oui (Nuxt UI), variantes à aligner |
| `Frise` | Les trois étapes d'une édition | Proposition |
| `ActionCard` | « À faire maintenant » | Proposition (remplace `AdminStatusCard`) |
| `Counters` | Trois compteurs après le tirage | Proposition |
| `ListRow` | Ligne de personne avec statut, ligne d'action | Oui (`UiList`, `UiListItem`) |
| `Avatar` | Rond d'avatar, pile plafonnée | Oui (`UiAvatar`) ; pile proposée |
| `Notice` | Information, attention, récapitulatif, irréversible | En partie (`UAlert`) |
| `Segmented` | Choix du message | Oui (connexion) |
| `Field` | Texte, date, recherche, case | Oui (Nuxt UI, `AdminDateField`) ; recherche proposée |
| `Sheet` | Panneau du bas | Oui (`UDrawer`) |

Les aperçus sont du HTML statique écrit avec les jetons : il n'y a pas de bibliothèque de composants à charger. Pour construire un écran, reprends la structure d'un aperçu et les règles de son guide.

## Ce qui manque

- Le thème sombre (l'app n'en a pas).
- Les fichiers de police (chargées depuis Google Fonts).
- Les illustrations d'enveloppe en fichiers : elles n'existent que dans les maquettes.
- Les composants du journal (frise à fil rouge) et de la liste de souhaits, déjà dans le code mais pas repris ici.
- La teinte exacte du voile derrière un panneau (`scrim` est une approximation).
''')

w('assets/Logos/README.md', '''# Logos

`favicon.svg` : l'icône de l'app, un sapin blanc cassé sous son étoile moutarde, sur un carré arrondi brique. Copié tel quel de `public/favicon.svg`.

- Couleurs : fond `#a43a2f` (primary-text), sapin `#fffdf9` (surface), étoile `#e6b94a` (star).
- À utiliser comme icône d'onglet et d'écran d'accueil. Dans l'interface, le nom de l'app s'écrit en Fraunces précédé de l'étoile à quatre branches, sans ce carré.
- Ne pas le redessiner, ne pas changer ses couleurs.
''')

index = {"v": 3, "layout": "files", "createdOnFiles": {"v": 1, "at": "2026-11-15T08:25:00Z"}, "title": "Under the Tree", "namespace": "UnderTheTree", "libraries": [],
 "sections": {}, "groups": ["Logos"],
 "assetGroups": {"Logos": {"name": "Logos", "tile": "l", "order": ["favicon.svg"], "files": {"favicon.svg": {"name": "favicon.svg", "blob": "e6a8d6e779dc906a53c322e6438caaa1", "size": 311, "type": "image/svg+xml"}}}},
 "blobs": {}, "docs": {"sections": []},
 "lastChange": {"by": "Julien Rabin", "at": "2026-11-15T08:25:00Z", "via": "Claude", "note": "Première version, extraite du code et des maquettes du 15 novembre 2026"}}
w('design-system.json', json.dumps(index, ensure_ascii=False, indent=1))

# checks
names = [t['name'] for fam in ('color', 'spacing', 'radius', 'shadow') for t in tokens[fam]['tokens']]
assert len(names) == len(set(names)), 'dup'
import re
used = set()
for f in R.rglob('preview.html'):
    used |= set(re.findall(r'var\(--([A-Za-z0-9_.-]+)', f.read_text()))
missing = used - set(names) - {'font-sans', 'font-display'}
print('missing vars:', missing, '| colors:', len(C))
for f in sorted(R.rglob('*')):
    if f.is_file(): print(f.relative_to(R.parent))
