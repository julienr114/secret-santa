import pathlib, json, re, shutil
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
O = pathlib.Path('/home/claude/gen/orig')
def parts(name):
    s = (O/f'{name}.dc.html').read_text(); a = s.index('<div style="width: 390px'); b = s.index('</x-dc>'); return s, a, b, s[a:b]
def between(body, start, end, from_=0):
    i = body.index(start, from_); j = body.index(end, i); return body[i:j].rstrip()
HDR = '<div style="display: flex; align-items: center; gap: 12px">\n      <span aria-hidden="true" style="width: 48px;'
LINK = 'min-height: 44px; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px'
def preview(text, link):
    return f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.45">
        <p style="margin: 0">{text}</p>
        <p style="margin: 0; font-weight: 600; color: #8a2f27">{link}</p>
      </div>
      <a href="PersonnaliserMessage.dc.html" style="{LINK}; align-self: flex-start; text-decoration: none">Personnaliser le message{ic('<path d="m9 18 6-6-6-6"/>', 16, 2.4)}</a>
    </div>'''
def more(sub):
    return f'''    <button style="margin: 0 -16px -24px; min-height: 56px; padding: 6px 16px; box-sizing: border-box; border: 0; border-top: 1px solid #e9dcc5; background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left">
      <span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 600">Autre moyen, ou un souci ?</span><span style="font-size: 13px; color: #57534e">{sub}</span></span>{CHEV}
    </button>'''
def sheet(tpl, name, title, label, top, header, inner, h=844):
    s, a, b, _ = tpl
    html = f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; color: #5c554c">Noël 2026</div>
  <section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    {header}
{inner}
  </section>
</div>
'''
    save(name, s[:a] + html + s[b:], title, h)
bottom = lambda *xs: '    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">\n      ' + '\n      '.join(xs) + '\n    </div>'

# ----- envoi, avec adresse -----
E_ = parts('Envoi'); eb = E_[3]
eh = between(eb, HDR, '<div role="radiogroup"').replace('Encore 3 personnes à prévenir', 'Pas encore envoyé')
i = eb.index('<button style="width: 100%; min-height: 56px;'); eprimary = eb[i:eb.index('</button>', i) + 9]
i = eb.index('<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">'); egrid = eb[i:eb.index('</div>', eb.index('Copier', i)) + 6]
emiddle = between(eb, '<div role="radiogroup"', '<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">')
MSG = ('Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :', 'under-the-tree.party/p/aIFR…')
sheet(E_, 'Envoi.dc.html', 'Envoyer à une personne', 'Envoyer à Inès', 350, eh, preview(*MSG) + '\n' + bottom(eprimary, egrid) + '\n' + more('Copier le lien seul, corriger l’adresse, régénérer le lien'))
# ----- envoi, sans adresse -----
S_ = parts('EnvoiSansEmail'); sb = S_[3]
sh = between(sb, HDR, '<div role="radiogroup"').replace('Encore 3 personnes à prévenir', 'Pas encore envoyé')
i = sb.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">'); sbot = sb[i:sb.rindex('</div>', 0, sb.rindex('</section>'))+6]
sbot = '    ' + sbot
MSGR = ('Rose, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :', 'under-the-tree.party/p/aIFR…')
sheet(S_, 'EnvoiSansEmail.dc.html', 'Envoyer à une personne sans adresse email', 'Envoyer à Rose', 300, sh, preview(*MSGR) + '\n' + sbot + '\n' + more('Copier le lien seul, régénérer le lien'))
J_ = parts('EnvoiAjouterEmail'); jb = J_[3]
i = jb.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">'); jbot = '    ' + jb[i:jb.rindex('</div>', 0, jb.rindex('</section>'))+6]
sheet(J_, 'EnvoiAjouterEmail.dc.html', 'Envoi — ajouter l’adresse email sans quitter le panneau', 'Envoyer à Rose', 220, sh, preview(*MSGR) + '\n' + jbot + '\n' + more('Copier le lien seul, régénérer le lien'))

# ----- renvoi -----
R_ = parts('Renvoi'); rb_ = R_[3]
rh = between(rb_, HDR, '<div role="radiogroup"')
i = rb_.index('<button style="width: 100%; min-height: 56px;'); rprimary = rb_[i:rb_.index('</button>', i) + 9]
sheet(R_, 'Renvoi.dc.html', 'Envoi — renvoyer à quelqu’un', 'Renvoyer à Hugo', 400, rh, preview("Petit rappel Hugo : ton lien t'attend, pense à l'ouvrir. Ton lien :", 'under-the-tree.party/p/k9Qd…') + '\n' + bottom(rprimary) + '\n' + more('Partager, copier, corriger l’adresse, dépannage'))
li = lambda t, s_='', first=False: f'''      <li><button style="width: 100%; min-height: 56px; padding: 8px 16px; box-sizing: border-box; border: 0;{'' if first else ' border-top: 1px solid #e9dcc5;'} background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">{t}</span>{f'<span style="font-size: 13px; color: #57534e">{s_}</span>' if s_ else ''}</span></button></li>\n'''
H2s = "margin: 0; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e"
BACK = '<button style="align-self: flex-start; min-height: 44px; margin: -8px 0; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px">' + ic('<path d="m15 18-6-6 6-6"/>', 16, 2.4) + 'Retour</button>'
UL = 'list-style: none; margin: 0 -16px; padding: 0; border-top: 1px solid #e9dcc5; border-bottom: 1px solid #e9dcc5'
sheet(R_, 'RenvoiPepin.dc.html', 'Envoi — « Autre moyen, ou un souci ? » ouvert', 'Renvoyer à Hugo', 250, rh, f'''    {BACK}
    <div style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2s}">L’email n’arrive pas</h2>
      <ul style="{UL}">
{li('Partager par WhatsApp, SMS…', first=True)}{li('Copier le message')}{li('Copier le lien seul')}{li('Corriger son adresse email', 'hugo-demo@example.com')}      </ul>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2s}">Dépannage</h2>
      <ul style="{UL}">
{li('Pas envoyé finalement ?', 'Remet Hugo dans « à prévenir »', True)}{li('Régénérer son lien', 'S’il a été transféré par erreur. Un second appui confirme.')}      </ul>
    </div>''')


print(OUT)
