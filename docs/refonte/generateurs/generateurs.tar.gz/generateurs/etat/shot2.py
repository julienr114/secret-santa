import sys,json,subprocess
names=sys.argv[2:]; out=sys.argv[1]; H=int(max(json.load(open('/tmp/v3meta.json'))[n]['h'] for n in names)); H=min(H,2600)
html=''
for f in names:
    s=open('/home/claude/s/'+f+'.dc.html',encoding='utf-8').read()
    i=s.index('<div style="width: 390px;',s.index('<x-dc>')); j=s.rindex('</div>\n</x-dc>')+6
    html+=f'<div style="width:390px;height:{H}px;overflow:hidden;font-family:Nunito,sans-serif;flex-shrink:0">'+s[i:j]+'</div>'
open('/tmp/a.html','w').write('<meta charset="utf-8"><body style="margin:0;display:flex;align-items:flex-start;gap:6px;background:#ddd">'+html)
subprocess.run(['google-chrome','--headless','--no-sandbox','--disable-gpu','--hide-scrollbars','--screenshot='+out,f'--window-size={396*len(names)},{H}','/tmp/a.html'],capture_output=True)
