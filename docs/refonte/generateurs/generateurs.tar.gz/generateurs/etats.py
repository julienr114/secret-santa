import pathlib, json, re
src = open('/home/claude/gen/groupe.py').read().split("past = lambda")[0]
exec(src)
OUT = {}
def save(name, text, title, h=None):
    a = text.index('<title>'); b = text.index('</title>') + 8
    text = text[:a] + f'<title>{title}</title>' + text[b:]
    if h:
        text = re.sub(r'(width: 390px; height: )\d+px', lambda m: f'{m.group(1)}{h}px', text, count=1)
        text = re.sub(r'"height":\d+', f'"height":{h}', text)
    else:
        h = int(re.search(r'"height":(\d+)', text).group(1))
    (P/name).write_text(text); OUT[name] = h
def cut_section(t, marker):
    k = t.index(marker); a = t.rindex('<section', 0, k); b = t.index('</section>', k) + len('</section>')
    return a, b
SEARCH = lambda ph: f'''<div style="position: relative">
      <label for="q" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%)">{ph}</label>
      <span aria-hidden="true" style="position: absolute; left: 14px; top: 15px; color: #57534e; display: flex">{ic('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500"/>', 18, 2.2)}</span>
      <input id="q" type="search" placeholder="{ph}" style="width: 100%; height: 48px; box-sizing: border-box; padding: 0 12px 0 42px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>'''
BIG = [('Adèle', '🎅', 'brick'), ('Agathe', '🍪', 'kraft'), ('Albane', '⛄', 'frost'), ('Alexis', '🦊', 'pine'), ('Ambre', '🧣', 'plum'), ('Anatole', '🌰', 'mustard')]
def bav(e, c, size=40, fs=18): return av(e, c, size, fs)
FOLDSETS = [(('🦊', 'pine'), ('🧣', 'plum'), ('🍬', 'frost')), (('🎁', 'mustard'), ('⛸️', 'kraft'), ('🛷', 'brick')), (('🥨', 'mustard'), ('🍎', 'brick'), ('🧝', 'pine'))]
_fold_i = [0]
def stack3(who):
    def one(e, c, x):
        bg, ring = SH[c]
        return f'<span style="position: absolute; top: 7px; left: {x}px; width: 26px; height: 26px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 2px #fffdf9, 0 0 0 3px {ring}; display: flex; align-items: center; justify-content: center; font-size: 12px">{e}</span>'
    return '<span aria-hidden="true" style="position: relative; width: 44px; height: 40px; flex-shrink: 0">' + ''.join(one(e, c, i * 9) for i, (e, c) in enumerate(who)) + '</span>'
def foldrow(n, sub='', gap=True):
    who = FOLDSETS[_fold_i[0] % 3]; _fold_i[0] += 1
    sp = '        <li aria-hidden="true" style="height: 10px; background: #f7f2e9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad; margin-bottom: -1px"></li>\n' if gap else ''
    s_ = f'<span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: #57534e">{sub}</span>' if sub else ''
    return f"""        <li style="border-top: 1px solid #e9dcc5"><button aria-expanded="false" style="width: 100%; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border: 0; background: transparent; color: #292524; font-family: inherit; display: flex; align-items: center; gap: 12px; text-align: left">
          {stack3(who)}
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 15px; color: #8a2f27">Voir les {n} autres</span>{s_}</span>
          <span style="width: 44px; height: 44px; margin-right: -12px; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="m6 9 6 6 6-6"/>', 20, 2.4)}</span>
        </button></li>
""" + sp
MORE = lambda n, gap=True: foldrow(n, '', gap)
SENDB = lambda n: f'<button aria-label="Envoyer le lien de {n}" style="width: 44px; height: 44px; border: 0; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{ic("<path d=\'M22 2 11 13M22 2l-7 20-4-9-9-4z\'/>", 18)}</button>'
DASH = ic('<circle cx="12" cy="12" r="9" stroke-dasharray="3.500 4"/>', 14, 2.2)
def lrow(n, e, c, sub='', trail=CHEV, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    s = f'<span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: #57534e">{sub}</span>' if sub else ''
    return f'''        <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">
          {bav(e, c)}
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span>{s}</span>
          {trail}
        </li>
'''
def lsec(title, body, foot=''):
    f = f'\n      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">{foot}</p>' if foot else ''
    return f'''<section style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="{H2}">{title}</h2>
      {SEARCH('Chercher un prénom')}
      <ul style="{LIST}">
{body}      </ul>{f}
    </section>'''

# ---------- grands groupes ----------
t = (P/'Main.dc.html').read_text()
a, b = cut_section(t, '>4 participants</h2>')
body = ''.join(lrow(n, e, c, first=(i == 0)) for i, (n, e, c) in enumerate(BIG)) + MORE(94) + row(bubble('userplus'), 'Ajouter des participants')
t2 = t[:a] + lsec('100 participants', body, 'Triés par prénom. La recherche apparaît au-delà de 10 participants.') + t[b:]
t2 = t2.replace('4 participants, toutes les règles sont respectées.', '100 participants, toutes les règles sont respectées.').replace('Amis de Camille · Budget 20 €', 'Comité d’entreprise · Budget 15 €')
save('Preparer100.dc.html', t2, 'Édition à préparer — 100 participants', 1290)

t = (P/'Suivi.dc.html').read_text()
a, b = cut_section(t, '>5 participants</h2>')
body = ''.join(lrow(n, e, c, DASH + 'Pas encore envoyé', SENDB(n), first=(i == 0)) for i, (n, e, c) in enumerate(BIG)) + MORE(58)
t2 = t[:a] + lsec('À prévenir · 64', body, 'Touche un compteur pour changer de liste. La recherche porte sur les 100 participants.') + t[b:]
# counters as filters
for old, new in [('line-height: 1; color: #8a2f27">3</dd>', 'line-height: 1; color: #8a2f27">64</dd>'), ('line-height: 1; color: #79511d">1</dd>', 'line-height: 1; color: #79511d">21</dd>'), ('line-height: 1; color: #274e34">1</dd>', 'line-height: 1; color: #274e34">15</dd>'),
                 ('padding: 10px; border-radius: 10px; background: #fbf3f1"', 'padding: 10px; border-radius: 10px; background: #fbf3f1; box-shadow: 0 0 0 2px #b8483a"'), ('Famille Camille</p>', 'Comité d’entreprise</p>')]:
    assert old in t2, old; t2 = t2.replace(old, new)
save('Suivi100.dc.html', t2, 'Tirage fait — 100 participants', 1560)

t = (P/'SelectionEmail.dc.html').read_text()
a = t.index(f'<ul style="{LIST}">'); b = t.index('</ul>', a) + 5
def crow(n, e, c, first=False):
    bt = '' if first else ' style="border-top: 1px solid #e9dcc5"'
    return f'''        <li{bt}>
          <label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">
            {bav(e, c)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="font-size: 13px; color: #57534e">Pas encore envoyé · {n.lower().replace('è', 'e')}@exemple.fr</span></span>
            <input type="checkbox" checked style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
          </label>
        </li>
'''
ul = SEARCH('Chercher un prénom') + f'\n      <ul style="{LIST}">\n' + ''.join(crow(n, e, c, i == 0) for i, (n, e, c) in enumerate(BIG[:5])) + MORE(95, False) + '      </ul>'
t2 = t[:a] + ul + t[b:]
for old, new in [('2 sélectionnés sur 5', '64 sélectionnés sur 100'), ('Tout sélectionner', 'Tout désélectionner'), ('Envoyer 2 emails', 'Envoyer 64 emails'), ('Aperçu, pour Inès', 'Aperçu, pour Adèle'), ('Inès, le tirage est fait !', 'Adèle, le tirage est fait !')]:
    assert old in t2, old; t2 = t2.replace(old, new)
t2 = t2.replace('Chacun le reçoit avec son prénom, son lien et dans sa langue.', '7 personnes sans adresse ne sont pas dans la liste : partage-leur le lien à la main.')
save('SelectionEmail100.dc.html', t2, 'Sélection par email — 100 participants', 1010)

t = (P/'GroupeMembres.dc.html').read_text()
a, b = cut_section(t, 'Ajouter une personne')
body = ''.join(lrow(n, e, c, f'{n.lower().replace("è", "e")}@exemple.fr', first=(i == 0)) for i, (n, e, c) in enumerate(BIG)) + MORE(94) + row(bubble('userplus'), 'Ajouter une personne')
t2 = t[:a] + lsec('100 personnes', body, 'L’historique de ceux qui ne participent plus est conservé.') + t[b:]
t2 = t2.replace('<p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille</p>', '<p style="margin: 0; font-size: 15px; color: #57534e">Comité d’entreprise</p>')
save('GroupeMembres100.dc.html', t2, 'Membres — 100 personnes', 1060)

# ---------- clôturée sans dévoiler ----------
t = (P/'Cloturee.dc.html').read_text()
a, b = cut_section(t, 'Le tirage · 5 participants')
people = [('Camille', 'plum', '🦌'), ('Hugo', 'mustard', '🐧'), ('Inès', 'mustard', '🍭'), ('Louis', 'mustard', '🎄'), ('Rose', 'plum', '🐧')]
body = ''.join(lrow(n, e, c, 'A participé', '', first=(i == 0)) for i, (n, c, e) in enumerate(people))
sec = f'''<section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">5 participants</h2>
      <ul style="{LIST}">
{body}      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Les résultats n’ont pas été dévoilés. Ils servent quand même à éviter les mêmes paires l’an prochain.</p>
    </section>'''
t2 = t[:a] + sec + t[b:]
for old, new in [('Résultats dévoilés</h2>', 'Édition clôturée</h2>'), ("Les listes de souhaits restent modifiables jusqu'à la clôture de l'édition.", 'En lecture seule. Le tirage reste secret, même pour toi.')]:
    assert old in t2, old; t2 = t2.replace(old, new)
k = t2.index('Clôturer l\'édition</span>') if "Clôturer l'édition</span>" in t2 else -1
if k > 0:
    a = t2.rindex('<li>', 0, k); b = t2.index('</li>', k) + 5
    t2 = t2[:a] + t2[b:]
save('ClotureeSecrete.dc.html', t2, 'Édition clôturée sans dévoiler', 1010)

# ---------- accueil : demande ----------
t = (P/'AccueilVide.dc.html').read_text()
a, b = cut_section(t, 'Organiser un Secret Santa')
quote = '<p style="margin: 0; padding: 10px 12px; border-radius: 10px; background: #f1e8d8; font-size: 15px; line-height: 1.45">Le Noël de ma famille, une douzaine de personnes.</p>'
pend = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <div style="display: flex; align-items: center; gap: 10px"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f9eecb; color: #79511d; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 18)}</span><h2 style="{CT}">Ta demande est partie</h2></div>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Envoyée le 15 novembre. Un administrateur la lit et te répond par email.</p>
      {quote}
    </section>'''
save('AccueilDemandeAttente.dc.html', t[:a] + pend + t[b:], 'Accueil — demande en attente')
ref = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <h2 style="{CT}">Ta demande du 15 novembre a été refusée</h2>
      <div style="display: flex; flex-direction: column; gap: 4px"><p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Le mot de l’administrateur</p><p style="margin: 0; padding: 10px 12px; border-radius: 10px; background: #f1e8d8; font-size: 15px; line-height: 1.45">On est complets pour cette année, reviens en octobre !</p></div>
      <a href="PanneauDemandeGroupe.dc.html" style="height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Faire une autre demande</a>
    </section>'''
save('AccueilDemandeRefusee.dc.html', t[:a] + ref + t[b:], 'Accueil — demande refusée')
acc = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant</p>
        <h2 style="{CT}">Ta demande est acceptée : crée ton groupe</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Donne-lui un nom, ajoute les membres, et le tirage est à toi.</p>
      </div>
      <a href="GroupeNouveau.dc.html" style="{BTN}">Créer mon groupe</a>
    </section>'''
a1, b1 = cut_section(t, 'Aucun tirage pour l')
first = t[a1:b1]
tt = t[:a1] + acc + '\n    ' + first + t[b:]  # accepted card first, then "aucun tirage", drop the request card
save('AccueilDemandeAcceptee.dc.html', tt, 'Accueil — demande acceptée')

# ---------- tirage impossible ----------
t = (P/'Main.dc.html').read_text()
a, b = cut_section(t, 'À faire maintenant')
imp = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #79511d">À corriger avant le tirage</p>
        <h2 style="{CT}">Le tirage est impossible pour l’instant</h2>
      </div>
      <ul style="list-style: none; margin: 0; padding: 0; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #66431d; font-size: 14px; line-height: 1.45">
        <li style="display: flex; align-items: center; gap: 10px; padding: 10px 12px">{bav('🌰', 'mustard', 32, 15)}<span><strong style="color: #3a240c">Lou</strong> : personne ne peut être tiré pour elle.</span></li>
        <li style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-top: 1px solid #ebc762">{bav('🍷', 'plum', 32, 15)}<span><strong style="color: #3a240c">Sacha</strong> : très peu de choix.</span></li>
      </ul>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Il y a trop d’exclusions pour 4 participants. Retire-en une, ou ajoute quelqu’un.</p>
      <div style="display: flex; flex-direction: column; gap: 4px">
        <a href="GroupeExclusions.dc.html" style="{BTN}">Voir les exclusions</a>
        <a href="AjouterParticipants.dc.html" style="height: 44px; border-radius: 6px; color: #8a2f27; font-size: 15px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Ajouter des participants</a>
      </div>
    </section>'''
save('PreparerImpossible.dc.html', t[:a] + imp + t[b:], 'Édition à préparer — tirage impossible', 1260)

# ---------- préparer vide ----------
a, b = cut_section(t, 'À faire maintenant')
empty = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant</p>
        <h2 style="{CT}">Ajoute les participants</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Il en faut au moins trois pour un tirage. Choisis-les parmi les membres du groupe, ou envoie un lien pour qu’ils s’inscrivent.</p>
      </div>
      <a href="AjouterParticipants.dc.html" style="{BTN}">{ic(I['userplus'])}Ajouter des participants</a>
      <a href="GroupeInvitation.dc.html" style="height: 44px; border-radius: 6px; color: #8a2f27; font-size: 15px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Inviter par lien</a>
    </section>'''
t2 = t[:a] + empty + t[b:]
a, b = cut_section(t2, '>4 participants</h2>')
t2 = t2[:a] + f'''<section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Aucun participant</h2>
      <ul style="{LIST}"><li style="padding: 14px 16px; font-size: 15px; color: #57534e">Personne pour l’instant.</li></ul>
    </section>''' + t2[b:]
save('PreparerVide.dc.html', t2, 'Édition à préparer — aucun participant', 900)

# ---------- envoi sans email ----------
t = (P/'Envoi.dc.html').read_text()
a = t.index('<div style="margin-top: auto;'); b = t.index('</section>', a)
SEC = 'height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none'
bottom = f'''<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{ic(I['share'])}Partager (WhatsApp, SMS…)</button>
      <button style="{SEC}">{ic(I['copy'], 18)}Copier le message</button>
      <div style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; background: #f1e8d8">
        <span aria-hidden="true" style="display: flex; color: #57534e">{ic('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>', 18)}</span>
        <p style="margin: 0; flex-grow: 1; font-size: 14px; line-height: 1.35; color: #292524">Rose n’a pas d’adresse email.</p>
        <a href="GroupePersonne.dc.html" style="min-height: 44px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27">Ajouter</a>
      </div>
    </div>
  '''
t2 = t[:a] + bottom + t[b:]
for old, new in [('Envoyer à Inès</h1>', 'Envoyer à Rose</h1>'), ('aria-label="Envoyer à Inès"', 'aria-label="Envoyer à Rose"'), ('>🍭</span>', '>🐧</span>'), ('Inès, le tirage est fait !', 'Rose, le tirage est fait !'),
                 ('background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 22px', 'background: #ead2e2; box-shadow: 0 0 0 1px #c493b4; display: flex; align-items: center; justify-content: center; font-size: 22px')]:
    assert old in t2, old; t2 = t2.replace(old, new)
save('EnvoiSansEmail.dc.html', t2, 'Envoyer à une personne sans adresse email')

# ---------- alerte hors du journal ----------
t = (P/'TirageRevoir.dc.html').read_text()
old = "Tout ce qui s'est passé, à la vue de tous</span>"
assert old in t
k = t.index(old)
t2 = t.replace(old, '<span style="color: #79511d; font-weight: 600">1 alerte depuis ta dernière visite</span></span>'.replace('</span></span>', '</span>') if False else '1 alerte depuis ta dernière visite</span>')
k = t2.index('1 alerte depuis ta dernière visite'); s = t2.index('<svg aria-hidden="true" width="20" height="20"', k)
pill = '<span aria-hidden="true" style="width: 12px; height: 12px; border-radius: 50%; background: #e6b94a; box-shadow: 0 0 0 3px #f9eecb; flex-shrink: 0"></span>'
t2 = t2[:s] + pill + t2[s:]
save('TirageAlerteJournal.dc.html', t2, 'Page d\'un tirage — alerte au journal')
print(json.dumps(OUT))
