import pathlib, json, re
jsrc = open('/home/claude/gen/journal.py').read().split("# J1 l'essentiel")[0]
exec(jsrc)
IC.update(pen='<path d="M17 3a2.800 2.800 0 1 1 4 4L7.500 20.500 2 22l1.500-5.500z"/>', globe='<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>')
LESS = f'<button aria-expanded="true" style="align-self: flex-start; min-height: 44px; margin: -8px 0; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px">Replier{ic("<path d=\'m6 15 6-6 6 6\'/>", 14, 2.4)}</button>'
def sub(items):
    lis = ''.join(f'<li style="display: flex; align-items: center; gap: 8px">{pav(n, size=24, fs=11)}<span style="flex-grow: 1; font-size: 14px">{n}</span><time style="font-size: 12px; color: #57534e">{t}</time></li>' for n, t in items)
    return f'<ul style="list-style: none; margin: 0; padding: 8px 0 0; border-top: 1px solid #e9dcc5; display: flex; flex-direction: column; gap: 8px">{lis}</ul>'
build('JournalTout.dc.html', 'Journal — tout, un regroupement déplié', f'''<main style="{MAIN}">
    {head('Journal du groupe', 'Famille Camille')}
    {controls(1, 'Tout le monde')}
    {timeline(
      day('Dimanche 15 novembre', card('eye', 'L’organisateur a consulté le résultat de Hugo (accès de dernier recours)', '14:02', True, WHY) + line('rules', 'L’organisateur a modifié les règles du tirage', '13:56') + line('globe', 'Rose a changé sa langue (English)', '10:12'))
      + day('Samedi 14 novembre', line('open', '<strong>5 personnes</strong> ont découvert leur résultat', '21:40 – 23:50', LESS + sub([('Rose', '23:50'), ('Louis', '22:31'), ('Inès', '22:02'), ('Hugo', '21:52'), ('Camille', '21:40')])) + line('pen', 'Inès a changé son icône', '21:58') + line('mail', 'L’organisateur a envoyé « Tirage fait » à <strong>5 personnes</strong> par email', '21:30', MORE('Voir le détail')) + card('star', 'Le tirage a été effectué pour 5 participants', '21:26'))
    )}
  </main>''', 1330)

# chargement, erreur, toast (from Suivi template)
SK = lambda w, h, r=8: f'<span style="display: block; width: {w}; height: {h}px; border-radius: {r}px; background: #e9dcc5"></span>'
build('EtatChargement.dc.html', 'État — chargement', f'''<main aria-busy="true" aria-label="Chargement" style="{MAIN}">
    <div style="display: flex; flex-direction: column; gap: 8px">{SK('60%', 34)}{SK('40%', 16)}</div>
    <div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 24px; padding: 0 24px">{SK('100%', 24, 12)}{SK('100%', 24, 12)}{SK('100%', 24, 12)}</div>
    <div style="border-radius: 16px; background: #fffdf9; box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05); padding: 20px; display: flex; flex-direction: column; gap: 14px">{SK('35%', 12).replace('#e9dcc5', '#f1e8d8')}{SK('85%', 24).replace('#e9dcc5', '#f1e8d8')}{SK('100%', 48, 6).replace('#e9dcc5', '#f1e8d8')}</div>
    <div style="display: flex; flex-direction: column; gap: 8px">{SK('30%', 12)}
      <div style="margin: 0 -16px; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
        {''.join(f'<div style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{"" if i == 0 else " border-top: 1px solid #e9dcc5;"}"><span style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; flex-shrink: 0"></span><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 6px"><span style="width: {w}%; height: 14px; border-radius: 6px; background: #f1e8d8"></span><span style="width: {w + 20}%; height: 10px; border-radius: 6px; background: #f1e8d8"></span></span></div>' for i, w in enumerate([30, 22, 36, 26]))}
      </div>
    </div>
  </main>''', 844)
build('EtatErreur.dc.html', 'État — erreur de chargement', f'''<main style="{MAIN}">
    {head('Noël 2026', 'Famille Camille')}
    <section role="alert" style="{CARD} padding: 24px 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; align-items: flex-start; gap: 12px">
        <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #fbe1e5; color: #961d35; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M10.300 3.900 1.800 18a2 2 0 0 0 1.700 3h17a2 2 0 0 0 1.700-3L13.700 3.900a2 2 0 0 0-3.400 0zM12 9v4M12 17h.010"/>', 20)}</span>
        <div style="display: flex; flex-direction: column; gap: 4px"><h2 style="{CT}">On n’arrive pas à charger l’édition</h2><p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Vérifie ta connexion, puis réessaie. Rien n’a été perdu.</p></div>
      </div>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Réessayer</button>
      <a href="Groupe.dc.html" style="height: 44px; border-radius: 6px; color: #8a2f27; font-size: 15px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Revenir au groupe</a>
    </section>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <p style="{H2}">Les autres messages d’erreur</p>
      <ul style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; background: #fffdf9; font-size: 14px; line-height: 1.45; color: #57534e">
        <li style="padding: 12px 14px"><strong style="color: #292524">Dans un panneau</strong> : une ligne rouge au-dessus du bouton, le panneau reste ouvert et la saisie est gardée.</li>
        <li style="padding: 12px 14px; border-top: 1px solid #e9dcc5"><strong style="color: #292524">Après une action</strong> : un message en haut de l’écran qui dit quoi faire, pas un code.</li>
        <li style="padding: 12px 14px; border-top: 1px solid #e9dcc5"><strong style="color: #292524">Accès refusé</strong> : « Tu n’as pas accès à ce groupe. » avec le retour à l’accueil.</li>
      </ul>
    </div>
  </main>''', 844)
t = (P/'Suivi.dc.html').read_text()
toast = f'''<div role="status" style="position: absolute; top: 68px; left: 16px; right: 16px; z-index: 2; display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 12px; background: #fffdf9; box-shadow: 0 8px 24px rgba(60, 30, 10, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.06)">
    <span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(I['check'], 18, 2.6)}</span>
    <div style="flex-grow: 1; display: flex; flex-direction: column"><p style="margin: 0; font-size: 15px; font-weight: 700">3 emails envoyés</p><p style="margin: 0; font-size: 13px; color: #57534e">Inès, Louis et Rose sont prévenus.</p></div>
    <button aria-label="Fermer" style="width: 44px; height: 44px; margin: -8px -8px -8px 0; border: 0; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0">{ic('<path d="M6 6l12 12M18 6 6 18"/>', 18, 2.2)}</button>
  </div>'''
t = t.replace('display: flex; flex-direction: column">\n  <header', 'display: flex; flex-direction: column; position: relative">\n  <header', 1)
assert 'position: relative">\n  <header' in t
k = t.index('</header>') + 9
t = t[:k] + '\n  ' + toast + t[k:]
for old, new in [('line-height: 1; color: #8a2f27">3</dd>', 'line-height: 1; color: #8a2f27">0</dd>'), ('line-height: 1; color: #79511d">1</dd>', 'line-height: 1; color: #79511d">4</dd>'), ('<title>Édition tirée — suivi</title>', '<title>État — confirmation après un envoi</title>')]:
    assert old in t, old; t = t.replace(old, new)
(P/'EtatConfirmation.dc.html').write_text(t)
print('ok')
