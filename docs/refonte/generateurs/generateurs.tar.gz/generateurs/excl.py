import pathlib, json, re
P = pathlib.Path('/home/claude/utt/project')
out = {}
BAN = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m5.600 5.600 12.800 12.800"/></svg>'
for f in ['Groupe.dc.html', 'GroupeSansEdition.dc.html']:
    t = (P/f).read_text()
    a = t.index('<span style="font-weight: 600; font-size: 16px">Membres</span>')
    li_start = t.rindex('<li>', 0, a); li_end = t.index('</li>\n', a) + 6
    old = t[li_start:li_end]
    new_membres = old.replace('5 personnes · 1 exclusion', '6 personnes')
    excl = old.replace('GroupeMembres.dc.html', 'GroupeExclusions.dc.html').replace('>Membres<', '>Exclusions<').replace('5 personnes · 1 exclusion', '1 paire qui ne se tire jamais').replace('box-sizing: border-box; text-decoration', 'box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration')
    s = excl.index('<svg'); e = excl.index('</svg>') + 6
    excl = excl[:s] + BAN + excl[e:]
    new = new_membres + '        ' + excl
    assert t.count(old) == 1
    out[f] = [{"old_text": old, "new_text": new}]
    (P/f).write_text(t.replace(old, new).replace('height: 1010px', 'height: 1070px').replace('"height":1010', '"height":1070').replace('height: 900px', 'height: 960px').replace('"height":900', '"height":960'))
for f, pairs in [('GroupeMembres.dc.html', []), ('GroupeExclusions.dc.html', [('>Membres</h1>', '>Exclusions</h1>')])]:
    t = (P/f).read_text()
    if f == 'GroupeMembres.dc.html':
        t = t.replace('Ceux qui ne participent plus sont en dernier. Leur historique est conservé.', 'L’historique de ceux qui ne participent plus est conservé.')
    a = t.index('<div role="tablist"'); b = t.index('</div>', a) + 6
    old = t[a:b]; eds = [{"old_text": old, "new_text": ""}]
    t = t.replace(old, '')
    for o, n in pairs:
        assert o in t; eds.append({"old_text": o, "new_text": n}); t = t.replace(o, n)
    out[f] = eds; (P/f).write_text(t)
json.dump(out, open('/home/claude/gen/excl.json', 'w'), ensure_ascii=False)
for k, v in out.items(): print(k, len(json.dumps(v)))
