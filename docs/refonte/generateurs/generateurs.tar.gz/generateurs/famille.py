# « Ma famille » : voir tout le monde, et supprimer quelqu'un pour de bon (Julien, 19 novembre 2026)
import io,contextlib,json
NO_WRITE=True
src=open('/home/claude/gen/garde2.py').read()
with contextlib.redirect_stdout(io.StringIO()): exec(src.split("# ---------- Lot 39 : signaler")[0])
BTNN='height: 48px; box-sizing: border-box; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
M={}
def frow(n,sub,top=True,href='ListePersonne.dc.html'): return f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 68px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524">{av(n,44)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 16px">{n}</span><span style="font-size: 14px; color: #57534e">{sub}</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
M['Famille']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Mon compte</p><h1 style="{H1}">Ma famille</h1><p style="{P}">Les personnes pour qui tu tiens des listes. Toi seul les vois ici.</p></div>
    <ul style="{UL}">{frow('Léo','6 ans · sur 2 listes',False)}{frow('Zoé','3 ans · sur 2 listes')}{frow('Hugo','sur 1 liste')}{frow('Mamie','sur aucune liste')}</ul>
    <a href="ListePersonne.dc.html" style="{BTNN}">{PLUS}Ajouter quelqu’un</a>
    <p style="{SM}">Touche une personne pour changer sa fiche, ou la supprimer.</p>''','Compte — ma famille'),900,'« Ma famille » : tout le monde, même ceux qui ne sont sur aucune liste')
M['FamilleSupprimer']=(scr(844,f'''<div style="display: flex; align-items: center; gap: 14px">{av('Hugo',64)}<div style="display: flex; flex-direction: column; gap: 2px"><p style="{SM}">Ma famille</p><h1 style="{H1}">Supprimer Hugo ?</h1></div></div>
    <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; font-size: 16px; line-height: 1.45">
      <li>Hugo ne sera plus proposé dans « Ajouter quelqu’un ».</li>
      <li>Sa fiche et ses goûts sont effacés.</li>
      <li><strong>Il est sur 1 liste, « Noël 2026 »</strong> : ses 4 idées en sortent, et 1 cadeau déjà prévu pour lui est perdu.</li>
    </ul>
    <div role="note" style="{NOTE}"><span>C’est définitif. Pour l’enlever d’une seule liste en le gardant dans ta famille, choisis plutôt « Retirer de cette liste ».</span></div>
    <div style="display: flex; flex-direction: column; gap: 10px"><a href="Famille.dc.html" style="{BTN}">Supprimer Hugo</a><a href="#" style="{BTNN}">Annuler</a></div>''','Compte — supprimer quelqu’un de ma famille'),844,'Supprimer quelqu’un de sa famille : ce qui part avec')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in M.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h); open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(M))
# Le lien « Gérer ma famille » sous « Ajouter quelqu'un » : c'est le seul endroit où l'on voit quelqu'un qui n'est sur aucune liste (Julien, 19 novembre 2026)
import glob,os
GL='<p data-fam="1" style="margin: 0; font-size: 14px; line-height: 1.45"><a href="Famille.dc.html" style="min-height: 32px; display: inline-flex; align-items: center; font-weight: 700; color: #57534e; text-decoration: underline">Gérer ma famille</a></p>'
liens=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if n in('ListeNouvelleForme','ListeSansPersonne'): continue
    h=open(f).read()
    if 'Ajouter quelqu’un</h2>' not in h or 'data-fam="1"' in h: continue
    i=h.index('Ajouter quelqu’un</h2>'); j=h.index('</section>',i)
    k=h.rindex('\n',i,j)  # la dernière ligne avant </section>
    h=h[:j].rstrip()+'\n      '+GL+'\n    '+h[j:]; open(f,'w').write(h); liens.append(n)
print('liens',liens)
