# Dernier écran du palmarès : une pluie animée, flocons ou confettis (19 novembre 2026)
import re,random,json,os,shutil
PJ='/home/claude/utt/project/'
if not os.path.exists(PJ+'DevineStory7.sans-pluie.html'): shutil.copy(PJ+'DevineStory7.dc.html',PJ+'DevineStory7.sans-pluie.html')
base=open(PJ+'DevineStory7.sans-pluie.html').read()
CSS='''
@keyframes utt-fall{from{transform:translate3d(0,-60px,0) rotate(0deg)}to{transform:translate3d(var(--dx),920px,0) rotate(var(--r))}}
.utt-p{position:absolute;top:-40px;animation:utt-fall var(--d) linear var(--t) infinite;will-change:transform}
@media (prefers-reduced-motion: reduce){.utt-p{animation:none;top:var(--y)}}
'''
# trois flocons à six branches (tracés calculés, contrôlés à part) : à barbes simples, à barbes doubles, en étoile nue
FL={"a":'M12 12L12.00 2.00M12.00 5.80L9.38 3.96M12.00 5.80L14.62 3.96M12 12L20.66 7.00M17.37 8.90L17.65 5.71M17.37 8.90L20.27 10.25M12 12L20.66 17.00M17.37 15.10L20.27 13.75M17.37 15.10L17.65 18.29M12 12L12.00 22.00M12.00 18.20L14.62 20.04M12.00 18.20L9.38 20.04M12 12L3.34 17.00M6.63 15.10L6.35 18.29M6.63 15.10L3.73 13.75M12 12L3.34 7.00M6.63 8.90L3.73 10.25M6.63 8.90L6.35 5.71',"b":'M12 12L12.00 2.00M12.00 7.40L10.03 6.02M12.00 7.40L13.97 6.02M12.00 4.40L10.03 3.02M12.00 4.40L13.97 3.02M12 12L20.66 7.00M15.98 9.70L16.19 7.31M15.98 9.70L18.16 10.71M18.58 8.20L18.79 5.81M18.58 8.20L20.76 9.21M12 12L20.66 17.00M15.98 14.30L18.16 13.29M15.98 14.30L16.19 16.69M18.58 15.80L20.76 14.79M18.58 15.80L18.79 18.19M12 12L12.00 22.00M12.00 16.60L13.97 17.98M12.00 16.60L10.03 17.98M12.00 19.60L13.97 20.98M12.00 19.60L10.03 20.98M12 12L3.34 17.00M8.02 14.30L7.81 16.69M8.02 14.30L5.84 13.29M5.42 15.80L5.21 18.19M5.42 15.80L3.24 14.79M12 12L3.34 7.00M8.02 9.70L5.84 10.71M8.02 9.70L7.81 7.31M5.42 8.20L3.24 9.21M5.42 8.20L5.21 5.81',"c":'M12 12L12.00 3.50M12 12L19.36 7.75M12 12L19.36 16.25M12 12L12.00 20.50M12 12L4.64 16.25M12 12L4.64 7.75'}
FLAKE='<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round"><path d="{d}"/></svg>'
def layer(kind,n,seed):
    rnd=random.Random(seed); out=''
    for i in range(n):
        x=rnd.uniform(2,96); d=rnd.uniform(7,14); t=-rnd.uniform(0,14); dx=rnd.uniform(-40,40); y=rnd.uniform(4,92)
        if kind=='flocons':
            # des flocons de neige : bleus de glace et un peu de lilas, lisibles sur le fond crème
            s=rnd.choice([12,14,16,20,24,28]); c=rnd.choice(['#6eb0f2','#6eb0f2','#8fc0f4','#b5d6f9','#b993dd'])
            k=rnd.choice('aab') if s>=20 else rnd.choice('acc')
            w={12:2.6,14:2.4,16:2.2,20:1.9,24:1.7,28:1.6}[s]
            body=FLAKE.format(s=s,c=c,w=w,d=FL[k]) if rnd.random()<0.72 else f'<span style="display: block; width: {s//3}px; height: {s//3}px; border-radius: 50%; background: {rnd.choice(["#b5d6f9","#cfe6ff","#8fc0f4"])}"></span>'
            d=rnd.uniform(9,17)
            r=rnd.uniform(40,200); op=rnd.uniform(0.6,1)
        else:
            c=rnd.choice(['#ff8478','#4fcaa3','#f4b82e','#6eb0f2','#b993dd','#d93a2b']); w=rnd.choice([6,8,10]); h=rnd.choice([10,14,6])
            rad='50%' if rnd.random()<0.25 else '2px'
            body=f'<span style="display: block; width: {w}px; height: {h}px; border-radius: {rad}; background: {c}"></span>'
            r=rnd.uniform(360,1080); op=1; d=rnd.uniform(4.5,9)
        out+=f'<span class="utt-p" style="left: {x:.1f}%; opacity: {op:.2f}; --d: {d:.1f}s; --t: {t:.1f}s; --dx: {dx:.0f}px; --r: {r:.0f}deg; --y: {y:.0f}%">{body}</span>'
    return f'<div aria-hidden="true" style="position: absolute; inset: 0; overflow: hidden; pointer-events: none; z-index: -1">{out}</div>'
# la variante de fête : les flocons, avec des étoiles à quatre branches qui scintillent et quelques confettis aux couleurs de Sorbet
STAR='<svg class="utt-tw" style="--tw: {tw}s; --td: {td}s" width="{s}" height="{s}" viewBox="0 0 24 24" fill="{c}"><path d="M12 1C12.8 7.5 16.5 11.2 23 12C16.5 12.8 12.8 16.5 12 23C11.2 16.5 7.5 12.8 1 12C7.5 11.2 11.2 7.5 12 1Z"/></svg>'
def layer_fete(seed):
    rnd=random.Random(seed); out=''
    kinds=['f']*24+['e']*11+['c']*12; rnd.shuffle(kinds)
    for k in kinds:
        x=rnd.uniform(2,96); t=-rnd.uniform(0,16); dx=rnd.uniform(-40,40); y=rnd.uniform(4,92); op=1
        if k=='f':
            s=rnd.choice([12,14,16,20,24,28]); c=rnd.choice(['#6eb0f2','#6eb0f2','#8fc0f4','#b5d6f9','#b993dd'])
            w={12:2.6,14:2.4,16:2.2,20:1.9,24:1.7,28:1.6}[s]; body=FLAKE.format(s=s,c=c,w=w,d=FL[rnd.choice('aab') if s>=20 else rnd.choice('acc')])
            d=rnd.uniform(9,17); r=rnd.uniform(40,200); op=rnd.uniform(0.7,1)
        elif k=='e':
            s=rnd.choice([12,14,18,22,26]); c=rnd.choice(['#b993dd','#b993dd','#ff8478','#4fcaa3'])
            body=STAR.format(s=s,c=c,tw=round(rnd.uniform(1.4,2.6),1),td=round(-rnd.uniform(0,2.6),1)); d=rnd.uniform(10,18); r=rnd.uniform(-30,30)
        else:
            c=rnd.choice(['#ff8478','#d93a2b','#4fcaa3','#b993dd','#f2a65a']); w=rnd.choice([6,8,10]); h=rnd.choice([10,14,6])
            body=f'<span style="display: block; width: {w}px; height: {h}px; border-radius: {"50%" if rnd.random()<0.3 else "2px"}; background: {c}"></span>'
            d=rnd.uniform(6,11); r=rnd.uniform(360,900)
        out+=f'<span class="utt-p" style="left: {x:.1f}%; opacity: {op:.2f}; --d: {d:.1f}s; --t: {t:.1f}s; --dx: {dx:.0f}px; --r: {r:.0f}deg; --y: {y:.0f}%">{body}</span>'
    return f'<div aria-hidden="true" style="position: absolute; inset: 0; overflow: hidden; pointer-events: none; z-index: -1">{out}</div>'
CSS2='''@keyframes utt-twinkle{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.72)}}
.utt-tw{display:block;animation:utt-twinkle var(--tw) ease-in-out var(--td) infinite}
@media (prefers-reduced-motion: reduce){.utt-tw{animation:none}}
'''
def make_fete(seed,title):
    h=base.replace('</style>',CSS+CSS2+'</style>',1)
    a='flex-direction: column; padding: 14px 16px 28px">'; assert h.count(a)==1
    h=h.replace(a,'flex-direction: column; padding: 14px 16px 28px; position: relative; isolation: isolate; overflow: hidden">\n  '+layer_fete(seed),1)
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',h,count=1)
def make(kind,n,seed,title):
    h=base.replace('</style>',CSS+'</style>',1)
    a='flex-direction: column; padding: 14px 16px 28px">'; assert h.count(a)==1
    h=h.replace(a,'flex-direction: column; padding: 14px 16px 28px; position: relative; isolation: isolate; overflow: hidden">\n  '+layer(kind,n,seed),1)
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',h,count=1)
F=make('flocons',38,7,'Devine qui — le dernier écran, sous les flocons')
open(PJ+'DevineStory7Flocons.dc.html','w').write(F)
open(PJ+'DevineStory7Confettis.dc.html','w').write(make('confettis',46,11,'Devine qui — le dernier écran, sous les confettis'))
names=json.load(open('/tmp/names.json'))
G=make_fete(23,'Devine qui — le dernier écran, flocons, étoiles et confettis')
open(PJ+'DevineStory7Fete.dc.html','w').write(G)
# retenu par Julien le 19 novembre 2026 : c'est l'écran « La fin » du palmarès
open(PJ+'DevineStory7.dc.html','w').write(re.sub(r'<title>[^<]*</title>',re.search(r'<title>[^<]*</title>',base).group(0),G,count=1))
for x in ('DevineStory7Confettis.dc.html','DevineStory7Flocons.dc.html','DevineStory7Fete.dc.html'):
    if x not in names: names.append(x)
json.dump(names,open('/tmp/names.json','w'))
