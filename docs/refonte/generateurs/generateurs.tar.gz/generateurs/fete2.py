# La fête se partage (Julien, 20 novembre 2026) : la page d'une fête partagée, et ajouter sa liste à une fête. Après accueil3d.py.
import json,re
src=open('/home/claude/gen/accueil3d.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))\nfor k,(h,ht,t) in P4.items():")[0])
P5={}
GLOBE=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',20)
SHARE=ic('<path d="M12 15V3"/><path d="m7 8 5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/>',16,2.2)
SWON='<span role="switch" aria-checked="true" aria-label="Partage par lien" style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 23px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>'
BAR=f'''<div style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); min-height: 48px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 8px"><span style="display: flex; color: #274e34">{GLOBE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; min-height: 44px"><span style="font-size: 14px; font-weight: 700">Partage par lien</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">Activé par Camille</span></span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px">{SHARE}Partager</button></div>'''
def page_fete(extra_lists,sheet=''):
    m=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 8px; padding: 4px 4px 0"><span style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px 0 8px; border-radius: 999px; background: {CAT['Noël'][1]}; font-size: 13px; font-weight: 700; color: #274e34">🎄 Noël · tous les ans</span><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Noël chez Camille</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: {DRED}">25 décembre 2026 · dans 35 jours</p></div>
    {BAR}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le tirage')}<ul style="{UL}">{irow(tl(),'Famille Camille','8 participants · Camille te demande des pistes',dot(),True,'Pistes.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes de chacun')}<ul style="{UL}">{irow(av('🦌',36),'La liste de Camille','Tu offres 1 cadeau','',True)}{irow(av('🧶',36),'La liste de Mamie','Tu offres 2 cadeaux · 1 nouvelle idée',dot())}{extra_lists}{irow(av('🎸',36),'La liste de Tonton','Rien de coché encore')}</ul>
      <div style="display: flex; gap: 10px; flex-wrap: wrap; padding-top: 8px"><a href="FeteAjouterListe.dc.html" style="{BTN2}">{PLUS}Ajouter ma liste</a><a href="GroupeNouveau.dc.html" style="{BTN2}">{PLUS}Organiser un tirage</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts','',True)}{irow(yr('2024'),'Noël 2024','Tu offrais à Camille')}</ul></section>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: {MUT}">Tous ceux qui ont cette fête voient ses listes. Les participants du tirage l’ont déjà.</p>
  </main>'''
    h=page('Une fête partagée : le tirage et les listes de chacun',m,1180).replace(HEADER,hd,1)
    if sheet:
        h=h.replace('min-height: 1180px;','min-height: 1180px; position: relative;',1).replace('\n  <nav aria-label="Sections"',sheet+'\n  <nav aria-label="Sections"',1)
    return h
P5['FetePartagee']=(page_fete(''),1180,'La fête se partage · 1. la page : le tirage, les listes de chacun, « Partage par lien », « Ajouter ma liste »')
SHEETA=f'''<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>
  <div role="dialog" aria-label="Ajouter ta liste à Noël chez Camille" style="position: absolute; left: 0; right: 0; top: 330px; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 14px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">
    <span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>
    <h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Ajouter ta liste à « Noël chez Camille »</h2>
    <ul role="radiogroup" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">
      {opt(ll(),'Ma liste « Noël 2026 »','Léo, Zoé et moi · 9 idées',True,True)}
      {opt(DASH,'Une nouvelle liste','Elle sera dans cette fête dès le début')}
    </ul>
    <p style="margin: 0; padding: 0 20px; font-size: 15px; line-height: 1.45; color: {INK}">Elle sera visible par <strong>tous ceux qui ont cette fête</strong>, dont les 8 participants du tirage. Tu pourras l’en retirer quand tu veux.</p>
    <div style="padding: 0 16px; display: flex; flex-direction: column; gap: 4px"><a href="FetePartageeAjoutee.dc.html" style="{BTN}">Ajouter ma liste</a><a href="FetePartagee.dc.html" style="min-height: 44px; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 700; color: {MUT}">Annuler</a></div>
  </div>'''
P5['FeteAjouterListe']=(page_fete('',SHEETA),1180,'La fête se partage · 2. ajouter sa liste : choisir laquelle, et savoir qui la verra')
P5['FetePartageeAjoutee']=(page_fete(irow(av('🐧',36),'Ma liste','Léo, Zoé et moi · 9 idées · ajoutée à l’instant')),1180,'La fête se partage · 3. ma liste est dans la fête, avec celles des autres')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in P5.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P5))
