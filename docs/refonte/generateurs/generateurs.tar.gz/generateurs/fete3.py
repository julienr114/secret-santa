# Le groupe devient la fête (Julien, 20 novembre 2026) : une fête a des membres ; les listes appartiennent à une ou plusieurs fêtes
# (visibles par leurs membres), ou à tout le monde par un lien. Après fete2.py. Remplace AccueilFetes2, FeteChoisir, FetePage.
import json,re
src=open('/home/claude/gen/fete2.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))\nfor k,(h,ht,t) in P5.items():")[0])
P6={}
def stack(es):
    o=''
    for i,e in enumerate(es):
        bg,bd=AV.get(e,('#f1e8d8','#dccbad'))
        o+=f'<span aria-hidden="true" style="width: 26px; height: 26px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 2px {CARD}; display: flex; align-items: center; justify-content: center; font-size: 13px;{" margin-left: -7px;" if i else ""}">{e}</span>'
    return f'<span style="display: flex; flex-shrink: 0">{o}</span>'
AV.update({'👵':('#f3d3cc','#e09e92'),'🦊':('#f3d3cc','#e09e92')})
# ---------- 1. l'accueil ----------
NOEL3=(season('Noël 2026','dans 34 jours')
  +fcard2('Noël','Famille Camille','25 déc.',irow(tl(),'Le tirage 2026','Camille te demande des pistes',dot(),True)+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi chez Mamie')+irow(ll(),'La liste de Camille','Tu offres 1 cadeau'))
  +fcard2('Noël','Chez Mamie','24 déc.',irow(ll(),'La liste de Mamie','Tu offres 2 cadeaux','',True)+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi dans Famille Camille'))
  +fcard2('Noël','Les copains du foot','21 déc.',irow(tl(),'Le tirage 2026','Pas encore tiré','',True),'Nouvelle liste')
  +fcard2('Noël','Bureau, 3e étage','19 déc.',irow(tl(),'Le tirage 2026','Tu sais à qui tu offres','',True)))
LATER3=(f'<div style="padding-top: 10px">{SEC("Plus tard")}</div>'
  +fcard2('Anniversaire','Les 40 ans de Tonton','8 févr.',irow(ll(),'La liste de Tonton','3 nouvelles idées',dot(),True))
  +fcard2('Anniversaire','L’anniversaire de Léo','12 mars','',add='Reprendre sa liste de l’an dernier'))
BYLINK=(f'<div style="padding-top: 10px">{SEC("Reçues par un lien")}</div><ul style="{UL}">{irow(ll(),"La liste de Karim","Pour sa crémaillère · il te l’a envoyée","",True)}</ul>')
CLOCKI='<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: '+MUT+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',18)+'</span>'
PASTROW=f'<ul style="{UL}; margin-top: 10px">'+irow(CLOCKI,'Les fêtes passées','Noël 2025, les 6 ans de Léo et 2 autres','',True)+'</ul>'
MAIN3=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {NOEL3}
    {LATER3}
    {PASTROW}
    <div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="FeteChoisir.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="FeteNouvelle.dc.html" style="{BTN2}">{PLUS}Nouvelle fête</a></div>
  </main>'''
P6['AccueilFetes2']=(page('Accueil · par fête',MAIN3,1760),1760,'La fête · 1. l’accueil : mes fêtes, leurs tirages et les listes de leurs membres ; une liste peut être dans deux fêtes')
# ---------- 2. qui verra cette liste ? ----------
def chk(lead,t,s,on,first=False):
    b=(f'<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 6px; background: {RED}; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{CHECK}</span>' if on else
       '<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 6px; border: 2px solid #a8a29e; flex-shrink: 0"></span>')
    return (f'<li><button role="checkbox" aria-checked="{"true" if on else "false"}" style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border: 0;{"" if first else f" border-top: 1px solid {SOFT};"} background: transparent; font-family: inherit; text-align: left; color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 13px; color: {MUT}">{s}</span></span>{b}</button></li>')
SWOFF='<span role="switch" aria-checked="false" aria-label="Tout le monde, avec un lien" style="width: 48px; height: 28px; border-radius: 999px; background: #d6d3d1; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 3px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>'
SHEETQ=f'''<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>
  <div role="dialog" aria-label="Qui verra ta liste ?" style="position: absolute; left: 0; right: 0; top: 260px; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">
    <span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>
    <h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px">Qui verra ta liste ?</h2>
    <ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">
      {chk(cat('Noël'),'Famille Camille','Noël · 12 membres',True,True)}
      {chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',True)}
      {chk(cat('Noël'),'Les copains du foot','Noël · 8 membres',False)}
      {chk(cat('Anniversaire'),'Les 40 ans de Tonton','Anniversaire · 15 membres',False)}
    </ul>
    <div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 20px"><span style="display: flex; color: {MUT}">{GLOBE}</span><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">Tout le monde, avec un lien</span><span style="font-size: 13px; color: {MUT}">Pour ceux qui ne sont dans aucune de tes fêtes</span></span>{SWOFF}</div>
    <div style="padding: 0 16px"><a href="ListeNouvelle.dc.html" style="{BTN}">Continuer</a></div>
  </div>'''
h=page('Nouvelle liste · qui la verra ?',MAIN3,1760).replace('min-height: 1760px;','min-height: 1760px; position: relative;',1)
h=h.replace('\n  <nav aria-label="Sections"',SHEETQ+'\n  <nav aria-label="Sections"',1)
P6['FeteChoisir']=(h,1760,'La fête · 2. « Qui verra ta liste ? » : une ou plusieurs de mes fêtes, et / ou tout le monde avec un lien (à la création, et depuis la liste)')
# ---------- 3. la page d'une fête ----------
mainf=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 8px; padding: 4px 4px 0"><span style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px 0 8px; border-radius: 999px; background: {CAT['Noël'][1]}; font-size: 13px; font-weight: 700; color: #274e34">🎄 Noël · tous les ans</span><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Famille Camille</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: {DRED}">25 décembre 2026 · dans 35 jours</p></div>
    <a href="GroupeMembres.dc.html" style="{CARDS}; min-height: 56px; padding: 0 14px; display: flex; align-items: center; gap: 12px; text-decoration: none; color: {INK}">{stack(['🦌','👵','🚀','🦄','🐧'])}<span style="flex-grow: 1; font-weight: 600">12 membres</span><span style="font-size: 14px; font-weight: 700; color: {DRED}">Inviter</span><span style="color: #78716c; display: flex">{CHEV}</span></a>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le tirage')}<ul style="{UL}">{irow(tl(),'Le tirage 2026','Camille te demande des pistes',dot(),True,'Pistes.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes')}<ul style="{UL}">{irow(av('🐧',36),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',True,'ListeTeneur.dc.html')}{irow(av('🦌',36),'La liste de Camille','Tu offres 1 cadeau')}{irow(av('👵',36),'La liste de Mamie','Tu offres 2 cadeaux · 1 nouvelle idée',dot())}</ul>
      <div style="padding-top: 8px"><a href="FeteChoisir.dc.html" style="{BTN2}; align-self: flex-start; display: inline-flex">{PLUS}Nouvelle liste</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts','',True)}{irow(yr('2024'),'Noël 2024','Tu offrais à Camille')}</ul></section>
  </main>'''
P6['FetePage']=(page('Une fête : ses membres, son tirage, ses listes',mainf,1040).replace(HEADER,hd,1),1040,'La fête · 4. la page d’une fête (l’ancien groupe) : ses membres, son tirage, les listes de ses membres')
names=json.load(open('/tmp/names.json'))
for k in ('FetePartagee','FeteAjouterListe','FetePartageeAjoutee'):
    if k+'.dc.html' in names: names.remove(k+'.dc.html')
for k,(h,ht,t) in P6.items():
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P6))
