import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
# ---------- Renvoi : « En cas de pépin » ----------
t = (P/'Renvoi.dc.html').read_text()
anchor = "Partager ouvre WhatsApp, SMS… Le lien de Hugo ne change pas : rien de tout ça ne révèle son résultat.</p>\n      </div>\n"
if 'En cas de pépin' not in t:
    assert t.count(anchor) == 1
    DOWN = ic('<path d="m6 9 6 6 6-6"/>', 18, 2.4); UP = ic('<path d="m6 15 6-6 6 6"/>', 18, 2.4)
    head = lambda open_: f'''      <button aria-expanded="{'true' if open_ else 'false'}" style="margin: 0 -16px -24px; min-height: 52px; padding: 0 16px; box-sizing: border-box; border: 0; border-top: 1px solid #e9dcc5; background: transparent; color: #57534e; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; justify-content: space-between; text-align: left">En cas de pépin{UP if open_ else DOWN}</button>\n'''
    closed = t.replace(anchor, anchor + head(False))
    save('Renvoi.dc.html', closed, 'Envoi — renvoyer à quelqu’un', 930)
    prow = lambda title, sub, first=False: f'''        <li><a href="PanneauRegenerer.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{'' if first else ' border-top: 1px solid #e9dcc5;'} text-decoration: none; color: #292524">
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{title}</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">{sub}</span></span>{CHEV}
        </a></li>\n'''
    opened = t.replace(anchor, anchor + head(True).replace('margin: 0 -16px -24px;', 'margin: 0 -16px;') + f'''      <ul style="list-style: none; margin: -14px -16px -24px; padding: 0; border-top: 1px solid #e9dcc5">\n{prow('Régénérer son lien', 'Si son lien a été transféré à quelqu’un d’autre', True)}{prow('Marquer comme pas envoyé', 'Remet Hugo dans « à prévenir »')}      </ul>\n''')
    save('RenvoiPepin.dc.html', opened, 'Envoi — en cas de pépin, déplié', 1050)

# ---------- Choisir les participants ----------
t = (P/'AjouterParticipants.dc.html').read_text()
def crow(n, e, c, sub, on, first=False):
    return f'''        <li{'' if first else ' style="border-top: 1px solid #e9dcc5"'}>
          <label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">
            {av(e, c)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span>
            <input type="checkbox"{' checked' if on else ''} style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
          </label>
        </li>
'''
M = [('Camille', *PEOPLE['Camille'], 'camille-demo@example.com', True), ('Hugo', *PEOPLE['Hugo'], 'hugo-demo@example.com', True), ('Inès', *PEOPLE['Inès'], 'ines-demo@example.com', True),
     ('Léa', '🧣', 'frost', 'lea-demo@example.com', True), ('Louis', *PEOPLE['Louis'], 'louis-demo@example.com', True), ('Mamie Jo', '🕯️', 'pine', 'A participé à Noël 2025', False),
     ('Rose', *PEOPLE['Rose'], 'Pas d’adresse email', True), ('Zoé', '🍪', 'kraft', 'Pas d’adresse email', False)]
a, b = cut_section(t, 'Membres du groupe qui ne participent pas')
sec = f'''<section style="display: flex; flex-direction: column; gap: 6px">
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 0 4px">
        <h2 style="{H2.replace('padding: 0 4px; ', '')}">8 membres du groupe</h2>
        <button style="min-height: 44px; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700">Tout cocher</button>
      </div>
      <ul style="{LIST}">
{''.join(crow(*m, first=(i == 0)) for i, m in enumerate(M))}      </ul>
    </section>'''
t = t[:a] + sec + t[b:]
for x, y in [('>Ajouter des participants</h1>', '>Choisir les participants</h1>'), ('Noël 2026 · 5 participants pour l’instant', 'Noël 2026 · coche ceux qui participent'), ('>Ajouter 2 personnes</button>', '>Enregistrer · 6 participants</button>')]:
    assert t.count(x) == 1, x; t = t.replace(x, y)
save('AjouterParticipants.dc.html', t, 'Édition — choisir les participants', 1180)

# ---------- canevas ----------
cv = json.loads((P/'canvas.json').read_text())
B = cv['boards']
B['Renvoi.dc.html']['h'] = OUT.get('Renvoi.dc.html', B['Renvoi.dc.html']['h'])
B['AjouterParticipants.dc.html'].update({'h': 1180, 'title': 'Choisir les participants'})
if 'FicheParticipant.dc.html' in B:
    del B['FicheParticipant.dc.html']; cv['order'].remove('FicheParticipant.dc.html')
    for k in ('PanneauRegenerer.dc.html', 'AnnulerTirage.dc.html'): B[k]['x'] -= 470
    cv['notes']['t09']['maxW'] = 1800
if 'RenvoiPepin.dc.html' not in B:
    B['EtatConfirmation.dc.html']['x'] += 470
    B['RenvoiPepin.dc.html'] = {'x': 1880, 'y': 3660, 'w': 390, 'h': 1050, 'title': 'En cas de pépin, déplié', 'page': 'edition'}
    cv['order'].insert(cv['order'].index('Renvoi.dc.html') + 1, 'RenvoiPepin.dc.html')
    cv['notes']['t10']['maxW'] = 2740
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT, sorted((v['y'], v['x'], v['h'], k) for k, v in B.items() if v['page'] == 'edition' and v['y'] in (0, 1680, 3660)))
