import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
ENVX = {'bet': '<circle cx="12" cy="12" r="9"/><path d="M9.500 9.500a2.500 2.500 0 1 1 3.500 2.300c-.700.400-1 1-1 1.700M12 17h.010"/>'}
def minix(inner, tone='primary'):
    bg, fg = {'primary': ('#f6e2dd', '#a43a2f'), 'quiet': ('#f1e8d8', '#57534e'), 'warn': ('#f9eecb', '#79511d')}[tone]
    return f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(inner, 18)}</span>'
def tabs(cur):
    def tab(label, icon, on):
        col = '#8a2f27' if on else '#57534e'
        cur_ = ' aria-current="page"' if on else ''
        return f'<a href="#"{cur_} style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: {col}; font-size: 12px; font-weight: {700 if on else 600}">{ic(icon, 22)}{label}</a>'
    return f'<nav aria-label="Sections" style="margin-top: auto; flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad">{tab("Tirages", ENV("sealed"), cur == 0)}{tab("Listes", ENV("list"), cur == 1)}</nav>'
def build2(name, title, main, h, cur):
    build(name, title, main, h)
    p = P/name; t = p.read_text()
    a = t.index('<button aria-label="Retour"'); b = t.index('</button>', a) + 9
    t = t[:a] + t[b:]
    k = t.rindex('</main>') + 7
    t = t[:k] + '\n  ' + tabs(cur) + t[k:]
    p.write_text(t)

build2('FuturAccueil.dc.html', 'Futur — accueil avec les paris', f'''<main style="{MAIN}">
    {greet('Camille')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">À faire maintenant · Famille Camille</p>
        <h2 style="{CT}">Devine qui offre à qui</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Tu as fait 2 paris sur 5. Les réponses tombent à la fête, dans 40 jours.</p>
      </div>
      <a href="#paris" style="{BTN}">Faire mes paris</a>
    </section>
    <h2 style="{H2L}">Mes groupes</h2>
    {group('Famille Camille', 'Noël 2026 · fête dans 40 jours', inrow(mini('open', 'ok'), 'Mon tirage', 'Tu sais à qui tu offres', first=True) + inrow(minix(ENVX['bet'], 'warn'), 'Devine qui a qui', '2 paris sur 5 · jusqu’à la fête') + inrow(mini('gear', 'primary'), 'Gérer le tirage', 'Tirage fait · tout le monde est prévenu'), True)}
    {group('Amis de Camille', 'Noël 2026 · fête dans 34 jours', inrow(mini('wait'), 'Mon tirage', 'Pas encore tiré', first=True) + inrow(mini('gear', 'primary'), 'Gérer le tirage', 'À préparer · 4 participants'), True)}
  </main>''', 1090, 0)

def lrow(n, sub, first=False, new=''):
    badge = f'<span style="padding: 2px 8px; border-radius: 999px; background: #f6e2dd; color: #8a2f27; font-size: 12px; font-weight: 700; flex-shrink: 0">{new}</span>' if new else ''
    return inrow(pav(n), n, sub, badge + CHEV, first)
build2('FuturListes.dc.html', 'Futur — onglet Listes', f'''<main style="{MAIN}">
    {head('Listes', 'Des idées de cadeaux toute l’année, avec ou sans tirage.')}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="{OVER}">Ma liste</p>
        <h2 style="{CT}">12 idées</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Vue par Famille Camille et 2 autres personnes. Celui qui t’a tiré au sort la voit aussi.</p>
      </div>
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">
        <a href="#liste" style="{BTN}">Modifier</a>
        <a href="#partage" style="height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Partager</a>
      </div>
    </section>
    {section('Partagées avec moi', lrow('Inès', '8 idées · Famille Camille', True, '2 nouvelles') + lrow('Louis', '5 idées · Famille Camille') + lrow('Hugo', 'Aucune idée pour l’instant') + lrow('Rose', '3 idées · partagée avec toi seule'), 'Sur ta propre liste, tu ne vois jamais qui a réservé quoi.')}
  </main>''', 960, 1)
print('ok')
