# Lots 39, 38 B, 34 et 38 A : signaler, modérer, les règles d'usage, les interrupteurs d'urgence, la limite de participants (19 novembre 2026)
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/stop.py').read().split("# 1. le premier email")[0])
G={}
FIELD='height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px'
TA='box-sizing: border-box; padding: 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45'
def rad(t,on=False,top=True):
    dot='<span style="width: 10px; height: 10px; border-radius: 50%; background: #b8483a"></span>' if on else ''
    return f'<label style="display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 6px 14px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} font-size: 16px"><span role="radio" aria-checked="{"true" if on else "false"}" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 50%; border: 2px solid {"#b8483a" if on else "#a8a29e"}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{dot}</span>{t}</label>'
RGS='border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; background: #fffdf9; display: flex; flex-direction: column'
def who(t): return f'<p style="{SM}">{t}</p>'
FLAG=ic('<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',18)
def sw(on,label):
    return (f'<span role="switch" aria-checked="{"true" if on else "false"}" aria-label="{label}" style="width: 48px; height: 28px; border-radius: 999px; background: {"#b8483a" if on else "#d6d3d1"}; position: relative; flex-shrink: 0">'
            f'<span style="position: absolute; top: 3px; left: {23 if on else 3}px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>')
def badge(n): return f'<span style="min-width: 22px; height: 22px; padding: 0 7px; box-sizing: border-box; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 12px; font-weight: 700; display: flex; align-items: center; justify-content: center">{n}</span>'
def tag(t,kind='n'):
    bg,fg={'n':('#f1e8d8','#57534e'),'w':('#fbf0cf','#5b430f'),'ok':('#dbe9dd','#274e34'),'r':('#f6e2dd','#8a2f27')}[kind]
    return f'<span style="font-size: 12px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: {bg}; color: {fg}; white-space: nowrap">{t}</span>'
# ---------- Lot 39 : signaler
G['Signaler']=(scr(1060,f'''<div style="display: flex; flex-direction: column; gap: 10px">
      <p style="{SM}">La liste « Noël chez Camille »</p>
      <h1 style="{H1}">Signaler cette page</h1>
      <p style="{P}">Dis-nous ce qui ne va pas. Une personne lit chaque signalement.</p>
    </div>
    <div role="radiogroup" aria-label="Ce qui ne va pas" style="{RGS}">{rad('Un contenu illégal',False,False)}{rad('Du harcèlement, des insultes')}{rad('Des informations sur moi ou sur un enfant, sans accord',True)}{rad('Une arnaque, de la publicité')}{rad('Autre chose')}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="m" style="font-size: 15px; font-weight: 600">Quelques mots (facultatif)</label><textarea id="m" rows="3" style="{TA}">Le prénom et l’âge de mon fils sont sur cette liste.</textarea>{who('Lu seulement par l’administrateur de l’application.')}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="font-size: 15px; font-weight: 600">Ton adresse email (facultatif)</label><input id="e" type="email" placeholder="pour recevoir la réponse" style="{FIELD}">{who('Elle sert à te répondre, rien d’autre. Celui qui a écrit la page ne la voit pas, et ne sait pas qui a signalé.')}</div>
    <a href="SignalerEnvoye.dc.html" style="{BTN}">Envoyer le signalement</a>
    <p style="{SM}; text-align: center"><a href="Regles.dc.html" style="{A}">Les règles d’usage</a></p>''','Signaler — le formulaire, sans compte'),1060,'« Signaler », en bas de toute page ouverte par un lien')
G['SignalerEnvoye']=(scr(844,f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; padding-top: 24px">
      <span aria-hidden="true" style="width: 64px; height: 64px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center">{ic('<path d="m5 12 5 5 9-10"/>',30,2.6)}</span>
      <h1 style="{H1}">Signalement reçu</h1>
      <p style="{P}">Merci. L’administrateur le lit et décide : laisser, rendre la page inaccessible, ou suspendre le compte.</p>
      <p style="{SM}">Tu as laissé ton adresse : tu recevras un accusé de réception, puis la décision.</p>
    </div>
    <div role="note" style="{NOTE}"><span>En cas de danger immédiat, n’attends pas notre réponse : appelle le 17, ou le 112.</span></div>''','Signaler — c’est envoyé',back=False),844,'Après l’envoi')
def srow(titre,motif,quand,st,top=True):
    return f'<li><a href="AdminSignalement.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 72px; padding: 10px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524"><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px"><span style="font-weight: 700; font-size: 16px">{titre}</span><span style="font-size: 14px; color: #57534e">{motif} · {quand}</span></span>{st}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
G['AdminSignalements']=(scr(960,f'''<div style="display: flex; flex-direction: column; gap: 6px"><h1 style="{H1}">Signalements</h1><p style="{SM}">Du plus récent au plus ancien. Rien n’est effacé sur un simple signalement.</p></div>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; display: flex; align-items: center; gap: 8px">À traiter {badge(2)}</h2>
      <ul style="{UL}">{srow('Liste « Noël chez Camille »','Informations sur un enfant','il y a 2 h',tag('Nouveau','r'),False)}{srow('Email du groupe « Bureau 3e »','Envoi non voulu','hier',tag('2 signalements','w'))}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Traités</h2>
      <ul style="{UL}">{srow('Liste « Promo -70 % »','Publicité','le 12 novembre',tag('Partage arrêté','n'),False)}{srow('Liste « Anniv de Zoé »','Autre chose','le 3 novembre',tag('Classé','ok'))}</ul></section>
    <p style="{SM}">Gardés un an, avec la décision prise.</p>''','Administration — la file des signalements'),960,'La file des signalements du super-admin')
BTNN='height: 48px; box-sizing: border-box; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
G['AdminSignalement']=(scr(1280,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Signalement · il y a 2 h</p><h1 style="{H1}">Liste « Noël chez Camille »</h1></div>
    <section style="{CARD}; padding: 16px; display: flex; flex-direction: column; gap: 10px">
      <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Ce qui est signalé</p>
      <p style="{P}"><strong>Des informations sur moi ou sur un enfant, sans accord</strong></p>
      <p style="{P}">« Le prénom et l’âge de mon fils sont sur cette liste. »</p>
      <p style="{SM}">Par quelqu’un qui a laissé son adresse : une réponse lui sera envoyée.</p>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">La page</h2>
      <ul style="{UL}"><li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Tenue par Camille Morel</span><span style="font-size: 14px; color: #57534e">Compte créé le 2 novembre · aucun signalement avant</span></span></li><li><a href="#" style="display: flex; align-items: center; justify-content: space-between; min-height: 52px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5; font-size: 16px; font-weight: 600; {A}">Voir la liste telle qu’elle est partagée<span style="color: #78716c; display: flex">{CHEV}</span></a></li></ul></section>
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Ta décision</h2>
      <div role="radiogroup" aria-label="Décision" style="{RGS}">{rad('Classer : rien à retirer',False,False)}{rad('Arrêter le partage de cette liste',True)}{rad('Suspendre le compte de Camille Morel')}</div>
      <div style="display: flex; flex-direction: column; gap: 6px"><label for="r" style="font-size: 15px; font-weight: 600">La raison, envoyée à Camille</label><textarea id="r" rows="3" style="{TA}">La liste donne le prénom et l’âge d’un enfant dont un parent n’a pas donné son accord.</textarea>{who('Camille reçoit la raison, la règle visée et comment contester. Jamais le nom de qui a signalé.')}</div>
      <a href="ModerationEmail.dc.html" style="{BTN}">Arrêter le partage et prévenir</a>
      <p style="{SM}">Rien n’est effacé : la liste reste chez Camille, son lien ne marche plus. Tu peux revenir dessus.</p>
    </section>''','Administration — un signalement, et la décision'),1280,'Un signalement : la décision et sa raison')
G['ModerationEmail']=(mail('Le partage de ta liste « Noël chez Camille » a été arrêté','camille-demo@example.com',f'''<p style="margin: 0">Bonjour Camille,</p>
    <p style="margin: 0">Après un signalement, l’administrateur d’Under the Tree a arrêté le partage par lien de ta liste « Noël chez Camille ».</p>
    <p style="margin: 0"><strong>La raison :</strong> la liste donne le prénom et l’âge d’un enfant dont un parent n’a pas donné son accord.</p>
    <p style="margin: 0"><strong>La règle :</strong> « Pas d’informations sur quelqu’un d’autre sans son accord » (<a href="Regles.dc.html" style="{ML}">les règles d’usage</a>).</p>
    <p style="margin: 0"><strong>Ce qui change :</strong> le lien de la liste ne marche plus. La liste, ses idées et ses coches sont toujours chez toi. Rien n’est effacé.</p>
    <p style="margin: 0"><strong>Pour la partager de nouveau :</strong> retire ce qui pose problème, puis réponds à cet email.</p>
    <p style="margin: 0"><strong>Tu n’es pas d’accord ?</strong> Réponds à cet email en expliquant pourquoi : une personne relira la décision.</p>
    <p style="margin: 0">Under the Tree</p>''','Emails — la décision motivée, à celui dont le contenu est retiré',900),900,'La décision, expliquée à celui qui tient la liste')
G['ListePartageSuspendu']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 10px">{tile('🎄','sapin',72)}<h1 style="{H1}">Noël chez Camille</h1></div>
    <div role="alert" style="{NOTE}"><span aria-hidden="true" style="display: flex; flex-shrink: 0; margin-top: 1px">{FLAG}</span><span><strong>Le partage par lien de cette liste a été arrêté par l’administrateur.</strong> La raison : la liste donne le prénom et l’âge d’un enfant dont un parent n’a pas donné son accord.<br><a href="Regles.dc.html" style="color: #5b430f; text-decoration: underline; font-weight: 700">Les règles d’usage</a> · <a href="#" style="color: #5b430f; text-decoration: underline; font-weight: 700">Contester</a></span></div>
    <p style="{P}">Ta liste, ses idées et ses coches sont toujours là. Tu peux la modifier.</p>
    <p style="{SM}">L’interrupteur « Partage par lien » est bloqué tant que l’administrateur ne l’a pas rouvert.</p>''','Listes — le partage arrêté par l’administrateur, vu par celui qui tient la liste'),844,'Dans l’application : celui qui tient la liste le voit')
def rule(t,d): return f'<li style="display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 700; font-size: 16px">{t}</span><span style="font-size: 15px; line-height: 1.45; color: #57534e">{d}</span></li>'
RUL='list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 14px'
H2B=f'margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2'
G['Regles']=(scr(1900,f'''<div style="display: flex; flex-direction: column; gap: 10px"><h1 style="{H1}">Les règles d’usage</h1><p style="{P}">Under the Tree sert à organiser des tirages au sort de cadeaux et à tenir des listes de cadeaux, entre gens qui se connaissent. C’est gratuit, sans publicité.</p></div>
    <section style="display: flex; flex-direction: column; gap: 12px"><h2 style="{H2B}">Ce qu’on n’y met pas</h2><ul style="{RUL}">
      {rule('Rien d’illégal','Ni menaces, ni contenu haineux, ni rien que la loi interdit.')}
      {rule('Pas de harcèlement','On n’ajoute pas quelqu’un pour l’embêter, on n’écrit rien de blessant.')}
      {rule('Pas d’informations sur quelqu’un d’autre sans son accord','Un prénom suffit. Pour un enfant, c’est un de ses parents qui décide.')}
      {rule('Pas de publicité ni de démarchage','L’application n’est pas un outil d’envoi d’emails.')}
      {rule('Pas de données sensibles','Santé, opinions, religion : ça n’a rien à faire dans une liste de cadeaux.')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 12px"><h2 style="{H2B}">Les adresses email</h2><p style="{P}">N’ajoute que des gens que tu connais et qui s’y attendent. Chacun peut refuser les emails, d’un clic, en bas de n’importe lequel.</p></section>
    <section style="display: flex; flex-direction: column; gap: 12px"><h2 style="{H2B}">Si quelque chose ne va pas</h2><p style="{P}">Chaque page ouverte par un lien a un lien « Signaler ». Une personne lit chaque signalement. Selon le cas, elle laisse, rend la page inaccessible, ou suspend le compte. Celui qui a écrit reçoit la raison et peut contester.</p><p style="{P}">Personne ne lit tes listes ni tes tirages pour les surveiller : on n’agit que sur signalement.</p></section>
    <section style="display: flex; flex-direction: column; gap: 12px"><h2 style="{H2B}">Ce que l’application te doit, et ne te doit pas</h2><p style="{P}">Elle est tenue par une seule personne, sur son temps libre. Elle fait de son mieux, sans garantie : elle peut être en panne, changer, ou s’arrêter. Dans ce cas, tu seras prévenu et tu pourras récupérer tes données.</p></section>
    <section style="display: flex; flex-direction: column; gap: 12px"><h2 style="{H2B}">Nous écrire</h2><p style="{P}">Une seule adresse, pour tout : contact@under-the-tree.party</p></section>
    <p style="{SM}"><a href="Confidentialite.dc.html" style="{A}">Tes données, en clair</a> · <a href="#" style="{A}">Mentions légales</a></p>
    <p style="{SM}">Mises à jour le 19 novembre 2026.</p>''','Les règles d’usage — la page publique',back=False),1900,'« Les règles d’usage », la page publique')
G['CompteCreerRegles']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 10px"><h1 style="{H1}">Créer mon compte</h1></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="p" style="font-size: 15px; font-weight: 600">Ton prénom</label><input id="p" value="Léa" style="{FIELD}"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="font-size: 15px; font-weight: 600">Ton adresse email</label><input id="e" type="email" value="lea-demo@example.com" style="{FIELD}">{who('Elle sert à te connecter et à te prévenir. Personne d’autre ne la voit.')}</div>
    <div style="display: flex; flex-direction: column; gap: 10px"><a href="#" style="{BTN}">Créer mon compte</a>
    <p style="{SM}; text-align: center">En créant ton compte, tu acceptes <a href="Regles.dc.html" style="{A}">les règles d’usage</a>. Voir aussi <a href="Confidentialite.dc.html" style="{A}">tes données, en clair</a>.</p></div>''','Compte — créer, avec les règles d’usage'),844,'À la création du compte : une phrase, pas une case')
# ---------- Lot 34 : la limite de participants
G['LimiteParticipants']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Bureau 3e · Noël 2026</p><h1 style="{H1}">Participants</h1><p style="{SM}">30 participants</p></div>
    <div role="status" style="{NOTE}"><span><strong>Ce groupe peut tirer jusqu’à 30 participants.</strong> Tu les as tous. Il t’en faut plus ? Demande : c’est gratuit, et la réponse arrive vite.</span></div>
    <a href="DemandePlus.dc.html" style="{BTN}">Demander plus de participants</a>
    <p style="{SM}">Rien n’est perdu : tes 30 participants restent, et le tirage peut se faire à 30.</p>''','Tirage — la limite de participants est atteinte'),844,'Au 31e participant : la limite, et la demande')
G['DemandePlus']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 10px"><p style="{SM}">Bureau 3e</p><h1 style="{H1}">Demander plus de participants</h1></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="n" style="font-size: 15px; font-weight: 600">Combien de participants, au plus ?</label><input id="n" inputmode="numeric" value="45" style="{FIELD}; width: 120px">{who('Aujourd’hui : 30. Le maximum possible est 100.')}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="m" style="font-size: 15px; font-weight: 600">Un mot pour l’administrateur</label><textarea id="m" rows="3" style="{TA}">Le Secret Santa de l’étage, on est 42 cette année.</textarea>{who('Lu seulement par l’administrateur de l’application.')}</div>
    <a href="#" style="{BTN}">Envoyer la demande</a>
    <p style="{SM}">Tu seras prévenu de la réponse, par email et sur ton accueil.</p>''','Tirage — demander plus de participants'),900,'La même demande que pour un groupe, avec un nombre')
# Le panneau unique d'une demande (Julien, 19 novembre 2026, option A) : plus « ai-je la place ? » mais « puis-je faire confiance à ce compte ? »
def fact2(k,v,warn=False,top=True): return f'<li style="display: flex; align-items: baseline; justify-content: space-between; gap: 12px; min-height: 44px; padding: 10px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} font-size: 15px"><span style="color: #57534e">{k}</span><span style="font-weight: 700; text-align: right; color: {"#8a2f27" if warn else "#292524"}">{v}</span></li>'
def chipm(t,on=False): return f'<button aria-pressed="{"true" if on else "false"}" style="height: 36px; padding: 0 12px; border-radius: 999px; border: 1px solid {"#b8483a" if on else "#cdb48a"}; background: {"#f6e2dd" if on else "#fffdf9"}; color: {"#8a2f27" if on else "#292524"}; font-family: inherit; font-size: 14px; font-weight: 700">{t}</button>'
def dem(e,bg,name,when,kind,asked,mot,facts,field,chips,word,title,h):
    f=''.join(fact2(k,v,w,i>0) for i,(k,v,w) in enumerate(facts))
    wd=f'<textarea aria-label="Un mot" rows="3" style="{TA}">{word}</textarea>' if word else f'<textarea aria-label="Un mot" rows="2" placeholder="Écris, ou choisis un mot tout prêt" style="{TA}"></textarea>'
    return scr(h,f'''<div style="display: flex; flex-direction: column; gap: 8px"><p style="{SM}">Demande · {when}</p>
      <div style="display: flex; align-items: center; gap: 12px"><span aria-hidden="true" style="width: 48px; height: 48px; border-radius: 50%; background: {bg}; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0">{e}</span><h1 style="{H1}; font-size: 26px">{name}</h1></div>
      <p style="margin: 0; display: flex">{kind}</p></div>
    <section style="{CARD}; padding: 16px; display: flex; flex-direction: column; gap: 8px"><p style="{P}"><strong>{asked}</strong></p><p style="{P}">« {mot} »</p></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Ce qu’on sait de ce compte</h2><ul style="{UL}">{f}</ul><p style="{SM}"><a href="AdminCompte.dc.html" style="{A}">Voir le compte</a></p></section>
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Ta réponse</h2>
      {field}
      <div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 15px; font-weight: 600">Un mot pour {name.split()[0]} (facultatif)</span><div style="display: flex; flex-wrap: wrap; gap: 8px">{chips}</div>{wd}{who('Ajouté à l’email qui prévient de ta réponse.')}</div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><a href="#" style="{BTNN}">Refuser</a><a href="#" style="{BTN}; height: 48px; font-size: 16px">Accepter</a></div></section>''',title)
NB=lambda lab,val,hint: f'<div style="display: flex; flex-direction: column; gap: 6px"><label for="n" style="font-size: 15px; font-weight: 600">{lab}</label><input id="n" inputmode="numeric" value="{val}" style="{FIELD}; width: 120px">{who(hint)}</div>'
G['AdminDemande']=(dem('🧣','#f3d3cc','Léa Martin','le 14 novembre',tag('Un groupe de plus','r'),'Un 4e groupe','Un quatrième groupe pour le club de rando.',
  [('Compte créé','il y a 2 ans',False),('Groupes','3 · 7 tirages faits',False),('Emails envoyés','184 · 0 rejeté',False),('Adresses qui ont refusé ses emails','0',False),('Signalements','aucun',False)],
  NB('Groupes qu’elle pourra organiser','4','Aujourd’hui : 3.'),chipm('C’est d’accord')+chipm('D’accord, mais pour moins')+chipm('Pas pour l’instant'),'','Administration — une demande : un groupe de plus',1180),1180,'Une demande, le panneau unique : un groupe de plus')
G['AdminDemandeParticipants']=(dem('🎧','#d6e6ef','Karim Benali','le 18 novembre',tag('Plus de participants','w'),'60 participants dans « Bureau 3e »','Le Secret Santa de tout le bâtiment cette année.',
  [('Compte créé','il y a 6 semaines',False),('Groupes','1 · aucun tirage fait',False),('Emails envoyés','30 · 4 rejetés',True),('Adresses qui ont refusé ses emails','2',True),('Signalements','aucun',False)],
  NB('Participants, au plus, dans ce groupe','40','Aujourd’hui : 30. Demandé : 60. Maximum : 100.'),chipm('C’est d’accord')+chipm('D’accord, mais pour moins',True)+chipm('Pas pour l’instant'),'D’accord pour 40 pour cette fois : c’est ton premier tirage ici. Redemande si ça ne suffit pas.','Administration — une demande : plus de participants, acceptée pour moins',1280),1280,'La même, pour des participants : acceptée pour moins')
# ---------- Les demandes, repensées : tout compte a 3 groupes et 30 participants ; on ne demande que « plus »
def drow(e,bg,n,what,sub,href,top=True):
    return f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 76px; padding: 10px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524"><span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0">{e}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px"><span style="font-weight: 700; font-size: 16px">{n}</span><span style="display: flex; flex-wrap: wrap; align-items: center; gap: 6px; font-size: 14px; color: #57534e">{what}{sub}</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
G['AdminDemandes']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 6px"><h1 style="{H1}">Demandes</h1><p style="{SM}">Chacun a 3 groupes et 30 participants par tirage sans rien demander. Ici, ceux à qui ça ne suffit pas.</p></div>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; display: flex; align-items: center; gap: 8px">À traiter {badge(2)}</h2>
      <ul style="{UL}">{drow('🧣','#f3d3cc','Léa Martin',tag('Un groupe de plus','r'),'a déjà 3 groupes · le 14 nov.','AdminDemande.dc.html',False)}{drow('🎧','#d6e6ef','Karim Benali',tag('Plus de participants','w'),'Bureau 3e · 45 demandés','AdminDemandeParticipants.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Traitées</h2>
      <ul style="{UL}">{drow('🦊','#f6e3ad','Inès Roux',tag('Plus de participants','n'),'acceptée · 60 · le 9 nov.','#',False)}{drow('🐻','#cfe2d3','Paul Girard',tag('Un groupe de plus','n'),'refusée · le 2 nov.','#')}</ul></section>''','Administration — les demandes, des deux sortes'),900,'Les demandes : un groupe de plus, plus de participants')
G['LimiteGroupes']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 6px"><h1 style="{H1}">Nouveau groupe</h1></div>
    <div role="status" style="{NOTE}"><span><strong>Tu organises déjà 3 groupes, le maximum sans demande.</strong> Il t’en faut un de plus ? Demande : c’est gratuit, et la réponse arrive vite.</span></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="m" style="font-size: 15px; font-weight: 600">Un mot pour l’administrateur</label><textarea id="m" rows="3" style="{TA}">Un quatrième groupe pour le club de rando.</textarea>{who('Lu seulement par l’administrateur de l’application.')}</div>
    <a href="#" style="{BTN}">Demander un groupe de plus</a>
    <p style="{SM}">Tes 3 groupes ne changent pas. Tu peux aussi supprimer un groupe qui ne sert plus.</p>''','Groupes — la limite de 3 groupes, et la demande'),844,'Au 4e groupe : la limite, et la demande')
# ---------- Lot 38 B : quand les emails sont suspendus
G['EnvoiSuspendu']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Famille Camille · Noël 2026</p><h1 style="{H1}">Envoyer par email</h1></div>
    <div role="status" style="{NOTE}"><span aria-hidden="true" style="display: flex; flex-shrink: 0; margin-top: 1px">{NOMAIL}</span><span><strong>L’envoi d’emails est en pause pour tout le monde.</strong> Ce n’est pas ton groupe : l’application a atteint sa limite. Il reprendra tout seul.</span></div>
    <p style="{P}">En attendant, envoie à chacun son lien depuis ton téléphone : ça marche toujours, et ça ne dépend de rien.</p>
    <a href="#" style="{BTN}">{SHARE}Partager les liens</a>''','Emails — l’envoi est en pause, vu par un organisateur'),844,'Emails suspendus : ce que voit un organisateur')
# ---------- Lot 38 A : trop de demandes
G['TropDeDemandes']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 10px"><h1 style="{H1}">Se connecter</h1><p style="{P}">Reçois un lien de connexion par email.</p></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="font-size: 15px; font-weight: 600">Ton adresse email</label><input id="e" type="email" value="lea-demo@example.com" style="{FIELD}"></div>
    <div role="alert" style="{NOTE}"><span><strong>Trop de demandes d’un coup.</strong> Attends quelques minutes avant de réessayer. Si tu as déjà demandé un lien, regarde dans tes emails : il est valable 15 minutes.</span></div>
    <button disabled style="{BTN}; opacity: 0.5">Recevoir mon lien</button>''','Connexion — trop de demandes'),844,'Trop de demandes : le message')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in G.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
json.dump({k:[ht,t] for k,(h,ht,t) in G.items()},open('/tmp/garde2.json','w'),ensure_ascii=False)
print(list(G))
