# Réordonner en glissant : la ligne soulevée et l'endroit où elle va tomber (Julien, 19 novembre 2026). À lancer après proches.py.
import re,json
PJ='/home/claude/utt/project/'
h=open(PJ+'ListeTeneur.dc.html').read()
A='<li><a href="ListeIdee.dc.html" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none">'
GRIP='<span aria-hidden="true" style="margin-left: auto; align-self: center; display: flex; color: #78716c; flex-shrink: 0"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.7"/><circle cx="15" cy="6" r="1.7"/><circle cx="9" cy="12" r="1.7"/><circle cx="15" cy="12" r="1.7"/><circle cx="9" cy="18" r="1.7"/><circle cx="15" cy="18" r="1.7"/></svg></span>'
k=h.index('Livres sur les dinosaures'); a=h.rindex('<li',0,k); b=h.index('</a></li>',k)
assert h[a:a+len(A)]==A
lift=('<li style="position: relative; z-index: 2"><a href="ListeIdee.dc.html" aria-grabbed="true" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; margin: 0 -12px; padding: 10px 12px; box-sizing: border-box; text-decoration: none; border-radius: 14px; background: #fffdf9; box-shadow: 0 0 0 1.5px #b8483a, 0 14px 30px rgba(41, 37, 36, 0.22); transform: translateY(-30px) rotate(-1.2deg)">')
h=h[:a]+lift+h[a+len(A):b]+GRIP+h[b:]
k=h.index('Vélo 16 pouces'); a=h.rindex('<li',0,k)
h=h[:a]+'<li aria-hidden="true" style="height: 4px; margin: 2px 0; border-radius: 999px; background: #b8483a"></li>'+h[a:]
h=re.sub(r'<title>[^<]*</title>','<title>Listes — réordonner en glissant : la ligne soulevée, et où elle va tomber</title>',h,count=1)
open(PJ+'ListeGlisser.dc.html','w').write(h)
names=json.load(open('/tmp/names.json'))
if 'ListeGlisser.dc.html' not in names: names.append('ListeGlisser.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print('ok')
