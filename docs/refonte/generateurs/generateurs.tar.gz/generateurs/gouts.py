# « ses goûts » : trois façons de l'afficher sans lien souligné (Julien, 20 novembre 2026). Planche de propositions. Après coche.py.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.6): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
HEART='<path d="M12 20s-7-4.4-7-9.6A4 4 0 0 1 12 8a4 4 0 0 1 7 2.400C19 15.600 12 20 12 20z"/>'
CH='<path d="m9 6 6 6-6 6"/>'
v=open(PJ+'ListeVisiteur.dc.html',encoding='utf-8').read()
i=v.index('ses goûts'); a=v.rfind('<section',0,i); u=v.index('<ul',i); e=v.index('</ul>',u)
head=v[a:u]; ul=v[u:e]
lis=re.findall(r'<li>.*?</li>',ul,flags=re.S)[:2]; ulopen=ul[:ul.index('>')+1]
lines=ulopen+''.join(lis)+'</ul></section>'
LINK=' · <a href="ListePersonne.dc.html" style="color: #8a2f27; text-decoration: underline">ses goûts</a>'
assert LINK in head
plain=head.replace(LINK,'')
# A. tout l'en-tête est le bouton, une flèche au bout (à la place du « ⋯ » de celui qui tient la liste)
hA=plain.replace('<div style="display: flex; align-items: center; gap: 12px">','<a href="ListePersonne.dc.html" aria-label="Léo, ses infos et ses goûts" style="display: flex; align-items: center; gap: 12px; text-decoration: none; color: inherit">',1)
k=hA.rindex('</div>'); hA=hA[:k]+f'<span aria-hidden="true" style="margin-left: auto; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; color: #78716c">{ic(CH,18,2)}</span></a>'+hA[k+6:]
# B. une pastille d'action sous les infos
chip=f'<a href="ListePersonne.dc.html" style="align-self: flex-start; margin-top: 4px; display: inline-flex; align-items: center; gap: 4px; font-size: 12px; line-height: 20px; font-weight: 600; letter-spacing: 0.01em; border-radius: 999px; text-decoration: none; white-space: nowrap; color: #292524; background: #fffdf9; box-shadow: inset 0 0 0 1.5px #a8a29e; padding: 1px 6px 1px 7px">{ic(HEART)}Ses goûts{ic(CH,12,2.8)}</a>'
hB=plain.replace('pointure 30</p>','pointure 30</p>'+chip,1); assert chip in hB
# C. un aperçu de ses goûts, sur une ligne, qui ouvre la fiche
peek=(f'<a href="ListePersonne.dc.html" aria-label="Les goûts de Léo" style="margin: 8px 0 2px; display: flex; align-items: center; gap: 8px; min-height: 40px; padding: 0 8px 0 12px; border-radius: 12px; background: #f1e8d8; text-decoration: none; color: #57534e; font-size: 14px; line-height: 1.35">'
      f'<span style="display: flex; color: #8a2f27">{ic(HEART,16,2.2)}</span><span style="flex-grow: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap"><strong style="color: #292524; font-weight: 600">Les dinosaures, les billes</strong> · évite les peluches</span><span style="display: flex; color: #78716c">{ic(CH,16,2.2)}</span></a>')
k=plain.rindex('</div>'); hC=plain[:k+6]+peek+plain[k+6:]
def blk(tag,title,sub,h):
    return (f'<div style="display: flex; flex-direction: column; gap: 6px"><p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">{tag}</p>'
            f'<h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 20px">{title}</h2><p style="margin: 0 0 6px; font-size: 14px; line-height: 1.45; color: #57534e">{sub}</p>'
            f'<div style="margin: 0 -16px; padding: 14px 16px 4px; background: #f7f2e9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{h}{lines}</div></div>')
body=(blk('A','Tout l’en-tête se touche','Une flèche au bout, là où celui qui tient la liste a son « ⋯ ». Rien de plus à lire.',hA)
     +blk('B','Une pastille « Ses goûts »','À filet, donc elle se touche : la règle des pastilles.',hB)
     +blk('C · recommandée','Un aperçu de ses goûts','Ce qu’il aime en ce moment et ce qu’il faut éviter, sur une ligne. On sait déjà quelque chose sans rien ouvrir. Pas de goûts écrits, pas de ligne.',hC))
pre=v[:v.index('<header')]; tail=v[v.rindex('</div>\n</x-dc>'):]
page=(pre+f'<main style="display: flex; flex-direction: column; gap: 30px; padding: 24px 16px 32px"><h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 26px; line-height: 1.15">« Ses goûts », sans lien souligné</h1>{body}</main>'+tail)
page=re.sub(r'<title>[^<]*</title>','<title>« Ses goûts » : trois façons de l’afficher</title>',page,count=1)
page=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1260}',page)
page=re.sub(r'(<div style="width: 390px;[^"]*?)(?:min-)?height: \d+px;',r'\1min-height: 1260px;',page,count=1)
open(PJ+'ListeGoutsPistes.dc.html','w',encoding='utf-8').write(page)
names=json.load(open('/tmp/names.json'))
if 'ListeGoutsPistes.dc.html' not in names: names.append('ListeGoutsPistes.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print('ok')
