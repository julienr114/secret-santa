# « ses goûts », deuxième série (Julien : aucune des trois ; creuser autour de l'aperçu). Remplace la planche ListeGoutsPistes. Après gouts.py.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.6): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
HEART='<path d="M12 20s-7-4.4-7-9.6A4 4 0 0 1 12 8a4 4 0 0 1 7 2.4C19 15.600 12 20 12 20z"/>'
CH='<path d="m9 6 6 6-6 6"/>'; UP='<path d="m6 15 6-6 6 6"/>'
v=open(PJ+'ListeVisiteur.dc.html',encoding='utf-8').read()
i=v.index('ses goûts'); a=v.rfind('<section',0,i); u=v.index('<ul',i); e=v.index('</ul>',u)
head=v[a:u]; ul=v[u:e]
lis=re.findall(r'<li>.*?</li>',ul,flags=re.S); ulopen=ul[:ul.index('>')+1]
addli=[x for x in lis if 'J’offre autre chose' in x][0]
def lines(extra_after_add=''):
    return ulopen+''.join(lis[:2])+addli.replace('</a></li>','</a>'+extra_after_add+'</li>') +'</ul></section>'
LINK=' · <a href="ListePersonne.dc.html" style="color: #8a2f27; text-decoration: underline">ses goûts</a>'
plain=head.replace(LINK,''); assert plain!=head
META='pointure 30</p>'
# D. une troisième ligne dans l'en-tête, en texte, sans fond
lineD=(f'<a href="ListePersonne.dc.html" aria-label="Les goûts de Léo" style="display: flex; align-items: center; gap: 6px; min-height: 24px; margin-top: 1px; text-decoration: none; font-size: 14px; line-height: 1.4; color: #57534e">'
       f'<span style="display: flex; color: #8a2f27">{ic(HEART,14,2.4)}</span><span style="min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">Les dinosaures, les billes</span><span style="display: flex; color: #78716c">{ic(CH,14,2.4)}</span></a>')
hD=plain.replace(META,META+lineD,1); assert lineD in hD
# E. la même ligne, mais elle se déplie sur place : on lit ses goûts sans quitter la liste
lineE=(f'<button aria-expanded="true" style="display: flex; align-items: center; gap: 6px; min-height: 24px; margin-top: 1px; padding: 0; border: 0; background: transparent; font-family: inherit; font-size: 14px; line-height: 1.4; font-weight: 600; color: #292524">'
       f'<span style="display: flex; color: #8a2f27">{ic(HEART,14,2.4)}</span>Ses goûts<span style="display: flex; color: #78716c">{ic(UP,14,2.4)}</span></button>')
def row(l,t): return f'<div style="display: grid; grid-template-columns: 96px 1fr; gap: 10px; align-items: baseline"><dt style="font-size: 13px; color: #57534e">{l}</dt><dd style="margin: 0; font-size: 15px; line-height: 1.4; color: #292524">{t}</dd></div>'
blockE=('<dl style="margin: 12px 0 6px 6px; padding: 2px 0 2px 12px; border-left: 2px solid #e6b9b0; display: flex; flex-direction: column; gap: 8px">'
        +row('En ce moment','Les dinosaures, les billes')+row('Lui servirait','Un cartable pour le CP')+row('À éviter','Les peluches, il en a trop')+row('Il préfère','Un objet, à garder, surprenant')+'</dl>')
hE=plain.replace(META,META+lineE,1); k=hE.rindex('</div>'); hE=hE[:k+6]+blockE+hE[k+6:]
# F. rien dans l'en-tête : ses goûts arrivent là où ils servent, sous « J'offre autre chose à Léo »
subF='<a href="ListePersonne.dc.html" style="display: block; margin: -8px 0 10px 34px; text-decoration: none; font-size: 14px; line-height: 1.45; color: #57534e">Il aime <strong style="font-weight: 600; color: #292524">les dinosaures, les billes</strong>. À éviter : les peluches.</a>'
def blk(tag,title,sub,h,ln):
    return (f'<div style="display: flex; flex-direction: column; gap: 6px"><p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">{tag}</p>'
            f'<h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 20px">{title}</h2><p style="margin: 0 0 6px; font-size: 14px; line-height: 1.45; color: #57534e">{sub}</p>'
            f'<div style="margin: 0 -16px; padding: 14px 16px 4px; background: #f7f2e9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{h}{ln}</div></div>')
body=(blk('D','Une troisième ligne, en texte','Sous l’âge et la taille, ce qu’il aime en ce moment. Pas de fond, pas de cadre : une ligne de plus dans l’en-tête, qui ouvre sa fiche.',hD,lines())
     +blk('E · recommandée','Ses goûts se déplient sur place','« ♡ Ses goûts » sous les infos. On le touche : ses goûts s’ouvrent là, sans quitter la liste, et on continue de voir les idées. Ici, déplié.',hE,lines())
     +blk('F','Ses goûts, là où ils servent','Rien dans l’en-tête. Ils apparaissent sous « J’offre autre chose à Léo », au moment où l’on cherche une idée hors de la liste.',plain,lines(subF)))
pre=v[:v.index('<header')]; tail=v[v.rindex('</div>\n</x-dc>'):]
page=(pre+f'<main style="display: flex; flex-direction: column; gap: 30px; padding: 24px 16px 32px"><h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 26px; line-height: 1.15">« Ses goûts », deuxième série</h1>{body}</main>'+tail)
page=re.sub(r'<title>[^<]*</title>','<title>« Ses goûts » : deuxième série de propositions</title>',page,count=1)
H=1580
page=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,page)
page=re.sub(r'(<div style="width: 390px;[^"]*?)(?:min-)?height: \d+px;',r'\1min-height: %dpx;'%H,page,count=1)
open(PJ+'ListeGoutsPistes.dc.html','w',encoding='utf-8').write(page); print('ok')
