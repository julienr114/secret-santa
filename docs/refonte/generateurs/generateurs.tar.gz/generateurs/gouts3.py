# « ses goûts », retenu (Julien, 20 novembre 2026) : E mêlé à C — un petit cadre teinté qui donne envie, et qui ouvre un panneau
# (pas de dépliage sur place : les goûts peuvent être longs). Remplace la planche ListeGoutsPistes. Après gouts2.py.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.6): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
HEART='<path d="M12 20s-7-4.4-7-9.6A4 4 0 0 1 12 8a4 4 0 0 1 7 2.4C19 15.600 12 20 12 20z"/>'
CH='<path d="m9 6 6 6-6 6"/>'
v=open(PJ+'ListeVisiteur.dc.html',encoding='utf-8').read()
LINK=' · <a href="ListePersonne.dc.html" style="color: #8a2f27; text-decoration: underline">ses goûts</a>'
PEEK={'Léo':'Les dinosaures, les billes · évite les peluches','Zoé':'Les licornes, la pâte à modeler · évite les petits objets'}
def card(name,peek):
    return (f'<a href="ListeGoutsPanneau.dc.html" aria-label="Les goûts de {name}" style="margin: 10px 0 2px; display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 6px 8px 6px 10px; border-radius: 12px; background: #f1e8d8; text-decoration: none; color: #292524">'
            f'<span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #fffdf9; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(HEART,16,2.2)}</span>'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 14px; font-weight: 700; line-height: 1.3">Ses goûts</span><span style="font-size: 13px; line-height: 1.35; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{peek}</span></span>'
            f'<span style="display: flex; color: #78716c">{ic(CH,16,2.2)}</span></a>')
h=v; n=0
for m in list(re.finditer(re.escape(LINK),v)):
    pass
parts=h.split(LINK); out=parts[0]
for p in parts[1:]:
    # le prénom de cette section : le dernier <h2> avant le lien
    name=re.findall(r'<h2[^>]*>([^<]*)</h2>',out)[-1]
    # fermer la ligne d'infos, puis poser le cadre après l'en-tête (le premier </div></div> qui suit)
    k=p.index('</div>'); k=p.index('</div>',k+6)+6
    out+=p[:k]+card(name,PEEK.get(name,'À découvrir'))+p[k:]; n+=1
assert n>=1
P={}
# le panneau : tout lire, sans quitter la liste
def row(l,t): return f'<div style="display: flex; flex-direction: column; gap: 2px"><dt style="font-size: 13px; font-weight: 700; color: #57534e">{l}</dt><dd style="margin: 0; font-size: 16px; line-height: 1.45; color: #292524">{t}</dd></div>'
SHEET=('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
  '<div role="dialog" aria-label="Les goûts de Léo" style="position: absolute; left: 0; right: 0; top: 250px; min-height: 594px; box-sizing: border-box; z-index: 5; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 20px 24px; display: flex; flex-direction: column; gap: 16px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
  '<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>'
  '<div style="display: flex; align-items: center; gap: 12px"><span aria-hidden="true" style="width: 44px; height: 44px; border-radius: 50%; background: #d6e6ef; box-shadow: 0 0 0 1px #94bbd0; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0">🚀</span><div style="display: flex; flex-direction: column"><h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.2">Les goûts de Léo</h2><p style="margin: 0; font-size: 14px; color: #57534e">6 ans · taille 6 ans, pointure 30</p></div></div>'
  '<dl style="margin: 0; display: flex; flex-direction: column; gap: 14px">'
  +row('En ce moment','Les dinosaures, surtout les tricératops. Les billes. Il commence à lire tout seul, les petites histoires lui plaisent.')
  +row('Ce qui lui servirait','Un cartable pour le CP, des chaussons pour l’école.')
  +row('À éviter','Les peluches, il en a trop. Rien qui fasse du bruit, merci pour nous.')
  +row('Côté cadeaux, il préfère','Un objet plutôt qu’une sortie, à garder, et il aime être surpris.')
  +'</dl><a href="ListeGoutsParagraphe.dc.html" style="height: 48px; border-radius: 6px; border: 1px solid #dccbad; color: #292524; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Fermer</a></div>')
hp=open(PJ+'ListeGoutsParagraphe.dc.html',encoding='utf-8').read()  # carte écartée : derrière le panneau, la liste avec le paragraphe
k=hp.index('<div style="width: 390px;',hp.index('<x-dc>')); e=hp.index('">',k); hp=hp[:e]+'; position: relative'+hp[e:]
z=hp.rindex('</div>\n</x-dc>'); hp=hp[:z]+SHEET+hp[z:]
P['ListeGoutsPanneau']=(hp,'Avant de publier · 5. le paragraphe ouvre un panneau : tous ses goûts, sans quitter la liste')
names=json.load(open('/tmp/names.json'))
if 'ListeGoutsPistes.dc.html' in names: names.remove('ListeGoutsPistes.dc.html')
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P),n,re.search(r'"\$preview":\{[^}]*\}',h).group(0))
