# « ses goûts », l'autre piste de Julien : un petit paragraphe qui présente la personne, au-dessus de ses idées. Après gouts3.py.
import json,re
PJ='/home/claude/utt/project/'
v=open(PJ+'ListeVisiteur.dc.html',encoding='utf-8').read()
LINK=' · <a href="ListePersonne.dc.html" style="color: #8a2f27; text-decoration: underline">ses goûts</a>'
TXT={'Léo':'En ce moment, <strong style="font-weight: 600; color: #292524">les dinosaures et les billes</strong>. Il commence à lire tout seul. Il lui faudrait un cartable pour le CP. À éviter : les peluches, il en a trop. Côté cadeaux, il préfère un objet à garder, et il aime être surpris.',
     'Zoé':'En ce moment, <strong style="font-weight: 600; color: #292524">les licornes et la pâte à modeler</strong>. À éviter : les petits objets, elle met tout à la bouche.'}
CHD='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>'
CHU=CHD.replace('m6 9 6 6 6-6','m6 15 6-6 6 6')
LONG={'Léo'}  # ceux dont le texte dépasse trois lignes : eux seuls ont « Voir plus »
def para(name,deplie=False):
    # pas de panneau (Julien, 20 novembre 2026) : trois lignes, puis « Voir plus » qui déroule sur place
    clamp='' if deplie else 'display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden'
    more=''
    if name in LONG:
        more=(f'<button aria-expanded="{"true" if deplie else "false"}" style="margin-top: 2px; min-height: 32px; padding: 0; border: 0; background: transparent; font-family: inherit; font-size: 13px; font-weight: 700; color: #57534e; display: flex; align-items: center; gap: 4px">{"Voir moins" if deplie else "Voir plus"}{CHU if deplie else CHD}</button>')
    return (f'<div data-gouts="1" style="margin: 10px 0 0; display: block; text-decoration: none; font-size: 15px; line-height: 1.5; color: #57534e">'
            f'<span style="{clamp}">{TXT.get(name,"")}</span>{more}</div>')
TXT['Camille']='En ce moment, <strong style="font-weight: 600; color: #292524">la cuisine et les polars</strong>. À éviter : les bougies, elle en a pour dix ans.'
# une personne sans âge ni taille n'a que le lien dans sa ligne d'infos : la ligne disparaît avec lui
LONE='<p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e"><a href="ListePersonne.dc.html" style="color: #8a2f27; text-decoration: underline">ses goûts</a></p>'
v=v.replace(LONE,'<p hidden>'+LINK+'</p>')
def build(deplie):
    parts=v.split(LINK); out=parts[0]
    for p in parts[1:]:
        name=re.findall(r'<h2[^>]*>([^<]*)</h2>',out)[-1]
        k=p.index('</div>'); k=p.index('</div>',k+6)+6
        out+=p[:k]+para(name,deplie)+p[k:]
    return out
# sources locales de groupe.py (la mise en page finale est ListeGroupeFil) : elles ne sont plus publiées
open(PJ+'ListeGoutsParagraphe.dc.html','w',encoding='utf-8').write(build(False))
open(PJ+'ListeGoutsParagrapheDeplie.dc.html','w',encoding='utf-8').write(build(True))
names=json.load(open('/tmp/names.json'))
for k in ('ListeGoutsParagraphe.dc.html','ListeGoutsPanneau.dc.html'):
    if k in names: names.remove(k)
json.dump(names,open('/tmp/names.json','w'))
print('ok')
