# Mieux grouper par personne, et faire tomber les cases sous l'en-tête (Julien, 20 novembre 2026). Trois pistes, à partir de la liste
# avec le paragraphe (5 bis, retenu). Après gouts4.py.
import json,re
PJ='/home/claude/utt/project/'
src=open(PJ+'ListeGoutsParagraphe.dc.html',encoding='utf-8').read()
SEC=re.compile(r'<section style="display: flex; flex-direction: column; gap: 2px(; margin-top: 44px)?">')
def colonne(h):
    # deux colonnes : à gauche l'icône de la personne et les cases, centrées l'une sous l'autre ; à droite tout le texte, sur un seul bord
    h=re.sub(r'(<span aria-hidden="true" style=")width: 52px; height: 52px;([^"]*?)font-size: 23px;',r'\1width: 40px; height: 40px;\2font-size: 18px;',h)
    h=h.replace('<div style="display: flex; align-items: center; gap: 12px">\n        <span aria-hidden="true" style="width: 40px;','<div style="display: flex; align-items: center; gap: 10px">\n        <span aria-hidden="true" style="width: 40px;')
    h=h.replace("font-weight: 700; font-size: 26px; line-height: 1.15\">","font-weight: 700; font-size: 24px; line-height: 1.15\">")
    assert 'data-gouts="1" style="margin: 10px 0 0; display: block;' in h
    h=h.replace('style="margin: 10px 0 0; display: block; text-decoration: none; font-size: 15px; line-height: 1.5; color: #57534e"','style="margin: 8px 0 0 50px; display: block; text-decoration: none; font-size: 15px; line-height: 1.5; color: #57534e"')
    h=h.replace('<ul style="list-style: none; margin: 6px 0 0; padding: 0 0 0 6px">','<ul style="list-style: none; margin: 6px 0 0; padding: 0 0 0 9px">')
    h=h.replace('style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 13px 0; box-sizing: border-box; text-decoration: none"','style="display: flex; align-items: flex-start; gap: 19px; min-height: 44px; padding: 13px 0; box-sizing: border-box; text-decoration: none"')
    return h
def carte(h):
    n=[0]
    def f(m):
        n[0]+=1
        return '<section style="display: flex; flex-direction: column; gap: 2px; margin: %s -8px 0; padding: 14px 12px 4px; border-radius: 18px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)">'%('0' if n[0]==1 else '0')
    return SEC.sub(f,h)
def fil(h):
    h=colonne(h)
    # un fil part de l'icône et passe derrière chaque case
    h=SEC.sub(lambda m:'<section style="position: relative; display: flex; flex-direction: column; gap: 2px%s"><span aria-hidden="true" style="position: absolute; left: 19px; top: 46px; bottom: 26px; width: 2px; border-radius: 2px; background: #dccbad"></span>'%(m.group(1) or ''),h)
    h=h.replace('flex-shrink: 0; margin-top: 1px; border: 2px dashed #cdb48a; color: #8a2f27"','flex-shrink: 0; margin-top: 1px; border: 2px dashed #cdb48a; color: #8a2f27; background: #f7f2e9"')
    h=re.sub(r'(<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px;)',r'\1 position: relative; z-index: 1;',h)
    return h
# le fil est retenu (Julien, 20 novembre 2026) ; les deux colonnes seules et la carte sont écartées
srcd=open(PJ+'ListeGoutsParagrapheDeplie.dc.html',encoding='utf-8').read()
P={'ListeGroupeFil':(fil(src),'Grouper par personne (retenu) : deux colonnes, un fil, et le paragraphe des goûts avec « Voir plus »'),
   'ListeGroupeFilDeplie':(fil(srcd),'Le paragraphe des goûts, déroulé sur place par « Voir plus »')}
names=json.load(open('/tmp/names.json'))
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P))
