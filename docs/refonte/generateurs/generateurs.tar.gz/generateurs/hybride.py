import pathlib, json, re, shutil
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
O = pathlib.Path('/home/claude/gen/orig')
eb = (O/'Envoi.dc.html').read_text()
i = eb.index('<div role="radiogroup"'); seg = eb[i:eb.index('</div>', i) + 6]
page = (P/'AnnulerTirage.dc.html').read_text()
mi = page.index('<main'); k = page.rindex('</div>', 0, page.index('</x-dc>'))
A = 'min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 600; color: #57534e; text-decoration: none'
NAV = f'<nav aria-label="Tu es ici" style="margin: -14px 0 -12px; display: flex; align-items: center; gap: 6px; color: #57534e"><a href="#" style="{A}">Famille Camille</a><span aria-hidden="true">·</span><a href="#" style="{A}">Noël 2026</a></nav>'
H1 = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1"
LBL = 'margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
def bubble(first, word=''):
    w = f'\n        <p style="margin: 0">{word}</p>' if word else ''
    return f'''<div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.45">
        <p style="margin: 0">{first}</p>
        <p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/p/aIFR…</p>{w}
      </div>'''
def screen(name, title, who, apercu, word, lang=True, h=900):
    count = f'{len(word)} / 500' if word else '0 / 500'
    langrow = f'''
    <ul style="{LIST}">
        <li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #292524"><span style="flex-grow: 1; font-weight: 600; font-size: 16px">Langue du message</span><span style="font-size: 15px; color: #57534e">Français</span>{CHEV}</a></li>
    </ul>''' if lang else f'''
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: #57534e">Chacun reçoit le message dans sa langue. Ton mot part tel quel.</p>'''
    main = f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 24px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      {NAV}
      <h1 style="{H1}">Personnaliser le message</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">{who}</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="{LBL}">Quel message</h2>
      {seg}
    </div>
    <div style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="{LBL}">{apercu}</h2>
      {bubble('Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :', word)}
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="mot" style="{LBL}">Un mot en plus <span style="font-weight: 600; text-transform: none; letter-spacing: 0">(facultatif)</span></label>
      <textarea id="mot" rows="3" placeholder="Par exemple : on ouvre les cadeaux après le dessert !" style="width: 100%; min-height: 96px; box-sizing: border-box; padding: 12px; border: {'2px solid #b8483a' if word else '1px solid #a8a29e'}; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45; resize: none">{word}</textarea>
      <p style="margin: 0; padding: 0 4px; display: flex; justify-content: space-between; font-size: 13px; color: #57534e"><span>Ajouté sous le message.</span><span>{count}</span></p>
    </div>{langrow}
  </main>
  <footer style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 14px 16px 20px">
    <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
  </footer>
'''
    save(name, page[:mi] + main + page[k:], title, h)
WORD = 'On ouvre les cadeaux après le dessert, pensez à venir avec un petit quelque chose à partager !'
screen('PersonnaliserMessage.dc.html', 'Personnaliser le message — pour une personne', 'Pour Inès', 'Ce qu’elle recevra', '')
screen('PersonnaliserMessageMot.dc.html', 'Personnaliser le message — avec un mot', 'Pour Inès', 'Ce qu’elle recevra', WORD, h=980)
screen('PersonnaliserMessagePlusieurs.dc.html', 'Personnaliser le message — pour plusieurs personnes', 'Pour les 3 personnes sélectionnées', 'Aperçu, pour Inès', '', lang=False, h=860)

cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
for f in ['EnvoiPersonnaliser.dc.html', 'EnvoiMotOuvert.dc.html', 'EnvoiMotAjoute.dc.html']:
    if f in B: del B[f]; cv['order'].remove(f)
row = ['SelectionEmail', 'Envoi', 'PersonnaliserMessage', 'PersonnaliserMessageMot', 'PersonnaliserMessagePlusieurs', 'EnvoiSansEmail', 'EnvoiAjouterEmail', 'Renvoi', 'RenvoiPepin', 'EtatConfirmation']
titles = {'PersonnaliserMessage': 'Personnaliser le message', 'PersonnaliserMessageMot': 'Personnaliser, avec un mot', 'PersonnaliserMessagePlusieurs': 'Personnaliser, pour plusieurs'}
for x, n in enumerate(row):
    f = n + '.dc.html'
    if f not in B:
        B[f] = {'x': 0, 'y': 3660, 'w': 390, 'h': OUT[f], 'title': titles[n], 'page': 'edition'}; cv['order'].insert(cv['order'].index('Envoi.dc.html') + 1 + list(titles).index(n), f)
    B[f]['x'] = 470 * x
    if f in OUT: B[f]['h'] = OUT[f]
cv['notes']['t10']['maxW'] = 470 * len(row) - 80
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)
