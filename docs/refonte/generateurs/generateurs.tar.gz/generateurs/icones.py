# Pistes pour la forme des icônes de personne et de liste, en Sorbet (19 novembre 2026). Écrit directement aux couleurs de Sorbet.
import re,json
src=open('/home/claude/s/Pistes.dc.html').read(); a=src.index('<div style="width: 390px'); HEAD=src[:a]; TAIL=src[src.index('</x-dc>'):]
F="'Outfit', system-ui, sans-serif"
C={'corail':('#ffd0c8','#ff8478'),'menthe':('#c6f1e2','#4fcaa3'),'citron':('#ffe9a8','#f4b82e'),'peche':('#ffe2c4','#f2a65a'),'ciel':('#cfe6ff','#6eb0f2'),'lilas':('#e6d6f8','#b993dd')}
BLOB='58% 42% 55% 45% / 48% 56% 44% 52%'
def av(v,e,c,s):
    bg,ring=C[c]; base=f'width: {s}px; height: {s}px; display: flex; align-items: center; justify-content: center; font-size: {round(s*0.46)}px; line-height: 1; flex-shrink: 0'
    st={1:f'border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}',
        2:f'border-radius: 50%; background: {bg}',
        3:f'border-radius: 50%; background: {bg}; box-shadow: 0 {max(2,round(s*0.055))}px 0 {ring}',
        4:f'border-radius: 50%; background: linear-gradient(150deg, #ffffff 0%, {bg} 42%, {ring} 135%)',
        5:f'border-radius: 50%; background: {bg}; box-shadow: 0 0 0 {max(2,round(s*0.05))}px #ffffff, 0 3px 8px rgba(90, 40, 60, 0.22)',
        6:f'border-radius: {BLOB}; background: {bg}',
        7:f'border-radius: 50%; background: linear-gradient(150deg, #ffffff 0%, {bg} 42%, {ring} 135%); box-shadow: 0 0 0 {max(2,round(s*0.05))}px #ffffff, 0 3px 8px rgba(90, 40, 60, 0.22)'}[v]
    return f'<span aria-hidden="true" style="{base}; {st}">{e}</span>'
def tile(v,e,c,s):
    bg,ring=C[c]; base=f'width: {s}px; height: {s}px; display: flex; align-items: center; justify-content: center; font-size: {round(s*0.5)}px; line-height: 1; flex-shrink: 0'
    st={1:f'border-radius: {round(s*0.25)}px; background: {ring}; box-shadow: 0 2px 6px rgba(90, 40, 60, 0.18)',
        2:f'border-radius: {round(s*0.3)}px; background: {bg}',
        3:f'border-radius: {round(s*0.3)}px; background: {bg}; box-shadow: 0 {max(2,round(s*0.055))}px 0 {ring}',
        4:f'border-radius: {round(s*0.3)}px; background: linear-gradient(150deg, {bg} 0%, {ring} 110%)',
        5:f'border-radius: {round(s*0.28)}px; background: {ring}; box-shadow: 0 0 0 {max(2,round(s*0.05))}px #ffffff, 0 3px 8px rgba(90, 40, 60, 0.22); transform: rotate(-4deg)',
        6:f'border-radius: {BLOB}; background: {ring}',
        7:f'border-radius: {round(s*0.3)}px; background: linear-gradient(150deg, {bg} 0%, {ring} 110%); box-shadow: 0 0 0 {max(2,round(s*0.05))}px #ffffff, 0 3px 8px rgba(90, 40, 60, 0.22); transform: rotate(-3deg)'}[v]
    return f'<span aria-hidden="true" style="{base}; {st}">{e}</span>'
def stack(v):
    o=''
    for i,(e,c) in enumerate([('🧶','corail'),('🎸','menthe'),('🦌','peche')]):
        o+=f'<span style="display: flex;{" margin-left: -7px;" if i else ""} border-radius: 50%; box-shadow: 0 0 0 2px #ffffff">{av({5:2,7:4}.get(v,v),e,c,28)}</span>'
    return f'<span style="display: flex; padding-bottom: 3px">{o}</span>'
V=[(1,'Aujourd’hui','Un pastel et un fin bord pour les personnes, une couleur pleine pour les listes.'),
   (2,'À plat','Le pastel seul, sans bord. Le plus sobre.'),
   (3,'La bande dessous','Le pastel, avec la même bande pleine que sous les cartes de Sorbet.'),
   (4,'Le dégradé doux','Une lumière en haut à gauche, la teinte qui se renforce en bas.'),
   (5,'L’autocollant','Un liseré blanc et une ombre, la tuile de liste un peu penchée.'),
   (6,'Le galet','Une forme arrondie irrégulière, à la place du rond et du carré.'),
   (7,'Le mélange : autocollant en dégradé','Le dégradé doux de la piste 4, avec le liseré blanc et l’ombre de la piste 5.')]
def card(v,t,d):
    return f'''<section style="background: #ffffff; border-radius: 28px; box-shadow: 0 3px 0 #ffd9cc, 0 0 0 1.5px #ffd9cc; padding: 20px; display: flex; flex-direction: column; gap: 16px">
      <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">{v}. {t}</h2><p style="margin: 0; font-size: 14px; line-height: 1.4; color: #6b5a7a">{d}</p></div>
      <div style="display: flex; align-items: center; gap: 12px">{av(v,'🚀','ciel',56)}{av(v,'🦄','lilas',56)}{av(v,'🐧','citron',56)}<span style="flex-grow: 1"></span>{tile(v,'❄️','ciel',56)}{tile(v,'🎂','corail',56)}</div>
      <div style="display: flex; align-items: center; gap: 12px; padding-top: 12px; border-top: 1px solid #ffd9cc">{av(v,'🧶','corail',40)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">Mamie</span><span style="font-size: 13px; color: #6b5a7a">Liste de Mamie</span></span>{stack(v)}{tile(v,'🎁','menthe',40)}</div>
    </section>'''
H=1400
html=HEAD+f'''<div style="width: 860px; height: {H}px; box-sizing: border-box; background: #fff6f1; color: #2b1b3d; font-family: 'DM Sans', system-ui, sans-serif; padding: 28px; display: flex; flex-direction: column; gap: 20px">
  <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Icônes de personne et de liste : sept pistes</h1><p style="margin: 0; font-size: 15px; line-height: 1.45; color: #6b5a7a">À gauche les personnes, à droite les listes. Dessous, les mêmes en petit : une ligne, un groupe d’icônes qui se chevauchent, une tuile de 40 px.</p></div>
  <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px">{"".join(card(*x) for x in V)}</div>
</div>
'''+TAIL
html=re.sub(r'<title>[^<]*</title>','<title>Icônes de personne et de liste — six pistes</title>',html)
html=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":860,"height":%d}'%H,html)
open('/home/claude/s/StyleIcones.dc.html','w').write(html)
print(len(html), '$preview' in html)
