import math
P='#2b1b3d'; CO='#ff5c4d'; CO2='#ff8478'; PE='#ffd9cc'; SO='#ffeae1'; MI='#1fb58a'; MI2='#7fe0c1'; YE='#ffc94a'; LI='#b993dd'; W='#ffffff'
ST=f'stroke="{P}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"'
def star(cx,cy,R,r,fill=YE,sw=3):
    pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5; rr=R if i%2==0 else r; pts.append(f'{cx+rr*math.cos(a):.1f},{cy+rr*math.sin(a):.1f}')
    return f'<polygon points="{" ".join(pts)}" fill="{fill}" stroke="{P}" stroke-width="{sw}" stroke-linejoin="round"/>'
def spark(x,y,s,fill=YE): return f'<path d="M{x} {y-s}Q{x} {y} {x+s} {y}Q{x} {y} {x} {y+s}Q{x} {y} {x-s} {y}Q{x} {y} {x} {y-s}Z" fill="{fill}"/>'
def dot(x,y,r,fill): return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}"/>'
def tree(cx=92):
    t=lambda pts:f'<polygon points="{pts}" fill="{MI}" {ST}/>'
    return (f'<rect x="{cx-7}" y="112" width="14" height="18" rx="3" fill="#8a5a6b" {ST}/>'
      +t(f'{cx-46},118 {cx+46},118 {cx},60')+t(f'{cx-37},92 {cx+37},92 {cx},40')+t(f'{cx-27},66 {cx+27},66 {cx},24')
      +f'<path d="M{cx-30} 104q14 8 30 4" fill="none" stroke="{MI2}" stroke-width="4" stroke-linecap="round"/><path d="M{cx-18} 80q10 6 22 2" fill="none" stroke="{MI2}" stroke-width="4" stroke-linecap="round"/>'
      +f'<circle cx="{cx+18}" cy="106" r="5.5" fill="{CO}" stroke="{P}" stroke-width="2.5"/><circle cx="{cx+12}" cy="80" r="4.5" fill="{YE}" stroke="{P}" stroke-width="2.5"/><circle cx="{cx-8}" cy="56" r="4" fill="{W}" stroke="{P}" stroke-width="2.5"/>'
      +star(cx,17,12,5.2))
def gift(x,y,w,h,body,rib,lid=None):
    lid=lid or body
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="5" fill="{body}" {ST}/>'
      +f'<rect x="{x+w/2-4.5}" y="{y}" width="9" height="{h}" fill="{rib}" stroke="{P}" stroke-width="2.5"/>'
      +f'<rect x="{x-3}" y="{y-9}" width="{w+6}" height="12" rx="4" fill="{lid}" {ST}/>'
      +f'<rect x="{x+w/2-4.5}" y="{y-9}" width="9" height="12" fill="{rib}" stroke="{P}" stroke-width="2.5"/>'
      +f'<ellipse cx="{x+w/2-8}" cy="{y-13}" rx="8" ry="5.5" fill="{rib}" stroke="{P}" stroke-width="2.5" transform="rotate(-20 {x+w/2-8} {y-13})"/><ellipse cx="{x+w/2+8}" cy="{y-13}" rx="8" ry="5.5" fill="{rib}" stroke="{P}" stroke-width="2.5" transform="rotate(20 {x+w/2+8} {y-13})"/><circle cx="{x+w/2}" cy="{y-11}" r="4" fill="{rib}" stroke="{P}" stroke-width="2.5"/>')
def wrap(inner,label=None,w=220,h=150):
    a=f'role="img" aria-label="{label}"' if label else 'aria-hidden="true"'
    return f'<svg {a} width="{w}" height="{h}" viewBox="0 0 220 150" fill="none">{inner}</svg>'
BG=f'<circle cx="110" cy="74" r="64" fill="{SO}"/><ellipse cx="110" cy="130" rx="98" ry="13" fill="{PE}"/>'
ILL={}
ILL['connexion']=wrap(BG+spark(182,40,9)+spark(30,48,7)+dot(196,74,4,MI)+dot(22,86,3.5,CO)+dot(168,22,3,LI)
  +tree(96)+gift(138,98,40,30,CO,YE,CO2)+gift(24,106,30,22,LI,MI,'#cdb0e8'),'Un sapin, des cadeaux dessous',240,164)
ILL['vide']=wrap(BG+spark(180,44,8)+spark(34,52,6,PE)+dot(194,82,3.5,MI)
  +tree(92)+f'<rect x="140" y="94" width="40" height="34" rx="7" fill="{W}" stroke="#f5b8a5" stroke-width="3" stroke-dasharray="6 7" stroke-linecap="round"/><path d="M160 104v14M153 111h14" stroke="#f5b8a5" stroke-width="3" stroke-linecap="round"/>',None,200,136)
env=(f'<g transform="rotate(-6 110 82)"><rect x="48" y="44" width="124" height="80" rx="11" fill="{W}" {ST}/>'
  +f'<path d="M52 120 100 86M168 120l-48-34" stroke="#f5b8a5" stroke-width="3" stroke-linecap="round"/>'
  +f'<path d="M48 55c0-6 5-11 11-11h102c6 0 11 5 11 11v1l-54 38c-5 3.500-11 3.500-16 0L48 56z" fill="{CO}" {ST}/>'
  +f'<circle cx="110" cy="93" r="14" fill="{YE}" {ST}/>'+star(110,93,7.5,3.3,W,2)+'</g>')
ILL['enveloppe']=wrap(BG+spark(186,38,10)+spark(30,44,7)+spark(196,104,5,CO2)+dot(26,96,4,MI)+dot(160,18,3.5,LI)
  +f'<rect x="20" y="64" width="12" height="5" rx="2.500" fill="{CO}" transform="rotate(30 26 66)"/><rect x="188" y="62" width="12" height="5" rx="2.500" fill="{MI}" transform="rotate(-25 194 64)"/>'+env,None,220,150)
if __name__=='__main__':
    for k,v in ILL.items(): open(f'ill/{k}.svg','w').write(v.replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" '))
