import re,os,shutil,json
PJ='/home/claude/utt/project/'; out='/mnt/user-data/outputs/incit'; os.makedirs(out,exist_ok=True)
R=lambda f: open(PJ+f+'.dc.html').read()
made={}
def one(s,a,b):
    assert s.count(a)==1,(s.count(a),a[:60]); return s.replace(a,b)
def title(s,t): return re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',s)
def rootH(s,old,new): return one(s,f'width: 390px; height: {old}px',f'width: 390px; height: {new}px')
LOUPE='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500M9 9.500a2.500 2.500 0 0 1 4.200 1.800c0 1.200-1.700 1.700-1.700 2.700M11.500 16h.010"/></svg>'
PASSE='<a href="DevinePasse.dc.html" style="align-self: center; min-height: 36px; display: flex; align-items: center; font-size: 14px; font-weight: 600; color: #57534e">Je passe mon tour</a>'
# 1 après la découverte
s=R('TirageResultat'); m=s.index('<main'); i=s.index('<section',m); j=s.index('</section>',i)+10
card=f'''

    <section style="background: #fffdf9; border-radius: 16px; box-shadow: 0 0 0 2px #b8483a; padding: 16px; display: flex; flex-direction: column; gap: 12px">
      <div style="display: flex; align-items: center; gap: 12px">
        <span aria-hidden="true" style="width: 44px; height: 44px; border-radius: 50%; background: #b8483a; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{LOUPE}</span>
        <div style="display: flex; flex-direction: column; gap: 2px">
          <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 20px; line-height: 1.2">Et toi, qui t’offre ton cadeau ?</h2>
          <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">4 sur 6 ont déjà fait leur pronostic. Réponse à la fête.</p>
        </div>
      </div>
      <a href="DevineUniquePrix.dc.html" style="height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Faire mon pronostic</a>
      {PASSE}
    </section>'''
made['DevineInviteResultat']=(title(rootH(s[:j]+card+s[j:],1426,1640),'Devine qui — proposé après la découverte'),1640,'Juste après avoir découvert à qui j’offre')
# 2 tuile
s=R('DevineTirage')
s=one(s,'<span style="font-size: 14px; font-weight: 700; color: #8a2f27">Fais ton pronostic</span>','<span style="font-size: 14px; font-weight: 700; color: #8a2f27">Fais ton pronostic</span><span style="font-size: 13px; line-height: 1.3; color: #57534e">4 sur 6 ont joué<br>Plus que 3 jours</span>')
made['DevineTirageFin']=(title(rootH(s,1006,1040),'Devine qui — la tuile, avec le compte et l’échéance'),1040,'La tuile : combien ont joué, combien de temps reste')
# 3 accueil
s=R('DevineAccueil')
s=one(s,'Un pronostic, jusqu’au 25 décembre à 18 h. Réponse à la fête.','4 sur 6 ont déjà joué. Plus que 3 jours : réponse à la fête.')
s=one(s,'justify-content: center; gap: 8px; width: 100%">Faire mon pronostic</a>','justify-content: center; gap: 8px; width: 100%">Faire mon pronostic</a>\n      '+PASSE)
made['DevineAccueilFin']=(title(s,'Devine qui — la carte de l’accueil, avec le compte'),880,'La carte de l’accueil : le compte, l’échéance, « Je passe mon tour »')
# 4 page du jeu, les prix
chip=lambda t:f'<span style="height: 30px; padding: 0 12px; border-radius: 999px; background: #f1e8d8; box-shadow: 0 0 0 1px #dccbad; font-size: 13px; font-weight: 600; display: flex; align-items: center">{t}</span>'
teaser=f'''<section style="display: flex; flex-direction: column; gap: 10px; padding: 14px 16px; border-radius: 16px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)">
      <h2 style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">À gagner à la fête</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 6px">{chip("Démasqués")}{chip("Le suspect idéal")}{chip("Sur le fil")}{chip("La girouette")}{chip("et d’autres…")}</div>
      <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e"><strong style="font-weight: 700; color: #292524">L’an dernier : 3 démasqués sur 6.</strong> À battre.</p>
    </section>
    '''
s=R('DevineUnique')
s=one(s,'<div style="display: flex; flex-direction: column; gap: 12px">\n      <a href="DevineChoisir.dc.html"',teaser+'<div style="display: flex; flex-direction: column; gap: 12px">\n      <a href="DevineChoisir.dc.html"')
s=one(s,'<p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Personne ne voit ton pronostic avant la fête.</p>','<p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Personne ne voit ton pronostic avant la fête.</p>\n      '+PASSE)
made['DevineUniquePrix']=(title(rootH(s,844,960),'Devine qui — la page du jeu, avec les prix à gagner'),960,'La page du jeu : les prix à gagner, le défi de l’an dernier')
# 5 dans la course
s=R('DevinePaires'); a=s.index('<section',s.index('<main'))
course='''<div style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 16px; border-radius: 12px; background: #dbe9dd; color: #1f3d29">
      <span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #274e34; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg></span>
      <p style="margin: 0; font-size: 15px; line-height: 1.45"><strong style="font-weight: 700">Tu es dans la course</strong> pour Démasqués et Le détective. Encore un pronostic pour viser Le sans-faute.</p>
    </div>
    '''
made['DevinePairesCourse']=(title(rootH(s[:a]+course+s[a:],900,1010),'Devine qui — dans la course pour'),1010,'Après avoir joué : « Tu es dans la course pour… »')
# 6 je passe mon tour
s=R('DevineUnique')
a=s.index('<div style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 22px; text-align: center">'); b=s.index('</main>')
s=s[:a]+'''<div style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 18px; text-align: center">
      <span aria-hidden="true" style="width: 112px; height: 112px; border-radius: 50%; background: #f1e8d8; color: #78716c; display: flex; align-items: center; justify-content: center"><svg aria-hidden="true" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.800" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4l10 8-10 8z"/><path d="M19 5v14"/></svg></span>
      <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.15">Tu passes ton tour</p>
      <p style="margin: 0; max-width: 300px; font-size: 16px; line-height: 1.45; color: #57534e">On ne te rappellera pas le jeu. Tu verras quand même le palmarès à la fête.</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 12px">
      <a href="DevineUniquePrix.dc.html" style="height: 52px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement, je joue</a>
      <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Possible jusqu’au 25 décembre à 18 h.</p>
    </div>
  '''+s[b:]
s=one(s,'Un seul pronostic, que tu peux changer jusqu’au 25 décembre à 18 h.','Un jeu de pronostics : qui t’offre ton cadeau ?')
made['DevinePasse']=(title(s,'Devine qui — je passe mon tour'),844,'« Je passe mon tour »')
# 7 emails
E=R('PistesEmail'); ea=E.index('<div style="width: 390px'); eh=E[:ea]; et=E[E.index('</x-dc>'):]
def email(subject,to,paras):
    ps=''.join(f'\n    <p style="margin: 0">{p}</p>' for p in paras)
    return eh+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #ffffff; color: #1c1917; font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; display: flex; flex-direction: column">
  <div style="padding: 16px; border-bottom: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 4px">
    <h1 style="margin: 0; font-size: 18px; font-weight: 700; line-height: 1.3">{subject}</h1>
    <p style="margin: 0; font-size: 13px; color: #57534e">Under the Tree · à {to}</p>
  </div>
  <div style="padding: 16px; display: flex; flex-direction: column; gap: 14px; font-size: 16px; line-height: 1.5">{ps}
    <p style="margin: 0">Under the Tree</p>
  </div>
</div>
'''+et
L=lambda t:f'<a href="#" style="color: #1d4ed8; text-decoration: underline">{t}</a>'
made['DevineEmailRappelAuto']=(title(email('Plus que 2 jours pour deviner qui t’offre ton cadeau','rose-demo@example.com',['Bonjour Rose,','Pour Noël 2026 (Famille Camille), 4 personnes sur 6 ont déjà fait leur pronostic. Et toi, qui t’offre ton cadeau ?','Tu as jusqu’au 25 décembre à 18 h. Réponse à la fête, avec le palmarès.',L('Faire mon pronostic'),'Pas envie de jouer ? '+L('Je passe mon tour')+', et on ne te le rappellera plus.','C’est le seul rappel automatique que tu recevras.']),'Email — rappel automatique, jamais joué'),844,'Email automatique, 2 jours avant : jamais joué')
made['DevineEmailRappelEncore']=(title(email('Encore quelques pronostics avant la fin ?','hugo-demo@example.com',['Bonjour Hugo,','Tu as deviné ton Père Noël : tu es dans la course pour Noël 2026 (Famille Camille).','Il te reste 2 jours pour pronostiquer aussi pour les autres, et viser le détective.',L('Continuer mes pronostics'),'C’est le seul rappel automatique que tu recevras.']),'Email — rappel automatique, un seul pronostic'),844,'Email automatique, 2 jours avant : un seul pronostic')
made['DevineEmailOrgaPoint']=(title(email('Devine qui : 2 personnes n’ont pas encore joué','camille-demo@example.com',['Bonjour Camille,','Pour Noël 2026 (Famille Camille), 3 personnes sur 5 ont fait un pronostic. Rose et Louis n’ont pas encore joué ; Louis n’a pas d’adresse email.','Les pronostics ferment le 25 décembre à 18 h, dans 5 jours. Un rappel automatique partira dans 3 jours à ceux qui ont une adresse.',L('Leur rappeler maintenant'),'Tu peux couper ces emails dans les réglages du jeu.']),'Email à l’organisateur — point d’étape'),844,'Email à l’organisateur, 5 jours avant la fin')
made['DevineEmailOrgaFin']=(title(email('Devine qui : les pronostics sont fermés','camille-demo@example.com',['Bonjour Camille,','Pour Noël 2026 (Famille Camille), 4 personnes sur 5 ont joué. Le palmarès est prêt : il se lance dès que tu dévoiles le tirage.',L('Dévoiler le tirage'),'Si tu ne le fais pas, il sera dévoilé tout seul demain à 18 h.','Tu peux couper ces emails dans les réglages du jeu.']),'Email à l’organisateur — pronostics fermés'),844,'Email à l’organisateur, à la fermeture')
# 8 suivi : la relance suggérée
s=R('DevineSuivi')
s=one(s,'3 sur 5 ont fait un pronostic. Fin le 25 décembre à 18 h.','<strong style="font-weight: 700; color: #292524">2 personnes n’ont pas encore joué.</strong> Fin dans 5 jours.')
s=one(s,'<a href="DevineRappel.dc.html" style="align-self: flex-start; min-height: 36px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27">Envoyer un rappel</a>','<a href="DevineRappel.dc.html" style="align-self: flex-start; margin-top: 6px; height: 40px; padding: 0 16px; border-radius: 6px; background: #b8483a; color: #ffffff; text-decoration: none; display: flex; align-items: center; font-size: 15px; font-weight: 700">Leur rappeler</a>')
i=s.index('Le jeu de cette édition'); a=s.rfind('<section style="background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05);',0,i)
s=s[:a]+s[a:].replace('box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05);','box-shadow: 0 0 0 2px #b8483a;',1)
made['DevineSuiviRelance']=(title(s,'Suivi — la relance suggérée'),1400,'Sur le suivi, 5 jours avant la fin : la relance suggérée')
# 9 rappel : deux moyens
s=R('DevineRappel')
s=one(s,'<p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Louis n’a pas d’adresse : partage-lui son lien avec le bouton de sa ligne.</p>','<a href="DevineRappelGroupe.dc.html" style="height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; text-decoration: none; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px"><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.800 7L4 20l1-4.500A8 8 0 1 1 21 12z"/></svg>Écrire au groupe</a>\n      <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Dernier rappel : aucun. Louis n’a pas d’adresse : partage-lui son lien avec le bouton de sa ligne.</p>')
s=one(s,'height: 130px; flex-shrink: 0','height: 80px; flex-shrink: 0')
made['DevineRappel']=(s,844,None)
# 10 message au groupe
s=R('DevineRappel')
a=s.index('<div style="display: flex; flex-direction: column; gap: 8px">\n      <h2',s.index('aria-label="Rappeler le jeu"')); b=s.index('<div style="display: flex; flex-direction: column; gap: 8px">\n      <h2',a+10)
s=s[:a]+s[b:]
s=one(s,'Salut Rose ! 🔍 Devine qui t’offre ton cadeau cette année : tu as jusqu’au 25 décembre à 18 h pour faire ton pronostic. Réponse à la fête !','Plus que 5 jours pour jouer à Devine qui ! 🔍 3 sur 5 ont déjà fait leur pronostic. Qui offre à qui ? Réponse à la fête, avec le palmarès.')
s=one(s,'<p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/p/aIFR…</p>','<p style="margin: 0; color: #57534e">Chacun retrouve le jeu avec son lien personnel.</p>')
a=s.index('<div style="margin-top: auto'); b=s.index('</section>',a)
s=s[:a]+'''<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Partager</button>
      <button style="width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600">Copier le message</button>
      <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Pour WhatsApp, SMS… Le message ne nomme personne et ne contient aucun lien personnel.</p>
    </div>
  '''+s[b:]
s=one(s,'>Rappeler le jeu</h1>','>Écrire au groupe</h1>'); s=one(s,'2 personnes n’ont pas encore fait de pronostic','Un message pour tout le monde')
s=one(s,'height: 130px; flex-shrink: 0','height: 330px; flex-shrink: 0')
made['DevineRappelGroupe']=(title(s,'Devine qui — écrire au groupe'),844,'Le message pour le groupe')
# 11 réglage
s=R('DevineReglage')
tog=lambda t,sub:f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 14px; box-sizing: border-box; border-top: 1px solid #e9dcc5"><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{t}</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span></span><span role="switch" aria-checked="true" style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 23px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff"></span></span></label>'''
blk='<div style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; margin-top: 0">'+tog('Rappel automatique','2 jours avant la fin, à ceux qui n’ont pas joué').replace(' border-top: 1px solid #e9dcc5','')+tog('Me tenir au courant','Un email 5 jours avant la fin, un à la fermeture')+'</div>\n    '
s=one(s,'<div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">\n      <button style="width: 100%; height: 52px;',blk+'<div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">\n      <button style="width: 100%; height: 52px;')
made['DevineReglage']=(rootH(s,844,1000),1000,None)
# 12 suivi rappel fait
s=R('DevineSuiviRappelFait')
s=one(s,'<p style="margin: 0; min-height: 36px; display: flex; align-items: center; font-size: 14px; color: #57534e">Rappel envoyé le 20 décembre</p>','<p style="margin: 0; min-height: 36px; display: flex; align-items: center; flex-wrap: wrap; gap: 4px 8px; font-size: 14px; color: #57534e">Dernier rappel le 20 décembre <a href="DevineRappel.dc.html" style="font-weight: 700; color: #8a2f27">Rappeler encore</a></p>')
made['DevineSuiviRappelFait']=(s,1360,None)
for k,(h,_,_) in made.items():
    open(PJ+k+'.dc.html','w').write(h); shutil.copy(PJ+k+'.dc.html',f'{out}/{k}.html')
print(json.dumps([{"as":f"project/{k}.dc.html","path":f"{PJ}{k}.dc.html"} for k in made]))
print(json.dumps([{"stagedPath":f"{out}/{k}.html","devicePath":f"/Users/julien.rabin/Workspace/personnal/secret-santa/docs/refonte/maquettes/{k}.html"} for k in made]))
print([(k,v[1],v[2]) for k,v in made.items()])
