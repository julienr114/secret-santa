# Retrait des idées sous une personne : 20px -> 6px (Julien, 20 novembre 2026). À lancer après personne3.py.
import glob,json
PJ='/home/claude/utt/project/'
R=[('padding: 0 0 0 20px','padding: 0 0 0 6px'),('margin: 0 -16px 0 -36px','margin: 0 -16px 0 -22px'),('padding: 0 16px 10px 36px','padding: 0 16px 10px 22px'),('padding: 0 16px 0 36px','padding: 0 16px 0 22px')]
n=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read(); t=s
    for a,b in R: t=t.replace(a,b)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n)); json.dump(n,open('/tmp/indent.json','w'))
