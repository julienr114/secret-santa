import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
IC = dict(
 star='<path d="M12 2l2.200 7.800L22 12l-7.800 2.200L12 22l-2.200-7.800L2 12l7.800-2.200z"/>',
 plus='<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M12 13v5M9.500 15.500h5"/>',
 mail='<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
 open='<path d="M3 10v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-9l-9-6z"/><path d="m3 10 9 6 9-6"/>',
 rules=I['gear'], link=I['link'], eye='<path d="M2.500 12S6 5 12 5s9.500 7 9.500 7-3.500 7-9.500 7-9.500-7-9.500-7z"/><circle cx="12" cy="12" r="3"/>',
 list='<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>', key='<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M14 9l2 2"/>',
)
def knot(icon, kind='plain'):
    if kind == 'mile': st, size, s = 'background: #b8483a; color: #ffffff;', 40, 20
    elif kind == 'alert': st, size, s = 'background: #e6b94a; color: #3a240c;', 40, 20
    else: st, size, s = 'background: #fffdf9; color: #57534e;', 32, 16
    return f'<span aria-hidden="true" style="width: 40px; display: flex; justify-content: center; flex-shrink: 0"><span style="width: {size}px; height: {size}px; border-radius: 50%; {st} box-shadow: 0 0 0 4px #f7f2e9, 0 2px 6px 3px rgba(60, 30, 10, 0.06); display: flex; align-items: center; justify-content: center">{ic(IC[icon], s)}</span></span>'
def line(icon, text, time, extra='', hl=False):
    bg = ' background: #fbf3f1; border-radius: 10px; padding: 6px 8px; margin: -6px -8px;' if hl else ''
    return f'''<li style="display: flex; align-items: flex-start; gap: 12px">{knot(icon)}<div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; padding-top: 5px;{bg}"><div style="display: flex; align-items: baseline; gap: 12px"><p style="margin: 0; flex-grow: 1; font-size: 15px; line-height: 1.35">{text}</p><time style="flex-shrink: 0; font-size: 12px; color: #57534e">{time}</time></div>{extra}</div></li>'''
def card(icon, text, time, alert=False, more=''):
    st = 'background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762;' if alert else 'background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05);'
    col = '#3a240c' if alert else '#292524'
    return f'''<li style="display: flex; align-items: flex-start; gap: 12px">{knot(icon, 'alert' if alert else 'mile')}<div style="flex-grow: 1; min-width: 0; border-radius: 16px; {st} padding: 12px 16px; display: flex; flex-direction: column; gap: 4px"><p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 17px; line-height: 1.3; color: {col}">{text}</p><time style="font-size: 12px; color: #57534e">{time}</time>{more}</div></li>'''
def day(label, items):
    return f'''<section style="position: relative; display: flex; flex-direction: column; gap: 16px">
        <h2 style="margin: 0; display: flex; align-items: center; font-family: inherit"><span aria-hidden="true" style="width: 40px; display: flex; justify-content: center; flex-shrink: 0"><span style="width: 10px; height: 10px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 4px #f7f2e9"></span></span><span style="padding-left: 12px; font-size: 12px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: #57534e">{label}</span></h2>
        <ol style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 18px">{items}</ol>
      </section>'''
def timeline(days):
    return f'''<div style="position: relative; display: flex; flex-direction: column; gap: 28px">
      <span aria-hidden="true" style="position: absolute; top: 10px; bottom: 0; left: 19px; width: 2px; border-radius: 999px; background: #e0b4ab"></span>
      {days}
    </div>'''
def stackn(names):
    return '<span aria-hidden="true" style="display: flex">' + ''.join(pav(n, size=26, fs=12, extra=(' box-shadow: 0 0 0 2px #f7f2e9;' + ('' if i == 0 else ' margin-left: -8px;'))) for i, n in enumerate(names)) + '</span>'
MORE = lambda label: f'<button aria-expanded="false" style="align-self: flex-start; min-height: 44px; margin: -8px 0; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px">{label}{ic("<path d=\'m6 9 6 6 6-6\'/>", 14, 2.4)}</button>'
CHIP = lambda label, on=False: f'<button style="min-height: 44px; padding: 0 14px; box-sizing: border-box; border: 1px solid {"#b8483a" if on else "#dccbad"}; border-radius: 999px; background: {"#fbf3f1" if on else "#fffdf9"}; color: {"#8a2f27" if on else "#292524"}; font-family: inherit; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px; flex-shrink: 0">{label}{ic("<path d=\'m6 9 6 6 6-6\'/>", 14, 2.4)}</button>'
def controls(seg_on, person, pon=False):
    return f'''{seg(['L’essentiel', 'Tout'], seg_on)}
    <div style="display: flex; gap: 8px; flex-wrap: wrap">{CHIP('Noël 2026')}{CHIP(person, pon)}</div>'''
INTRO = '<p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Tout le groupe voit ce journal. Il ne dit jamais qui offre à qui. <a href="#aide" style="font-weight: 700; color: #8a2f27">À quoi sert-il ?</a></p>'
WHY = '<a href="JournalDetail.dc.html" style="align-self: flex-start; min-height: 32px; display: flex; align-items: center; font-size: 13px; font-weight: 700; color: #66431d">Qu’est-ce que ça veut dire ?</a>'

# J1 l'essentiel
build('Journal.dc.html', 'Journal — l\'essentiel', f'''<main style="{MAIN}">
    {head('Journal du groupe', 'Famille Camille')}
    {INTRO}
    {controls(0, 'Tout le monde')}
    {timeline(
      day('Dimanche 15 novembre', card('eye', 'L’organisateur a consulté le résultat de Hugo (accès de dernier recours)', '14:02', True, WHY) + line('rules', 'L’organisateur a modifié les règles du tirage', '13:56'))
      + day('Samedi 14 novembre', line('open', '<strong>5 personnes</strong> ont découvert leur résultat', '21:40 – 23:50', stackn(['Camille', 'Hugo', 'Inès', 'Louis', 'Rose']) + MORE('Voir le détail')) + line('mail', 'L’organisateur a envoyé « Tirage fait » à <strong>5 personnes</strong> par email', '21:30', MORE('Voir le détail')) + card('star', 'Le tirage a été effectué pour 5 participants', '21:26') + card('plus', 'L’édition Noël 2026 a été créée', '21:20'))
    )}
    <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">L’essentiel regroupe les envois et laisse de côté les changements d’icône et de langue. « Tout » montre chaque événement.</p>
  </main>''', 1230)

# J2 ce qui me concerne (participant)
build('JournalPersonne.dc.html', 'Journal — filtré sur une personne', f'''<main style="{MAIN}">
    {head('Journal du groupe', 'Famille Camille')}
    {controls(1, 'Moi (Hugo)', True)}
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #274e34">{ic(I['check'], 18, 2.6)}</span>
      <span>Tout ce qui touche ton lien, ton résultat et ta liste. Si une ligne ne vient pas de toi, préviens ton organisateur.</span>
    </div>
    {timeline(
      day('Dimanche 15 novembre', card('eye', 'L’organisateur a consulté ton résultat (accès de dernier recours)', '14:02', True, WHY))
      + day('Samedi 14 novembre', line('link', 'L’organisateur a copié ton lien', '23:14') + line('list', 'Tu as mis à jour ta liste de souhaits (3 idées)', '22:05') + line('open', 'Tu as découvert ton résultat', '21:52') + line('mail', 'L’organisateur t’a envoyé « Tirage fait » par email', '21:30'))
    )}
  </main>''', 1010)

# J3 détail
tpl = (P/'ConfirmerTirage.dc.html').read_text()
a = tpl.index('<section aria-label="Lancer le tirage"'); b = tpl.index('</section>', a) + len('</section>')
sec = f'''<section aria-label="Accès de dernier recours" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 16px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px">
      <span aria-hidden="true" style="width: 44px; height: 44px; border-radius: 50%; background: #e6b94a; color: #3a240c; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(IC['eye'], 22)}</span>
      <div style="display: flex; flex-direction: column; gap: 2px"><h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.15">Accès de dernier recours</h1><p style="margin: 0; font-size: 14px; color: #57534e">Dimanche 15 novembre à 14:02</p></div>
    </div>
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 16px; line-height: 1.35; color: #3a240c">L’organisateur a consulté le résultat de Hugo</p>
    <div style="display: flex; flex-direction: column; gap: 10px; font-size: 15px; line-height: 1.5">
      <p style="margin: 0"><strong>Ce qui s’est passé.</strong> L’organisateur a regardé à qui Hugo offre un cadeau. Il n’a vu que ce résultat-là.</p>
      <p style="margin: 0"><strong>Pourquoi c’est permis.</strong> En cas de doute ou de désaccord, il faut pouvoir vérifier. L’organisateur doit recopier une phrase et accepter que tout le groupe le sache.</p>
      <p style="margin: 0"><strong>Ce que ça change pour toi.</strong> Rien : ton résultat et ta liste n’ont pas été vus.</p>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <a href="Journal.dc.html" style="height: 52px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">J’ai compris</a>
    </div>
  </section>'''
t = tpl[:a] + sec + tpl[b:]
for old, new in [('<title>Confirmation du tirage</title>', '<title>Journal — détail d\'un événement</title>'), ('height: 150px', 'height: 230px'), ('font-size: 30px; color: #5c554c">Noël 2026', 'font-size: 30px; color: #5c554c">Journal du groupe')]:
    assert old in t; t = t.replace(old, new)
(P/'JournalDetail.dc.html').write_text(t)
print('ok')
