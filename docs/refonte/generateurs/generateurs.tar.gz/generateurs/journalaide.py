import pathlib
P = pathlib.Path('/home/claude/utt/project')
tpl = (P/'ConfirmerTirage.dc.html').read_text()
def ic(inner, s=18, sw=2):
    return f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{inner}</svg>'
def block(icon, bg, fg, title, items):
    lis = ''.join(f'<li>{x}</li>' for x in items)
    return f'''<div style="display: flex; align-items: flex-start; gap: 12px">
      <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(icon)}</span>
      <div style="display: flex; flex-direction: column; gap: 4px">
        <h2 style="margin: 0; font-family: inherit; font-size: 16px; font-weight: 700">{title}</h2>
        <ul style="margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 3px; font-size: 14px; line-height: 1.45; color: #57534e">{lis}</ul>
      </div>
    </div>'''
a = tpl.index('<section aria-label="Lancer le tirage"'); b = tpl.index('</section>', a) + len('</section>')
sec = f'''<section aria-label="À quoi sert le journal ?" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15">À quoi sert le journal ?</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">À garder le tirage honnête : tout ce qui touche au secret y est noté, à la vue de tout le groupe. Tricher reste possible, mais ça se voit.</p>
    </div>
    {block('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>', '#f6e2dd', '#a43a2f', 'Ce qu’il note', ['Le tirage, son annulation, la clôture', 'Chaque lien envoyé, copié ou régénéré', 'La première fois que chacun découvre son résultat', 'Les listes de souhaits modifiées', 'Tout accès de l’organisateur à un résultat'])}
    {block('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', '#dbe9dd', '#274e34', 'Ce qu’il ne dit jamais', ['Qui offre à qui', 'Ce que contiennent les listes de souhaits'])}
    {block('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.870M16 3.130a4 4 0 0 1 0 7.750"/>', '#f1e8d8', '#57534e', 'Qui le voit', ['Tous les participants du groupe et l’organisateur, avec les mêmes lignes'])}
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #66431d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #79511d">{ic('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.010"/>')}</span>
      <span>Une ligne te concerne et ne vient pas de toi ? Préviens ton organisateur : il peut régénérer ton lien.</span>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column">
      <a href="Journal.dc.html" style="height: 52px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">J’ai compris</a>
    </div>
  </section>'''
t = tpl[:a] + sec + tpl[b:]
for old, new in [('<title>Confirmation du tirage</title>', '<title>Journal — à quoi sert-il</title>'), ('height: 150px', 'height: 70px'), ('font-size: 30px; color: #5c554c">Noël 2026', 'font-size: 30px; color: #5c554c">Journal du groupe'), ('height: 844px', 'height: 900px'), ('"height":844', '"height":900')]:
    assert old in t, old; t = t.replace(old, new)
(P/'JournalAide.dc.html').write_text(t)
# link from the journal intro
for f in ['Journal.dc.html']:
    p = P/f; s = p.read_text(); assert 'href="#aide"' in s; p.write_text(s.replace('href="#aide"', 'href="JournalAide.dc.html"'))
print('ok')
