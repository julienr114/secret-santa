# La page de présentation (landing), pour qui arrive sans session (19 novembre 2026)
import io,contextlib,json,sys
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
sys.path.insert(0,'/home/claude/gen'); import illus,illus2
H=3800
DATA=('Aucune publicité, aucun traceur, aucune revente : l’application ne suit personne.','Ni mot de passe, ni numéro de téléphone.','À chaque écran, tu sais qui verra ce que tu écris.','Tu refuses les emails d’un geste. Tu télécharges ou tu supprimes tes données quand tu veux.')
def shot(n,w=200,h=330,t='0'): return f'@@SHOT:{n}:{w}:{h}:{t}@@'
SUB='margin: 0; font-size: 15px; line-height: 1.45; color: #57534e'
def h2(t): return f'<h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">{t}</h2>'
def over(t): return f'<p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">{t}</p>'
def pts(*xs):
    li=''.join(f'<li style="display: flex; align-items: flex-start; gap: 10px; font-size: 15px; line-height: 1.4"><span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{CHECK}</span><span>{x}</span></li>' for x in xs)
    return f'<ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px">{li}</ul>'
def card(o,t,body,art,extra=''):
    # sur téléphone : pas de capture d'écran, une toute petite icône à côté du titre (Julien, 19 novembre 2026)
    return f'''<section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; align-items: center; gap: 14px">{art}<div style="min-width: 0; display: flex; flex-direction: column; gap: 4px">{over(o)}{h2(t)}</div></div>
      <p style="{SUB}">{body}</p>{extra}
    </section>'''
# un petit bout de liste, pour montrer plutôt que dire
def box(state):
    if state=='free': return '<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; border: 2px solid #a8a29e; background: #fffdf9; flex-shrink: 0; margin-top: 1px"></span>'
    if state=='mine': return f'<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; background: #2f613f; color: #ffffff">{CHECK}</span>'
    return f'<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; background: #a8a29e; color: #ffffff">{CHECK}</span>'
def line(state,t):
    st={'free':'','mine':'font-weight: 600','taken':'color: #78716c; text-decoration: line-through'}[state]
    return f'<li style="display: flex; align-items: flex-start; gap: 12px; font-size: 15px; line-height: 1.45">{box(state)}<span style="{st}">{t}</span></li>'
MINI=f'''<div aria-hidden="true" style="width: 100%; box-sizing: border-box; border-radius: 12px; background: #f7f2e9; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <div style="display: flex; align-items: center; gap: 12px">{tile('🎄','sapin',40)}<span style="display: flex; flex-direction: column"><span style="font-family: {F}; font-weight: 700; font-size: 18px; line-height: 1.2">Noël 2026</span><span style="font-size: 13px; color: #57534e">dans 36 jours</span></span></div>
        <div style="display: flex; align-items: center; gap: 10px">{av('Léo',32)}<span style="font-weight: 700; font-size: 15px">Léo</span><span style="font-size: 13px; color: #57534e">6 ans</span></div>
        <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px">{line('taken','Circuit de billes')}{line('mine','Vélo 16 pouces')}{line('free','Déguisement de pompier')}</ul>
      </div>'''
def row(icon,t,d,top=True):
    return f'''<li style="display: flex; align-items: flex-start; gap: 12px; padding: 14px 16px;{' border-top: 1px solid #e9dcc5;' if top else ''}"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{d}</span></span></li>'''
PHONE=ic('<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',18)
BELL=ic('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0"/>',18)
GLOBE=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',18)
KEY=ic('<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M14 9l2 2"/>',18)
CAL=ic('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',18)
def bubble(t): return f'<p style="margin: 0; align-self: flex-start; max-width: 280px; padding: 10px 14px; border-radius: 16px 16px 16px 4px; background: #fffdf9; font-size: 15px; line-height: 1.4; color: #292524">{t}</p>'
CTA=f'''<div style="display: flex; flex-direction: column; gap: 10px"><a href="ConnexionCreer.dc.html" style="{BTN}">Créer un compte</a><a href="Connexion.dc.html" style="{BTN2}">Se connecter</a></div>'''
main=f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center">
      {illus2.svg('connexion',200,'Under the Tree')}
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.05; color: #a43a2f">Under the Tree</h1>
      <p style="margin: 0; font-family: {F}; font-weight: 600; font-size: 20px; line-height: 1.25">Le Secret Santa de la famille, et les listes de cadeaux qui vont avec.</p>
      <p style="margin: 0; font-size: 16px; line-height: 1.4; color: #57534e">Chacun découvre en secret à qui il offre. Personne ne triche, et personne n’offre deux fois la même chose.</p>
    </div>
    {CTA}
    <a href="#aide" style="display: flex; align-items: flex-start; gap: 12px; padding: 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; text-decoration: none">
      <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{LINK}</span>
      <span style="display: flex; flex-direction: column; gap: 2px; font-size: 14px; line-height: 1.4"><strong style="font-size: 15px">Tu as reçu un lien personnel ?</strong>Ouvre-le directement : il fonctionne sans compte.</span>
    </a>
    <h2 style="{H2}; margin-top: 12px">Ce qu’on y fait</h2>
    {card('Le tirage','Un tirage vraiment secret','Chacun ouvre son enveloppe sur son téléphone. L’organisateur ne voit pas qui offre à qui. S’il regarde un résultat en dernier recours, tout le groupe le sait.',tile('✉️','brique',44),pts('Pas soi-même, pas son conjoint, pas la même personne que les années passées.','Un lien par personne, à envoyer par WhatsApp, SMS ou email.','Un journal que tout le groupe peut lire : la triche se voit.'))}
    {card('Les pistes','Des pistes pour ne pas tomber à côté','Six questions, trente secondes. Chacun dit ce qui lui ferait plaisir et ce qu’il vaut mieux éviter. Son Père Noël les lit en ouvrant son enveloppe.',tile('🏷️','nuit',44))}
    {card('Le jeu','Devine qui','Avant la fête, chacun parie sur qui offre à qui. Le jour venu, le palmarès arrive en images : le détective, le mieux caché, le suspect idéal.',tile('🕵️','prune',44))}
    {card('Les listes','Des listes de cadeaux pour toute la famille','Pour Noël, un anniversaire ou toute l’année. Tu écris les idées de chacun, tu envoies un lien, et la famille coche ce qu’elle offre.',tile('🎁','sapin',44),pts('Personne n’offre deux fois la même chose.','Un cadeau trop gros ? On s’y met à plusieurs.','Une liste se tient à deux, et tout se met à jour en direct.'))}
    {card('Tes données','En clair, et le moins possible','Under the Tree est fait par une seule personne, pour ses familles. Il ne vit pas de tes données.',tile('🔒','kraft',44),pts(*DATA)+f'<a href="Confidentialite.dc.html" style="{A}; font-size: 15px; font-weight: 700">Tes données, en clair</a>')}
    <h2 style="{H2}; margin-top: 12px">Et aussi</h2>
    <ul style="{UL}">{row(PHONE,'Sur ton téléphone, comme une application','Elle s’installe sur l’écran d’accueil, sur iPhone comme sur Android.',False)}{row(BELL,'Prévenu quand il faut','Une notification sur le moment, un résumé par email le matin. Pas un email à chaque geste.')}{row(KEY,'Sans mot de passe','Un lien ou un code reçu par email suffit.')}{row(CAL,'D’une année sur l’autre','Le groupe, les exclusions et les tirages passés sont gardés.')}{row(GLOBE,'En trois langues','Français, anglais, allemand : chacun choisit la sienne.')}</ul>
    <section style="margin-top: 12px; border-radius: 12px; background: #fbf0cf; border: 1px solid #ebc762; padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <span style="align-self: flex-start; height: 24px; padding: 0 10px; border-radius: 999px; background: #e6b94a; color: #3d2c08; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; display: flex; align-items: center">Bientôt</span>
      {h2('Demande-le à ton assistant préféré')}
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #5b430f">Under the Tree se branchera sur l’assistant que tu utilises déjà, grâce à MCP, le standard qui relie les assistants aux applications. Tu lui parles, il s’occupe de la liste.</p>
      <div aria-label="Exemples de demandes" style="display: flex; flex-direction: column; gap: 8px">{bubble('« Ajoute un vélo 16 pouces à la liste de Léo. »')}{bubble('« Qu’est-ce qu’il reste à offrir à Mamie ? »')}</div>
      <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #5b430f">Le tirage, lui, reste secret : aucun assistant ne saura qui offre à qui.</p>
    </section>
    <section style="margin-top: 12px; display: flex; flex-direction: column; gap: 14px; text-align: center">
      <div style="display: flex; flex-direction: column; gap: 6px">{h2('Prêt pour cette année ?')}<p style="{SUB}">Un compte suffit pour tenir une liste. Pour organiser un tirage, tu demandes la création de ton groupe.</p></div>
      {CTA}
    </section>
    <footer style="margin-top: auto; padding-top: 24px; display: flex; justify-content: center; gap: 16px; font-size: 14px; color: #57534e"><span style="font-weight: 700; color: #292524">Français</span><a href="#" style="color: #57534e">English</a><a href="#" style="color: #57534e">Deutsch</a></footer>
    <p style="margin: 0; text-align: center; font-size: 14px"><a href="APropos.dc.html" style="color: #8a2f27; font-weight: 600">Qui a fait ça, et pourquoi ?</a></p>'''
# ---- la version pour un écran large (1280 px) ----
HD=4720
FEAT=[('Le tirage','Un tirage vraiment secret','Chacun ouvre son enveloppe sur son téléphone. L’organisateur ne voit pas qui offre à qui. S’il regarde un résultat en dernier recours, tout le groupe le sait.','TirageDecouvrir',('Pas soi-même, pas son conjoint, pas la même personne que les années passées.','Un lien par personne, à envoyer par WhatsApp, SMS ou email.','Un journal que tout le groupe peut lire : la triche se voit.')),
 ('Les pistes','Des pistes pour ne pas tomber à côté','Six questions, trente secondes. Chacun dit ce qui lui ferait plaisir et ce qu’il vaut mieux éviter. Son Père Noël les lit en ouvrant son enveloppe.','PistesResultat',()),
 ('Le jeu','Devine qui','Avant la fête, chacun parie sur qui offre à qui. Le jour venu, le palmarès arrive en images : le détective, le mieux caché, le suspect idéal.','DevineStory4',()),
 ('Les listes','Des listes de cadeaux pour toute la famille','Pour Noël, un anniversaire ou toute l’année. Tu écris les idées de chacun, tu envoies un lien, et la famille coche ce qu’elle offre.','ListeVisiteurMes',('Personne n’offre deux fois la même chose.','Un cadeau trop gros ? On s’y met à plusieurs.','Une liste se tient à deux, et tout se met à jour en direct.'))]
ICO={'Le tirage':('✉️','brique'),'Les pistes':('🏷️','nuit'),'Le jeu':('🕵️','prune'),'Les listes':('🎁','sapin')}
def drow(k,f):
    o,t,b,n,p=f
    txt=f'<div style="display: flex; flex-direction: column; gap: 16px"><div style="display: flex; flex-direction: column; align-items: flex-start; gap: 16px">{tile(*ICO[o],52)}<div style="min-width: 0; display: flex; flex-direction: column; gap: 6px">{over(o)}<h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.15">{t}</h2></div></div><p style="margin: 0; font-size: 18px; line-height: 1.5; color: #57534e">{b}</p>{pts(*p) if p else ""}</div>'
    halo={'Le tirage':'255, 208, 200','Les pistes':'207, 230, 255','Le jeu':'230, 214, 248','Les listes':'198, 241, 226'}[o]
    ph=f'<div style="display: flex; justify-content: center; padding: 28px 0; background: radial-gradient(closest-side, rgba({halo}, 0.95) 0%, rgba({halo}, 0) 100%)">{shot(n,240,440,"R" if k%2==0 else "L")}</div>'
    return f'<section style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 64px; align-items: center">{ph+txt if k%2==0 else txt+ph}</section>'
def dcard(icon,t,d): return f'<li style="{CARD}; padding: 20px; display: flex; align-items: flex-start; gap: 12px"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{d}</span></span></li>'
DBTN=BTN+'; padding: 0 28px'; DBTN2=BTN2+'; height: 52px; padding: 0 28px'
DCTA=f'<div style="display: flex; gap: 12px"><a href="ConnexionCreer.dc.html" style="{DBTN}">Créer un compte</a><a href="Connexion.dc.html" style="{DBTN2}">Se connecter</a></div>'
dmain=f"""<section style="display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); gap: 48px; align-items: center">
      <div style="display: flex; flex-direction: column; gap: 20px">
        <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 56px; line-height: 1.05; color: #a43a2f">Le Secret Santa de la famille, et les listes de cadeaux qui vont avec.</h1>
        <p style="margin: 0; font-size: 20px; line-height: 1.45; color: #57534e">Chacun découvre en secret à qui il offre. Personne ne triche, et personne n’offre deux fois la même chose.</p>
        {DCTA}
        <a href="#aide" style="align-self: flex-start; display: flex; align-items: flex-start; gap: 12px; padding: 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; text-decoration: none">
          <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{LINK}</span>
          <span style="display: flex; flex-direction: column; gap: 2px; font-size: 14px; line-height: 1.4"><strong style="font-size: 15px">Tu as reçu un lien personnel ?</strong>Ouvre-le directement : il fonctionne sans compte.</span>
        </a>
      </div>
      <div style="display: flex; justify-content: center; align-items: flex-start; gap: 20px"><div style="margin-top: 48px">{shot('TirageDecouvrir',220,430,'R')}</div>{shot('DevineStory5',220,430,'L')}</div>
    </section>
    {''.join(drow(k,f) for k,f in enumerate(FEAT))}
    <section style="{CARD}; padding: 40px; display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.2fr); gap: 48px; align-items: center">
      <div style="display: flex; flex-direction: column; align-items: flex-start; gap: 16px">{tile('🔒','kraft',52)}<div style="display: flex; flex-direction: column; gap: 6px">{over('Tes données')}<h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.15">En clair, et le moins possible</h2></div><p style="margin: 0; font-size: 18px; line-height: 1.5; color: #57534e">Under the Tree est fait par une seule personne, pour ses familles. Il ne vit pas de tes données.</p><a href="Confidentialite.dc.html" style="{A}; font-size: 16px; font-weight: 700">Tes données, en clair</a></div>
      {pts(*DATA)}
    </section>
    <section style="display: flex; flex-direction: column; gap: 20px">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.15; text-align: center">Et aussi</h2>
      <ul style="list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px">{dcard(PHONE,'Sur ton téléphone, comme une application','Elle s’installe sur l’écran d’accueil, sur iPhone comme sur Android.')}{dcard(BELL,'Prévenu quand il faut','Une notification sur le moment, un résumé par email le matin. Pas un email à chaque geste.')}{dcard(KEY,'Sans mot de passe','Un lien ou un code reçu par email suffit.')}{dcard(CAL,'D’une année sur l’autre','Le groupe, les exclusions et les tirages passés sont gardés.')}{dcard(GLOBE,'En trois langues','Français, anglais, allemand : chacun choisit la sienne.')}</ul>
    </section>
    <section style="border-radius: 16px; background: #fbf0cf; border: 1px solid #ebc762; padding: 40px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 48px; align-items: center">
      <div style="display: flex; flex-direction: column; gap: 14px">
        <span style="align-self: flex-start; height: 24px; padding: 0 10px; border-radius: 999px; background: #e6b94a; color: #3d2c08; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; display: flex; align-items: center">Bientôt</span>
        <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.15">Demande-le à ton assistant préféré</h2>
        <p style="margin: 0; font-size: 18px; line-height: 1.5; color: #5b430f">Under the Tree se branchera sur l’assistant que tu utilises déjà, grâce à MCP, le standard qui relie les assistants aux applications. Tu lui parles, il s’occupe de la liste.</p>
        <p style="margin: 0; font-size: 15px; line-height: 1.4; color: #5b430f">Le tirage, lui, reste secret : aucun assistant ne saura qui offre à qui.</p>
      </div>
      <div aria-label="Exemples de demandes" style="display: flex; flex-direction: column; gap: 12px">{bubble('« Ajoute un vélo 16 pouces à la liste de Léo. »')}{bubble('« Qu’est-ce qu’il reste à offrir à Mamie ? »')}</div>
    </section>
    <section style="display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.15">Prêt pour cette année ?</h2>
      <p style="margin: 0; font-size: 18px; line-height: 1.5; color: #57534e">Un compte suffit pour tenir une liste. Pour organiser un tirage, tu demandes la création de ton groupe.</p>
      {DCTA}
    </section>
    <footer style="margin-top: auto; padding-top: 24px; border-top: 1px solid #e9dcc5; display: flex; justify-content: space-between; align-items: center; font-size: 14px; color: #57534e"><a href="APropos.dc.html" style="color: #8a2f27; font-weight: 600">Qui a fait ça, et pourquoi ?</a><span style="display: flex; gap: 16px"><span style="font-weight: 700; color: #292524">Français</span><a href="#" style="color: #57534e">English</a><a href="#" style="color: #57534e">Deutsch</a></span></footer>"""
d=HEAD+f"""<div style="width: 1280px; height: {HD}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  <header style="height: 72px; flex-shrink: 0; box-sizing: border-box; width: 100%; max-width: 1128px; margin: 0 auto; padding: 0 24px; display: flex; align-items: center; justify-content: space-between">
    <div style="display: flex; align-items: center; gap: 8px; font-family: {F}; font-weight: 700; font-size: 22px; color: #a43a2f"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>Under the Tree</div>
    <div style="display: flex; align-items: center; gap: 20px"><button aria-label="Langue : français" style="height: 44px; min-width: 44px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600">FR</button><a href="Connexion.dc.html" style="font-size: 16px; font-weight: 700; color: #8a2f27; text-decoration: none">Se connecter</a><a href="ConnexionCreer.dc.html" style="{BTN}; height: 44px; font-size: 16px; padding: 0 20px">Créer un compte</a></div>
  </header>
  <main style="flex-grow: 1; box-sizing: border-box; width: 100%; max-width: 1128px; margin: 0 auto; display: flex; flex-direction: column; gap: 88px; padding: 40px 24px 32px">
    {dmain}
  </main>
</div>
"""+TAIL
d=re.sub(r'<title>[^<]*</title>','<title>Under the Tree — la page de présentation, écran large</title>',d)
d=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":1280,"height":%d}'%HD,d)
open(PJ+'LandingDesktop.dc.html','w').write(d)
s=HEAD+f'''<div style="width: 390px; height: {H}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header('FR').replace('<div><button aria-label="Retour"','<div><button hidden aria-label="Retour"')}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 24px 16px 24px">
    {main}
  </main>
</div>
'''+TAIL
s=re.sub(r'<title>[^<]*</title>','<title>Under the Tree — la page de présentation</title>',s)
s=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,s)
open(PJ+'Landing.dc.html','w').write(s)
names=json.load(open('/tmp/names.json'))
for x in ('Landing.dc.html','LandingDesktop.dc.html'):
    if x not in names: names.append(x)
json.dump(names,open('/tmp/names.json','w'))
print(len(s))
