# Le lien, 3e version (Julien, 20 novembre 2026) : toujours sous le texte, en italique, une petite icône, sans pastille.
# En écriture, la ligne du lien est toujours là dans l'encart blanc : vide (« Ajouter un lien ») ou remplie, modifiable sur place.
# « Changer » disparaît : toucher la ligne ou sa case ouvre le panneau. Après chips.py.
import glob,json,re
PJ='/home/claude/utt/project/'
LK='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/></svg>'
CARET='<span aria-hidden="true" style="display: inline-block; width: 2px; height: 16px; background: #b8483a; vertical-align: -3px; margin-left: 1px"></span>'
def line(d): return f'<span data-lien="3" style="display: flex; align-items: center; gap: 5px; margin-top: 1px; font-size: 13px; line-height: 1.5; font-style: italic; font-weight: 500; color: #5f37a6; text-decoration: none">{LK}<span style="min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{d}</span></span>'
def field(val,focus=False,clear=False):
    inner=(f'<span style="color: #292524; font-style: normal">{val}</span>' if val else '')+(CARET if focus else '')+('' if val else f'<span style="color: #a8a29e">{"Colle ou écris l’adresse" if focus else "Ajouter un lien"}</span>')
    x='<button aria-label="Retirer le lien" style="width: 32px; height: 32px; margin: -6px -8px -6px 0; border: 0; background: transparent; color: #78716c; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>' if clear else ''
    return (f'<div style="padding-left: 34px"><div data-lien="champ" role="textbox" aria-label="Le lien de cette idée" style="display: flex; align-items: center; gap: 6px; min-height: 32px; padding-top: 6px; border-top: 1px solid #efe6d6; font-size: 14px; line-height: 1.4; font-style: italic; color: {"#5f37a6" if val else "#a8a29e"}">'
            f'<span style="display: flex; color: {"#5f37a6" if (val or focus) else "#a8a29e"}">{LK}</span><span style="flex-grow: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{inner}</span>{x}</div></div>')
n=set()
# 1. les trois états de l'écriture
for f,val,focus in (('ListeIdee','',False),('ListeIdeeLien','',True),('ListeIdeeLienFait','lutin-jouets.fr/puzzle-dinosaures-100',False)):
    p=PJ+f+'.dc.html'; s=open(p,encoding='utf-8').read()
    a=s.index('<li style="margin: 0 -16px 0 -22px; padding: 0 16px 10px 22px; background: #fffdf9; box-shadow: inset 3px 0 0 #b8483a">'); b=s.index('</li>',a)
    li=s[a:b]
    li=re.sub(r'<span data-par="1"[^>]*>.*?</span></span>','',li,flags=re.S)
    li=li.replace(' : <span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: #b8483a; vertical-align: -4px; margin-left: 1px"></span><span style="color: #a8a29e; text-decoration: underline; text-underline-offset: 3px">colle ou écris l’adresse</span>','')
    if focus is False and val: pass
    k=li.index('<div style="padding-left: 34px">')
    li=li[:k]+field(val,focus,bool(val))
    s=s[:a]+li+s[b:]; open(p,'w',encoding='utf-8').write(s); n.add(f+'.dc.html')
# 2. en lecture : la pastille devient une ligne sous le texte ; 3. plus de « Changer »
PILL=re.compile(r'<span data-lien="2"[^>]*><svg.*?</svg>([^<]*)</span>',re.S)
ROW=re.compile(r'(<span data-par="1"[^>]*>)((?:(?!</span></span>).)*</span>|)</span>',re.S)
CH=re.compile(r'<span data-chip="action"[^>]*><svg.*?</svg>Changer</span>',re.S)
def row(m):
    body=m.group(2); body=CH.sub('',body)
    k=PILL.search(body); pre=''
    if k: pre=line(k.group(1)); body=PILL.sub('',body,count=1)
    return pre+((m.group(1)+body+'</span>') if body.strip() else '')
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read()
    if 'data-par="1"' not in s: continue
    t=ROW.sub(row,s)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.add(f.split('/')[-1])
print(len(n)); json.dump(sorted(n),open('/tmp/lien3.json','w'))
