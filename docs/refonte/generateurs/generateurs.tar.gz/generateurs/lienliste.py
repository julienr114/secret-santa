# Relier ses pistes d'un tirage à une liste qu'on tient (19 novembre 2026). Un simple lien vers la liste, rien de plus.
NO_WRITE=True
import io,contextlib,json
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
R={}
def grow(h,d):
    m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+d
    return h.replace(m.group(0),f'width: 390px; height: {H}px',1),H
def ret(h,t): return re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
SM='margin: 0; font-size: 14px; line-height: 1.45; color: #57534e'
SECT='background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05); padding: 16px; display: flex; flex-direction: column; gap: 10px'
# 1. mes pistes : « Ma liste de cadeaux »
h=open(PJ+'Pistes.dc.html').read()
a='<span>Seule la personne qui t’offre un cadeau les verra, une fois le tirage fait.</span>\n    </div>'; assert h.count(a)==1
blk=f'''
    <section style="{SECT}">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 20px">Ma liste de cadeaux</h2>
      <a href="PistesListeChoisir.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; text-decoration: none; color: #292524">{tile('❄️','nuit',44)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 700">Noël 2026</span><span style="font-size: 14px; color: #57534e">Ta liste, publiée</span></span><span style="font-size: 14px; font-weight: 700; color: #8a2f27">Changer</span></a>
      <p style="{SM}">La personne qui t’offre un cadeau verra un lien vers elle. Ce qu’elle y coche est anonyme : personne ne saura que c’est elle, pas même toi.</p>
    </section>'''
h=h.replace(a,a+blk,1); h,H=grow(h,190); R['PistesListe']=(ret(h,'Mes pistes — reliées à ma liste de cadeaux'),H)
# 2. choisir la liste : un panneau, mes listes par leur nom
def opt(on,e,c,t,d,dis=False): return f'<label style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 0; border-top: 1px solid #e9dcc5;{" opacity: 0.55;" if dis else ""}">{tile(e,c,40)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 700">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span><input type="radio" name="l" {"checked" if on else ""} {"disabled" if dis else ""} style="width: 22px; height: 22px; accent-color: #b8483a"></label>'
R['PistesListeChoisir']=(sheet(300,'Ma liste de cadeaux',f'''<h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Quelle liste ?</h2>
    <p style="{SM}">Les listes que tu tiens, et celles où tu figures. Seule une liste publiée peut être reliée.</p>
    <div>{opt(True,'❄️','nuit','Noël 2026','Ta liste · publiée')}{opt(False,'🎄','sapin','Noël chez Mamie','La liste de Mamie · tu y figures')}{opt(False,'🎂','brique','Mes 40 ans','Brouillon : publie-la d’abord',True)}<label style="display: flex; align-items: center; gap: 12px; min-height: 56px; border-top: 1px solid #e9dcc5"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Aucune liste</span><input type="radio" name="l" style="width: 22px; height: 22px; accent-color: #b8483a"></label></div>
    <button style="{BTN}; margin-top: auto">Valider</button>''','Mes pistes — choisir la liste',backdrop='Mes pistes'),844)
# 3. le résultat : un lien vers sa liste
h=open(PJ+'PistesResultat.dc.html').read()
a='<h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 20px">Pour t’aider à choisir</h2>'; assert h.count(a)==1
lnk=f'<a href="ListeVisiteurTirage.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 12px; border-radius: 12px; background: #f1e8d8; text-decoration: none; color: #292524">{tile("❄️","nuit",40)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 700">Sa liste de cadeaux : Noël 2026</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">Le mode anonyme y sera activé pour toi.</span></span><span style="display: flex; color: #78716c">{CHEV}</span></a>'
h=h.replace(a,a+lnk,1)
# « Si tu sèches » n'a plus d'intérêt quand une liste est reliée (Julien, 19 novembre 2026)
i=h.index('Si tu sèches'); j=h.rfind('<div style="display: flex; flex-direction: column; gap: 4px">',0,i)
k=j; depth=0
for m in re.finditer(r'<(/?)div\b',h[j:]):
    depth+= -1 if m.group(1) else 1
    if depth==0: k=j+m.end()+1; break
cut=h[j:k]; assert cut.endswith('</div>') and 'Si tu sèches' in cut
h=h[:j]+h[k:]; h,H=grow(h,76-40*cut.count('<li')); R['PistesResultatListe']=(ret(h,'Page d’un tirage — le lien vers sa liste'),H)
# 4. la liste, ouverte depuis le tirage : on coche en anonyme
h=open(PJ+'ListeVisiteurMes.dc.html').read()
a='Tu offres 2 cadeaux : seule Camille sait que c’est toi.'; assert h.count(a)==1
h=h.replace(a,'Tu offres 2 cadeaux.')
h=h.replace('Tu l’offres · seul, sous ton prénom · ','Tu l’offres · anonyme · ',1)
R['ListeVisiteurTirage']=(ret(h,'Listes — ouverte depuis un tirage : cocher en anonyme'),int(re.search(r'width: 390px; height: (\d+)px',h).group(1)))
names=json.load(open('/tmp/names.json'))
for k,(h,ht) in R.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
print({k:v[1] for k,v in R.items()})
