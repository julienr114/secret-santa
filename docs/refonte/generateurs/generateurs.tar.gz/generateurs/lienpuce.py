# Le lien d'une idée : une puce avec le nom du site, plus « : lien » (Julien, 20 novembre 2026). Après offrent.py.
import glob,json,re
PJ='/home/claude/utt/project/'
ICO='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8a2f27" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/></svg>'
def chip(d): return f'<span data-lien="1" style="display: inline-flex; align-items: center; gap: 4px; height: 24px; padding: 0 8px 0 6px; box-sizing: border-box; border-radius: 8px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #57534e; font-size: 13px; font-weight: 600; text-decoration: none; vertical-align: 1px; white-space: nowrap; max-width: 180px; overflow: hidden; text-overflow: ellipsis">{ICO}{d}</span>'
DOM=[('grand modèle','lutin-jouets.fr'),('Draisienne','petit-velo.fr'),('raclette','maison-fromage.fr'),('auteur préféré','librairie-du-coin.fr'),('Console','jeux-video.fr')]
PAT=re.compile(r'(.{0,40}) : <span style="color: #8a2f27; text-decoration: underline">lien</span>')
def rep(m):
    d='lutin-jouets.fr'
    for k,v in DOM:
        if k in m.group(1): d=v
    return m.group(1)+' '+chip(d)
n=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read(); t=PAT.sub(rep,s)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n)); json.dump(n,open('/tmp/lienpuce.json','w'))
