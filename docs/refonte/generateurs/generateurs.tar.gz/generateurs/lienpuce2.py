# Le lien d'une idée, 2e version : une pastille lilas sur la ligne de ceux qui offrent (Julien, 20 novembre 2026). Après lienpuce.py.
import glob,json,re
PJ='/home/claude/utt/project/'
ICO='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/></svg>'
def pill(d): return f'<span data-lien="2" style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 700; color: #3b2463; background: #f1e8fc; border-radius: 999px; padding: 1px 8px 1px 6px; text-decoration: none; white-space: nowrap; max-width: 190px; overflow: hidden; text-overflow: ellipsis">{ICO}{d}</span>'
ROW='<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px; text-decoration: none">'
PAT=re.compile(r' <span data-lien="1"[^>]*><svg.*?</svg>([^<]*)</span>(</span>)?(<span data-par="1"[^>]*>)?',re.S)
def rep(m):
    d,close,row=m.group(1),m.group(2),m.group(3)
    if not close: return ' '+pill(d)
    if row: return '</span>'+row+pill(d)
    return '</span>'+ROW+pill(d)+'</span>'
n=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read(); t=PAT.sub(rep,s)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n)); json.dump(n,open('/tmp/lienpuce.json','w'))
