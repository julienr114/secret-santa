import re,os,shutil,json
PJ='/home/claude/utt/project/'; out='/mnt/user-data/outputs/listes'; os.makedirs(out,exist_ok=True)
src=open(PJ+'Pistes.dc.html').read(); a=src.index('<div style="width: 390px'); HEAD=src[:a]; TAIL=src[src.index('</x-dc>'):]
F="'Fraunces', Georgia, serif"
ic=lambda d,w=20,sw=2:f'<svg aria-hidden="true" width="{w}" height="{w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{d}</svg>'
CHEV=ic('<path d="m9 18 6-6-6-6"/>'); BACK=ic('<path d="m15 18-6-6 6-6"/>',22); PLUS=ic('<path d="M12 5v14M5 12h14"/>',18,2.2); CHECK=ic('<path d="m5 12 5 5 9-10"/>',14,3)
LINK=ic('<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',18)
GIFT=ic('<path d="M20 12v9H4v-9M2 7h20v5H2zM12 22V7M12 7H7.500a2.500 2.500 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.500a2.500 2.500 0 0 0 0-5C13 2 12 7 12 7z"/>')
STAR='<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#e6b94a"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
SHARE=ic('<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',18)
USERS=ic('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.870M16 3.130a4 4 0 0 1 0 7.750"/>',18)
PP={'Léo':('🚀','#d6e6ef','#94bbd0'),'Zoé':('🦄','#ead2e2','#c493b4'),'Hugo':('🐧','#f6e3ad','#e6b94a'),'Camille':('🦌','#ead2e2','#c493b4'),'Mamie':('🧶','#f3d3cc','#e09e92'),'Tonton':('🎸','#cfe2d3','#8db898')}
def av(n,s=40):
    e,bg,bd=PP[n]; return f'<span aria-hidden="true" style="width: {s}px; height: {s}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {bd}; display: flex; align-items: center; justify-content: center; font-size: {round(s*0.45)}px; flex-shrink: 0">{e}</span>'
LC={'sapin':'#274e34','brique':'#a43a2f','moutarde':'#e6b94a','prune':'#5b3a55','nuit':'#2c4a63','kraft':'#b89565'}
def tile(e,c,s=56):
    return f'<span aria-hidden="true" style="width: {s}px; height: {s}px; border-radius: {round(s*0.25)}px; background: {LC[c]}; box-shadow: 0 2px 6px rgba(60, 30, 10, 0.18); display: flex; align-items: center; justify-content: center; font-size: {round(s*0.52)}px; line-height: 1; flex-shrink: 0">{e}</span>'
H2='margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
CARD='background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'
UL='list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad'
BTN='height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
BTN2='height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
def header(right='FR'):
    r=f'<button aria-label="Langue : français" style="justify-self: end; height: 44px; min-width: 44px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600">FR</button>' if right=='FR' else right
    return f'''<header style="height: 56px; flex-shrink: 0; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 0 12px">
    <div><button aria-label="Retour" style="width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0">{BACK}</button></div>
    <div style="display: flex; align-items: center; gap: 6px; font-family: {F}; font-weight: 700; font-size: 18px; color: #a43a2f"><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>Under the Tree</div>
    {r}
  </header>'''
NAV=f'''<nav aria-label="Sections" style="margin-top: auto; flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad"><a href="Accueil.dc.html" style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: #57534e; font-size: 12px; font-weight: 600">{ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',22)}Tirages</a><a href="ListesAccueil.dc.html" aria-current="page" style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: #8a2f27; font-size: 12px; font-weight: 700">{ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',22)}Listes</a></nav>'''
def page(h,main,title,footer='',nav=False,right='FR'):
    foot=f'\n  <footer style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 14px 16px 20px; display: flex; flex-direction: column; gap: 10px">{footer}</footer>' if footer else ''
    s=HEAD+f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header(right)}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    {main}
  </main>{foot}{NAV if nav else ''}
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
def sheet(top,label,inner,title,backdrop='Noël 2026'):
    s=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: {F}; font-weight: 700; font-size: 30px; color: #5c554c">{backdrop}</div>
  <section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 16px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    {inner}
  </section>
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
def titles(eyebrow,h1,sub=''):
    return f'''<div style="display: flex; flex-direction: column; gap: 4px">
      <p style="margin: 0; font-size: 14px; color: #57534e">{eyebrow}</p>
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{h1}</h1>
      {f'<p style="margin: 4px 0 0; font-size: 15px; line-height: 1.45; color: #57534e">{sub}</p>' if sub else ''}
    </div>'''
def sh(h1,sub=''): return f'''<div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 24px; line-height: 1.15">{h1}</h1>
      {f'<p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{sub}</p>' if sub else ''}
    </div>'''
def pill(t,kind):
    c={'free':('transparent','#8a2f27','1px dashed #b8483a'),'taken':('#f1e8d8','#57534e','1px solid #dccbad'),'mine':('#dbe9dd','#1f3d29','1px solid #8db898'),'group':('#fbf0cf','#5b430f','1px solid #ebc762')}[kind]
    return f'<span style="min-height: 32px; box-sizing: border-box; padding: 0 12px; border-radius: 999px; background: {c[0]}; color: {c[1]}; border: {c[2]}; font-size: 13px; font-weight: 700; display: flex; align-items: center; gap: 5px; flex-shrink: 0; white-space: nowrap">{t}</span>'
def item(title,sub,right,star=False,top=True,link=False):
    return f'''<li style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}">
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px">
            <span style="font-weight: 600; font-size: 16px; display: flex; align-items: center; gap: 6px">{STAR if star else ''}{title}{'<span style="color: #8a2f27; display: flex">'+LINK+'</span>' if link else ''}</span>
            <span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span>
          </span>
          {right}
        </li>'''
def person(name,meta,items,extra=''):
    return f'''<section style="display: flex; flex-direction: column; gap: 8px">
      <div style="display: flex; align-items: center; gap: 12px; padding: 0 4px">{av(name,44)}<div style="flex-grow: 1; display: flex; flex-direction: column"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">{name}</h2><p style="margin: 0; font-size: 13px; color: #57534e">{meta}</p></div>{extra}</div>
      <ul style="{UL}">
        {''.join(items)}
      </ul>
    </section>'''
addrow=lambda t,sub='':f'''<li style="border-top: 1px solid #e9dcc5"><a href="ListeIdee.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #8a2f27"><span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #f6e2dd; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{PLUS}</span><span style="display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 15px">{t}</span>{f'<span style="font-size: 13px; color: #57534e">{sub}</span>' if sub else ''}</span></a></li>'''
portrait=lambda href:f'<a href="{href}" style="min-height: 36px; padding: 0 12px; border-radius: 999px; background: #f1e8d8; box-shadow: 0 0 0 1px #dccbad; color: #292524; text-decoration: none; font-size: 13px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">Ses goûts</a>'
B={}
# ---- Accueil des listes
def lrow(icon,t,sub,top=True,badge=''):
    return f'''<li><a href="ListeTeneur.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''} text-decoration: none; color: #292524">{icon}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">{sub}</span></span>{badge}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'''
gi=f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{GIFT}</span>'
B['ListesAccueil']=(page(844,titles('','Listes','Des idées de cadeaux à réserver, pour Noël, un anniversaire, toute l’année.')+f'''
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Mes listes</h2>
      <ul style="{UL}">
        {lrow(gi,'Noël 2026','Léo, Zoé, Hugo, moi · 9 idées sur 14 réservées',False)}
        {lrow(gi,'Les 6 ans de Léo','Passé le 12 mars · 7 cadeaux offerts')}
      </ul>
      <a href="ListeNouvelle.dc.html" style="{BTN2}; margin-top: 6px">{PLUS}Créer une liste</a>
    </section>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Partagées avec moi</h2>
      <ul style="{UL}">
        {lrow(av('Mamie'),'Noël 2026, chez Mamie','Tenue par Mamie · tu as réservé 2 cadeaux',False)}
        {lrow(av('Tonton'),'Les 40 ans de Tonton','Tenue par Tonton · rien réservé',True,'<span style="height: 24px; padding: 0 8px; border-radius: 999px; background: #b8483a; color: #fff; font-size: 12px; font-weight: 700; display: flex; align-items: center">3 nouvelles</span>')}
      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Une liste apparaît ici dès que tu ouvres son lien en étant connecté.</p>
    </section>''','Listes — accueil',nav=True),844,'L’onglet Listes')
# ---- Nouvelle liste
def chk(name,meta,on=True,top=True):
    return f'''<li{' style="border-top: 1px solid #e9dcc5"' if top else ''}><label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">{av(name)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{name}</span><span style="font-size: 13px; color: #57534e">{meta}</span></span><input type="checkbox" {'checked ' if on else ''}style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0"></label></li>'''
INP='height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; width: 100%'
LAB='font-size: 15px; font-weight: 600'
B['ListeNouvelle']=(page(960,titles('Listes','Nouvelle liste','Une liste par événement, avec ceux de ta famille qui recevront des cadeaux.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="n" style="{LAB}">Nom de l’événement</label><input id="n" value="Noël 2026" style="{INP}"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="d" style="{LAB}">Date <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="d" value="25/12/2026" style="{INP}; width: 180px"><p style="margin: 0; font-size: 13px; color: #57534e">Après cette date, la liste passe dans « passées ».</p></div>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Qui est sur la liste ? · 4 sur 4</h2>
      <ul style="{UL}">
        {chk('Léo','6 ans',True,False)}{chk('Zoé','3 ans')}{chk('Hugo','Mon conjoint')}{chk('Camille','Moi')}
        <li style="border-top: 1px solid #e9dcc5"><a href="ListePersonne.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #8a2f27"><span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #f6e2dd; display: flex; align-items: center; justify-content: center">{PLUS}</span><span style="font-weight: 700; font-size: 15px">Ajouter quelqu’un à ma famille</span></a></li>
      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Ta famille est gardée pour les prochaines listes. Leurs idées non offertes sont reprises.</p>
    </section>''','Listes — nouvelle liste',footer=f'<a href="ListeTeneur.dc.html" style="{BTN}">Créer la liste</a>'),960,'Créer une liste')
# ---- Page du teneur
B['ListeTeneur']=(page(1640,titles('Listes','Noël 2026','Le 25 décembre · 9 idées sur 14 réservées')+f'''
    <div style="{CARD}; padding: 14px 16px; display: flex; flex-direction: column; gap: 10px">
      <p style="margin: 0; font-size: 15px; line-height: 1.45"><strong style="font-weight: 700">Toi seul vois qui a réservé.</strong> Ceux qui ont le lien voient seulement « Réservé ».</p>
      <a href="ListePartager.dc.html" style="{BTN}; height: 48px; font-size: 16px">{SHARE}Partager la liste</a>
    </div>
    {person('Léo','6 ans · taille 6 ans, pointure 30',[
      item('Circuit de billes','Environ 35 € · le grand modèle',pill('Mamie','taken'),star=True,top=False,link=True),
      item('Déguisement de pompier','Taille 6 ans',pill('Anonyme','taken')),
      item('Vélo 16 pouces','Environ 120 €',pill('Mamie, Tonton','group'),star=True),
      item('Livres sur les dinosaures','Il les a presque tous',pill('Libre','free')),
      item('Hors liste · un jeu de société','Ajouté par Tonton',pill('Tonton','taken')),
      addrow('Ajouter une idée')],portrait('ListePersonne.dc.html'))}
    {person('Zoé','3 ans · taille 3 ans',[
      item('Poupée en tissu','Environ 25 €',pill('Libre','free'),top=False),
      item('Draisienne','Environ 60 €',pill('Mamie','taken'),link=True),
      addrow('Ajouter une idée')],portrait('ListePersonne.dc.html'))}
    {person('Camille','Moi',[
      item('Un bon couteau de cuisine','Environ 50 €',pill('Tonton','taken'),top=False),
      item('Un week-end à deux','',pill('Libre','free')),
      addrow('Ajouter une idée')],portrait('ListePersonne.dc.html'))}
    <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Hugo n’a pas encore d’idées. Une réservation en jaune est faite à plusieurs.</p>''','Listes — la liste, vue par celui qui la tient'),1640,'La liste, vue par celui qui la tient')
# ---- Idée
B['ListeIdee']=(sheet(170,'Nouvelle idée',sh('Une idée pour Léo','Ce que la famille verra sur la liste.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="i" style="{LAB}">L’idée</label><input id="i" value="Circuit de billes" style="{INP}"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="l" style="{LAB}">Lien <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="l" placeholder="https://…" style="{INP}"></div>
    <div style="display: flex; gap: 12px"><div style="flex: 1; display: flex; flex-direction: column; gap: 6px"><label for="p" style="{LAB}">Prix, à peu près</label><input id="p" value="35 €" style="{INP}"></div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="m" style="{LAB}">Un mot <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="m" value="Le grand modèle" style="{INP}"><p style="margin: 0; font-size: 13px; color: #57534e">Une taille, une couleur, où le trouver.</p></div>
    <label style="display: flex; align-items: center; gap: 12px; min-height: 48px"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 6px">{STAR}Il y tient vraiment</span><span style="font-size: 13px; color: #57534e">Mise en avant sur la liste</span></span><span role="switch" aria-checked="true" style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 23px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff"></span></span></label>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Ajouter l’idée</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a></div>''','Listes — une idée'),844,'Ajouter une idée')
# ---- Personne : infos et goûts
def fact(k,v,top=True): return f'''<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''} text-decoration: none; color: #292524"><span style="flex-grow: 1; font-weight: 600; font-size: 16px">{k}</span><span style="font-size: 15px; color: #57534e">{v}</span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'''
tag=lambda t:f'<span style="min-height: 36px; padding: 0 12px; border-radius: 999px; background: #f1e8d8; box-shadow: 0 0 0 1px #dccbad; font-size: 14px; font-weight: 600; display: flex; align-items: center">{t}</span>'
B['ListePersonne']=(page(1100,f'''<div style="display: flex; align-items: center; gap: 14px">{av('Léo',64)}<div style="display: flex; flex-direction: column; gap: 2px"><p style="margin: 0; font-size: 14px; color: #57534e">Ma famille</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Léo</h1></div></div>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Infos pratiques</h2>
      <ul style="{UL}">{fact('Date de naissance','14 mars 2020 · 6 ans',False)}{fact('Taille de vêtements','6 ans')}{fact('Pointure','30')}</ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Ce que la famille demande toujours. Affiché en haut de sa section.</p>
    </section>
    <section style="display: flex; flex-direction: column; gap: 10px">
      <h2 style="{H2}">Ses goûts</h2>
      <div style="{CARD}; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <p style="margin: 0; font-family: {F}; font-weight: 700; font-size: 20px">Côté cadeaux, Léo préfère…</p>
        <div style="display: flex; flex-wrap: wrap; gap: 8px">{tag('un cadeau surprenant')}{tag('un objet')}{tag('quelque chose à garder')}{tag('le neuf ou l’occasion')}</div>
        <a href="#" style="align-self: flex-start; min-height: 36px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Répondre aux questions pour lui</a>
      </div>
      <ul style="{UL}">{fact('En ce moment','Les dinosaures, les billes',False)}{fact('Ce qui lui servirait','Un cartable pour le CP')}{fact('À éviter','Les peluches, il en a trop')}</ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Les mêmes questions que les pistes de cadeaux d’un tirage. Utile à ceux qui veulent offrir autre chose que la liste.</p>
    </section>''','Listes — une personne de ma famille'),1100,'Une personne : infos pratiques et goûts')
# ---- Partager
B['ListePartager']=(page(900,titles('Listes · Noël 2026','Partager la liste','Un message tout prêt pour la conversation de la famille.')+f'''
    <div style="align-self: flex-start; max-width: 94%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.45">
      <p style="margin: 0">🎁 Notre liste de cadeaux pour Noël 2026 est prête : Léo, Zoé, Hugo et moi. Réserve ce que tu offres, pour que personne n’ait la même idée :</p>
      <p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/l/k3Fq…</p>
      <p style="margin: 0; color: #57534e">Fait avec Under the Tree, pour les listes de cadeaux et les Secret Santa en famille.</p>
    </div>
    <a href="#" style="align-self: flex-start; min-height: 36px; display: flex; align-items: center; gap: 4px; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Personnaliser le message{CHEV}</a>
    <div style="display: flex; flex-direction: column; gap: 10px"><button style="{BTN}; width: 100%">{SHARE}Partager le message</button><div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px"><button style="{BTN2}; border-color: #dccbad; color: #292524">Copier le message</button><button style="{BTN2}; border-color: #dccbad; color: #292524">Copier le lien seul</button></div></div>
    <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Avec le lien, on voit la liste. Pour réserver, il faut se connecter avec son adresse email.</p>
    <ul style="list-style: none; margin: 0 -16px; padding: 0; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">
      <li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #292524"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Créer un nouveau lien</span><span style="font-size: 14px; color: #57534e">L’ancien ne marchera plus ; les réservations restent</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>
    </ul>''','Listes — partager'),900,'Partager : le message pour la famille')
# ---- Visiteur
take=lambda:f'<a href="ListeReserver.dc.html" style="min-height: 36px; padding: 0 14px; border-radius: 999px; background: #b8483a; color: #ffffff; text-decoration: none; font-size: 14px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">Je le prends</a>'
join=lambda:f'<a href="ListeRejoindre.dc.html" style="min-height: 36px; padding: 0 14px; border-radius: 999px; background: #fbf0cf; color: #5b430f; border: 1px solid #ebc762; text-decoration: none; font-size: 14px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">À plusieurs</a>'
other=lambda n:f'''<li style="border-top: 1px solid #e9dcc5"><a href="ListeHorsListe.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #8a2f27"><span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #f6e2dd; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{PLUS}</span><span style="display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 15px">J’offre autre chose à {n}</span><span style="font-size: 13px; color: #57534e">Pour que personne n’offre la même chose</span></span></a></li>'''
def visitor(mine=False):
    top=f'''<div style="{CARD}; padding: 14px 16px; display: flex; align-items: center; gap: 12px">{av('Camille',44)}<p style="margin: 0; font-size: 15px; line-height: 1.45"><strong style="font-weight: 700">Camille</strong> tient cette liste. {'Elle seule voit qui réserve ; les autres voient « Réservé ».' if not mine else 'Tu as réservé 2 cadeaux. Elle seule le voit.'}</p></div>'''
    leo=[item('Circuit de billes','Environ 35 € · le grand modèle',pill(CHECK+'Tu le prends','mine') if mine else take(),star=True,top=False,link=True),
      item('Déguisement de pompier','Taille 6 ans',pill('Réservé','taken')),
      item('Vélo 16 pouces','Environ 120 € · quelqu’un cherche des partenaires',pill(CHECK+'Tu participes','mine') if mine else join(),star=True),
      item('Livres sur les dinosaures','Il les a presque tous',take()),
      item('Hors liste · un cadeau surprise','',pill('Réservé','taken')),other('Léo')]
    zoe=[item('Poupée en tissu','Environ 25 €',take(),top=False),item('Draisienne','Environ 60 €',pill('Réservé','taken'),link=True),other('Zoé')]
    return titles('Listes','Noël 2026','Le 25 décembre · chez Camille et Hugo')+top+person('Léo','6 ans · taille 6 ans, pointure 30',leo,portrait('ListePersonne.dc.html'))+person('Zoé','3 ans · taille 3 ans',zoe,portrait('ListePersonne.dc.html'))
B['ListeVisiteur']=(page(1400,visitor(False),'Listes — la liste, vue avec le lien'),1400,'La liste, vue avec le lien')
B['ListeVisiteurMes']=(page(1400,visitor(True),'Listes — après avoir réservé'),1400,'Après avoir réservé')
# ---- Réserver
def radio(t,sub,on,top=True): return f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 10px 14px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}{' background: #fbf3f1;' if on else ''}"><input type="radio" name="r" {'checked ' if on else ''}style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{t}</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span></span></label>'''
sw=lambda t,sub,on:f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 56px"><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{t}</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span></span><span role="switch" aria-checked="{'true' if on else 'false'}" style="width: 48px; height: 28px; border-radius: 999px; background: {'#2f613f' if on else '#a8a29e'}; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: {'23' if on else '3'}px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff"></span></span></label>'''
B['ListeReserver']=(sheet(190,'Réserver',sh('Tu prends le circuit de billes ?','Pour Léo')+f'''
    <div role="radiogroup" aria-label="Comment" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">{radio('Je l’offre seul','Les autres verront « Réservé »',True,False)}{radio('On l’offre à plusieurs','D’autres pourront se joindre à toi',False)}</div>
    {sw('Dire à Camille que c’est moi','Elle tient la liste. Sinon, elle verra « Anonyme ».',True)}
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; font-size: 14px; line-height: 1.45">Personne d’autre ne saura que c’est toi. Tu peux annuler quand tu veux, depuis la liste.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Je le prends</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement non</a></div>''','Listes — réserver'),844,'Réserver un cadeau')
B['ListeReserverPlusieurs']=(sheet(170,'Réserver à plusieurs',sh('Tu prends le vélo à plusieurs ?','Pour Léo')+f'''
    <div role="radiogroup" aria-label="Comment" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">{radio('Je l’offre seul','Les autres verront « Réservé »',False,False)}{radio('On l’offre à plusieurs','D’autres pourront se joindre à toi',True)}</div>
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fbf0cf; color: #5b430f"><span style="display: flex; margin-top: 2px">{USERS}</span><p style="margin: 0; font-size: 14px; line-height: 1.45"><strong style="font-weight: 700">Ton prénom sera visible</strong> de ceux qui ouvrent la liste, pour qu’ils puissent se joindre à toi. Vous vous arrangez entre vous pour l’achat.</p></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="w" style="{LAB}">Un mot pour eux <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="w" value="Je l’achète, on partage ?" style="{INP}"></div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Je le prends, à plusieurs</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement non</a></div>''','Listes — réserver à plusieurs'),844,'Réserver à plusieurs')
B['ListeRejoindre']=(sheet(250,'Se joindre',sh('Le vélo, à plusieurs','Pour Léo')+f'''
    <ul style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden"><li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 14px">{av('Mamie')}<span style="display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Mamie</span><span style="font-size: 14px; color: #57534e">« Je l’achète, on partage ? »</span></span></li><li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 14px; border-top: 1px solid #e9dcc5">{av('Tonton')}<span style="font-weight: 600; font-size: 16px">Tonton</span></li></ul>
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #fbf0cf; color: #5b430f; font-size: 14px; line-height: 1.45">En te joignant, <strong style="font-weight: 700">ton prénom sera visible</strong> de ceux qui ouvrent la liste. L’application ne gère pas l’argent : vous vous arrangez entre vous.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Je participe</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Pas cette fois</a></div>''','Listes — se joindre à un cadeau'),844,'Se joindre à un cadeau à plusieurs')
B['ListeConnexion']=(sheet(330,'Se connecter pour réserver',sh('Ton adresse email, pour réserver','Elle sert à retrouver tes réservations et à les annuler. Pas de mot de passe : tu reçois un lien.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="{LAB}">Adresse email</label><input id="e" placeholder="toi@exemple.fr" style="{INP}"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="f" style="{LAB}">Ton prénom</label><input id="f" placeholder="Celui que Camille verra" style="{INP}"></div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Recevoir mon lien</button><p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Le circuit de billes t’attend : tu le réserves en revenant.</p></div>''','Listes — se connecter pour réserver'),844,'Sans compte : l’adresse email, pour réserver')
B['ListeHorsListe']=(sheet(250,'Autre chose',sh('Tu offres autre chose à Léo ?','Dis-le en deux mots : les autres sauront qu’un cadeau est prévu, sans savoir lequel.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="o" style="{LAB}">Ce que tu offres</label><input id="o" value="Un jeu de société" style="{INP}"><p style="margin: 0; font-size: 13px; color: #57534e">Seule Camille le lira. Les autres verront « Hors liste · un cadeau surprise ».</p></div>
    {sw('Dire à Camille que c’est moi','Sinon, elle verra « Anonyme ».',True)}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Ajouter et réserver</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a></div>''','Listes — j’offre autre chose'),844,'« J’offre autre chose »')

# ===== Version « document », d'après la liste Notion de Julien
def box(kind):
    base='width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px'
    if kind=='free': return f'<span aria-hidden="true" style="{base}; border: 2px solid #a8a29e; background: #fffdf9"></span>'
    if kind=='taken': return f'<span aria-hidden="true" style="{base}; background: #a8a29e; color: #ffffff">{CHECK}</span>'
    if kind=='mine': return f'<span aria-hidden="true" style="{base}; background: #2f613f; color: #ffffff">{CHECK}</span>'
    if kind=='group': return f'<span aria-hidden="true" style="{base}; background: #e6b94a; color: #3d2c08">{ic('<path d="M12 5v14M5 12h14"/>',14,3)}</span>'
    if kind=='add': return f'<span aria-hidden="true" style="{base}; border: 2px dashed #cdb48a; color: #8a2f27">{ic('<path d="M12 5v14M5 12h14"/>',12,3)}</span>'
A='color: #8a2f27; text-decoration: underline'
def dline(kind,text,note='',href='#'):
    st={'free':'color: #292524','taken':'color: #78716c; text-decoration: line-through','mine':'color: #292524; font-weight: 600','group':'color: #292524','add':'color: #8a2f27; font-weight: 700'}[kind]
    n=f'<span style="display: block; font-size: 13px; line-height: 1.35; color: #57534e; text-decoration: none; font-weight: 400">{note}</span>' if note else ''
    return f'''<li><a href="{href}" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none">{box(kind)}<span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45"><span style="{st}">{text}</span>{n}</span></a></li>'''
def dperson(name,emoji,meta,lines,tastes=True):
    t=(' · ' if meta else '')+f'<a href="ListePersonne.dc.html" style="{A}">ses goûts</a>' if tastes else ''
    return f'''<section style="display: flex; flex-direction: column; gap: 2px">
      <div style="display: flex; align-items: center; gap: 12px">
        {av(name,52)}
        <div style="min-width: 0; display: flex; flex-direction: column; gap: 2px">
          <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 26px; line-height: 1.15">{name}</h2>
          <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">{meta}{t}</p>
        </div>
      </div>
      <ul style="list-style: none; margin: 6px 0 0; padding: 0 0 0 20px">
        {"".join(lines)}
      </ul>
    </section>'''
def dhead(intro,extra=''):
    return f'''<div style="display: flex; flex-direction: column; gap: 10px">
      {tile('❄️','nuit',72)}
      <h1 style="margin: 4px 0 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1">Noël 2026</h1>
      <p style="margin: 0; font-size: 16px; line-height: 1.5">{intro}</p>{extra}
    </div>'''
lk=lambda t:f'<span style="{A}">{t}</span>'
INTRO='Quelques idées pour t’éviter de chercher. Coche ce que tu offres, et personne n’aura la même idée. Tu en as une autre ? Elle est la bienvenue.'
# visiteur
def doc_visitor(mine):
    who='<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La liste de Camille et Hugo. '+('Tu as coché 2 cadeaux : seule Camille sait que c’est toi.' if mine else 'Camille seule voit qui a coché quoi.')+'</p>'
    leo=[dline('mine' if mine else 'free','Circuit de billes, le grand modèle : '+lk('lien'),'C’est toi · appuie pour annuler' if mine else '','ListeReserver.dc.html'),
      dline('taken','Déguisement de pompier (taille 6 ans)'),
      dline('group','Vélo 16 pouces','Tu participes, avec Mamie et Tonton' if mine else 'Mamie et Tonton l’offrent à plusieurs · se joindre à eux','ListeRejoindre.dc.html'),
      dline('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)','','ListeReserver.dc.html'),
      dline('taken','Un cadeau surprise, hors liste'),
      dline('add','J’offre autre chose à Léo','','ListeHorsListe.dc.html')]
    zoe=[dline('free','Poupée en tissu','','ListeReserver.dc.html'),dline('taken','Draisienne : '+lk('lien')),dline('free','Des livres cartonnés, toujours','','ListeReserver.dc.html'),dline('add','J’offre autre chose à Zoé','','ListeHorsListe.dc.html')]
    cam=[dline('free','Un bon couteau de cuisine','','ListeReserver.dc.html'),dline('free','Une carte cadeau pour un week-end','','ListeReserver.dc.html'),dline('add','J’offre autre chose à Camille','','ListeHorsListe.dc.html')]
    return dhead(INTRO,who)+dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',leo)+dperson('Zoé','🦄','3 ans · taille 3 ans',zoe)+dperson('Camille','🦌','',cam)
B['ListeVisiteur']=(page(1560,doc_visitor(False),'Listes — la liste, vue avec le lien'),1560,'La liste, vue avec le lien')
B['ListeVisiteurMes']=(page(1560,doc_visitor(True),'Listes — après avoir coché'),1560,'Après avoir coché')
# teneur
by=lambda n:f' <span style="display: inline-block; text-decoration: none; font-size: 13px; font-weight: 700; color: #57534e; background: #f1e8d8; border-radius: 999px; padding: 1px 8px; margin-left: 4px">{n}</span>'
def tl(kind,text,who='',note=''):
    st={'free':'color: #292524','taken':'color: #78716c; text-decoration: line-through','group':'color: #292524'}[kind]
    n=f'<span style="display: block; font-size: 13px; line-height: 1.35; color: #57534e">{note}</span>' if note else ''
    return f'''<li><a href="ListeIdee.dc.html" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none">{box(kind)}<span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45"><span style="{st}">{text}</span>{by(who) if who else ''}{n}</span></a></li>'''
addl=lambda n:dline('add',f'Ajouter une idée pour {n}','','ListeIdee.dc.html')
share=f'''<div style="display: flex; gap: 10px; margin-top: 4px"><a href="ListePartager.dc.html" style="{BTN}; height: 44px; font-size: 15px; padding: 0 16px">{SHARE}Partager</a><a href="ListeNouvelle.dc.html" style="{BTN2}; height: 44px; font-size: 15px; padding: 0 16px; border-color: #dccbad; color: #292524">Modifier l’en-tête</a></div><p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">9 cadeaux déjà prévus. Toi seul vois les prénoms.</p>'''
B['ListeTeneur']=(page(1700,dhead(INTRO,share)
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('taken','Circuit de billes, le grand modèle : '+lk('lien'),'Mamie'),tl('taken','Déguisement de pompier (taille 6 ans)','Anonyme'),tl('group','Vélo 16 pouces','Mamie, Tonton','Offert à plusieurs'),tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),tl('taken','Hors liste : un jeu de société','Tonton'),addl('Léo')])
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[tl('free','Poupée en tissu'),tl('taken','Draisienne : '+lk('lien'),'Mamie'),tl('free','Des livres cartonnés, toujours'),addl('Zoé')])
  +dperson('Camille','🦌','Moi',[tl('taken','Un bon couteau de cuisine','Tonton'),tl('free','Une carte cadeau pour un week-end'),addl('Camille')])
  +dperson('Hugo','🐧','',[addl('Hugo')])
  +f'<a href="ListeNouvelle.dc.html" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 700; color: #8a2f27; text-decoration: none">{PLUS}Ajouter une personne</a>','Listes — la liste, vue par celui qui la tient'),1700,'La liste, vue par celui qui la tient')
# idée : une ligne, comme dans un document
B['ListeIdee']=(sheet(400,'Une idée',sh('Une idée pour Léo','Écris-la comme tu la dirais : le modèle, la taille, la couleur.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="i" style="{LAB}">L’idée</label><textarea id="i" rows="2" style="{INP}; height: auto; min-height: 76px; padding: 12px; line-height: 1.45; resize: none">Circuit de billes, le grand modèle</textarea></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="l" style="{LAB}">Un lien <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="l" placeholder="https://…" style="{INP}"></div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Ajouter</button><button style="{BTN2}; width: 100%; border-color: #dccbad; color: #292524">Ajouter, et en écrire une autre</button></div>''','Listes — une idée'),844,'Ajouter une idée : une ligne, un lien')
# nouvelle liste : avec l'icône et le mot d'en-tête
B['ListeNouvelle']=(page(1230,f'''<a href="ListeIcone.dc.html" aria-label="Changer l’icône de la liste" style="align-self: flex-start; position: relative; display: flex; text-decoration: none">{tile('❄️','nuit',72)}<span aria-hidden="true" style="position: absolute; right: -8px; bottom: -8px; width: 28px; height: 28px; border-radius: 50%; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #57534e; display: flex; align-items: center; justify-content: center">{ic('<path d="M12 20h9M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',14,2.2)}</span></a>'''+titles('Listes','Nouvelle liste','Une liste par événement, avec ceux de ta famille qui recevront des cadeaux.')+f'''
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="n" style="{LAB}">Nom de l’événement</label><input id="n" value="Noël 2026" style="{INP}"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="d" style="{LAB}">Date <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="d" value="25/12/2026" style="{INP}; width: 180px"></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="w" style="{LAB}">Ton mot en haut de la liste</label><textarea id="w" rows="3" style="{INP}; height: auto; min-height: 96px; padding: 12px; line-height: 1.45; resize: none">Coche ce que tu offres, et personne n’aura la même idée. Bien entendu, on accepte toute autre idée de cadeau.</textarea></div>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Qui est sur la liste ? · 4 sur 4</h2>
      <ul style="{UL}">
        {chk('Léo','6 ans',True,False)}{chk('Zoé','3 ans')}{chk('Hugo','Mon conjoint')}{chk('Camille','Moi')}
        <li style="border-top: 1px solid #e9dcc5"><a href="ListePersonne.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #8a2f27"><span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #f6e2dd; display: flex; align-items: center; justify-content: center">{PLUS}</span><span style="font-weight: 700; font-size: 15px">Ajouter quelqu’un à ma famille</span></a></li>
      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Ta famille est gardée pour les prochaines listes, avec les idées qui n’ont pas été offertes.</p>
    </section>''','Listes — nouvelle liste',footer=f'<a href="ListeTeneur.dc.html" style="{BTN}">Créer la liste</a>'),1230,'Créer une liste')

# ===== L'onglet Listes, refait : des cartes, par date
def mini(names):
    out=''
    for i,n in enumerate(names):
        e,bg,bd=PP[n]; out+=f'<span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 2px #fffdf9; display: flex; align-items: center; justify-content: center; font-size: 14px;{" margin-left: -6px;" if i else ""}">{e}</span>'
    return f'<span style="display: flex">{out}</span>'
def chip(t,kind='mine'):
    c={'mine':('#f6e2dd','#8a2f27'),'other':('#f1e8d8','#57534e'),'new':('#b8483a','#ffffff')}[kind]
    return f'<span style="height: 24px; padding: 0 10px; border-radius: 999px; background: {c[0]}; color: {c[1]}; font-size: 12px; font-weight: 700; display: flex; align-items: center; white-space: nowrap">{t}</span>'
def bar(done,total):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px"><div role="img" aria-label="{done} idées cochées sur {total}" style="height: 6px; border-radius: 999px; background: #e9dcc5; overflow: hidden"><div style="width: {round(100*done/total)}%; height: 100%; background: #2f613f"></div></div></div>'''
def lcard(emoji,title,when,chips,people,line,progress=None,href='ListeTeneur.dc.html'):
    return f'''<a href="{href}" style="{CARD}; padding: 16px; display: flex; flex-direction: column; gap: 12px; text-decoration: none; color: #292524">
        <div style="display: flex; align-items: flex-start; gap: 12px">
          {tile(emoji[0],emoji[1],56)}
          <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">{title}</h3><p style="margin: 0; font-size: 14px; color: #57534e">{when}</p></div>
          <span style="color: #78716c; display: flex; margin-top: 4px">{CHEV}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap">{mini(people)}{chips}</div>
        {bar(*progress) if progress else ''}
        <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">{line}</p>
      </a>'''
past=lambda emoji,t,sub,top=True:f'''<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''} text-decoration: none; color: #292524">{tile(emoji[0],emoji[1],40)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'''
B['ListesAccueil']=(page(1330,f'''<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 12px">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1">Listes</h1><p style="margin: 0; font-size: 15px; line-height: 1.4; color: #57534e">Chacun coche ce qu’il offre.</p></div>
      <a href="ListeNouvelle.dc.html" style="{BTN}; height: 44px; font-size: 15px; padding: 0 16px; flex-shrink: 0">{PLUS}Nouvelle liste</a>
    </div>
    <section style="display: flex; flex-direction: column; gap: 12px">
      <h2 style="{H2}">À venir</h2>
      {lcard(('❄️','nuit'),'Noël 2026','Le 25 décembre · dans 37 jours',chip('Ma liste'),['Léo','Zoé','Hugo','Camille'],'<strong style="font-weight: 700; color: #292524">9 cadeaux déjà prévus.</strong> Hugo n’a pas encore d’idées.')}
      {lcard(('🎁','brique'),'Noël 2026, chez Mamie','Le 24 décembre · dans 36 jours',chip('Liste de Mamie','other'),['Mamie','Tonton'],'<strong style="font-weight: 700; color: #292524">Tu offres 2 cadeaux.</strong>',None,'ListeVisiteurMes.dc.html')}
      {lcard(('🎸','prune'),'Les 40 ans de Tonton','Le 8 février · dans 82 jours',chip('Liste de Tonton','other')+chip('3 nouvelles idées','new'),['Tonton'],'Tu n’as encore rien coché.',None,'ListeVisiteur.dc.html')}
    </section>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Passées</h2>
      <ul style="{UL}">
        {past(('🎂','moutarde'),'Les 6 ans de Léo','Le 12 mars · 7 cadeaux offerts · ma liste',False)}
        {past(('❄️','sapin'),'Noël 2025','12 cadeaux offerts · ma liste')}
      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Une liste qu’on t’a envoyée apparaît ici dès que tu ouvres son lien en étant connecté.</p>
    </section>''','Listes — accueil',nav=True),1330,'L’onglet Listes')
# vide
B['ListesVide']=(page(844,f'''<div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1">Listes</h1><p style="margin: 0; font-size: 15px; line-height: 1.4; color: #57534e">Chacun coche ce qu’il offre.</p></div>
    <section style="{CARD}; padding: 28px 24px 24px; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center">
      {tile('🎁','brique',72)}
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 24px; line-height: 1.2">Fini, les cadeaux en double</h2>
      <p style="margin: 0; font-size: 15px; line-height: 1.5; color: #57534e">Écris les idées de cadeaux de ta famille pour Noël ou un anniversaire, partage le lien, et chacun coche ce qu’il offre.</p>
      <a href="ListeNouvelle.dc.html" style="{BTN}; width: 100%">Créer ma première liste</a>
    </section>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: #57534e">On t’a envoyé une liste ? Ouvre son lien : elle apparaîtra ici.</p>''','Listes — accueil vide',nav=True),844,'L’onglet Listes, vide')

EMO=['❄️','🎄','🎁','🎂','🎉','🥂','🌸','🐣','🎃','🎓','💍','👶','🏖️','⭐','🧸','🕯️','🎈','🍾','🧁','🪅','🌟','🎊','🕎','🪔','💐','🍀','🏡','✈️','🎭','🎵']
LCN={'sapin':'Vert sapin','brique':'Rouge brique','moutarde':'Moutarde','prune':'Prune','nuit':'Bleu nuit','kraft':'Kraft'}
def emo(e,on=False): return f'<button role="radio" aria-checked="{"true" if on else "false"}" aria-label="{e}" style="width: 44px; height: 44px; padding: 0; border: 0; border-radius: 11px; background: {"#f6e2dd" if on else "#f1e8d8"}; box-shadow: {"0 0 0 2px #b8483a" if on else "none"}; font-size: 21px">{e}</button>'
def sw2(c,on=False): return f'<button role="radio" aria-checked="{"true" if on else "false"}" aria-label="{LCN[c]}" style="width: 44px; height: 44px; padding: 0; border: 0; background: transparent; display: flex; align-items: center; justify-content: center"><span style="width: 32px; height: 32px; border-radius: 8px; background: {LC[c]}; box-shadow: {"0 0 0 2px #fffdf9, 0 0 0 4px #b8483a" if on else "none"}"></span></button>'
_ic=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: 470px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: {F}; font-weight: 700; font-size: 30px; color: #5c554c">Nouvelle liste</div>
  <section aria-label="L’icône de la liste" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 14px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px">
      {tile('❄️','nuit',44)}
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">L’icône de la liste</h1>
    </div>
    <div role="radiogroup" aria-label="Symbole" style="margin: 0 -16px; padding: 4px 16px; display: grid; grid-template-rows: repeat(3, 44px); grid-auto-flow: column; grid-auto-columns: 44px; gap: 6px 7px; overflow-x: auto">{"".join(emo(e,e=="❄️") for e in EMO)}</div>
    <div role="radiogroup" aria-label="Couleur" style="display: flex; justify-content: space-between">{"".join(sw2(c,c=="nuit") for c in LC)}</div>
    <div style="margin-top: auto; display: grid; grid-template-columns: 1fr 2fr; gap: 10px">
      <a href="ListeNouvelle.dc.html" style="height: 48px; border: 1px solid #dccbad; box-sizing: border-box; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Valider</button>
    </div>
  </section>
</div>
'''+TAIL
B['ListeIcone']=(re.sub(r'<title>[^<]*</title>','<title>Listes — icône de la liste</title>',_ic),844,'Choisir l’icône de la liste')

# ===== Le choix de l'icône d'une personne, pour beaucoup plus d'icônes
SH={'brick':('#f3d3cc','#e09e92'),'pine':('#cfe2d3','#8db898'),'mustard':('#f6e3ad','#e6b94a'),'kraft':('#ecdfc6','#cdb48a'),'frost':('#d6e6ef','#94bbd0'),'plum':('#ead2e2','#c493b4')}
def eb(e,on=False): return f'<button role="radio" aria-checked="{"true" if on else "false"}" aria-label="{e}" style="width: 44px; height: 44px; padding: 0; border: 0; border-radius: 50%; background: {"#d6e6ef" if on else "#f1e8d8"}; box-shadow: {"0 0 0 2px #fffdf9, 0 0 0 4px #b8483a" if on else "none"}; font-size: 21px">{e}</button>'
def fam(t,es,on=None,note=''):
    return f'''<section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; padding: 0; position: sticky; top: 0; background: #fffdf9">{t}{f' <span style="font-weight: 600; text-transform: none; letter-spacing: 0">· {note}</span>' if note else ''}</h2><div style="display: grid; grid-template-columns: repeat(7, 44px); justify-content: space-between; row-gap: 8px">{"".join(eb(e,e==on) for e in es)}</div></section>'''
cb=lambda c,on=False:f'<button role="radio" aria-checked="{"true" if on else "false"}" aria-label="{c}" style="width: 44px; height: 44px; padding: 0; border: 0; background: transparent; display: flex; align-items: center; justify-content: center"><span style="width: 32px; height: 32px; border-radius: 50%; background: {SH[c][0]}; box-shadow: {"0 0 0 2px #fffdf9, 0 0 0 4px #b8483a" if on else "0 0 0 1px "+SH[c][1]}"></span></button>'
DICE=ic('<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 8h.010M16 8h.010M12 12h.010M8 16h.010M16 16h.010"/>',18)
_pa=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: 96px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: {F}; font-weight: 700; font-size: 30px; color: #5c554c">Léo</div>
  <section aria-label="Son icône" style="flex-grow: 1; min-height: 0; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 0; display: flex; flex-direction: column; gap: 12px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px">
      <span aria-hidden="true" style="width: 56px; height: 56px; border-radius: 50%; background: #d6e6ef; box-shadow: 0 0 0 1px #94bbd0; display: flex; align-items: center; justify-content: center; font-size: 28px; flex-shrink: 0">🚀</span>
      <h1 style="flex-grow: 1; margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">L’icône de Léo</h1>
      <button style="height: 40px; padding: 0 12px; border: 1px solid #dccbad; border-radius: 999px; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px">{DICE}Au hasard</button>
    </div>
    <div role="radiogroup" aria-label="Couleur" style="display: flex; justify-content: space-between; padding-bottom: 10px; border-bottom: 1px solid #e9dcc5">{"".join(cb(c,c=="frost") for c in SH)}</div>
    <div role="radiogroup" aria-label="Symbole" style="flex-grow: 1; min-height: 0; overflow: hidden; display: flex; flex-direction: column; gap: 16px">
      {fam('Pas encore pris',['🦖','🐿️','🪁','🧩','🎺','🦔','⚽'],None,'dans ta famille')}
      {fam('Personnages',['🎅','🤶','🧑‍🎄','🧝','🧝‍♀️','🧝‍♂️','👼','⛄','☃️','🧚','🦸','🧙','🤴','👸'])}
      {fam('Enfants et jeux',['🚀','🦄','🦖','🧸','🪀','🪁','⚽','🎨','🚲','🧩','🎲','🛹','🎮','🪄'],'🚀')}
      {fam('Animaux',['🦌','🫎','🐧','🦊','🦉','🐻‍❄️','🐻','🐿️','🦔','🐺','🐇','🦭','🐑','🦃','🕊️','🐦','🐈','🐕','🐢','🦋','🐝'])}
    </div>
  </section>
  <div style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 12px 16px 20px; display: grid; grid-template-columns: 1fr 2fr; gap: 10px; box-shadow: 0 -12px 16px rgba(255, 253, 249, 0.9)">
    <a href="#" style="height: 48px; border: 1px solid #dccbad; box-sizing: border-box; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Valider</button>
  </div>
</div>
'''+TAIL
B['PanneauAvatarGrand']=(re.sub(r'<title>[^<]*</title>','<title>Choisir l’icône d’une personne — proposition</title>',_pa),844,'Proposition · l’icône d’une personne, pour beaucoup d’icônes')

# ===== L'icône d'une liste, même forme que celle d'une personne : carrée, couleurs pleines, autres symboles
def eq(e,on=False): return f'<button role="radio" aria-checked="{"true" if on else "false"}" aria-label="{e}" style="width: 44px; height: 44px; padding: 0; border: 0; border-radius: 11px; background: {"#2c4a63" if on else "#f1e8d8"}; box-shadow: {"0 0 0 2px #fffdf9, 0 0 0 4px #b8483a" if on else "none"}; font-size: 21px">{e}</button>'
def famq(t,es,on=None):
    return f'''<section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; padding: 0; position: sticky; top: 0; background: #fffdf9">{t}</h2><div style="display: grid; grid-template-columns: repeat(7, 44px); justify-content: space-between; row-gap: 8px">{"".join(eq(e,e==on) for e in es)}</div></section>'''
_li=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: 96px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: {F}; font-weight: 700; font-size: 30px; color: #5c554c">Nouvelle liste</div>
  <section aria-label="L’icône de la liste" style="flex-grow: 1; min-height: 0; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 0; display: flex; flex-direction: column; gap: 12px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px">
      {tile('❄️','nuit',56)}
      <h1 style="flex-grow: 1; margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">L’icône de la liste</h1>
      <button style="height: 40px; padding: 0 12px; border: 1px solid #dccbad; border-radius: 999px; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px">{DICE}Au hasard</button>
    </div>
    <div role="radiogroup" aria-label="Couleur" style="display: flex; justify-content: space-between; padding-bottom: 10px; border-bottom: 1px solid #e9dcc5">{"".join(sw2(c,c=="nuit") for c in LC)}</div>
    <div role="radiogroup" aria-label="Symbole" style="flex-grow: 1; min-height: 0; overflow: hidden; display: flex; flex-direction: column; gap: 16px">
      {famq('Noël et hiver',['❄️','🎄','🎁','⭐','🕯️','☃️','🔔','🧦','🦌','🎅','🌨️','🏔️','🕎','🪔'],'❄️')}
      {famq('Anniversaires et fêtes',['🎂','🎈','🎉','🎊','🥂','🍾','🧁','🪅','🎵','💃','🕺','🎭','🪩','🎇'])}
      {famq('Grands moments',['👶','🍼','💍','💐','🎓','🏡','🔑','✈️','🎒','👋','🥇','💝','🤍','🕊️'])}
      {famq('Saisons',['🌸','🐣','🌷','☀️','🏖️','🍉','🍂','🎃','🍄','🌰','🌙','🌈','🍀','🌻'])}
    </div>
  </section>
  <div style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 12px 16px 20px; display: grid; grid-template-columns: 1fr 2fr; gap: 10px">
    <a href="ListeNouvelle.dc.html" style="height: 48px; border: 1px solid #dccbad; box-sizing: border-box; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Valider</button>
  </div>
</div>
'''+TAIL
B['ListeIcone']=(re.sub(r'<title>[^<]*</title>','<title>Listes — icône de la liste</title>',_li),844,'Choisir l’icône de la liste')

# ===== Écrire dans la liste, comme dans un document : plus de panneau
def ghost(n,first=False):
    t=f'Une idée pour {n}…' if first else 'Une autre idée…'
    return f'''<li><a href="ListeIdee.dc.html" aria-label="Écrire une idée pour {n}" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none"><span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; border: 2px solid #dccbad; flex-shrink: 0; margin-top: 1px"></span><span style="flex-grow: 1; font-size: 16px; line-height: 1.45; color: #a8a29e">{t}</span></a></li>'''
share2=f'''<div style="display: flex; gap: 10px; margin-top: 4px"><a href="ListePartager.dc.html" style="{BTN}; height: 44px; font-size: 15px; padding: 0 16px">{SHARE}Partager</a></div><p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">9 cadeaux déjà prévus. Toi seul vois les prénoms.<br>Touche un texte pour le modifier.</p>'''
B['ListeTeneur']=(page(1700,dhead(INTRO,share2)
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('taken','Circuit de billes, le grand modèle : '+lk('lien'),'Mamie'),tl('taken','Déguisement de pompier (taille 6 ans)','Anonyme'),tl('group','Vélo 16 pouces','Mamie, Tonton','Offert à plusieurs'),tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),tl('taken','Hors liste : un jeu de société','Tonton'),ghost('Léo')])
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[tl('free','Poupée en tissu'),tl('taken','Draisienne : '+lk('lien'),'Mamie'),tl('free','Des livres cartonnés, toujours'),ghost('Zoé')])
  +dperson('Camille','🦌','Moi',[tl('taken','Un bon couteau de cuisine','Tonton'),tl('free','Une carte cadeau pour un week-end'),ghost('Camille')])
  +dperson('Hugo','🐧','',[ghost('Hugo',True)])
  +f'<a href="ListeNouvelle.dc.html" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 700; color: #8a2f27; text-decoration: none">{PLUS}Ajouter une personne</a>','Listes — la liste, vue par celui qui la tient'),1700,'La liste, vue par celui qui la tient')
CARET='<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: #b8483a; vertical-align: -4px; margin-left: 1px"></span>'
live=f'''<li style="margin: 0 -16px; padding: 0 16px; background: #fffdf9; box-shadow: inset 3px 0 0 #b8483a"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box">{box('free')}<span role="textbox" aria-label="Une idée pour Léo" style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45">Puzzle 100 pièces, avec des dinosaures : <span style="{A}">lien</span>{CARET}</span></div></li>'''
def keyrow(ks,pad=0): return f'<div style="display: flex; gap: 5px; padding: 0 {pad}px">'+"".join(f'<span style="flex: 1; height: 40px; border-radius: 5px; background: #fffdf9; box-shadow: 0 1px 0 #a8a29e; display: flex; align-items: center; justify-content: center; font-size: 17px">{k}</span>' for k in ks)+'</div>'
tb=lambda t,i='',c='#292524':f'<button style="height: 40px; padding: 0 12px; border: 0; border-radius: 999px; background: transparent; color: {c}; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px">{i}{t}</button>'
KB=f'''<div style="flex-shrink: 0; margin-top: auto">
    <div role="toolbar" aria-label="La ligne" style="height: 48px; background: #fffdf9; border-top: 1px solid #dccbad; display: flex; align-items: center; padding: 0 6px">{tb('Lien',LINK)}{tb('Supprimer la ligne','','#57534e')}<span style="flex-grow: 1"></span>{tb('Terminé','','#8a2f27')}</div>
    <div aria-hidden="true" style="background: #d6d0c6; padding: 8px 4px 28px; display: flex; flex-direction: column; gap: 9px; color: #292524">
      {keyrow('azertyuiop')}{keyrow('qsdfghjklm')}{keyrow('wxcvbn',44)}
      <div style="display: flex; gap: 5px"><span style="width: 88px; height: 40px; border-radius: 5px; background: #b9b2a6; display: flex; align-items: center; justify-content: center; font-size: 14px">123</span><span style="flex: 1; height: 40px; border-radius: 5px; background: #fffdf9; box-shadow: 0 1px 0 #a8a29e; display: flex; align-items: center; justify-content: center; font-size: 14px">espace</span><span style="width: 88px; height: 40px; border-radius: 5px; background: #b9b2a6; display: flex; align-items: center; justify-content: center; font-size: 14px">retour</span></div>
    </div>
  </div>'''
_w=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; overflow: hidden">
  {header()}
  <main style="flex-grow: 1; min-height: 0; overflow: hidden; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 0">
    {dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('group','Vélo 16 pouces','Mamie, Tonton','Offert à plusieurs'),tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),tl('taken','Hors liste : un jeu de société','Tonton'),live,ghost('Léo')])}
  </main>
  {KB}
</div>
'''+TAIL
B['ListeIdee']=(re.sub(r'<title>[^<]*</title>','<title>Listes — écrire une idée dans la liste</title>',_w),844,'Écrire une idée, directement dans la liste')

# ===== Accueil : qui tient la liste, en tête de carte
def holder(n,mine=False):
    t='Tu tiens cette liste' if mine else f'Liste de {n}'
    return f'<div style="display: flex; align-items: center; gap: 8px; padding-bottom: 10px; border-bottom: 1px solid #e9dcc5">{av(n,28)}<span style="font-size: 14px; font-weight: 700; color: {"#8a2f27" if mine else "#292524"}">{t}</span></div>'
def lcard2(emoji,title,when,who,mine,people,line,chips='',href='ListeTeneur.dc.html'):
    return f'''<a href="{href}" style="{CARD}; padding: 14px 16px 16px; display: flex; flex-direction: column; gap: 12px; text-decoration: none; color: #292524">
        {holder(who,mine)}
        <div style="display: flex; align-items: flex-start; gap: 12px">
          {tile(emoji[0],emoji[1],56)}
          <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">{title}</h3><p style="margin: 0; font-size: 14px; color: #57534e">{when}</p></div>
          <span style="color: #78716c; display: flex; margin-top: 4px">{CHEV}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap"><span style="font-size: 13px; font-weight: 600; color: #57534e">Pour</span>{mini(people)}{chips}</div>
        <p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">{line}</p>
      </a>'''
SB='<strong style="font-weight: 700; color: #292524">'
B['ListesAccueil']=(page(1460,f'''<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 12px">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1">Listes</h1><p style="margin: 0; font-size: 15px; line-height: 1.4; color: #57534e">Chacun coche ce qu’il offre.</p></div>
      <a href="ListeNouvelle.dc.html" style="{BTN}; height: 44px; font-size: 15px; padding: 0 16px; flex-shrink: 0">{PLUS}Nouvelle liste</a>
    </div>
    <section style="display: flex; flex-direction: column; gap: 12px">
      <h2 style="{H2}">À venir</h2>
      {lcard2(('🎁','brique'),'Noël 2026, chez Mamie','Le 24 décembre · dans 36 jours','Mamie',False,['Mamie','Tonton'],SB+'Tu offres 2 cadeaux.</strong>','','ListeVisiteurMes.dc.html')}
      {lcard2(('❄️','nuit'),'Noël 2026','Le 25 décembre · dans 37 jours','Camille',True,['Léo','Zoé','Hugo','Camille'],SB+'9 cadeaux déjà prévus</strong>, dont 2 par toi. Hugo n’a pas encore d’idées.')}
      {lcard2(('🎸','prune'),'Les 40 ans de Tonton','Le 8 février · dans 82 jours','Tonton',False,['Tonton'],'Tu n’as encore rien coché.',chip('3 nouvelles idées','new'),'ListeVisiteur.dc.html')}
    </section>
    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Passées</h2>
      <ul style="{UL}">
        {past(('🎂','moutarde'),'Les 6 ans de Léo','Le 12 mars · 7 cadeaux offerts à Léo',False)}
        {past(('🧶','kraft'),'Les 70 ans de Mamie','Liste de Tonton · tu as offert 1 cadeau')}
        {past(('❄️','sapin'),'Noël 2025','Le 25 décembre · 12 cadeaux offerts')}
      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Une liste qu’on t’a envoyée apparaît ici dès que tu ouvres son lien en étant connecté.</p>
    </section>''','Listes — accueil',nav=True),1460,'L’onglet Listes')

# ===== Créer une liste = ouvrir le document vide et le remplir sur place
DATE='<p style="margin: 0; font-size: 15px; line-height: 1.4; color: #57534e">Le 25 décembre</p>'
for _k in ['ListeTeneur','ListeVisiteur','ListeVisiteurMes']:
    _h,_a,_b=B[_k]; _m='Noël 2026</h1>'; assert _h.count(_m)==1; B[_k]=(_h.replace(_m,_m+DATE),_a,_b)
def fchip(n):
    return f'<button style="height: 44px; padding: 0 14px 0 6px; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px">{av(n,32)}{n}</button>'
B['ListeNouvelle']=(page(844,f'''<div style="display: flex; flex-direction: column; gap: 10px">
      <a href="ListeIcone.dc.html" aria-label="Changer l’icône de la liste" style="align-self: flex-start; position: relative; display: flex; text-decoration: none">{tile('🎁','brique',72)}<span aria-hidden="true" style="position: absolute; right: -8px; bottom: -8px; width: 28px; height: 28px; border-radius: 50%; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #57534e; display: flex; align-items: center; justify-content: center">{ic('<path d="M12 20h9M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',14,2.2)}</span></a>
      <h1 role="textbox" aria-label="Nom de l’événement" style="margin: 4px 0 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1; color: #a8a29e"><span aria-hidden="true" style="display: inline-block; width: 2px; height: 32px; background: #b8483a; vertical-align: -5px; margin-right: 2px"></span>Nom de l’événement</h1>
      <a href="#" style="align-self: flex-start; min-height: 32px; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: #8a2f27; text-decoration: none">Ajouter une date</a>
      <div style="display: flex; flex-direction: column; gap: 4px; padding: 10px 12px; border: 1px dashed #cdb48a; border-radius: 10px"><span style="font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27; display: flex; align-items: center; gap: 6px">{ic('<path d="M12 20h9M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',13,2.2)}Ton mot pour la famille</span><p role="textbox" aria-label="Ton mot pour la famille" style="margin: 0; font-size: 16px; line-height: 1.5">{INTRO}</p><span style="font-size: 13px; line-height: 1.4; color: #57534e">Un texte de départ : touche-le pour écrire le tien.</span></div>
    </div>
    <section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px; border-top: 1px solid #dccbad">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Qui reçoit des cadeaux ?</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 8px">{fchip('Léo')}{fchip('Zoé')}{fchip('Hugo')}{fchip('Camille')}<a href="ListePersonne.dc.html" style="height: 44px; box-sizing: border-box; padding: 0 14px; border: 1px dashed #cdb48a; border-radius: 999px; color: #8a2f27; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px">{PLUS}Quelqu’un d’autre</a></div>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Touche un prénom : il s’ajoute à la liste, avec ses idées qui n’ont pas été offertes la dernière fois.</p>
    </section>''','Listes — une nouvelle liste, encore vide'),844,'Une nouvelle liste : le document, encore vide')

# ===== Un seul bouton tout en haut : brouillon ou partagée
def state(shared):
    dot='#2f613f' if shared else '#a8a29e'
    l='Partagée avec la famille' if shared else 'Brouillon · toi seul la vois'
    r=f'Le lien{CHEV}' if shared else f'{SHARE}Partager'
    rc='color: #8a2f27' if shared else 'background: #b8483a; color: #ffffff; padding: 0 12px; border-radius: 999px; height: 32px'
    return f'''<a href="ListePartager.dc.html" style="min-height: 48px; box-sizing: border-box; padding: 6px 8px 6px 14px; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; display: flex; align-items: center; gap: 10px; text-decoration: none; color: #292524"><span aria-hidden="true" style="width: 10px; height: 10px; border-radius: 50%; background: {dot}; flex-shrink: 0"></span><span style="flex-grow: 1; font-size: 14px; font-weight: 700">{l}</span><span style="display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 700; {rc}">{r}</span></a>'''
_M='padding: 8px 16px 24px">\n    '
for _k,_sh in [('ListeNouvelle',False),('ListeTeneur',True)]:
    _h,_a,_b=B[_k]; assert _h.count(_M)==1; _h=_h.replace(_M,_M+state(_sh)+'\n    ')
    if _k=='ListeTeneur':
        _d=share2[:share2.index('<p ')]; assert _h.count(_d)==1; _h=_h.replace(_d,'')
    B[_k]=(_h,_a,_b)

# ===== Ajouter quelqu'un : le même bloc dans le brouillon et dans la liste partagée
def addwho(names):
    hint='Touche un prénom : il s’ajoute à la liste, avec ses idées qui n’ont pas été offertes la dernière fois.' if names else 'Toute ta famille est déjà sur la liste.'
    return f'''<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px; border-top: 1px solid #dccbad">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Ajouter quelqu’un</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 8px">{"".join(fchip(n) for n in names)}<a href="ListePersonne.dc.html" style="height: 44px; box-sizing: border-box; padding: 0 14px; border: 1px dashed #cdb48a; border-radius: 999px; color: #8a2f27; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px">{PLUS}Quelqu’un d’autre</a></div>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">{hint}</p>
    </section>'''
_h,_a,_b=B['ListeNouvelle']; _n=len(re.findall(r'<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px.*?</section>',_h,flags=re.S)); assert _n==1
B['ListeNouvelle']=(re.sub(r'<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px.*?</section>',lambda m:addwho(['Léo','Zoé','Hugo','Camille']),_h,flags=re.S),_a,_b)
_h,_a,_b=B['ListeTeneur']; _r=r'<a href="ListeNouvelle.dc.html" style="align-self: flex-start; min-height: 44px;[^>]*>.*?Ajouter une personne</a>'; assert len(re.findall(_r,_h,flags=re.S))==1
B['ListeTeneur']=(re.sub(_r,lambda m:addwho([]),_h,flags=re.S),_a,_b)

# ===== Choix d'icône : panneau bas, symboles qui défilent sur le côté, couleurs dessous
def hblock(t,es,btn,on=None,note=''):
    return f'''<section style="flex-shrink: 0; display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; padding: 0; white-space: nowrap">{t}{f' <span style="font-weight: 600; text-transform: none; letter-spacing: 0">· {note}</span>' if note else ''}</h2><div style="display: grid; grid-auto-flow: column; grid-template-rows: repeat(3, 44px); grid-auto-columns: 44px; gap: 8px">{"".join(btn(e,e==on) for e in es)}</div></section>'''
def lowpanel(back,label,preview,h1,blocks,colors,cancel):
    return HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  <div aria-hidden="true" style="flex-grow: 1; padding: 20px 16px; box-sizing: border-box; font-family: {F}; font-weight: 700; font-size: 30px; color: #5c554c">{back}</div>
  <section aria-label="{label}" style="flex-shrink: 0; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 0 0; display: flex; flex-direction: column; gap: 14px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; align-items: center; gap: 12px; padding: 0 16px">
      {preview}
      <h1 style="flex-grow: 1; margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.15">{h1}</h1>
      <button aria-label="Au hasard" style="width: 44px; height: 44px; flex-shrink: 0; padding: 0; border: 1px solid #dccbad; border-radius: 50%; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center">{ic('<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',20)}</button>
    </div>
    <div style="position: relative">
      <div role="radiogroup" aria-label="Symbole" style="display: flex; gap: 20px; padding: 4px 16px 6px; overflow: hidden">{blocks}</div>
      <span aria-hidden="true" style="position: absolute; top: 0; right: 0; bottom: 0; width: 36px; background: linear-gradient(to right, rgba(255, 253, 249, 0), #fffdf9)"></span>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px; padding: 12px 16px 0; border-top: 1px solid #e9dcc5">
      <h2 style="{H2}; padding: 0">Couleur</h2>
      <div role="radiogroup" aria-label="Couleur" style="display: flex; justify-content: space-between">{colors}</div>
    </div>
    <div style="border-top: 1px solid #dccbad; padding: 12px 16px 20px; display: grid; grid-template-columns: 1fr 2fr; gap: 10px">
      <a href="{cancel}" style="height: 48px; border: 1px solid #dccbad; box-sizing: border-box; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Valider</button>
    </div>
  </section>
</div>
'''+TAIL
_pv='<span aria-hidden="true" style="width: 56px; height: 56px; border-radius: 50%; background: #d6e6ef; box-shadow: 0 0 0 1px #94bbd0; display: flex; align-items: center; justify-content: center; font-size: 28px; flex-shrink: 0">🚀</span>'
_pb=hblock('Enfants et jeux',['🚀','🦄','🧸','🪀','⚽','🎨','🚲','🎲','🛹','🎮','🪄','🎈'],eb,'🚀')+hblock('Personnages',['🎅','🤶','🧑‍🎄','🧝','👼','⛄','🧚','🦸','🧙','🤴','👸','🥷'],eb)+hblock('Animaux',['🦌','🐧','🦊','🦉','🐻','🐿️','🦔','🐺','🐇'],eb)
B['PanneauAvatarGrand']=(re.sub(r'<title>[^<]*</title>','<title>Choisir l’icône d’une personne — proposition</title>',lowpanel('Léo','Son icône',_pv,'L’icône de Léo',_pb,"".join(cb(c,c=="frost") for c in SH),'#')),844,'Proposition · l’icône d’une personne, pour beaucoup d’icônes')
_lb=hblock('Noël et hiver',['❄️','🎄','🎁','⭐','🕯️','☃️','🔔','🧦','🦌','🎅','🌨️','🏔️'],eq,'❄️')+hblock('Anniversaires et fêtes',['🎂','🎈','🎉','🎊','🥂','🍾','🧁','🪅','🎵','💃','🪩','🎇'],eq)+hblock('Grands moments',['👶','🍼','💍','💐','🎓','🏡','🔑','✈️','🎒'],eq)+hblock('Saisons',['🌸','🐣','🌷','☀️','🏖️','🍉','🍂','🎃','🍄'],eq)
B['ListeIcone']=(re.sub(r'<title>[^<]*</title>','<title>Listes — icône de la liste</title>',lowpanel('Nouvelle liste','L’icône de la liste',tile('❄️','nuit',56),'L’icône de la liste',_lb,"".join(sw2(c,c=="nuit") for c in LC),'ListeNouvelle.dc.html')),844,'Choisir l’icône de la liste')

# ===== Un cadeau à plusieurs : la ligne à 1, 3, 7 participants, au complet ; les panneaux
PP.update({'Toi':('🦊','#f3d3cc','#e09e92'),'Papi':('🎺','#f6e3ad','#e6b94a'),'Tata':('🌻','#cfe2d3','#8db898'),'Inès':('🐱','#ead2e2','#c493b4'),'Marc':('🚲','#d6e6ef','#94bbd0'),'Lou':('🦉','#ecdfc6','#cdb48a')})
def stack(names,more=0):
    o=''
    for i,n in enumerate(names):
        e,bg,bd=PP[n]; o+=f'<span aria-hidden="true" style="width: 26px; height: 26px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 2px #f7f2e9; display: flex; align-items: center; justify-content: center; font-size: 13px;{" margin-left: -7px;" if i else ""}">{e}</span>'
    if more: o+=f'<span aria-hidden="true" style="height: 26px; min-width: 26px; padding: 0 6px; box-sizing: border-box; border-radius: 999px; background: #e9dcc5; box-shadow: 0 0 0 2px #f7f2e9; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #57534e; margin-left: -7px">+{more}</span>'
    return f'<span style="display: flex; flex-shrink: 0">{o}</span>'
def gline(kind,text,names,more,who,action,href):
    st='color: #78716c; text-decoration: line-through' if kind=='taken' else ('color: #292524; font-weight: 600' if kind=='mine' else 'color: #292524')
    act={'join':f'<span style="{A}; font-size: 14px; font-weight: 700; flex-shrink: 0">Se joindre</span>','in':'<span style="font-size: 14px; font-weight: 700; color: #274e34; flex-shrink: 0">Tu participes</span>','':''}[action]
    return f'''<li><a href="{href}" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none">{box(kind)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px"><span style="font-size: 16px; line-height: 1.45; {st}">{text}</span><span style="display: flex; align-items: center; gap: 8px">{stack(names,more)}<span style="flex-grow: 1; min-width: 0; font-size: 13px; line-height: 1.35; color: #57534e">{who}</span>{act}</span></span></a></li>'''
B['ListePlusieursLigne']=(page(960,dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[
    dline('taken','Déguisement de pompier (taille 6 ans)'),
    gline('group','Vélo 16 pouces',['Mamie'],0,'Mamie l’offre, et propose de partager','join','ListeRejoindre.dc.html'),
    gline('mine','Cabane en bois pour le jardin',['Mamie','Tonton','Toi'],0,'Mamie, Tonton et toi','in','ListePlusieursOuvreur.dc.html'),
    gline('group','Console de jeux : '+lk('lien'),['Papi','Tata','Inès'],4,'7 personnes','join','ListeRejoindreSept.dc.html'),
    gline('taken','Trampoline',['Marc','Lou','Papi'],2,'Offert à plusieurs · au complet','','#'),
    dline('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)','','ListeReserver.dc.html'),
    dline('add','J’offre autre chose à Léo','','ListeHorsListe.dc.html')],False),'Listes — un cadeau à plusieurs, sur la ligne'),960,'Sur la ligne : à 1, à 3, à 7, au complet')
def prow(n,note='',tag='',top=True):
    t=f'<span style="height: 22px; padding: 0 8px; border-radius: 999px; background: #f1e8d8; color: #57534e; font-size: 12px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">{tag}</span>' if tag else ''
    nn=f'<span style="font-size: 14px; color: #57534e">{note}</span>' if note else ''
    return f'''<li style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 6px 14px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}">{av(n)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span>{nn}</span>{t}</li>'''
PUL='list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden'
B['ListeRejoindreSept']=(sheet(96,'Se joindre',sh('La console, à plusieurs','Pour Léo · 7 personnes participent')+f'''
    <ul style="{PUL}">{prow('Papi','« Je m’en occupe, dites-moi si vous en êtes. »','A ouvert',False)}{prow('Tata')}{prow('Inès','« Avec plaisir ! »')}{prow('Marc')}{prow('Lou')}{prow('Mamie')}{prow('Tonton')}</ul>
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #fbf0cf; color: #5b430f; font-size: 14px; line-height: 1.45">En te joignant, <strong style="font-weight: 700">ton prénom sera visible</strong> de ceux qui ouvrent la liste. Vous vous arrangez entre vous pour l’argent.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Je participe</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Pas cette fois</a></div>''','Listes — se joindre à sept'),844,'Se joindre quand ils sont déjà sept')
B['ListePlusieursOuvreur']=(sheet(150,'Ton cadeau à plusieurs',sh('Le vélo, à plusieurs','Pour Léo · c’est toi qui l’as proposé')+f'''
    <ul style="{PUL}">{prow('Toi','« Je l’achète, on partage ? »','Toi',False)}{prow('Tonton')}{prow('Tata','« J’en suis. »')}</ul>
    <div style="padding: 4px 14px; border: 1px solid #dccbad; border-radius: 12px">{sw('On est au complet','La ligne sera barrée et plus personne ne pourra se joindre.',False)}</div>
    <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Si personne ne se joint à toi, le vélo reste à toi : il compte comme un cadeau prévu.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Terminé</button><a href="#" style="height: 46px; color: #8a2f27; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement, je ne l’offre plus</a><p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Tonton et Tata restent : le vélo passe à Tonton.</p></div>''','Listes — le cadeau à plusieurs, vu par celui qui l’a proposé'),844,'Vu par celui qui l’a proposé : fermer le groupe')

# ===== Cocher sans panneau : la ligne « Changer », et le panneau devenu réglage
NO='<a href="#" style="height: 46px; color: #8a2f27; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement, je ne l’offre plus</a>'
RG=lambda solo:f'<div role="radiogroup" aria-label="Comment" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">{radio("Je l’offre seul","Les autres voient seulement que c’est pris",solo,False)}{radio("On l’offre à plusieurs","D’autres pourront se joindre à toi",not solo)}</div>'
B['ListeReserver']=(sheet(190,'Ton cadeau',sh('Le circuit de billes, c’est noté','Pour Léo · tu l’offres')+f'''
    {RG(True)}
    {sw('Dire à Camille que c’est moi','Elle tient la liste. Sinon, elle verra « Anonyme ».',True)}
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; font-size: 14px; line-height: 1.45">Personne d’autre ne saura que c’est toi.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Terminé</button>{NO}</div>''','Listes — changer la façon d’offrir'),844,'« Changer » : seul ou à plusieurs, avec ou sans prénom')
B['ListeReserverPlusieurs']=(sheet(170,'Ton cadeau, à plusieurs',sh('Le vélo, à plusieurs','Pour Léo · tu proposes de partager')+f'''
    {RG(False)}
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fbf0cf; color: #5b430f"><span style="display: flex; margin-top: 2px">{USERS}</span><p style="margin: 0; font-size: 14px; line-height: 1.45"><strong style="font-weight: 700">Ton prénom sera visible</strong> de ceux qui ouvrent la liste, pour qu’ils puissent se joindre à toi. Vous vous arrangez entre vous pour l’argent.</p></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="w" style="{LAB}">Un mot pour eux <span style="font-weight: 500; color: #57534e">(facultatif)</span></label><input id="w" value="Je l’achète, on partage ?" style="{INP}"></div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Proposer de partager</button>{NO}</div>''','Listes — proposer un cadeau à plusieurs'),844,'« Changer » : proposer le cadeau à plusieurs')
def doc_visitor2(mine):
    who='<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La liste de Camille et Hugo. '+('Tu offres 2 cadeaux : seule Camille sait que c’est toi.' if mine else 'Camille seule voit qui a coché quoi.')+'</p>'
    ch=f'Tu l’offres · seul, sous ton prénom · <span style="{A}; font-weight: 700">Changer</span>'
    leo=[dline('mine','Circuit de billes, le grand modèle : '+lk('lien'),ch,'ListeReserver.dc.html') if mine else dline('free','Circuit de billes, le grand modèle : '+lk('lien')),
      dline('taken','Déguisement de pompier (taille 6 ans)'),
      gline('mine','Vélo 16 pouces',['Mamie','Tonton','Toi'],0,'Mamie, Tonton et toi','in','ListeRejoindre.dc.html') if mine else gline('group','Vélo 16 pouces',['Mamie','Tonton'],0,'Mamie et Tonton','join','ListeRejoindre.dc.html'),
      dline('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),
      dline('taken','Un cadeau surprise, hors liste'),
      dline('add','J’offre autre chose à Léo','','ListeHorsListe.dc.html')]
    zoe=[dline('free','Poupée en tissu'),dline('taken','Draisienne : '+lk('lien')),dline('free','Des livres cartonnés, toujours'),dline('add','J’offre autre chose à Zoé','','ListeHorsListe.dc.html')]
    cam=[dline('free','Un bon couteau de cuisine'),dline('free','Une carte cadeau pour un week-end'),dline('add','J’offre autre chose à Camille','','ListeHorsListe.dc.html')]
    h=dhead(INTRO,who)+dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',leo)+dperson('Zoé','🦄','3 ans · taille 3 ans',zoe)+dperson('Camille','🦌','',cam)
    _m='Noël 2026</h1>'; assert h.count(_m)==1
    return h.replace(_m,_m+DATE)
B['ListeVisiteur']=(page(1600,doc_visitor2(False),'Listes — la liste, vue avec le lien'),1600,'La liste, vue avec le lien')
B['ListeVisiteurMes']=(page(1600,doc_visitor2(True),'Listes — après avoir coché'),1600,'Après avoir coché : c’est fait, sans panneau')
order=['ListesAccueil','ListesVide','ListeIcone','PanneauAvatarGrand','ListeNouvelle','ListeTeneur','ListeIdee','ListePersonne','ListePartager','ListeVisiteur','ListeConnexion','ListeReserver','ListeReserverPlusieurs','ListeRejoindre','ListeVisiteurMes','ListeHorsListe','ListePlusieursLigne','ListeRejoindreSept','ListePlusieursOuvreur']
for k in ([] if globals().get('NO_WRITE') else order):  # NO_WRITE : ne prendre que les outils, sans réécrire les maquettes V1
    open(PJ+k+'.dc.html','w').write(B[k][0]); shutil.copy(PJ+k+'.dc.html',f'{out}/{k}.html')
print(json.dumps([{"as":f"project/{k}.dc.html","path":f"{PJ}{k}.dc.html"} for k in order]))
print(json.dumps([(k,B[k][1],B[k][2]) for k in order],ensure_ascii=False))
