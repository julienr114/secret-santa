# Listes, V2 (19 novembre 2026) : temps réel, à plusieurs, personne reliée à un compte, plus de barre au-dessus du clavier,
# cadeau hors liste écrit sur place, reprendre une liste.
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
V={}
TRASH=ic('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',18)
X=ic('<path d="M6 6l12 12M18 6 6 18"/>',16,2.4); OK=ic('<path d="m5 12 5 5 9-10"/>',16,2.6)
def tagp(t): return f'<span style="display: inline-flex; align-items: center; height: 22px; padding: 0 8px; margin-left: 6px; border-radius: 999px; background: #e6b94a; color: #3d2c08; font-size: 12px; font-weight: 700; white-space: nowrap; text-decoration: none; vertical-align: 1px">{t}</span>'
def flash(kind,text,who='',tag='',note=''):
    st={'free':'color: #292524','taken':'color: #78716c; text-decoration: line-through','mine':'color: #292524; font-weight: 600'}[kind]
    n=f'<span style="display: block; font-size: 13px; line-height: 1.35; color: #5b430f; font-weight: 600">{note}</span>' if note else ''
    return f'''<li style="margin: 0 -16px 0 -36px; padding: 0 16px 0 36px; background: #fbf0cf"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box">{box(kind)}<span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45"><span style="{st}">{text}</span>{by(who) if who else ''}{tagp(tag) if tag else ''}{n}</span></div></li>'''
def locked(text,who):
    return f'''<li aria-disabled="true"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box"><span style="opacity: 0.4; display: flex">{box('free')}</span><span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45; color: #57534e">{text}<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: #f4b82e; vertical-align: -4px; margin-left: 1px"></span><span style="display: inline-flex; align-items: center; gap: 4px; height: 20px; padding: 0 7px 0 3px; margin-left: 2px; border-radius: 4px 999px 999px 4px; background: #f4b82e; color: #2b1b3d; font-size: 11px; font-weight: 700; vertical-align: 2px"><span aria-hidden="true" style="font-size: 11px; line-height: 1">{PP[who][0]}</span>{who}</span></span></div></li>'''
def dot(n,s=28):
    return f'<span style="position: relative; display: flex">{av(n,s)}<span aria-hidden="true" style="position: absolute; right: -2px; bottom: -2px; width: 10px; height: 10px; border-radius: 50%; background: #2f613f; box-shadow: 0 0 0 2px #f7f2e9"></span></span>'
HOLD=f'''<a href="ListeTeneurs.dc.html" style="min-height: 44px; display: flex; align-items: center; gap: 10px; text-decoration: none; color: #292524"><span style="display: flex">{av('Camille',28)}<span style="margin-left: -6px; display: flex">{dot('Hugo')}</span></span><span style="flex-grow: 1; font-size: 14px; line-height: 1.35">Tu tiens cette liste avec <strong style="font-weight: 700">Hugo</strong>. Il est là en ce moment.</span><span style="color: #78716c; display: flex">{CHEV}</span></a>'''
PP.setdefault('Hugo',('🐧','#f6e3ad','#e6b94a'))
# 1. temps réel, chez celui qui tient la liste
V['ListeLiveTeneur']=(page(1040,state(True)+HOLD+dhead(INTRO).replace('Noël 2026</h1>','Noël 2026</h1>'+DATE)
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('taken','Circuit de billes, le grand modèle : '+lk('lien'),'Mamie'),
     tl('taken','Livres sur les dinosaures (il les a presque tous, demandez-nous)','Tonton'),
     tl('group','Vélo 16 pouces','Mamie, Tonton','Offert à plusieurs'),
     locked('Un télescope pour enf','Hugo'),ghost('Léo')])
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[tl('free','Poupée en tissu'),tl('taken','Draisienne : '+lk('lien'),'Mamie'),ghost('Zoé')]),'Listes — en direct, pour celui qui tient la liste'),1040,'En direct, chez celui qui tient la liste')
# 3. tenir la liste à plusieurs
def hrow(n,sub,right='',top=True,present=False):
    return f'''<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}">{dot(n,40) if present else av(n,40)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span>{right}</li>'''
MAIL=ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',20)
V['ListeTeneurs']=(page(900,titles('Listes · Noël 2026','Ceux qui tiennent la liste','Vous êtes à égalité : chacun écrit les idées, partage le lien et voit qui offre quoi.')+f'''
    <ul style="{UL}">{hrow('Camille','C’est toi','',False)}{hrow('Hugo','Là en ce moment',f'<a href="#" style="min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Retirer</a>',True,True)}
      <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5"><span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{MAIL}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">mamie-demo@example.com</span><span style="font-size: 13px; color: #57534e">Invitée le 18 novembre · pas encore venue</span></span><a href="#" style="min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Annuler</a></li></ul>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="{LAB}">Inviter quelqu’un à tenir la liste</label><div style="display: flex; gap: 8px"><input id="e" type="email" placeholder="son@adresse.fr" style="{INP}; flex: 1; min-width: 0"><button style="height: 48px; padding: 0 16px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Inviter</button></div><p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Il reçoit un email. La liste apparaît dans ses listes dès qu’il se connecte.</p></div>
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; font-size: 14px; line-height: 1.45">Ceux qui tiennent la liste voient tout, y compris ce qu’on leur offre s’ils y figurent.</p>''','Listes — ceux qui tiennent la liste'),900,'Tenir la liste à plusieurs')
# 4. relier une personne à un compte
def pt(t): return f'<li style="display: flex; align-items: flex-start; gap: 10px; font-size: 15px; line-height: 1.45"><span aria-hidden="true" style="width: 6px; height: 6px; border-radius: 50%; background: #2f613f; margin-top: 8px; flex-shrink: 0"></span>{t}</li>'
V['ListePersonneCompte']=(page(900,f'''<div style="display: flex; align-items: center; gap: 14px">{av('Hugo',64)}<div style="display: flex; flex-direction: column; gap: 2px"><p style="margin: 0; font-size: 14px; color: #57534e">Ma famille</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Hugo</h1></div></div>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Son compte</h2>
      <ul style="{UL}"><li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box"><span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{LINK}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">hugo-demo@example.com</span><span style="font-size: 13px; color: #57534e">Relié à son compte</span></span><a href="#" style="min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Ne plus relier</a></li></ul>
      <ul style="list-style: none; margin: 4px 0 0; padding: 0 4px; display: flex; flex-direction: column; gap: 8px">{pt('Sur tes listes, Hugo peut <strong style="font-weight: 700">écrire ses propres idées</strong>.')}{pt('Pour le reste, il voit la liste comme tout le monde.')}{pt('Il ne tient pas la liste pour autant : il ne voit pas qui offre quoi.')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Pour un enfant</h2><p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: #57534e">Pas besoin de compte : laisse ce champ vide, comme pour Léo et Zoé.</p></section>''','Listes — une personne reliée à son compte'),900,'Relier une personne à son compte')
# 5. ce que voit la personne reliée
def own(text): return f'''<li><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box"><span aria-hidden="true" style="width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px"><span style="width: 7px; height: 7px; border-radius: 50%; background: #a8a29e"></span></span><span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45">{text}</span></div></li>'''
def ghostme(): return ghost('moi',True).replace('Une idée pour moi…','Une autre idée pour moi…').replace('border: 2px solid #dccbad','border: 0')
V['ListeVueReliee']=(page(1100,dhead(INTRO,'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La liste de Camille. Tu y figures : tu peux écrire tes propres idées.</p>').replace('Noël 2026</h1>','Noël 2026</h1>'+DATE)
  +dperson('Hugo','🐧','C’est toi',[dline('taken','Un bon couteau de cuisine'),dline('free','Le dernier roman de mon auteur préféré : '+lk('lien')),ghost('moi',True).replace('Une idée pour moi…','Une autre idée pour moi…')],False)
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[dline('mine','Circuit de billes, le grand modèle : '+lk('lien'),f'Tu l’offres · seul, sous ton prénom · <span style="{A}; font-weight: 700">Changer</span>','ListeReserver.dc.html'),dline('taken','Déguisement de pompier (taille 6 ans)'),dline('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),dline('add','J’offre autre chose à Léo','','ListeHorsListe.dc.html')],False)
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[dline('free','Poupée en tissu'),dline('taken','Draisienne : '+lk('lien')),dline('add','J’offre autre chose à Zoé','','ListeHorsListe.dc.html')],False),'Listes — la liste, pour quelqu’un qui y figure'),1100,'La liste, vue par quelqu’un qui y figure')
# 6. écrire une idée : les actions sous la ligne, plus rien au-dessus du clavier
KB2=KB[:KB.index('<div role="toolbar"')]+KB[KB.index('<div aria-hidden="true" style="background: #d6d0c6'):]
def chipa(t,i='',c='#8a2f27'): return f'<button style="min-height: 32px; padding: 0; border: 0; background: transparent; color: {c}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 5px; text-decoration: underline; text-underline-offset: 3px">{t}</button>'
def writing(text,under):
    return f'''<li style="margin: 0 -16px 0 -36px; padding: 0 16px 10px 36px; background: #fffdf9; box-shadow: inset 3px 0 0 #b8483a"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0 6px; box-sizing: border-box">{box('free')}<span role="textbox" aria-label="Une idée pour Léo" style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45">{text}</span></div><div style="padding-left: 34px">{under}</div></li>'''
def phone(main,title):
    s=HEAD+f'''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; overflow: hidden">
  {header()}
  <main style="flex-grow: 1; min-height: 0; overflow: hidden; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 0">
    {main}
  </main>
  {KB2}
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
ROW=f'<div role="group" aria-label="Cette ligne" style="display: flex; gap: 18px">{chipa("Ajouter un lien")}</div>'
V['ListeIdee']=(phone(dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),tl('taken','Hors liste : un jeu de société','Tonton'),writing('Puzzle 100 pièces, avec des dinosaures'+CARET,ROW),ghost('Léo')]),'Listes — écrire une idée dans la liste'),844,'Écrire une idée : les actions sous la ligne')
# le lien est à part du texte (Julien, 19 novembre 2026) : une idée = un texte, et un lien au plus, écrit « lien » en fin de ligne
GH='<span style="color: #a8a29e; text-decoration: underline; text-underline-offset: 3px">colle ou écris l’adresse</span>'
ROWL=f'<div role="group" aria-label="Le lien" style="display: flex; gap: 18px">{chipa("Annuler","","#57534e")}</div>'
V['ListeIdeeLien']=(phone(dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),writing('Puzzle 100 pièces, avec des dinosaures : '+CARET+GH,ROWL),ghost('Léo')]),'Listes — ajouter un lien, dans la ligne'),844,'« Ajouter un lien » : l’adresse se colle au bout de la ligne')
ROWF=f'<div role="group" aria-label="Cette ligne" style="display: flex; gap: 18px">{chipa("Changer le lien")}{chipa("Retirer le lien","","#57534e")}</div>'
V['ListeIdeeLienFait']=(phone(dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[tl('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),writing('Puzzle 100 pièces, avec des dinosaures'+CARET+' : '+lk('lien'),ROWF),ghost('Léo')]),'Listes — le lien posé au bout de la ligne'),844,'L’adresse collée devient le mot « lien », à part du texte')
# 7. j'offre autre chose : écrit sur place
def writing_mine(text,under):
    return f'''<li style="margin: 0 -16px 0 -36px; padding: 0 16px 10px 36px; background: #fffdf9; box-shadow: inset 3px 0 0 #2f613f"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0 6px; box-sizing: border-box">{box('mine')}<span role="textbox" aria-label="Ce que tu offres à Léo" style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45; font-weight: 600">{text}</span></div><div style="padding-left: 34px; display: flex; flex-direction: column; gap: 8px">{under}</div></li>'''
V['ListeHorsListe']=(phone(dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[dline('taken','Déguisement de pompier (taille 6 ans)'),dline('free','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),
   writing_mine('Un jeu de société'+CARET,f'<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Camille lira ces mots. Les autres verront seulement « Un cadeau surprise, hors liste ».</p>')],False),'Listes — offrir autre chose, écrit sur place'),844,'« J’offre autre chose » : écrit sur place, sans panneau')
# 8. reprendre une liste
def lchip(e,c,t,sub): return f'<a href="ListeReprise.dc.html" style="min-height: 56px; padding: 8px 14px 8px 8px; border: 1px solid #dccbad; border-radius: 14px; background: #fffdf9; color: #292524; text-decoration: none; display: flex; align-items: center; gap: 10px">{tile(e,c,40)}<span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 700">{t}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a>'
_n=B['ListeNouvelle'][0]; _k='<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px; border-top: 1px solid #dccbad">'; assert _n.count(_k)==1
_rep=f'''<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px; border-top: 1px solid #dccbad">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Repartir d’une liste</h2>
      {lchip('❄️','sapin','Noël 2025','4 personnes · 6 idées pas encore offertes')}{lchip('🎂','moutarde','Les 6 ans de Léo','1 personne · 3 idées pas encore offertes')}
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Tu reprends les personnes et les idées qui n’ont pas été cochées. L’ancienne liste ne change pas.</p>
    </section>
    '''
V['ListeNouvelleReprendre']=(re.sub(r'<title>[^<]*</title>','<title>Listes — une nouvelle liste, ou repartir d’une ancienne</title>',_n.replace(_k,_rep+_k).replace('width: 390px; height: 844px','width: 390px; height: 1090px',1)),1090,'Nouvelle liste : repartir d’une ancienne')
RE='<svg aria-label="Reprise de Noël 2025" role="img" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#a8a29e" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px; vertical-align: -1px"><path d="M3 12a9 9 0 1 0 3-6.700M3 4v5h5"/></svg>'
def kept(text): return tl('free',text+RE)
_head=f'''<div style="display: flex; flex-direction: column; gap: 10px">
      {tile('❄️','sapin',72)}
      <h1 role="textbox" aria-label="Nom de l’événement" style="margin: 4px 0 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1; color: #a8a29e"><span aria-hidden="true" style="display: inline-block; width: 2px; height: 32px; background: #b8483a; vertical-align: -5px; margin-right: 2px"></span>Nom de l’événement</h1>
      <a href="#" style="align-self: flex-start; min-height: 32px; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: #8a2f27; text-decoration: none">Ajouter une date</a>
      <p style="margin: 0; font-size: 16px; line-height: 1.5">{INTRO}</p>
    </div>
    <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Reprise de Noël 2025. Les idées marquées {RE.replace('margin-left: 6px; ','')} n’avaient pas été offertes : garde-les ou efface-les. Toi seul vois cette marque, elle disparaît au partage.</p>'''
V['ListeReprise']=(page(1500,state(False)+_head
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[kept('Livres sur les dinosaures (il les a presque tous, demandez-nous)'),kept('Un télescope pour enfant'),tl('free','Puzzle 100 pièces, avec des dinosaures'),ghost('Léo')])
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[kept('Poupée en tissu'),kept('Des livres cartonnés, toujours'),ghost('Zoé')])
  +dperson('Camille','🦌','Moi',[kept('Une carte cadeau pour un week-end'),ghost('Camille')])
  +dperson('Hugo','🐧','',[kept('Un bon couteau de cuisine'),ghost('Hugo')])+addwho([]),'Listes — une liste reprise d’une ancienne'),1500,'La liste reprise : une marque discrète sur les idées reprises')
import json
names=json.load(open('/tmp/names.json'))
for k,(h,ht,title) in V.items():
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
print(list(V))
