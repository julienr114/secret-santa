# En direct : la ligne que quelqu'un écrit est teintée à sa couleur, son icône et son prénom à droite (piste C, choisie par Julien le 19 novembre 2026).
# Plus d'étiquette collée au curseur. À lancer après proches.py.
import re,json,os
PJ='/home/claude/utt/project/'
h=open(PJ+'ListeLiveTeneur.dc.html').read()
k=h.index('Un télescope'); a=h.rindex('<li',0,k); b=h.index('</li>',k)+5
BG,RG='#f6e3ad','#e6b94a'
new=(f'<li aria-disabled="true" data-live="c"><div style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; margin: 0 -10px; padding: 10px; box-sizing: border-box; border-radius: 12px; background: #fbf0cf">'
 '<span style="opacity: 0.4; display: flex"><span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; flex-shrink: 0; margin-top: 1px; border: 2px solid #a8a29e; background: #fffdf9"></span></span>'
 f'<span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45; color: #57534e">Un télescope pour enf<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: {RG}; vertical-align: -4px; margin-left: 1px"></span>'
 # sous le texte : son icône et « Hugo écrit… » (les pistes C et A mêlées, Julien, 19 novembre 2026)
 f'<span style="display: flex; align-items: center; gap: 6px; margin-top: 4px; font-size: 13px; line-height: 1.35; font-weight: 700; color: #5b430f"><span aria-hidden="true" style="width: 18px; height: 18px; border-radius: 50%; background: {BG}; box-shadow: 0 0 0 1.5px {RG}; display: flex; align-items: center; justify-content: center; font-size: 10px; flex-shrink: 0">🐧</span>Hugo écrit…</span></span></div></li>')
h=h[:a]+new+h[b:]; open(PJ+'ListeLiveTeneur.dc.html','w').write(h)
if os.path.exists(PJ+'ListeLiveVariantes.dc.html'): os.remove(PJ+'ListeLiveVariantes.dc.html')
n=[x for x in json.load(open('/tmp/names.json')) if x!='ListeLiveVariantes.dc.html']; json.dump(n,open('/tmp/names.json','w')); print('ok')
