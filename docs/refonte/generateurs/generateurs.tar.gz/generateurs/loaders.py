import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
SPIN = lambda size=20, color='currentColor': f'<svg aria-hidden="true" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="2.4" stroke-linecap="round"><path d="M21 12a9 9 0 1 1-6.200-8.600"/></svg>'
def one(t, a, b):
    assert t.count(a) == 1, a[:70]; return t.replace(a, b)
def sub_between(t, start, end, new):
    i = t.index(start); j = t.index(end, i) + len(end); return t[:i] + new + t[j:]
SK = lambda w, h, bg='#f1e8d8', r=8: f'<span style="display: block; width: {w}; height: {h}px; border-radius: {r}px; background: {bg}"></span>'

# 1. Un bouton qui travaille : le tirage
t = (P/'ConfirmerTirage.dc.html').read_text()
t = sub_between(t, '<button style="width: 100%; height: 52px;', '</button>', f'<button aria-busy="true" disabled style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; opacity: 0.75; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 10px">{SPIN()}Tirage en cours…</button>')
t = one(t, 'color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Pas encore</a>', 'color: #292524; opacity: 0.4; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center" aria-disabled="true">Pas encore</a>')
save('ChargementBouton.dc.html', t, 'Chargement — un bouton qui travaille')

# 2. Un panneau dont le contenu arrive : le message à envoyer
t = (P/'Envoi.dc.html').read_text()
t = sub_between(t, '<div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px;', '</div>', f'<div aria-busy="true" aria-label="Chargement du message" style="align-self: flex-start; width: 92%; box-sizing: border-box; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 14px; display: flex; flex-direction: column; gap: 10px">{SK("100%", 12, "#e3d5bb")}{SK("86%", 12, "#e3d5bb")}{SK("55%", 12, "#e3d5bb")}</div>')
t = one(t, '<button style="width: 100%; min-height: 56px; padding: 6px 12px; border: 0; border-radius: 6px; background: #b8483a;', '<button disabled style="width: 100%; min-height: 56px; padding: 6px 12px; border: 0; border-radius: 6px; opacity: 0.5; background: #b8483a;')
t = t.replace('<button style="height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent;', '<button disabled style="height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; opacity: 0.5; background: transparent;')
save('ChargementPanneau.dc.html', t, 'Chargement — le contenu d’un panneau')

# 3. Un envoi groupé
t = (P/'SelectionEmail.dc.html').read_text()
t = sub_between(t, '<button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a;', '</button>', f'<button aria-busy="true" disabled style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; opacity: 0.75; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 10px">{SPIN()}Envoi des 2 emails…</button>')

i = t.index('<main'); j = t.index('>', i)
tag = t[i:j]
assert 'style="' in tag
t = t[:i] + tag.replace('style="', 'aria-disabled="true" style="opacity: 0.5; ', 1) + t[j:]
save('ChargementEnvoi.dc.html', t, 'Chargement — un envoi groupé')

# 4. Un réglage qui s'enregistre
t = (P/'GroupeReglages.dc.html').read_text()
t = one(t, '<span style="font-size: 15px; color: #57534e; flex-shrink: 0; max-width: 150px; text-align: right">Que l’an dernier</span><span style="color: #78716c; display: flex; flex-shrink: 0">', '<span style="font-size: 15px; color: #57534e; flex-shrink: 0; max-width: 170px; text-align: right">Que les 2 dernières années</span><span role="status" aria-label="Enregistrement" style="color: #a43a2f; display: flex; flex-shrink: 0">' + SPIN(20) + '</span><span hidden style="display: none">')
t = one(t, '<button role="switch" aria-checked="true" aria-label="Listes de souhaits" style="width: 48px; height: 44px; padding: 0; border: 0; background: transparent; display: flex; align-items: center; flex-shrink: 0"><span style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; display: flex; align-items: center"><span style="width: 24px; height: 24px; border-radius: 50%; background: #ffffff; margin-left: 20px"></span></span></button>',
  '<button role="switch" aria-checked="false" aria-busy="true" aria-label="Listes de souhaits" style="width: 48px; height: 44px; padding: 0; border: 0; background: transparent; display: flex; align-items: center; flex-shrink: 0"><span style="width: 48px; height: 28px; border-radius: 999px; background: #a8a29e; opacity: 0.7; display: flex; align-items: center"><span style="width: 24px; height: 24px; border-radius: 50%; background: #ffffff; margin-left: 4px; display: flex; align-items: center; justify-content: center">' + SPIN(14, '#57534e') + '</span></span></button>')
save('ChargementReglage.dc.html', t, 'Chargement — un réglage qui s’enregistre')

# 5. Une liste qui arrive : les membres
t = (P/'GroupeMembres.dc.html').read_text()
i = t.index('<main'); j = t.index('</main>') + 7
rowsk = lambda first=False: f'<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{"" if first else " border-top: 1px solid #e9dcc5;"}"><span style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; flex-shrink: 0"></span><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 8px">{SK("45%", 14)}{SK("65%", 10)}</span></li>'
main = f'''<main aria-busy="true" aria-label="Chargement" style="display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 32px">
    <div style="display: flex; flex-direction: column; gap: 8px">{SK("50%", 34, "#e9dcc5")}{SK("35%", 16, "#e9dcc5")}</div>
    <ul style="{LIST}">{''.join(rowsk(k == 0) for k in range(6))}</ul>
  </main>'''
save('ChargementListe.dc.html', t[:i] + main + t[j:], 'Chargement — une liste', 844)

cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
B['EtatChargement.dc.html']['title'] = 'Chargement d’un écran'
names = [('ChargementListe', 'Chargement d’une liste'), ('ChargementPanneau', 'Le contenu d’un panneau arrive'), ('ChargementBouton', 'Un bouton qui travaille'), ('ChargementEnvoi', 'Un envoi groupé en cours'), ('ChargementReglage', 'Un réglage qui s’enregistre')]
if 'ChargementListe.dc.html' not in B:
    B['EtatErreur.dc.html']['x'] = 470 * 6
    for k, (n, ti) in enumerate(names):
        f = n + '.dc.html'
        B[f] = {'x': 470 * (k + 1), 'y': 0, 'w': 390, 'h': OUT[f], 'title': ti, 'page': 'divers'}
        cv['order'].insert(cv['order'].index('EtatErreur.dc.html'), f)
    mh = max(B[n + '.dc.html']['h'] for n, _ in names)
    shift = max(0, mh + 420 - 1264)
    for k, v in B.items():
        if v['page'] == 'divers' and v['y'] == 1264: v['y'] += shift
    cv['notes']['t21']['y'] += shift; cv['notes']['t20']['maxW'] = 470 * 7 - 80
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)
