import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
def rep(t, pairs):
    for a, b in pairs:
        assert t.count(a) >= 1, a[:80]
        t = t.replace(a, b)
    return t
CHECK = ic('<path d="M20 6 9 17l-5-5"/>', 14, 2.5).replace('currentColor', '#2f613f')
CLOCK = ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 14, 2.2)
ALERT = ic('<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17h.01"/>', 14, 2.2)
MAIL = ic('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>', 18, 2)
SEND = lambda n, done=False: (f'<button aria-label="Écrire à {n}" style="width: 44px; height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">' if done else f'<button aria-label="Écrire à {n}" style="width: 44px; height: 44px; border: 0; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">') + ic('<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>', 18, 2) + '</button>'
ST = {
 'todo': DASH + 'Pas encore demandé',
 'wait': f'<span style="display: flex; align-items: center; gap: 5px; color: #79511d">{CLOCK}Demandé, pas encore répondu</span>',
 'ok': CHECK + 'A répondu',
 'bad': f'<span style="display: flex; align-items: center; gap: 5px; color: #961d35; font-weight: 600">{ALERT}Réponse à vérifier</span>',
}
def plist(states, foot):
    body = ''.join(lrow(n, *PEOPLE[n], ST[s], SEND(n, s == 'ok'), first=(i == 0)) for i, (n, s) in enumerate(states))
    return f'''<section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">5 participants</h2>
      <ul style="{LIST}">
{body}      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">{foot}</p>
    </section>'''
def counters(a, b, c):
    cell = lambda v, l, bg, c1, c2: f'''<div style="display: flex; flex-direction: column; gap: 2px; padding: 10px; border-radius: 10px; background: {bg}">
          <dd style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 26px; line-height: 1; color: {c1}">{v}</dd>
          <dt style="font-size: 12px; font-weight: 600; line-height: 1.25; color: {c2}">{l}</dt>
        </div>'''
    return f'''<dl style="margin: 0; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px">
        {cell(a, 'à prévenir', '#fbf3f1', '#8a2f27', '#702a24')}
        {cell(b, 'pas encore répondu', '#fdf8ea', '#79511d', '#66431d')}
        {cell(c, 'a répondu' if c < 2 else 'ont répondu', '#f0f6f1', '#274e34', '#223f2d')}
      </dl>'''
def card(eyebrow, title, inner, tone='#8a2f27'):
    return f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 16px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {tone}">{eyebrow}</p>
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 22px; line-height: 1.2">{title}</h2>
      </div>
      {inner}
    </section>'''
HELP = lambda s: f'<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">{s}</p>'
PBTN = lambda icon, label: f'<a href="#" style="{BTN}">{icon}{label}</a>'
OBTN = lambda label: f'<a href="#" style="height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; color: #292524; font-size: 15px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">{label}</a>'
LATER = section('Plus tard, ou en cas de pépin', row(bubble('userplus', 'quiet'), 'Ajouter ou retirer des participants', 'Possible tant que tu n’as pas validé', first=True) + row(bubble('undo', 'danger'), 'Abandonner et tirer avec l’application', 'Les réponses sont effacées · journalisé', color='#961d35'), 'Personne, organisateur compris, ne voit qui offre à qui.')

base = (P/'Suivi.dc.html').read_text()
base = rep(base, [('color: #8a2f27">Tirage fait</span>', 'color: #8a2f27">Réponses</span>')])
def collecte(name, title, h, cardhtml, states, foot):
    t = base
    a, b = cut_section(t, 'Préviens chacun que le tirage est fait'); t = t[:a] + cardhtml + t[b:]
    a, b = cut_section(t, '>5 participants</h2>'); t = t[:a] + plist(states, foot) + t[b:]
    a, b = cut_section(t, 'Plus tard, ou en cas de pépin'); t = t[:a] + LATER + t[b:]
    save(name, t, title, h)

collecte('ManuelCollecte.dc.html', 'Tirage déjà fait — demander les réponses', 1330,
  card('À faire maintenant', 'Demande à chacun à qui il offre', counters(3, 1, 1) + f'<div style="display: flex; flex-direction: column; gap: 6px">{PBTN(MAIL, "Demander par email")}{HELP("Personne ne voit d’idées de cadeaux avant que tout le monde ait répondu et que tu aies validé.")}</div>'),
  [('Inès', 'todo'), ('Louis', 'todo'), ('Rose', 'todo'), ('Hugo', 'wait'), ('Camille', 'ok')], 'Ceux qui restent à prévenir sont en premier. Tu vois qui a répondu, jamais ce qu’il a répondu.')

pair = f'''<div style="display: flex; align-items: flex-start; gap: 12px; padding: 12px; border-radius: 10px; background: #fdf0f2; border: 1px solid #f3c2ca">
        <span aria-hidden="true" style="display: flex; flex-shrink: 0">{av(*PEOPLE['Hugo'], 36, 16)}<span style="margin-left: -8px; display: flex">{av(*PEOPLE['Inès'], 36, 16, 'box-shadow: 0 0 0 2px #fdf0f2;')}</span></span>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #6f1528"><strong>Hugo et Inès</strong> ont nommé la même personne. L’un des deux s’est trompé : demande-leur de vérifier.</p>
      </div>'''
collecte('ManuelConflit.dc.html', 'Tirage déjà fait — deux réponses ne vont pas ensemble', 1450,
  card('À corriger', 'Deux réponses ne vont pas ensemble', counters(0, 1, 4) + pair + f'<div style="display: flex; flex-direction: column; gap: 6px">{PBTN(MAIL, "Leur écrire")}{HELP("Tu ne vois pas qui ils ont nommé. Chacun corrige sa réponse lui-même, sur sa page.")}</div>', '#961d35'),
  [('Hugo', 'bad'), ('Inès', 'bad'), ('Louis', 'wait'), ('Camille', 'ok'), ('Rose', 'ok')], 'Les réponses à vérifier sont en premier. Hugo et Inès ne voient aucun message d’erreur : c’est à toi de les prévenir.')

collecte('ManuelUneManque.dc.html', 'Tirage déjà fait — il ne manque qu’une réponse', 1430,
  card('À faire maintenant', 'Il ne manque que Louis', counters(0, 1, 4) + f'<p style="margin: 0; display: flex; align-items: flex-start; gap: 6px; font-size: 14px; line-height: 1.45; color: #57534e"><span style="margin-top: 3px; display: flex">{CHECK}</span>Les 4 autres réponses vont ensemble. Celle de Louis se déduit : il ne reste qu’une personne que nul n’a nommée.</p>' + f'<div style="display: flex; flex-direction: column; gap: 8px">{PBTN(MAIL, "Relancer Louis")}{OBTN("Valider sans attendre Louis")}{HELP("Sa réponse est remplie pour lui, sans que tu la voies. Il la découvrira sur sa page.")}</div>'),
  [('Louis', 'wait'), ('Camille', 'ok'), ('Hugo', 'ok'), ('Inès', 'ok'), ('Rose', 'ok')], 'Tu vois qui a répondu, jamais ce qu’il a répondu.')

STAR = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
collecte('ManuelPret.dc.html', 'Tirage déjà fait — prêt à valider', 1330,
  card('À faire maintenant', 'Tout le monde a répondu : valide le tirage', counters(0, 0, 5) + f'<p style="margin: 0; display: flex; align-items: center; gap: 6px; font-size: 14px; color: #57534e">{CHECK}5 réponses, elles vont toutes ensemble.</p>' + f'<div style="display: flex; flex-direction: column; gap: 6px">{PBTN(STAR, "Valider le tirage")}{HELP("Chacun verra ensuite les idées de cadeaux de la personne à qui il offre.")}</div>'),
  [(n, 'ok') for n in ['Camille', 'Hugo', 'Inès', 'Louis', 'Rose']], 'Tu vois qui a répondu, jamais ce qu’il a répondu.')

# ---------- étape Préparer : le lien ----------
t = (P/'Main.dc.html').read_text()
t = rep(t, [('<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Tu préviendras tout le monde juste après, par email.</p>',
 '<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Tu préviendras tout le monde juste après, par email.</p>\n      <a href="ManuelDemarrer.dc.html" style="margin: 0 -20px -20px; min-height: 52px; padding: 0 20px; border-top: 1px solid #e9dcc5; color: #8a2f27; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: space-between; gap: 8px">Le tirage a déjà été fait ailleurs ?' + ic('<path d="m9 18 6-6-6-6"/>', 18, 2.4) + '</a>')])
save('ManuelPreparer.dc.html', t, 'Tirage déjà fait — le lien à l’étape Préparer', 1150)

# ---------- panneaux ----------
INFO = ic('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', 16, 2.2)
def item(title, sub, first=False, icon=None):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''<li style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px;{bt}">
        <span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon or ic('<path d="M20 6 9 17l-5-5"/>', 16, 2.5)}</span>
        <span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 15px; font-weight: 600">{title}</span><span style="font-size: 13px; line-height: 1.4; color: #57534e">{sub}</span></span>
      </li>'''
def sheet(name, title, h, back, label, h1, desc, items, note, primary, secondary, top=150, pre=''):
    html = (P/'ConfirmerTirage.dc.html').read_text()
    a = html.index('<div style="width: 390px'); b = html.index('</x-dc>')
    body = f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; color: #5c554c">{back}</div>
  <section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    {pre}
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15">{h1}</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{desc}</p>
    </div>
    {('<ul style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden">' + items + '</ul>') if items else ''}
    {f'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">{note}</p>' if note else ''}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{primary}</button>
      <a href="#" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">{secondary}</a>
    </div>
  </section>
</div>
'''
    save(name, html[:a] + body + html[b:], title, h)

sheet('ManuelDemarrer.dc.html', 'Tirage déjà fait — panneau de démarrage', 844, 'Noël 2026', 'Tirage déjà fait',
  'Le tirage a déjà été fait ?', 'Sur papier ou avec une autre application : ici, chacun dit à qui il offre, et profite des listes de souhaits.',
  item('Chacun répond sur sa page', 'Sa réponse reste secrète, même pour toi.', True, INFO) + item('Tout reste fermé jusqu’à la dernière réponse', 'Si deux réponses ne vont pas ensemble, tu sais qui contacter, pas ce qu’ils ont répondu.', icon=INFO) + item('Tu valides, et c’est un tirage comme les autres', 'Idées de cadeaux, relances, historique pour l’an prochain.', icon=INFO),
  '<strong>L’exclusion du groupe (Camille et Hugo) n’est pas vérifiée</strong> : le tirage a eu lieu ailleurs. Elle reste enregistrée pour les prochaines éditions. Tu peux revenir au tirage par l’application tant que tu n’as pas validé.',
  'Demander les réponses', 'Pas encore', top=110)

sheet('ManuelValider.dc.html', 'Tirage déjà fait — confirmer la validation', 844, 'Noël 2026', 'Valider le tirage',
  'Valider le tirage ?', 'Les 5 réponses vont ensemble : chacun offre un cadeau et en reçoit un.',
  item('Les réponses ne pourront plus être modifiées', 'Pour corriger ensuite, il faudra annuler le tirage.', True) + item('La liste des participants sera verrouillée', 'Comme après un tirage par l’application.') + item('Chacun verra les idées de cadeaux de sa personne', 'Tu les préviens juste après, par email.'),
  'Personne, toi compris, ne voit qui offre à qui.', STAR + 'Valider le tirage', 'Pas encore', top=200)

# ---------- relance ----------
t = (P/'Envoi.dc.html').read_text()
k = t.index('<div style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; background: #f0f6f1">'); e = t.index('</div>', t.index('Passer</button>')) + 6
t = t[:k] + t[e:]
t = rep(t, [('aria-label="Envoyer à Inès"', 'aria-label="Relancer Louis"'), ('background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0">🍭', 'background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0">🎄'),
  ('>Envoyer à Inès</h1>', '>Relancer Louis</h1>'), ('Encore 3 personnes à prévenir', 'Demandé le 14 novembre, pas encore répondu'),
  ('aria-checked="true" style="height: 40px; border: 0; border-radius: 7px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12); color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">Tirage fait', 'aria-checked="false" style="height: 40px; border: 0; border-radius: 7px; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 600">Demande'),
  ('aria-checked="false" style="height: 40px; border: 0; border-radius: 7px; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 600">Relance', 'aria-checked="true" style="height: 40px; border: 0; border-radius: 7px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12); color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">Relance'),
  ('>Nouveau tirage</button>', '>À vérifier</button>'),
  ('Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :', 'Louis, on n’attend plus que toi ! 🎁 Dis à qui tu offres un cadeau : dès que tout le monde a répondu, chacun voit les idées de sa personne.'),
  ('ines-demo@example.com', 'louis-demo@example.com')])
k = t.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">')
t = t[:k] + '' + t[k:]
save('ManuelRelance.dc.html', t, 'Tirage déjà fait — message de relance')

# ---------- participant ----------
att = (P/'TirageAttente.dc.html').read_text()
m = re.search(r'padding: 28px 24px 24px[^>]*>\s*(<svg[\s\S]*?</svg>)', att); ENV = m.group(1)
t0 = (P/'TirageDecouvrir.dc.html').read_text()
t0 = rep(t0, [('text-align: center">Tirage fait</span>', 'text-align: center">Ta réponse</span>')])
def pcard(name, title, h2, p, btn, foot, outline=False):
    t = t0
    a, b = cut_section(t, "Ton enveloppe t'attend")
    bs = 'border: 1px solid #b8483a; background: transparent; color: #8a2f27' if outline else 'border: 0; background: #b8483a; color: #ffffff'
    c = f'''<section style="{CARD} padding: 28px 24px 24px; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">
      {ENV}
      <div style="display: flex; flex-direction: column; gap: 6px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.2">{h2}</h2>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{p}</p>
      </div>
      <button style="width: 100%; height: 48px; border-radius: 6px; {bs}; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{btn}</button>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">{foot}</p>
    </section>'''
    save(name, t[:a] + c + t[b:], title, 860)
pcard('ManuelTirageDeclarer.dc.html', 'Page d’un tirage — à qui offres-tu ?', 'À qui offres-tu un cadeau ?', 'Le tirage a été fait hors de l’application. Dis-le ici pour voir ses idées de cadeaux. Assure-toi que personne ne regarde ton écran.', 'Dire à qui j’offre', 'Ta réponse reste secrète, même pour l’organisateur.')
pcard('ManuelTirageAttente.dc.html', 'Page d’un tirage — réponse enregistrée', 'Réponse enregistrée', 'Tu verras les idées de cadeaux de ta personne quand tout le monde aura répondu. 3 réponses sur 5 pour l’instant.', 'Revoir ou corriger ma réponse', 'Ta réponse reste cachée : elle ne s’affiche que si tu le demandes.', True)
big = f'<div style="display: flex; flex-direction: column; align-items: center; gap: 8px; padding-top: 8px">{av(*PEOPLE["Louis"], 80, 38)}</div>'
sheet('ManuelTirageConfirmer.dc.html', 'Page d’un tirage — confirmer sa réponse', 844, 'Salut Camille !', 'Confirmer ma réponse',
  'Tu offres un cadeau à Louis ?', 'Vérifie bien : c’est la personne que tu as tirée, sur papier ou dans l’autre application.', '',
  'Tu pourras corriger ta réponse tant que l’organisateur n’a pas validé le tirage. Personne d’autre ne la voit.', 'Oui, c’est Louis', 'Choisir quelqu’un d’autre', top=330, pre=big)

# ---------- choix de la personne ----------
t = (P/'ChoisirPersonne.dc.html').read_text()
a = t.index('<li role="option" aria-selected="false">'); b = t.index('<li role="option" aria-selected="true">')
t = t[:a] + t[b:]
k = t.index('<span style="flex-grow: 1">Hugo</span>'); s1 = t.index('<svg', k); s2 = t.index('</svg>', s1) + 6
t = t[:s1] + t[s2:]
t = rep(t, [('<li role="option" aria-selected="true">', '<li role="option" aria-selected="false">'), ('border: 0; border-top: 1px solid #e9dcc5; background: #fbf3f1;', 'border: 0; background: transparent;'),
  ('color: #5c554c">Voir un seul résultat</div>', 'color: #5c554c">Salut Camille !</div>'), ('aria-label="Le résultat de qui ?"', 'aria-label="À qui offres-tu un cadeau ?"'),
  ('>Le résultat de qui ?</h1>', '>À qui offres-tu un cadeau ?</h1>'), ('>5 participants</p>', '>La personne que tu as tirée, sur papier ou dans l’autre application.</p>'),
  ('    </ul>\n  </section>', '    </ul>\n  </section>')])
save('ManuelTirageChoisir.dc.html', t, 'Page d’un tirage — choisir la personne')

# ---------- canevas ----------
cv = json.loads((P/'canvas.json').read_text())
rows = [('m1', 'Organisateur : du démarrage à la validation', ['ManuelPreparer', 'ManuelDemarrer', 'ManuelCollecte', 'ManuelRelance', 'ManuelConflit', 'ManuelUneManque', 'ManuelPret', 'ManuelValider'],
         ['Le lien à l’étape Préparer', 'Panneau de démarrage', 'Demander les réponses', 'Message de relance', 'Deux réponses ne vont pas ensemble', 'Il ne manque qu’une réponse', 'Prêt à valider', 'Confirmer la validation']),
        ('m2', 'Participant : dire à qui j’offre', ['ManuelTirageDeclarer', 'ManuelTirageChoisir', 'ManuelTirageConfirmer', 'ManuelTirageAttente'], ['À qui offres-tu ?', 'Choisir la personne', 'Confirmer sa réponse', 'Réponse enregistrée'])]
if not any(p['id'] == 'manuel' for p in cv['pages']):
    cv['pages'].insert(len(cv['pages']) - 1, {'id': 'manuel', 'name': 'Tirage déjà fait'})
y = 0
for nid, text, names, titles in rows:
    mh = 0
    for i, (n, ti) in enumerate(zip(names, titles)):
        f = n + '.dc.html'; h = OUT[f]; mh = max(mh, h)
        cv['boards'][f] = {'x': i * 470, 'y': y, 'w': 390, 'h': h, 'title': ti, 'page': 'manuel'}
        if f not in cv['order']: cv['order'].append(f)
    cv['notes'][nid] = {'x': 0, 'y': y - 300, 'text': text, 'kind': 'title1', 'maxW': len(names) * 470 - 80, 'page': 'manuel'}
    if nid not in cv['noteOrder']: cv['noteOrder'].append(nid)
    y += mh + 420
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)
