# Proposition : le burger devient l'icône du compte connecté (Julien, 20 novembre 2026). Trois maquettes, à part.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=20): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
BELL=ic('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>')
GLOBE=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>')
OUT=ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>')
CHEV=ic('<path d="m9 6 6 6-6 6"/>',18)
def avbtn(open_,dot,label):
    ring='0 0 0 2px #f7f2e9, 0 0 0 4px #292524' if open_ else '0 0 0 1px #e6b94a'
    d='<span aria-hidden="true" style="position: absolute; top: 4px; right: 3px; width: 10px; height: 10px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 2px #f7f2e9"></span>' if dot else ''
    return (f'<button aria-label="{label}" aria-haspopup="menu" aria-expanded="{"true" if open_ else "false"}" style="justify-self: end; position: relative; width: 44px; height: 44px; border: 0; background: transparent; display: flex; align-items: center; justify-content: center; padding: 0">'
            f'<span aria-hidden="true" style="width: 34px; height: 34px; border-radius: 50%; background: #f6e3ad; box-shadow: {ring}; display: flex; align-items: center; justify-content: center; font-size: 18px">🐧</span>{d}</button>')
ROW='width: 100%; min-height: 48px; padding: 0 14px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 500; display: flex; align-items: center; gap: 12px; text-align: left; box-sizing: border-box; text-decoration: none'
MENU=f'''<div style="position: absolute; top: 54px; right: 12px; width: 272px; z-index: 5; background: #fffdf9; border-radius: 14px; box-shadow: 0 8px 24px rgba(60, 30, 10, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.06); overflow: hidden">
    <ul role="menu" aria-label="Mon compte" style="list-style: none; margin: 0; padding: 0">
      <li role="none"><a role="menuitem" href="Compte.dc.html" aria-label="Mon compte, Hugo, hugo@exemple.fr" style="{ROW}; min-height: 68px; padding: 10px 12px 10px 14px"><span aria-hidden="true" style="width: 42px; height: 42px; border-radius: 50%; background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 21px; flex-shrink: 0">🐧</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 700">Mon compte</span><span style="font-size: 13px; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">Hugo · hugo@exemple.fr</span></span><span style="display: flex; color: #78716c">{CHEV}</span></a></li>
      <li role="none"><a role="menuitem" href="NotifCentre.dc.html" style="{ROW}; border-top: 1px solid #e9dcc5; font-weight: 700"><span style="display: flex; color: #57534e">{BELL}</span><span style="flex-grow: 1">Quoi de neuf</span><span style="height: 22px; padding: 0 8px; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 12px; font-weight: 700; display: flex; align-items: center; flex-shrink: 0">3</span></a></li>
      <li role="none"><button role="menuitem" style="{ROW}"><span style="display: flex; color: #57534e">{GLOBE}</span><span style="flex-grow: 1">Langue</span><span style="font-size: 14px; color: #57534e">Français</span></button></li>
      <li role="none"><button role="menuitem" style="{ROW}; border-top: 1px solid #e9dcc5"><span style="display: flex; color: #57534e">{OUT}</span><span style="flex-grow: 1">Se déconnecter</span></button></li>
    </ul>
  </div>'''
BURG=re.compile(r'<button aria-label="Menu[^"]*"[^>]*>.*?</button>',re.S)
src=open(PJ+'NotifMenu.dc.html',encoding='utf-8').read()
menu_old=re.search(r'\n  <div style="position: absolute; top: 52px; right: 12px; width: 240px;.*?</ul>\s*</div>',src,re.S).group(0)
P={}
closed=BURG.sub(lambda m:avbtn(False,True,'Mon compte, 3 nouveautés'),src.replace(menu_old,''),count=1)
P['MenuAvatar']=(closed,'Le compte · fermé : l’icône de Hugo à la place du burger, et le point des nouveautés')
opened=BURG.sub(lambda m:avbtn(True,False,'Mon compte, 3 nouveautés'),src.replace(menu_old,'\n  '+MENU),count=1)
P['MenuAvatarOuvert']=(opened,'Le compte · ouvert : mon compte en tête, quoi de neuf, langue, se déconnecter')
lt=open(PJ+'ListeTeneur.dc.html',encoding='utf-8').read()
lt2=BURG.sub(lambda m:avbtn(False,False,'Mon compte'),lt,count=1); assert lt2!=lt
P['MenuAvatarListe']=(lt2,'Le compte · sur une liste : la même icône, partout où l’on est connecté')
names=json.load(open('/tmp/names.json'))
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    h=h.replace('<button hidden aria-label="Retour" style="','<button hidden aria-label="Retour" style="visibility: hidden; ')
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
    print(k,re.search(r'"\$preview":\{[^}]*\}',h).group(0))
json.dump(names,open('/tmp/names.json','w'))
