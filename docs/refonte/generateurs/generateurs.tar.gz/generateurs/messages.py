# Les messages après une action, en prune foncé (Julien, 19 novembre 2026) : la planche du système de design
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/stop.py').read().split("# 1. le premier email")[0])
T='min-height: 52px; padding: 8px 8px 8px 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; gap: 12px; font-size: 15px; font-weight: 600'
ACT='min-height: 44px; padding: 0 10px; border: 0; background: transparent; color: #f6c9c0; font-family: inherit; font-size: 15px; font-weight: 700; flex-shrink: 0'
def dot(bg,fg,d): return f'<span aria-hidden="true" style="width: 26px; height: 26px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(d,15,3)}</span>'
OKD=dot('#dbe9dd','#274e34','<path d="m5 12 5 5 9-10"/>'); ERR=dot('#f6e2dd','#8a2f27','<path d="M12 7v6M12 17h.01"/>')
def toast(left,text,sub='',right=''):
    body=f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span>{text}</span>'+(f'<span style="font-size: 13px; font-weight: 400; color: #d6cfe0">{sub}</span>' if sub else '')+'</span>'
    return f'<div role="status" style="{T}">{left}{body}{right}</div>'
def bloc(k,d,t): return f'<section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">{k}</h2>{t}<p style="{SM}">{d}</p></section>'
XP='<path d="M6 6l12 12M18 6 6 18"/>'
CLOSE=f'<button aria-label="Fermer" style="width: 44px; height: 44px; border: 0; background: transparent; color: #d6cfe0; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(XP,18,2.4)}</button>'
def rule(t): return f'<li style="display: flex; align-items: flex-start; gap: 10px; font-size: 15px; line-height: 1.45"><span aria-hidden="true" style="width: 6px; height: 6px; border-radius: 50%; background: #292524; margin-top: 8px; flex-shrink: 0"></span><span>{t}</span></li>'
html=scr(1330,f'''<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Système de design</p><h1 style="{H1}">Les messages après une action</h1><p style="{P}">Un bandeau prune foncé, en bas de l’écran, qui dit ce qui vient de se passer et s’en va tout seul.</p></div>
    {bloc('C’est fait, et ça se rattrape','Le cas le plus courant. « Annuler » remet tout comme avant. Reste 6 secondes.',toast('','Coche de Mamie retirée','',f'<button style="{ACT}">Annuler</button>'))}
    {bloc('C’est fait','Une pastille verte, un titre, une ligne de détail au plus. Reste 4 secondes.',toast(OKD,'3 emails envoyés','Inès, Louis et Mamie'))}
    {bloc('Ça n’a pas marché','Une pastille corail. Reste jusqu’à ce qu’on le ferme, et dit quoi faire.',toast(ERR,'L’envoi n’est pas parti','Vérifie ta connexion, puis réessaie.',CLOSE))}
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Les règles</h2><ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px">
      {rule('<strong>Pour quoi</strong> : la suite immédiate d’un geste. Jamais pour une information qui doit rester : c’est le rôle des encadrés dans la page.')}
      {rule('<strong>Où</strong> : en bas, au-dessus de la barre d’onglets et du bord du téléphone. Jamais par-dessus le clavier ni la ligne qu’on écrit.')}
      {rule('<strong>Un seul à la fois</strong> : un nouveau remplace l’ancien.')}
      {rule('<strong>Le texte</strong> : ce qui est fait, au passé, sans point. Une ligne ; une seconde, plus claire, si elle aide.')}
      {rule('<strong>Une action au plus</strong>, à droite, en rose clair. Pas de bouton « OK ».')}
      {rule('<strong>Si ça se rattrape, on ne demande pas « tu es sûr ? »</strong> : on fait, et on propose « Annuler ».')}
      {rule('<strong>Lu à voix haute</strong> par les lecteurs d’écran ; le temps s’arrête tant qu’on le touche.')}</ul></section>''','Système de design — les messages après une action',back=False)
html=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1330}',html)
open(PJ+'StyleMessages.dc.html','w').write(html)
names=json.load(open('/tmp/names.json'))
if 'StyleMessages.dc.html' not in names: names.append('StyleMessages.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print('ok')
