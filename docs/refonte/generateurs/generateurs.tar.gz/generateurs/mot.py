import pathlib, json, re, shutil
P = pathlib.Path('/home/claude/utt/project')
src = (P/'EnvoiPersonnaliser.dc.html').read_text()
ic = lambda inner, s=16, sw=2.2: f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{inner}</svg>'
PEN = ic('<path d="M17 3a2.800 2.800 0 1 1 4 4L7.500 20.500 2 22l1.500-5.500z"/>')
WORD = 'On ouvre les cadeaux après le dessert, pensez à venir avec un petit quelque chose à partager !'
i = src.index('<button style="height: 40px; padding: 0 12px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 999px; background: transparent;'); j = src.index('</button>', i) + 9
chip_old = src[i:j]; assert 'Ajouter un mot' in chip_old
link_p = '<p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/p/aIFR…</p>'
assert src.count(link_p) == 1
def variant(name, title, h, top, chip, extra):
    t = src.replace(chip_old, chip)
    t = t.replace(link_p, link_p + f'\n        <p style="margin: 0">{WORD}</p>')
    k = t.index('<div style="margin-top: auto; display: flex; flex-direction: column; gap: 10px">')
    t = t[:k] + extra + t[k:]
    t = re.sub(r'(width: 390px; height: )\d+px', rf'\g<1>{h}px', t, count=1); t = re.sub(r'"height":\d+', f'"height":{h}', t)
    t = t.replace('<div aria-hidden="true" style="height: 110px;', f'<div aria-hidden="true" style="height: {top}px;', 1)
    t = re.sub(r'<title>[^<]*</title>', f'<title>{title}</title>', t, count=1)
    (P/name).write_text(t)
CH = 'height: 40px; padding: 0 12px; box-sizing: border-box; border-radius: 999px; font-family: inherit; font-size: 14px; display: flex; align-items: center; gap: 6px'
open_chip = f'<button aria-expanded="true" style="{CH}; border: 1px solid #b8483a; background: #f6e2dd; color: #8a2f27; font-weight: 700">{PEN}Ton mot{ic("<path d=\'m6 15 6-6 6 6\'/>", 14, 2.6)}</button>'.replace("\\'", "'")
field = f'''<div style="display: flex; flex-direction: column; gap: 6px">
      <label for="mot" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%)">Ton mot</label>
      <textarea id="mot" rows="3" style="width: 100%; box-sizing: border-box; padding: 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45; resize: none">{WORD}</textarea>
      <p style="margin: 0; display: flex; align-items: center; justify-content: space-between; font-size: 13px; color: #57534e"><button style="min-height: 44px; margin: -12px 0; padding: 0; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700">Retirer le mot</button><span>{len(WORD)} / 500</span></p>
    </div>
    '''
variant('EnvoiMotOuvert.dc.html', 'Envoyer à une personne — le mot en cours d’écriture', 1010, 24, open_chip, field)
done_chip = f'<button aria-expanded="false" style="{CH}; border: 1px solid #dccbad; background: transparent; color: #292524; font-weight: 600">{PEN}Modifier le mot{ic("<path d=\'m6 9 6 6 6-6\'/>", 14, 2.6)}</button>'.replace("\\'", "'")
variant('EnvoiMotAjoute.dc.html', 'Envoyer à une personne — un mot ajouté, champ replié', 900, 60, done_chip, '')
# closed, no word: add the chevron to the chip of the reference screen
if 'Ajouter un mot\n        </button>' in src:
    t = src.replace(chip_old, chip_old.replace('</button>', ic("<path d='m6 9 6 6 6-6'/>", 14, 2.6) + '\n        </button>'))
    (P/'EnvoiPersonnaliser.dc.html').write_text(t)
cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
if 'EnvoiMotOuvert.dc.html' not in B:
    x0 = B['EnvoiPersonnaliser.dc.html']['x']
    for k, v in B.items():
        if v['page'] == 'edition' and v['y'] == 3660 and v['x'] > x0: v['x'] += 940
    B['EnvoiMotOuvert.dc.html'] = {'x': x0 + 470, 'y': 3660, 'w': 390, 'h': 1010, 'title': 'Le mot en cours d’écriture', 'page': 'edition'}
    B['EnvoiMotAjoute.dc.html'] = {'x': x0 + 940, 'y': 3660, 'w': 390, 'h': 900, 'title': 'Un mot ajouté, champ replié', 'page': 'edition'}
    o = cv['order']; k = o.index('EnvoiPersonnaliser.dc.html'); o[k+1:k+1] = ['EnvoiMotOuvert.dc.html', 'EnvoiMotAjoute.dc.html']
    cv['notes']['t10']['maxW'] = 4620
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
for f in ['EnvoiMotOuvert', 'EnvoiMotAjoute', 'EnvoiPersonnaliser']: shutil.copy(P/f'{f}.dc.html', f'/mnt/user-data/outputs/refonte9/{f}.html')
print(sorted((v['x'], k) for k, v in B.items() if v['page'] == 'edition' and v['y'] == 3660))
