# V2 · la navigation toujours là (19 novembre 2026) : barre du bas et menu partout pour une personne connectée
import re,json
PJ='/home/claude/utt/project/'
ic=lambda d,w=22:f'<svg aria-hidden="true" width="{w}" height="{w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{d}</svg>'
def nav(active):
    def tab(href,label,icon,on):
        return f'<a href="{href}" {"aria-current=\"page\" " if on else ""}style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: {"#8a2f27" if on else "#57534e"}; font-size: 12px; font-weight: {"700" if on else "600"}">{icon}{label}</a>'
    return ('<nav aria-label="Sections" style="flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad">'
        +tab('Accueil.dc.html','Tirages',ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>'),active=='tirages')
        +tab('ListesAccueil.dc.html','Listes',ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>'),active=='listes')+'</nav>')
BURGER='<button aria-label="Menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>'
def navify(k,active,title,move_footer=False):
    h=open(PJ+k+'.dc.html').read()
    h,n=re.subn(r'<button aria-label="Langue : français"[^>]*>FR</button>',BURGER,h); 
    if move_footer:
        m=re.search(r'\s*<footer[^>]*>\s*(.*?)\s*</footer>',h,flags=re.S); assert m
        h=h.replace(m.group(0),'').replace('</main>',f'  <div style="margin-top: 8px">{m.group(1)}</div>\n  </main>',1)
    i=h.rindex('</div>\n</x-dc>'); h=h[:i]+nav(active)+'\n'+h[i:]
    m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+(0 if move_footer else 57)
    h=h.replace(m.group(0),f'width: 390px; height: {H}px',1)
    h=re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',h,count=1)
    return h,H
V={'NavTirage':navify('TirageDecouvrir','tirages','Navigation — la page d’un tirage, connecté')+('La page d’un tirage, connecté : le menu et la barre du bas',),
   'NavListe':navify('ListeTeneur','listes','Navigation — une liste')+('Une liste : le menu et la barre du bas',),
   'NavRedaction':navify('PistesTexteMoment','tirages','Navigation — une page où l’on rédige',True)+('Une page où l’on rédige : « Valider » dans la page, la barre reste',)}
names=json.load(open('/tmp/names.json'))
for k,(h,H,t) in V.items():
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
b=''.join(f'"{k}.dc.html": {json.dumps({"x":i*470,"y":4300,"w":390,"h":H,"title":t,"page":"accueil"},ensure_ascii=True)},\n    ' for i,(k,(h,H,t)) in enumerate(V.items()))
o=''.join(f'"{k}.dc.html",\n    ' for k in V)
n='"n1": '+json.dumps({"kind":"title1","maxW":1330,"page":"accueil","text":"V2 · La navigation toujours là, pour une personne connectée","w":240,"x":0,"y":4000})+',\n    '
print(json.dumps([{"old_text":'"PistesQuestion.dc.html": {',"new_text":b+'"PistesQuestion.dc.html": {'},{"old_text":'"order": [\n    ',"new_text":'"order": [\n    '+o},{"old_text":'"notes": {\n    ',"new_text":'"notes": {\n    '+n},{"old_text":'"noteOrder": [\n    ',"new_text":'"noteOrder": [\n    "n1",\n    '}]))
