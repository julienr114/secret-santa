# V2 · notifications, résumé par email, connexion par code, application installable (19 novembre 2026)
import io,contextlib,json
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
N={}
BURGER='<button aria-label="Menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>'
DOT='<span aria-hidden="true" style="width: 9px; height: 9px; border-radius: 50%; background: #b8483a; flex-shrink: 0"></span>'
def navd(active,dots=()):
    def tab(href,label,icon,key):
        on=active==key; d=f'<span aria-hidden="true" style="position: absolute; top: -2px; right: -7px; width: 9px; height: 9px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 2px #fffdf9"></span>' if key in dots else ''
        sr=' <span style="position: absolute; width: 1px; height: 1px; overflow: hidden">, du nouveau</span>' if key in dots else ''
        return f'<a href="{href}" {"aria-current=\"page\" " if on else ""}style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: {"#8a2f27" if on else "#57534e"}; font-size: 12px; font-weight: {"700" if on else "600"}"><span style="position: relative; display: flex">{icon}{d}</span>{label}{sr}</a>'
    return ('<nav aria-label="Sections" style="margin-top: auto; flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad">'
        +tab('Accueil.dc.html','Tirages',ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',22),'tirages')
        +tab('ListesAccueil.dc.html','Listes',ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',22),'listes')+'</nav>')
def scr(h,main,title,nav='',back=True,right=BURGER):
    hd=header(right) if back else header(right).replace('<div><button aria-label="Retour"','<div><button hidden aria-label="Retour"')
    s=HEAD+f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {hd}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    {main}
  </main>{nav}
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
def badge(t): return f'<span style="height: 22px; padding: 0 8px; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 12px; font-weight: 700; display: flex; align-items: center; white-space: nowrap; flex-shrink: 0">{t}</span>'
def trow(n,t,sub,right='',top=True):
    return f'''<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''} text-decoration: none; color: #292524">{av(n,40)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; color: #57534e">{sub}</span></span>{right}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'''
# 1. l'accueil : des pastilles là où ça se passe
N['NotifAccueil']=(scr(844,f'''<div style="display: flex; align-items: center; gap: 14px">{av('Hugo',56)}<h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Bonjour Hugo</h1></div>
    <section style="{CARD}; padding: 20px; display: flex; flex-direction: column; gap: 14px"><div style="display: flex; flex-direction: column; gap: 4px"><p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">À faire maintenant · Famille Camille</p><h2 style="margin: 0; font-family: {F}; font-weight: 600; font-size: 22px; line-height: 1.2">Camille te demande des pistes</h2><p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Elle ne sait pas quoi t’offrir. Trente secondes suffisent.</p></div><a href="Pistes.dc.html" style="{BTN}; height: 48px; font-size: 16px">Donner des pistes</a></section>
    <section style="display: flex; flex-direction: column; gap: 6px"><h2 style="{H2}">Mes tirages</h2><ul style="{UL}">
      {trow('Camille','Famille Camille','Fête dans 36 jours',badge('2 nouveautés'),False)}{trow('Tonton','Les copains du foot','Pas encore tiré · fête dans 34 jours')}{trow('Mamie','Bureau, 3e étage','Tu sais à qui tu offres',DOT)}</ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Une pastille s’efface dès que tu as vu ce qu’elle signale.</p></section>''','Notifications — l’accueil, avec ses pastilles',navd('tirages',('listes',)),False),844,'L’accueil : des pastilles là où il y a du nouveau')
# 2. dans une liste : le point sur ce qui est nouveau depuis ma dernière visite
def newl(kind,text,note=''):
    st={'free':'color: #292524','taken':'color: #78716c; text-decoration: line-through'}[kind]
    n=f'<span style="display: block; font-size: 13px; line-height: 1.35; color: #57534e">{note}</span>' if note else ''
    return f'''<li style="position: relative"><span aria-hidden="true" style="position: absolute; left: -12px; top: 18px; width: 7px; height: 7px; border-radius: 50%; background: #b8483a"></span><a href="#" style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; padding: 10px 0; box-sizing: border-box; text-decoration: none">{box(kind)}<span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45"><span style="{st}">{text}</span><span style="position: absolute; width: 1px; height: 1px; overflow: hidden"> (nouveau)</span>{n}</span></a></li>'''
N['NotifListe']=(scr(1000,dhead(INTRO,'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La liste de Camille et Hugo. Un point marque ce qui a changé depuis ta dernière visite.</p>').replace('Noël 2026</h1>','Noël 2026</h1>'+DATE)
  +dperson('Léo','🚀','6 ans · taille 6 ans, pointure 30',[dline('taken','Déguisement de pompier (taille 6 ans)'),newl('free','Un télescope pour enfant'),newl('taken','Livres sur les dinosaures (il les a presque tous, demandez-nous)'),dline('free','Circuit de billes, le grand modèle : '+lk('lien')),dline('add','J’offre autre chose à Léo','','ListeHorsListe.dc.html')],False)
  +dperson('Zoé','🦄','3 ans · taille 3 ans',[dline('free','Poupée en tissu'),dline('taken','Draisienne : '+lk('lien'))],False),'Notifications — dans une liste',navd('listes')),1000,'Dans une liste : un point sur ce qui est nouveau')
# 3. le réglage
N['NotifReglage']=(scr(1080,titles('Mon compte','Me prévenir','Dans l’appli, une pastille signale toujours ce qui est nouveau. Choisis ce qui t’arrive en plus : les deux se règlent à part.')+f'''
    <section style="display: flex; flex-direction: column; gap: 6px"><h2 style="{H2}">Sur ce téléphone</h2>
      <div style="margin: 0 -16px; padding: 4px 16px; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{sw('Notifications','Tout de suite, à chaque nouveauté.',True)}</div>
      <a href="Installer.dc.html" style="align-self: flex-start; min-height: 40px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27; text-decoration: none">Installer l’application sur un autre téléphone</a></section>
    <section style="display: flex; flex-direction: column; gap: 6px"><h2 style="{H2}">Par email</h2>
      <div role="radiogroup" aria-label="Par email" style="margin: 0 -16px; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad; display: flex; flex-direction: column">{radio('Un résumé le matin','Un seul email, avec ce que tu n’as pas encore vu.',True,False)}{radio('Tout de suite','Un email à chaque nouveauté.',False)}{radio('Aucun email','Sauf pour te connecter.',False)}</div></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Ce qui presse</h2><p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.5; color: #57534e">Ton enveloppe t’attend, une invitation, la réponse à une demande de groupe, quelqu’un te demande des pistes : avec le résumé, ces emails-là partent quand même tout de suite, sauf si tu as déjà vu la nouveauté.</p></section>''','Notifications — me prévenir',navd('tirages')),1080,'Mon compte : « Me prévenir », téléphone et email à part')
# 4. l'email de résumé, en texte seul
def mail(subject,to,body,title,h=844):
    s=HEAD+f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #ffffff; color: #1c1917; font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; display: flex; flex-direction: column">
  <div style="padding: 16px; border-bottom: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 4px">
    <h1 style="margin: 0; font-size: 18px; font-weight: 700; line-height: 1.3">{subject}</h1>
    <p style="margin: 0; font-size: 13px; color: #57534e">Under the Tree · à {to}</p>
  </div>
  <div style="padding: 16px; display: flex; flex-direction: column; gap: 14px; font-size: 16px; line-height: 1.5">
    {body}
  </div>
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
ML='color: #1d4ed8; text-decoration: underline'
N['NotifEmailResume']=(mail('Under the Tree : 4 nouveautés depuis hier','hugo-demo@example.com',f'''<p style="margin: 0">Bonjour Hugo,</p>
    <p style="margin: 0">Voici ce qui t’attend.</p>
    <p style="margin: 0"><strong>Secret Santa de Famille Camille</strong><br>Camille a laissé de nouvelles pistes de cadeaux.<br>Le journal a une nouvelle ligne.<br><a href="#" style="{ML}">Ouvrir le tirage</a></p>
    <p style="margin: 0"><strong>Liste « Noël 2026 »</strong><br>2 cadeaux ont été cochés sur ta liste.<br><a href="#" style="{ML}">Ouvrir la liste</a></p>
    <p style="margin: 0">Under the Tree</p>
    <p style="margin: 0; font-size: 13px; color: #57534e">Un seul résumé par jour, et seulement s’il y a du nouveau. <a href="#" style="{ML}">Changer ce réglage</a></p>''','Notifications — l’email de résumé'),844,'L’email de résumé : un par jour au plus, en texte seul')
# 5. connexion par code, dans l'application installée
def cell(c,on=False): return f'<span style="width: 46px; height: 58px; box-sizing: border-box; border: {"2px solid #b8483a" if on else "1px solid #a8a29e"}; border-radius: 6px; background: #fffdf9; display: flex; align-items: center; justify-content: center; font-family: {F}; font-size: 28px; font-weight: 700">{c}</span>'
N['ConnexionCode']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 6px; padding-top: 12px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Tape ton code</h1><p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Six chiffres envoyés à <strong style="color: #292524">hugo-demo@example.com</strong>. Le code est valable 15 minutes.</p></div>
    <div role="group" aria-label="Code à six chiffres" style="display: flex; justify-content: space-between">{cell('4')}{cell('8')}{cell('2')}{cell('',True)}{cell('')}{cell('')}</div>
    <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Il se valide tout seul au sixième chiffre.</p>
    <div style="display: flex; flex-direction: column; gap: 2px"><a href="#" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: #8a2f27; text-decoration: none">Renvoyer un code</a><a href="Connexion.dc.html" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 600; color: #292524; text-decoration: none">Utiliser une autre adresse</a></div>''','Connexion — le code, dans l’application installée',right='FR'),844,'Dans l’application installée : se connecter par code')
N['ConnexionCodeEmail']=(mail('Ton code Under the Tree : 482 913','hugo-demo@example.com',f'''<p style="margin: 0">Bonjour,</p>
    <p style="margin: 0">Voici ton code pour te connecter dans l’application :</p>
    <p style="margin: 0; font-size: 30px; font-weight: 700; letter-spacing: 0.08em">482 913</p>
    <p style="margin: 0">Il est valable 15 minutes et ne sert qu’une fois, sur le téléphone qui l’a demandé.</p>
    <p style="margin: 0">Si ce n’est pas toi, ignore ce message.</p>
    <p style="margin: 0">Under the Tree</p>''','Connexion — l’email du code'),844,'L’email du code')
# 6. installer l'application, autoriser les notifications : deux panneaux
def step(n,t): return f'<li style="display: flex; align-items: flex-start; gap: 12px"><span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{n}</span><span style="font-size: 16px; line-height: 1.45; padding-top: 2px">{t}</span></li>'
SHAREI='<svg aria-label="Partager" role="img" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: -3px"><path d="M12 15V3M8 7l4-4 4 4M6 11H5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-1"/></svg>'
N['Installer']=(sheet(330,'Installer l’application',sh('Mets Under the Tree sur ton écran d’accueil','Pour l’ouvrir d’un doigt, et être prévenu quand ton enveloppe t’attend.')+f'''
    <ol style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 14px">{step(1,f'Touche {SHAREI} <strong style="font-weight: 700">Partager</strong>, en bas de Safari.')}{step(2,'Choisis <strong style="font-weight: 700">Sur l’écran d’accueil</strong>.')}{step(3,'Ouvre l’application par sa nouvelle icône, et connecte-toi avec le code reçu par email.')}</ol>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">J’ai compris</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Plus tard</a></div>''','Application — l’installer, sur iPhone','Bonjour Hugo'),844,'Installer l’application, sur iPhone')
N['NotifAutoriser']=(sheet(410,'Être prévenu',sh('Être prévenu sur ce téléphone ?','Seulement ce qui te concerne : ton enveloppe, une invitation, une demande de pistes. Jamais de publicité.')+f'''
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; font-size: 14px; line-height: 1.45">Ton téléphone te demandera de confirmer. Tu pourras changer d’avis dans « Mon compte ».</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px"><button style="{BTN}; width: 100%">Activer les notifications</button><a href="#" style="height: 46px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Pas maintenant</a></div>''','Application — autoriser les notifications','Bonjour Hugo'),844,'Autoriser les notifications')
# 7. le centre de notifications, dans le menu
BURGERD=BURGER.replace('</svg></button>','</svg><span aria-hidden="true" style="position: absolute; top: 9px; right: 7px; width: 9px; height: 9px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 2px #f7f2e9"></span></button>').replace('justify-self: end;','justify-self: end; position: relative;').replace('aria-label="Menu"','aria-label="Menu, 3 nouveautés"')
BELL=ic('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0"/>',20)
USER=ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',20); OUT_=ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',20)
MI='width: 100%; min-height: 48px; padding: 0 14px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 500; display: flex; align-items: center; gap: 10px; text-align: left'
MENU=f'''<div style="position: absolute; top: 52px; right: 12px; width: 240px; background: #fffdf9; border-radius: 12px; box-shadow: 0 8px 24px rgba(60, 30, 10, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.06); overflow: hidden">
    <ul role="menu" aria-label="Menu" style="list-style: none; margin: 0; padding: 0">
      <li role="none"><a role="menuitem" href="NotifCentre.dc.html" style="{MI}; box-sizing: border-box; text-decoration: none; font-weight: 700">{BELL}<span style="flex-grow: 1">Quoi de neuf</span>{badge('3')}</a></li>
      <li role="none"><button role="menuitem" style="{MI}; border-top: 1px solid #e9dcc5">{USER}<span style="flex-grow: 1">Mon compte</span></button></li>
      <li role="none"><button role="menuitem" style="{MI}"><span aria-hidden="true" style="width: 20px; text-align: center; font-size: 13px; font-weight: 700">FR</span><span style="flex-grow: 1">Langue</span><span style="font-size: 14px; color: #57534e">Français</span></button></li>
      <li role="none"><button role="menuitem" style="{MI}; border-top: 1px solid #e9dcc5">{OUT_}<span style="flex-grow: 1">Se déconnecter</span></button></li>
    </ul>
  </div>'''
_m=N['NotifAccueil'][0].replace(BURGER,BURGERD.replace('aria-label="Menu, 3 nouveautés"','aria-label="Menu, 3 nouveautés" aria-expanded="true"')).replace('display: flex; flex-direction: column">\n  <header','display: flex; flex-direction: column; position: relative">\n  <header',1)
assert '</header>' in _m and 'position: relative">' in _m
N['NotifMenu']=(re.sub(r'<title>[^<]*</title>','<title>Notifications — le menu, avec « Quoi de neuf »</title>',_m.replace('</header>','</header>\n  '+MENU,1)),844,'Le menu : « Quoi de neuf », avec son compteur')
N['NotifAccueil']=(N['NotifAccueil'][0].replace(BURGER,BURGERD),844,N['NotifAccueil'][2])
def nrow(icon,tone,t,sub,new=False,top=True):
    c={'brick':('#f6e2dd','#8a2f27'),'pine':('#dbe9dd','#274e34'),'neutral':('#f1e8d8','#57534e')}[tone]
    return f'''<li><a href="#" style="display: flex; align-items: flex-start; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''} text-decoration: none; color: #292524"><span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {c[0]}; color: {c[1]}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; line-height: 1.35; font-weight: {'700' if new else '500'}">{t}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span>{'<span style="padding-top: 6px; display: flex">'+DOT+'<span style="position: absolute; width: 1px; height: 1px; overflow: hidden">Pas encore vu</span></span>' if new else ''}</a></li>'''
LISTI=ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',20); ENV=ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',20); TAGI=ic('<path d="M20 12 12 20l-8-8V4h8z"/><circle cx="8.500" cy="8.500" r="1.200"/>',20)
def grp(t,rows): return f'<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="{H2}">{t}</h2><ul style="{UL}">{rows}</ul></section>'
N['NotifCentre']=(scr(1100,titles('','Quoi de neuf','Ce qui te concerne, du plus récent au plus ancien.')
  +grp('Aujourd’hui',nrow(TAGI,'brick','Camille te demande des pistes de cadeaux','Famille Camille · 9 h 12',True,False)+nrow(LISTI,'pine','2 cadeaux ont été cochés sur ta liste','Noël 2026 · 8 h 40',True))
  +grp('Hier',nrow(TAGI,'brick','Camille a laissé de nouvelles pistes','Famille Camille · 18 h 02',True,False)+nrow(USERS,'pine','Mamie se joint au vélo, à plusieurs','Noël 2026 · 14 h 30'))
  +grp('Cette semaine',nrow(ENV,'brick','Le tirage est fait : ton enveloppe t’attend','Bureau, 3e étage · lundi',False,False)+nrow(LISTI,'neutral','Camille t’invite à tenir sa liste avec elle','Noël 2026 · dimanche'))
  +f'<p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.45; color: #57534e">Une ligne reste en gras tant que tu n’as pas ouvert ce qu’elle signale. Tout s’efface au bout de trente jours. <a href="NotifReglage.dc.html" style="color: #8a2f27; font-weight: 700">Choisir ce qui me prévient</a></p>','Notifications — quoi de neuf',navd('tirages',('listes',)),True,BURGERD),1100,'« Quoi de neuf » : le centre de notifications')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in N.items():
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
b=''.join(f'"{k}.dc.html": {json.dumps({"x":i*470,"y":0,"w":390,"h":ht,"title":t,"page":"notifs"},ensure_ascii=True)},\n    ' for i,(k,(h,ht,t)) in enumerate(N.items()))
o=''.join(f'"{k}.dc.html",\n    ' for k in N)
n='"q1": '+json.dumps({"kind":"title1","maxW":3680,"page":"notifs","text":"V2 · Pastilles, résumé par email, connexion par code, application installée","w":240,"x":0,"y":-300})+',\n    '
json.dump([{"old_text":'"PistesQuestion.dc.html": {',"new_text":b+'"PistesQuestion.dc.html": {'},{"old_text":'"order": [\n    ',"new_text":'"order": [\n    '+o},{"old_text":'"notes": {\n    ',"new_text":'"notes": {\n    '+n},{"old_text":'"noteOrder": [\n    ',"new_text":'"noteOrder": [\n    "q1",\n    '},{"old_text":'{\n      "id": "divers",',"new_text":'{\n      "id": "notifs",\n      "name": "Notifications et application"\n    },\n    {\n      "id": "divers",'}],open('/tmp/nedits.json','w'))
print(list(N))
