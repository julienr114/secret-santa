# Ceux qui offrent : toujours sous l'idée, une pastille par prénom ; plus de « Offert à plusieurs » (Julien, 20 novembre 2026). Après indent.py.
import glob,json,re
PJ='/home/claude/utt/project/'
PAT=re.compile(r' <span style="display: inline-block; text-decoration: none; font-size: 13px; font-weight: 700; color: #57534e; background: #f1e8d8; border-radius: 999px; padding: 1px 8px; margin-left: 4px([^"]*)"([^>]*)>([^<]*)</span>(<span style="display: block; font-size: 13px; line-height: 1.35; color: #57534e">Offert à plusieurs</span>)?')
def rep(m):
    extra,attrs,names=m.group(1),m.group(2),m.group(3)
    pills=''.join(f'<span style="display: inline-block; text-decoration: none; font-size: 13px; font-weight: 700; color: #57534e; background: #f1e8d8; border-radius: 999px; padding: 1px 8px{extra}"{attrs}>{n.strip()}</span>' for n in names.split(','))
    return f'<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px; text-decoration: none">{pills}</span>'
n=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read(); t=PAT.sub(rep,s)
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n)); json.dump(n,open('/tmp/offrent.json','w'))
