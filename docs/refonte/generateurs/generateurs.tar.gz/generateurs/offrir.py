# Le panneau de ce que j'offre, simplifié (Julien, 20 novembre 2026) : une seule question, trois choix, chacun dit qui le sait.
# Plus d'interrupteur « Dire à Camille que c'est moi », plus d'encart « Personne d'autre ne saura… ». Après trois.py.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.6): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
MASKP='<path d="M2.5 9.5c0-1.5 1-2.5 2.5-2.5 2.5 0 4.5 1.5 7 1.5s4.5-1.5 7-1.5c1.5 0 2.5 1 2.5 2.5 0 4.5-2.5 7.5-5.5 7.5-2 0-2.7-1.8-4-1.8s-2 1.8-4 1.8c-3 0-5.5-3-5.5-7.5z"/><path d="M7 11.5h2.5M14.5 11.5H17"/>'
r=open(PJ+'ListeReserver.dc.html',encoding='utf-8').read()
a=r.index('<div role="radiogroup" aria-label="Comment"'); e='Personne d’autre ne saura que c’est toi.</p>'; b=r.index(e,a)+len(e)
def opt(label,sub,sel=False,off=False,first=False,anon=False):
    bg=('#f1e6ee' if anon else '#fbf3f1') if sel else 'transparent'
    col='#a8a29e' if off else '#292524'; subc='#a8a29e' if off else '#57534e'
    acc='#5b3a55' if anon else '#b8483a'
    mask=f'<span aria-hidden="true" style="display: flex; color: {"#5b3a55" if not off else "#a8a29e"}">{ic(MASKP,20,2)}</span>' if anon else ''
    return (f'<label{" aria-disabled=\"true\"" if off else ""} style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 14px; box-sizing: border-box;{"" if first else " border-top: 1px solid #e9dcc5;"} background: {bg}; color: {col}">'
            f'<input type="radio" name="r"{" checked" if sel else ""}{" disabled" if off else ""} style="width: 22px; height: 22px; margin: 0; accent-color: {acc}; flex-shrink: 0">'
            f'<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{label}</span><span style="font-size: 13px; line-height: 1.35; color: {subc}">{sub}</span></span>{mask}</label>')
def group(mode):
    g=('<div role="radiogroup" aria-label="Comment tu l’offres" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">'
       +opt('Je l’offre seul','Camille sait que c’est toi. Les autres voient seulement que c’est pris.',sel=not mode,off=mode,first=True)
       +opt('Je l’offre seul, en anonyme','Personne ne sait que c’est toi, pas même Camille.',sel=mode,anon=True)
       +opt('On l’offre à plusieurs','D’autres pourront se joindre à toi, et verront ton prénom.',off=mode)+'</div>')
    if mode:
        g+=(f'<p style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 14px; line-height: 1.4; color: #5b3a55">{ic("<rect x=\"5\" y=\"11\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 11V7a4 4 0 0 1 8 0v4\"/>",16,2.2)}'
            '<span>Mode anonyme activé. Pour un autre choix, désactive-le en haut de la liste.</span></p>')
    return g
P={}
P['ListeReserverSimple']=(r[:a]+group(False)+r[b:],'Avant de publier · 2. le panneau simplifié : une question, trois choix, chacun dit qui le sait')
ra=r[:a]+group(True)+r[b:]
ra=ra.replace('Pour Léo · tu l’offres','Pour Léo · tu l’offres en anonyme',1)
P['ListeReserverAnonyme']=(ra,'Avant de publier · 2. le même, en mode anonyme : les deux autres choix sont fermés, un seul mot dessous')
names=json.load(open('/tmp/names.json'))
if 'ListeDecocherPanneau.dc.html' in names: names.remove('ListeDecocherPanneau.dc.html')
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(list(P))
