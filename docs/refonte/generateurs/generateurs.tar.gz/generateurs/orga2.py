import pathlib, json, re
src = open('/home/claude/gen/groupe.py').read().split("past = lambda")[0]
exec(src)
tplsheet = (P/'ConfirmerTirage.dc.html').read_text()
H1S = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15"
def sheet(name, title, back, filler, aria, inner, h=844):
    a = tplsheet.index('<section aria-label="Lancer le tirage"'); b = tplsheet.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="{aria}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
{inner}
  </section>'''
    t = tplsheet[:a] + sec + tplsheet[b:]
    for old, new in [('<title>Confirmation du tirage</title>', f'<title>{title}</title>'), ('height: 150px', f'height: {filler}px'), ('font-size: 30px; color: #5c554c">Noël 2026', f'font-size: 30px; color: #5c554c">{back}'), ('height: 844px', f'height: {h}px'), ('"height":844', f'"height":{h}')]:
        assert old in t, old; t = t.replace(old, new)
    (P/name).write_text(t)
def shead(title, desc): return f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1S}">{title}</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{desc}</p>
    </div>'''
PRIM = lambda label, dis=False: f'<button{" disabled" if dis else ""} style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">{label}</button>'
CANCEL = lambda href, label='Annuler': f'<a href="{href}" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">{label}</a>'
SAFE = lambda href, label: f'<a href="{href}" style="height: 52px; border-radius: 6px; background: #2f613f; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">{label}</a>'
DANGERBTN = lambda label: f'<button disabled style="width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #f6c3cc; border-radius: 6px; background: transparent; color: #b3243f; opacity: 0.55; font-family: inherit; font-size: 16px; font-weight: 700">{label}</button>'
bul = lambda s: f'<li style="display: flex; align-items: flex-start; gap: 8px"><span aria-hidden="true" style="width: 6px; height: 6px; margin-top: 8px; border-radius: 50%; background: #961d35; flex-shrink: 0"></span><span>{s}</span></li>'
def danger(title, items):
    return f'''<div role="alert" style="border: 2px solid #b3243f; border-radius: 12px; background: #fdf2f4; padding: 14px; display: flex; flex-direction: column; gap: 10px; color: #6b1c2e">
      <p style="margin: 0; display: flex; align-items: center; gap: 8px; font-family: 'Fraunces', Georgia, serif; font-size: 19px; font-weight: 700; line-height: 1.2">{ic('<path d="M10.300 3.900 1.800 18a2 2 0 0 0 1.700 3h17a2 2 0 0 0 1.700-3L13.700 3.900a2 2 0 0 0-3.400 0zM12 9v4M12 17h.010"/>', 24)}{title}</p>
      <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; font-size: 14px; line-height: 1.4">{''.join(bul(i) for i in items)}</ul>
    </div>'''
CLOCK = ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 14, 2.2)
I.update(refresh='<path d="M3 12a9 9 0 0 1 15-6.700L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.700L3 16M3 21v-5h5"/>', send='<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>', mail='<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>')

# 1 fiche participant (édition tirée)
build('FicheParticipant.dc.html', 'Édition — fiche d\'un participant', f'''<main style="{MAIN}">
    <div style="display: flex; align-items: center; gap: 16px">
      {pav('Hugo', size=72, fs=32)}
      <div style="display: flex; flex-direction: column; gap: 4px; min-width: 0">
        <h1 style="{H1}">Hugo</h1>
        <p style="margin: 0; display: flex; align-items: center; gap: 5px; font-size: 14px; color: #79511d">{CLOCK}Envoyé, pas encore consulté</p>
      </div>
    </div>
    <a href="Renvoi.dc.html" style="{BTN}">{ic(I['send'])}Renvoyer son lien</a>
    {section('Noël 2026', valrow('Message envoyé', 'Le 14 nov., par email', True) + valrow('Liste de souhaits', '3 idées') + valrow('Adresse et langue', 'Sa fiche', sub='hugo-demo@example.com · français'), 'Tu vois le nombre d’idées, jamais leur contenu.')}
    {section('Dépannage', row(bubble('undo', 'quiet'), 'Pas envoyé finalement ?', 'Remet Hugo dans « à prévenir »', first=True) + row(bubble('refresh', 'quiet'), 'Régénérer son lien', 'S’il a été transféré par erreur', href='PanneauRegenerer.dc.html') + row(bubble('userminus', 'quiet'), 'Retirer de l’édition', 'Impossible après le tirage : il faut d’abord l’annuler', href='AnnulerTirage.dc.html'), 'Aucune de ces actions ne révèle son résultat. Toutes sont inscrites au journal du groupe.')}
  </main>''', 1010)

# 2 panneau régénérer
sheet('PanneauRegenerer.dc.html', 'Panneau — régénérer un lien', 'Hugo', 250, 'Régénérer le lien de Hugo', shead('Régénérer le lien de Hugo ?', 'À faire si son lien a été transféré à quelqu’un d’autre.') + f'''
    <ul style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; font-size: 15px; line-height: 1.4">
      <li style="display: flex; gap: 12px; padding: 12px 14px"><span aria-hidden="true" style="color: #57534e; display: flex; margin-top: 2px">{ic(I['link'], 18)}</span>L’ancien lien ne marchera plus, pour personne.</li>
      <li style="display: flex; gap: 12px; padding: 12px 14px; border-top: 1px solid #e9dcc5"><span aria-hidden="true" style="color: #57534e; display: flex; margin-top: 2px">{ic(I['check'], 18, 2.6)}</span>Son résultat et sa liste de souhaits ne changent pas.</li>
      <li style="display: flex; gap: 12px; padding: 12px 14px; border-top: 1px solid #e9dcc5"><span aria-hidden="true" style="color: #57534e; display: flex; margin-top: 2px">{ic(I['doc'], 18)}</span>Le journal indiquera : « Le lien de Hugo a été régénéré ».</li>
    </ul>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      {PRIM('Régénérer et lui renvoyer')}
      {CANCEL('FicheParticipant.dc.html')}
    </div>''')

# 3 ajouter des participants
def crow(n, sub, checked, first=False):
    bt = '' if first else ' style="border-top: 1px solid #e9dcc5"'
    return f'''        <li{bt}>
          <label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">
            {pav(n)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="font-size: 13px; color: #57534e">{sub}</span></span>
            <input type="checkbox"{' checked' if checked else ''} style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
          </label>
        </li>
'''
PEOPLE.update({'Léa': ('🧣', 'frost'), 'Zoé': ('🍪', 'kraft'), 'Mamie Jo': ('🕯️', 'pine')})
t_main = f'''<main style="{MAIN}; flex-grow: 1">
    {head('Ajouter des participants', 'Noël 2026 · 5 participants pour l’instant')}
    {section('Membres du groupe qui ne participent pas', crow('Léa', 'lea-demo@example.com', True, True) + crow('Zoé', 'Pas d’adresse email', True) + crow('Mamie Jo', 'A participé à Noël 2025', False), 'Ceux qui ne participent plus au groupe n’apparaissent pas ici.')}
    {section('Quelqu’un de nouveau', row(bubble('userplus'), 'Créer une personne', 'Elle rejoint le groupe et cette édition', first=True, href='PersonneNouvelle.dc.html') + row(bubble('link'), 'Inviter par lien', 'Chacun s’inscrit lui-même', href='GroupeInvitation.dc.html'))}
  </main>
  <footer style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 14px 16px 20px">
    <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Ajouter 2 personnes</button>
  </footer>'''
build('AjouterParticipants.dc.html', 'Édition — ajouter des participants', t_main.split('\n  <footer')[0], 900)
p = P/'AjouterParticipants.dc.html'; t = p.read_text(); k = t.rindex('</main>') + 7
p.write_text(t[:k] + '\n  <footer' + t_main.split('\n  <footer')[1] + t[k:])

# 4 annuler le tirage
build('AnnulerTirage.dc.html', 'Édition — annuler le tirage', f'''<main style="{MAIN}">
    {head('Annuler le tirage ?', 'Noël 2026 · Famille Camille')}
    {danger('Tout le monde devra redécouvrir', ['Les 5 résultats sont effacés. 2 personnes avaient déjà découvert le leur.', 'La liste des participants redevient modifiable.', 'Après le nouveau tirage, il faudra prévenir chacun avec le message « Nouveau tirage ».'])}
    <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; font-size: 14px; line-height: 1.45; color: #57534e">
      <li style="display: flex; gap: 10px"><span aria-hidden="true" style="color: #2f613f; display: flex; margin-top: 2px">{ic(I['check'], 16, 2.6)}</span>Les liens personnels restent valables.</li>
      <li style="display: flex; gap: 10px"><span aria-hidden="true" style="color: #2f613f; display: flex; margin-top: 2px">{ic(I['check'], 16, 2.6)}</span>Les listes de souhaits sont conservées.</li>
    </ul>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="why" style="font-size: 15px; font-weight: 600">Motif</label>
      <input id="why" type="text" value="Désistement de Louis" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      <p style="margin: 0; font-size: 13px; color: #57534e">Affiché dans le journal, visible de tout le groupe.</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Ce que le groupe lira dans le journal</p>
      <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 16px; line-height: 1.35">Le tirage a été annulé. Motif : Désistement de Louis</p>
    </div>
    <label style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; font-size: 15px; line-height: 1.4">
      <input type="checkbox" style="width: 22px; height: 22px; margin: 1px 0 0; accent-color: #b8483a; flex-shrink: 0">
      Je comprends que les résultats actuels seront perdus
    </label>
    <div style="display: flex; flex-direction: column; gap: 8px">
      {SAFE('Suivi.dc.html', 'Garder ce tirage')}
      {DANGERBTN('Annuler le tirage')}
      <p style="margin: 0; text-align: center; font-size: 13px; color: #57534e">Le bouton s’active une fois la case cochée.</p>
    </div>
  </main>''', 1090)

# 5 nouvelle personne
build('PersonneNouvelle.dc.html', 'Groupe — nouvelle personne', f'''<main style="{MAIN}">
    <div style="display: flex; align-items: center; gap: 16px">
      <button aria-label="Changer l'avatar" style="position: relative; width: 72px; height: 72px; padding: 0; border: 0; border-radius: 50%; background: #d6e6ef; box-shadow: 0 0 0 1px #94bbd0; font-size: 32px; flex-shrink: 0"><span aria-hidden="true">⛄</span><span aria-hidden="true" style="position: absolute; right: -2px; bottom: -2px; width: 26px; height: 26px; box-sizing: border-box; border-radius: 50%; background: #fffdf9; border: 1px solid #dccbad; color: #57534e; display: flex; align-items: center; justify-content: center">{ic(I['pen'], 13)}</span></button>
      <div style="display: flex; flex-direction: column; gap: 4px; min-width: 0">
        <h1 style="{H1}">Nouvelle personne</h1>
        <p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille</p>
      </div>
    </div>
    {field('fn', 'Prénom', '', req=True)}
    {field('em', 'Adresse email', '', 'Pour lui envoyer son lien. Sans adresse, tu le partageras toi-même par WhatsApp ou SMS.', 'prenom@exemple.fr')}
    {section('', valrow('Langue de ses messages', 'Français', True) + switch('Participe à Noël 2026', True, 'Le tirage n’a pas encore eu lieu'))}
    <div style="display: flex; flex-direction: column; gap: 6px">
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700">Ajouter</button>
      <button style="height: 46px; border: 0; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 600">Ajouter, puis en créer une autre</button>
    </div>
    <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Une icône lui est donnée au hasard ; elle pourra la changer.</p>
  </main>''', 900)

# 6 panneau exclusion
def pick(label, n):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px">
        <span id="l-{n}" style="font-size: 15px; font-weight: 600">{label}</span>
        <button aria-labelledby="l-{n}" aria-haspopup="listbox" style="min-height: 56px; box-sizing: border-box; padding: 6px 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 12px; text-align: left">{pav(n)}<span style="flex-grow: 1">{n}</span><span style="color: #57534e; display: flex">{ic('<path d="m6 9 6 6 6-6"/>', 18, 2.2)}</span></button>
      </div>'''
SW = '''<div style="display: flex; align-items: center; gap: 12px; min-height: 48px">
      <span style="flex-grow: 1; font-size: 16px; font-weight: 600">Dans les deux sens</span>
      <button role="switch" aria-checked="true" aria-label="Dans les deux sens" style="width: 48px; height: 44px; padding: 0; border: 0; background: transparent; display: flex; align-items: center"><span style="width: 48px; height: 28px; border-radius: 999px; background: #2f613f; display: flex; align-items: center"><span style="width: 24px; height: 24px; border-radius: 50%; background: #ffffff; margin-left: 20px"></span></span></button>
    </div>'''
sheet('PanneauExclusion.dc.html', 'Panneau — nouvelle exclusion', 'Exclusions', 150, 'Nouvelle exclusion', shead('Nouvelle exclusion', 'Deux personnes qui ne doivent pas se tirer : un couple, des frères et sœurs…') + f'''
    {pick('Qui', 'Inès')}
    {pick('Ne tire pas', 'Louis')}
    {SW}
    <p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 15px; line-height: 1.4"><strong>Inès et Louis</strong> ne se tireront jamais l’un l’autre.</p>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      {PRIM('Ajouter l’exclusion')}
      {CANCEL('GroupeExclusions.dc.html')}
    </div>''')

# 7 panneau organisateur
sheet('PanneauOrganisateur.dc.html', 'Panneau — nouvel organisateur', 'Réglages', 280, 'Nouvel organisateur', shead('Nouvel organisateur', 'Il pourra gérer Famille Camille comme toi : membres, tirage, envois.') + f'''
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="oe" style="font-size: 15px; font-weight: 600">Son adresse email</label>
      <input id="oe" type="email" placeholder="prenom@exemple.fr" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Il lui suffira de se connecter avec cette adresse : aucun mot de passe à transmettre.</p>
    </div>
    <div style="display: flex; align-items: flex-start; gap: 10px; font-size: 14px; line-height: 1.45; color: #57534e">
      <span aria-hidden="true" style="display: flex; margin-top: 1px">{ic('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', 18)}</span>
      <span>Comme toi, il ne verra pas les résultats du tirage.</span>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      {PRIM('Ajouter')}
      {CANCEL('GroupeReglages.dc.html')}
    </div>''')

# 8 panneau supprimer le groupe
sheet('PanneauSupprimerGroupe.dc.html', 'Panneau — supprimer le groupe', 'Réglages', 110, 'Supprimer Famille Camille', shead('Supprimer Famille Camille ?', 'Réservé au super-admin.') + f'''
    {danger('Tout est effacé, pour de bon', ['Les 6 personnes et leurs exclusions.', 'Les 3 éditions, leurs tirages et les listes de souhaits.', 'Le journal du groupe.', 'Les liens personnels cessent de marcher.'])}
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="slug" style="font-size: 15px; font-weight: 600">Recopie l’identifiant du groupe : famille-camille</label>
      <input id="slug" type="text" autocomplete="off" autocapitalize="off" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 8px">
      {SAFE('GroupeReglages.dc.html', 'Garder le groupe')}
      {DANGERBTN('Supprimer définitivement')}
    </div>''')
print('ok')
