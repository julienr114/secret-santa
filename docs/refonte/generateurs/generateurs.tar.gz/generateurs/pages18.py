import re,os,shutil,json
PJ='/home/claude/utt/project/'; out='/mnt/user-data/outputs/c18'
src=open(PJ+'DevineRappelPersonnaliser.dc.html').read()
TOP=src[:src.index('<main')]; TAIL=src[src.index('</x-dc>'):]
F="'Fraunces', Georgia, serif"
LAB='margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
CHEV='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
OPT='<span style="font-weight: 600; text-transform: none; letter-spacing: 0">(facultatif)</span>'
def ctx(parts):
    if not parts: return ''
    a='<span aria-hidden="true">·</span>'.join(f'<a href="#" style="min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 600; color: #57534e; text-decoration: none">{p}</a>' for p in parts)
    return f'<nav aria-label="Tu es ici" style="margin: -14px 0 -12px; display: flex; align-items: center; gap: 6px; color: #57534e">{a}</nav>'
def head(parts,h1,sub=''):
    return f'''<div style="display: flex; flex-direction: column; gap: 4px">
      {ctx(parts)}
      <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{h1}</h1>
      {f'<p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{sub}</p>' if sub else ''}
    </div>'''
def area(id,label,value,ph,help,count,rows=4,opt=False):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px">
      <label for="{id}" style="{LAB}">{label}{' '+OPT if opt else ''}</label>
      <textarea id="{id}" rows="{rows}" placeholder="{ph}" style="width: 100%; min-height: {rows*24+24}px; box-sizing: border-box; padding: 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45; resize: none">{value}</textarea>
      <p style="margin: 0; padding: 0 4px; display: flex; justify-content: space-between; gap: 12px; font-size: 13px; line-height: 1.4; color: #57534e"><span>{help}</span><span style="flex-shrink: 0">{count}</span></p>
    </div>'''
def line(id,label,value,ph,help,opt=False):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px">
      <label for="{id}" style="{LAB}">{label}{' '+OPT if opt else ''}</label>
      <input id="{id}" type="text" value="{value}" placeholder="{ph}" style="width: 100%; height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      {f'<p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">{help}</p>' if help else ''}
    </div>'''
BTN='width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700'
def page(title,main,footer=None,h=844):
    footer=footer if footer is not None else f'<button style="{BTN}">Valider</button>'
    s=TOP.replace('height: 844px',f'height: {h}px',1)+f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 24px">
    {main}
  </main>
  <footer style="flex-shrink: 0; background: #fffdf9; border-top: 1px solid #dccbad; padding: 14px 16px 20px">
    {footer}
  </footer>
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
G=['Famille Camille','Noël 2026']
DEL=lambda t:f'<a href="#" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; font-size: 16px; font-weight: 600; color: #a43a2f; text-decoration: none">{t}</a>'
B={}
B['PistesIdee']=(page('Mes pistes — une idée précise',head(G,'Modifier l’idée','Une idée courte, et un lien si tu en as un.')
  +area('idee','Idée','Un jeu de société pour deux','Un livre, des chaussettes…','','27 / 200',2)
  +line('lien','Lien','https://boutique-jeux.example/duo','https://…','Colle l’adresse d’une page : il s’ouvrira dans un nouvel onglet.',True)
  +DEL('Supprimer l’idée')),'Une idée précise, sur sa page (remplace SouhaitsIdee)')
def texte(k,h1,help,val,ph,n):
    B[k]=(page(f'Mes pistes — {h1}',head(G,h1,help)+area('t',h1,val,ph,'',f'{n} / 300',5)),f'« {h1} », sur sa page (remplace PistesRubrique)')
texte('PistesTexteMoment','En ce moment','Ce qui t’occupe ou te fait envie ces temps-ci. Pas besoin d’objets précis.','Je me mets à la course à pied, je lis des BD et je cuisine le dimanche.','Un loisir qui démarre, une lecture, un projet…',71)
texte('PistesTexteServirait','Ce qui me servirait','Ce qui te rendrait service au quotidien.','Une bonne lampe de lecture. De quoi ranger mes épices.','Ce que tu utilises tous les jours, ce qui te manque…',54)
texte('PistesTexteEviter','J’évite, ou j’ai déjà','Ce qu’il vaut mieux ne pas t’offrir.','','Une allergie, ce que tu as en trop…',0)
B['EditionMot']=(page('Petit mot — Famille Camille · Noël 2026',head(G,'Petit mot')
  +area('m','Ton mot','On ouvre les cadeaux après le dessert !','On ouvre les cadeaux après le dessert !','Affiché avec le résultat de chacun.','39 / 300',4,True)),'Le petit mot de l’édition, sur sa page')
def rad(t,on,top=True): return f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}"><input type="radio" name="w" {'checked ' if on else ''}style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0"><span style="font-size: 16px; font-weight: 600">{t}</span></label>'''
B['GroupeMot']=(page('Mot ajouté aux messages — Famille Camille',head(['Famille Camille'],'Mot ajouté aux messages','Ajouté tel quel à chaque message et email envoyé aux participants. Tu peux encore le modifier au moment d’envoyer.')
  +area('m','Ton mot','On ouvre les cadeaux après le dessert !','','Envoyé tel quel, quelle que soit la langue.','39 / 500',5)
  +f'''<div style="display: flex; flex-direction: column; gap: 8px"><h2 style="{LAB}">Où le placer</h2><div role="radiogroup" aria-label="Où le placer" style="margin: 0 -16px; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{rad('Au-dessus du message',False,False)}{rad('En dessous du message',True)}</div></div>'''),'Le mot du groupe, sur sa page (remplace PanneauTexte)')
B['GroupeInvitationMot']=(page('Ton mot sur la page — Famille Camille',head(['Famille Camille'],'Ton mot sur la page','Facultatif. Ce que les invités liront en ouvrant le lien.')
  +area('m','Ton mot','Rejoins-nous ! On tire au sort le 1er décembre.','','','46 / 500',5)),'Le message du lien d’invitation, sur sa page')
B['DemandeGroupe']=(page('Organiser un tirage',head([],'Organiser un tirage','Pour qui veux-tu organiser un tirage ?')
  +area('d','Ta demande','','Le Noël de ma famille, une douzaine de personnes.','Un administrateur te répond par email.','0 / 500',5)
  +f'''<div style="padding: 14px 16px; border-radius: 12px; background: #f1e8d8; display: flex; flex-direction: column; gap: 4px"><h2 style="margin: 0; font-family: inherit; font-size: 15px; font-weight: 700">Pourquoi une demande ?</h2><p style="margin: 0; font-size: 14px; line-height: 1.45">Under the Tree est en bêta : la création de groupes se fait sur demande, le temps de vérifier que tout fonctionne bien.</p></div>''',
  f'<button style="{BTN}">Envoyer ma demande</button>'),'Demander à créer un groupe, sur sa page (remplace PanneauDemandeGroupe)')
def chipp(t,on=False): return f'<button aria-pressed="{"true" if on else "false"}" style="height: 40px; padding: 0 14px; border: 1px solid {"#b8483a" if on else "#dccbad"}; border-radius: 999px; background: {"#f6e2dd" if on else "#fffdf9"}; color: {"#8a2f27" if on else "#292524"}; font-family: inherit; font-size: 14px; font-weight: 700">{t}</button>'
def stepper(label,a,b,top=True): return f'''<li style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 6px 16px; box-sizing: border-box;{' border-top: 1px solid #e9dcc5;' if top else ''}"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">{label}</span><span style="font-size: 15px; color: #78716c">{a}</span><span aria-hidden="true" style="color: #78716c">→</span><span style="font-size: 16px; font-weight: 700">{b}</span></li>'''
def admin(k,val,n,on,title):
    B[k]=(page('Demande de Léa Martin — Administration',head(['Administration'],'Demande de Léa Martin','Envoyée le 14 novembre')
      +f'<blockquote style="margin: 0; padding: 12px 14px; border-radius: 16px 16px 16px 4px; background: #f1e8d8; font-size: 15px; line-height: 1.45">Le Noël de ma famille, une douzaine de personnes.</blockquote>'
      +f'''<div style="display: flex; flex-direction: column; gap: 8px">
      <label for="r" style="{LAB}">Un mot en réponse {OPT}</label>
      <div role="group" aria-label="Messages tout prêts" style="display: flex; flex-wrap: wrap; gap: 8px">{chipp('Bienvenue',on==0)}{chipp('C’est complet',on==1)}{chipp('Entre proches',on==2)}</div>
      <textarea id="r" rows="4" placeholder="Bienvenue ! Dis-moi si tu bloques." style="width: 100%; min-height: 120px; box-sizing: border-box; padding: 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45; resize: none">{val}</textarea>
      <p style="margin: 0; padding: 0 4px; display: flex; justify-content: space-between; gap: 12px; font-size: 13px; color: #57534e"><span>Ajouté à l’email qui annonce ta réponse.</span><span style="flex-shrink: 0">{n} / 300</span></p>
    </div>'''
      +f'''<div style="display: flex; flex-direction: column; gap: 8px"><h2 style="{LAB}">Si tu acceptes</h2><ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{stepper('Groupes qu’elle peut créer',0,1,False)}{stepper('Groupes dans l’application',4,5)}</ul><p style="margin: 0; padding: 0 4px; font-size: 13px; color: #57534e">5 sur environ 50 groupes couverts par les offres gratuites.</p></div>''',
      f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><button style="height: 52px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 17px; font-weight: 700">Refuser</button><button style="{BTN}">Accepter</button></div>',900),title)
admin('AdminDemandePage','',0,-1,'Répondre à une demande, sur sa page (remplace AdminDemande)')
admin('AdminDemandePageMot','Désolé, l’application est complète pour cette année. Retente ta chance l’an prochain !',86,1,'Répondre à une demande : un message tout prêt choisi (remplace AdminDemandeMot*)')
# EditionNouvelle : le petit mot devient une ligne qui ouvre la page
e=open(PJ+'EditionNouvelle.dc.html').read()
i=e.find('<div style="display: flex; flex-direction: column; gap: 6px">\n      <label for="mt"'); j=e.index('</div>',i)+6 if i>=0 else 0
row=f'''<ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad"><li><a href="EditionMot.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #292524"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">Petit mot pour les participants</span><span style="font-size: 13px; color: #57534e">Facultatif. Affiché avec le résultat.</span></span><span style="font-size: 15px; color: #57534e">Aucun</span><span style="color: #78716c; display: flex; flex-shrink: 0">{CHEV}</span></a></li></ul>'''

if i>=0: open(PJ+'EditionNouvelle.dc.html','w').write(e[:i]+row+e[j:])
# Pistes : les lignes ouvrent les nouvelles pages
p=open(PJ+'Pistes.dc.html').read()
for t in ['PistesTexteMoment','PistesTexteServirait','PistesTexteEviter']: p=p.replace('href="PistesRubrique.dc.html"',f'href="{t}.dc.html"',1)
open(PJ+'Pistes.dc.html','w').write(p)
# anciennes maquettes : « remplacée par … » dans le titre
OLD={'SouhaitsIdee':'PistesIdee','PistesRubrique':'PistesTexteMoment, PistesTexteServirait, PistesTexteEviter','PanneauTexte':'GroupeMot, EditionMot, GroupeInvitationMot','PanneauDemandeGroupe':'DemandeGroupe','AdminDemande':'AdminDemandePage','AdminDemandeMot':'AdminDemandePageMot','AdminDemandeMotBienvenue':'AdminDemandePageMot','AdminDemandeMotProches':'AdminDemandePageMot'}
for k,v in OLD.items():
    t=open(PJ+k+'.dc.html').read(); m=re.search(r'<title>([^<]*)</title>',t); assert m,k
    if 'remplacée par' not in m.group(1): t=t.replace(m.group(0),f'<title>{m.group(1)} — remplacée par {v} (Correction 18)</title>',1); open(PJ+k+'.dc.html','w').write(t)
for k in B: open(PJ+k+'.dc.html','w').write(B[k][0])
allk=list(B)+['EditionNouvelle','Pistes']+list(OLD)
for k in allk: shutil.copy(PJ+k+'.dc.html',f'{out}/{k}.html')
print(json.dumps([{"as":f"project/{k}.dc.html","path":f"{PJ}{k}.dc.html"} for k in allk]))
print(json.dumps([{"stagedPath":f"{out}/{k}.html","devicePath":f"/Users/julien.rabin/Workspace/personnal/secret-santa/docs/refonte/maquettes/{k}.html"} for k in allk]))
