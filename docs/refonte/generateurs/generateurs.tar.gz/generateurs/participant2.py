import pathlib, json, re
src = open('/home/claude/gen/accueil.py').read().split("# A1 participant seul")[0]
exec(src)
base = (P/'TirageAttente.dc.html').read_text()
BACK = '<button aria-label="Retour" style="width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg></button>'
def pbuild(name, title, main, h, back=True):
    t = base
    i = t.index('<main'); j = t.index('</main>') + len('</main>')
    t = t[:i] + main + t[j:]
    t = t.replace('<title>Mon tirage — avant le tirage</title>', f'<title>{title}</title>')
    if back: t = t.replace('<div></div>', f'<div>{BACK}</div>', 1)
    t = t.replace('height: 844px', f'height: {h}px').replace('"height":844', f'"height":{h}')
    (P/name).write_text(t)
PM = 'flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px'
LOCKN = f'''<div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #274e34">{ic('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', 18)}</span>
      <span>Seule la personne qui t’offre un cadeau verra ta liste, une fois le tirage fait.</span>
    </div>'''
def whead(sub='Famille Camille · Noël 2026'):
    return f'''<div style="display: flex; flex-direction: column; gap: 4px">
      <p style="margin: 0; font-size: 14px; color: #57534e">{sub}</p>
      <h1 style="{H1}">Ma liste de souhaits</h1>
    </div>'''
STARB = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#d9a62e" style="flex-shrink: 0"><path d="M12 2l2.200 7.800L22 12l-7.800 2.200L12 22l-2.200-7.800L2 12l7.800-2.200z"/></svg>'
def wish(label, link='', first=False, editable=True):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    l = f'<span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: #8a2f27; font-weight: 600">{ic(I["link"], 13)}{link}</span>' if link else ''
    trail = f'<span style="color: #78716c; display: flex; flex-shrink: 0">{ic(I["pen"], 18)}</span>' if editable else ''
    tag = 'a' if editable else 'div'
    href = ' href="SouhaitsIdee.dc.html"' if editable else ''
    return f'''        <li>
          <{tag}{href} style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 10px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            {STARB}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; line-height: 1.35">{label}</span>{l}</span>
            {trail}
          </{tag}>
        </li>
'''
ADD = inrow(bubble('plus'), 'Ajouter une idée', 'Encore 7 possibles', CHEV, href='SouhaitsIdee.dc.html')
# S1 remplie
pbuild('Souhaits.dc.html', 'Ma liste de souhaits', f'''<main style="{PM}">
    {whead()}
    {LOCKN}
    {section('3 idées', wish('Un roman policier', first=True) + wish('Un jeu de société pour deux', 'boutique-jeux.example') + wish('Des chaussettes bien chaudes') + ADD, 'Tu peux la modifier jusqu’à la fête. Chaque changement est noté au journal, sans son contenu.')}
  </main>''', 844)
# S2 vide
chip = lambda t: f'<button style="min-height: 44px; padding: 0 14px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600">{t}</button>'
pbuild('SouhaitsVide.dc.html', 'Ma liste de souhaits — vide', f'''<main style="{PM}">
    {whead()}
    {LOCKN}
    <section style="{CARD} padding: 24px 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <h2 style="{CT}">Aucune idée pour l’instant</h2>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Deux ou trois pistes suffisent : une envie, un auteur, une taille, un lien.</p>
      </div>
      <a href="SouhaitsIdee.dc.html" style="{BTN}">{ic(I['plus'])}Ajouter une idée</a>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px">
      <h2 style="{H2}">Pour démarrer</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 8px">{chip('Un livre')}{chip('Un jeu de société')}{chip('Quelque chose à déguster')}{chip('De quoi avoir chaud')}{chip('Une surprise')}</div>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; color: #57534e">Touche une piste pour la reprendre et la préciser.</p>
    </section>
  </main>''', 844)
# S4 lecture seule
pbuild('SouhaitsFigee.dc.html', 'Ma liste de souhaits — lecture seule', f'''<main style="{PM}">
    {whead('Famille Camille · Noël 2025')}
    <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; color: #292524; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #57534e">{ic(I['archive'], 18)}</span>
      <span>Cette édition est clôturée : la liste n’est plus modifiable.</span>
    </div>
    {section('3 idées', wish('Un roman policier', first=True, editable=False) + wish('Un jeu de société pour deux', 'boutique-jeux.example', editable=False) + wish('Des chaussettes bien chaudes', editable=False))}
  </main>''', 844)
# S3 panneau idée
tpl = (P/'ConfirmerTirage.dc.html').read_text()
def sheet(name, title, back, filler, aria, inner, h=844):
    a = tpl.index('<section aria-label="Lancer le tirage"'); b = tpl.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="{aria}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
{inner}
  </section>'''
    t = tpl[:a] + sec + tpl[b:]
    for old, new in [('<title>Confirmation du tirage</title>', f'<title>{title}</title>'), ('height: 150px', f'height: {filler}px'), ('font-size: 30px; color: #5c554c">Noël 2026', f'font-size: 30px; color: #5c554c">{back}'), ('height: 844px', f'height: {h}px'), ('"height":844', f'"height":{h}')]:
        assert old in t, old; t = t.replace(old, new)
    (P/name).write_text(t)
H1S = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15"
sheet('SouhaitsIdee.dc.html', 'Ma liste de souhaits — modifier une idée', 'Ma liste de souhaits', 230, 'Modifier l’idée', f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1S}">Modifier l’idée</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Une idée courte, et un lien si tu en as un.</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="idea" style="font-size: 15px; font-weight: 600">Idée</label>
      <input id="idea" type="text" value="Un jeu de société pour deux" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      <p style="margin: 0; text-align: right; font-size: 13px; color: #57534e">27 / 200</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="url" style="font-size: 15px; font-weight: 600">Lien <span style="font-weight: 400; color: #57534e">(facultatif)</span></label>
      <input id="url" type="url" inputmode="url" value="https://boutique-jeux.example/duo" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      <p style="margin: 0; font-size: 13px; color: #57534e">Colle l’adresse d’une page : il s’ouvrira dans un nouvel onglet.</p>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
      <button style="width: 100%; height: 46px; border: 0; border-radius: 6px; background: transparent; color: #961d35; font-family: inherit; font-size: 16px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px">{ic(I['trash'], 18)}Supprimer l’idée</button>
    </div>''')

# ---- Rejoindre ----
LOGO = '<svg role="img" aria-label="Under the Tree" width="56" height="56" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#a43a2f"/><path fill="#fffdf9" d="M32 15 44 30h-6l10 13H36v7h-8v-7H16l10-13h-6z"/><path fill="#e6b94a" d="m32 5 2.400 5 5.400.700-4 3.800 1 5.400-4.800-2.600-4.800 2.600 1-5.400-4-3.800 5.400-.700z"/></svg>'
def invite_head():
    return f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center">
      {LOGO}
      <p style="margin: 0; font-size: 15px; color: #57534e">Tu es invité au Secret Santa</p>
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 34px; line-height: 1.05; color: #a43a2f">Famille Camille</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">Noël 2026 · échange le 25 décembre · 5 personnes inscrites</p>
    </div>
    <figure style="margin: 0; display: flex; flex-direction: column; gap: 6px">
      <blockquote style="margin: 0; padding: 12px 14px; border-radius: 16px 16px 16px 4px; background: #f1e8d8; font-size: 16px; line-height: 1.45">Rejoins-nous ! On fait le tirage dimanche.</blockquote>
      <figcaption style="padding: 0 4px; font-size: 13px; color: #57534e">Le mot de l’organisateur</figcaption>
    </figure>'''
RM = 'flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 16px 16px 24px'
pbuild('Rejoindre.dc.html', 'Rejoindre un groupe — sans session', f'''<main style="{RM}">
    {invite_head()}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <p style="margin: 0; font-size: 15px; line-height: 1.45">Connecte-toi avec ton adresse email pour le rejoindre. Pas encore de compte ? Il se crée tout seul.</p>
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="email" style="font-size: 15px; font-weight: 600">Adresse email</label>
        <input id="email" type="email" autocomplete="email" placeholder="toi@exemple.fr" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
        <p style="margin: 0; font-size: 13px; color: #57534e">Pas de mot de passe : tu reçois un lien valable 15 minutes.</p>
      </div>
      <button style="height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{ic('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>')}Recevoir mon lien</button>
    </section>
  </main>''', 844, back=False)
pbuild('RejoindreConnecte.dc.html', 'Rejoindre un groupe — connecté', f'''<main style="{RM}">
    {invite_head()}
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px">
        <p style="margin: 0; font-size: 14px; color: #57534e; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">Connecté avec hugo-demo@example.com</p>
        <button style="min-height: 44px; padding: 0 4px; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 14px; font-weight: 700; text-decoration: underline; flex-shrink: 0">Ce n’est pas moi</button>
      </div>
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="fn" style="font-size: 15px; font-weight: 600">Prénom</label>
        <input id="fn" type="text" value="Hugo" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
        <p style="margin: 0; font-size: 13px; color: #57534e">Le prénom que verront les autres.</p>
      </div>
      <a href="RejoindreFait.dc.html" style="{BTN}">Rejoindre le groupe</a>
    </section>
  </main>''', 844, back=False)
pbuild('RejoindreFait.dc.html', 'Rejoindre un groupe — c\'est fait', f'''<main style="{RM}">
    <div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; padding-top: 24px">
      <span aria-hidden="true" style="width: 64px; height: 64px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center">{ic(I['check'], 32, 2.6)}</span>
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Bienvenue dans Famille Camille</h1>
      <p style="margin: 0; font-size: 16px; line-height: 1.45; color: #57534e">Tu participes à Noël 2026. Le tirage n’a pas encore eu lieu : ton organisateur te préviendra.</p>
    </div>
    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <h2 style="{CT}">En attendant</h2>
      <a href="SouhaitsVide.dc.html" style="{BTN}">Noter mes idées de cadeaux</a>
      <a href="TirageAttente.dc.html" style="height: 46px; border-radius: 6px; color: #8a2f27; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Voir mon tirage</a>
    </section>
    <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Tu le retrouveras sur ton accueil en te connectant avec hugo-demo@example.com.</p>
  </main>''', 844, back=False)
LOCKED = '''<svg aria-hidden="true" width="184" height="128" viewBox="0 0 184 128" fill="none">
      <rect x="6" y="14" width="172" height="108" rx="8" fill="#e9dcc5" stroke="#cdb48a" stroke-width="2"/>
      <path d="M8 18 84 74a13 13 0 0 0 16 0l76-56" fill="#f1e8d8" stroke="#cdb48a" stroke-width="2" stroke-linejoin="round"/>
      <circle cx="92" cy="78" r="24" fill="#fffdf9" stroke="#cdb48a" stroke-width="2"/>
      <rect x="82" y="76" width="20" height="15" rx="3" fill="#57534e"/>
      <path d="M86 76v-5a6 6 0 0 1 12 0v5" stroke="#57534e" stroke-width="3" stroke-linecap="round"/>
    </svg>'''
pbuild('RejoindreFerme.dc.html', 'Rejoindre un groupe — lien fermé', f'''<main style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 80px 32px 24px; text-align: center">
    {LOCKED}
    <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 28px; line-height: 1.15">Il n’y a plus de place par ce lien</h1>
    <p role="alert" style="margin: 0; font-size: 16px; line-height: 1.5; color: #57534e">Préviens l’organisateur de Famille Camille : il peut rouvrir des places ou t’ajouter lui-même.</p>
    <ul style="list-style: none; margin: 8px 0 0; padding: 0; align-self: stretch; text-align: left; border: 1px solid #dccbad; border-radius: 12px; background: #fffdf9; font-size: 14px; line-height: 1.45; color: #57534e">
      <li style="padding: 12px 14px"><strong style="color: #292524">Lien expiré</strong> : « Ce lien d’invitation n’est plus valable depuis le 10 décembre. »</li>
      <li style="padding: 12px 14px; border-top: 1px solid #e9dcc5"><strong style="color: #292524">Lien désactivé ou inconnu</strong> : « Ce lien d’invitation ne marche plus. »</li>
      <li style="padding: 12px 14px; border-top: 1px solid #e9dcc5"><strong style="color: #292524">Tirage déjà fait</strong> : tu rejoins le groupe, pas le tirage en cours.</li>
    </ul>
  </main>''', 844, back=False)

# ---- carte compte, 3 cas ----
def acct(label, body, btn, icon):
    return f'''<div style="display: flex; flex-direction: column; gap: 6px">
      <p style="{H2}">{label}</p>
      <section style="{CARD} padding: 16px; display: flex; flex-direction: column; gap: 10px">
        <div style="display: flex; align-items: flex-start; gap: 12px">
          <span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(icon, 18)}</span>
          <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 18px; line-height: 1.25">Garde tes tirages au même endroit</h2><p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">{body}</p></div>
        </div>
        <button style="height: 46px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 700">{btn}</button>
      </section>
    </div>'''
USER = '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.500 18.500a6.500 6.500 0 0 1 11 0"/>'
pbuild('CarteCompte.dc.html', 'Page d\'un tirage — carte de compte, les trois cas', f'''<main style="{PM}">
    {acct('Adresse connue de l’organisateur', 'Un lien de connexion, et ce tirage est dans ton compte, avec les suivants.', 'Recevoir mon lien à hugo-demo@example.com', I['share'] if False else '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>')}
    {acct('Pas d’adresse connue', 'Crée un compte avec ton adresse email : tu retrouveras ce tirage sans chercher le lien.', 'Créer mon compte', USER)}
    {acct('Déjà connecté, tirage pas encore rattaché', 'Ajoute ce tirage à ton compte pour le retrouver depuis ton accueil.', 'Ajouter à mon compte', I['link'])}
    <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Une fois le lien envoyé, la carte affiche « Lien envoyé à hugo-demo@example.com : ouvre-le pour créer ton compte. »</p>
  </main>''', 844, back=False)
print('ok')
