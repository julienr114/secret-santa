# La fiche d'un proche (Julien, 19 novembre 2026, soir, deuxième version) : la fiche garde ses lignes ; chacune ouvre une PAGE, plus un panneau.
# Date de naissance : jour, mois, année. Pointure : on choisit dans une grille, une ou plusieurs. Taille de vêtements et adresse : un champ d'une ligne.
# À lancer en tout dernier (après proches.py).
import io,contextlib,json,re
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/stop.py').read().split("# 1. le premier email")[0])
BURGER='<button aria-label="Menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>'
def pg(h,main,title):
    s=HEAD+f"""<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header(BURGER)}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 16px 16px 24px">
    {main}
  </main>
</div>
"""+TAIL
    s=re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
    return re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%h,s)
FIELD='width: 100%; height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px'
DOWN=ic('<path d="m6 9 6 6 6-6"/>',16,2.4)
def tete(t): return f'<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Mes proches · Léo</p><h1 style="{H1}">{t}</h1></div>'
def who(t): return f'<p style="{SM}">{t}</p>'
VAL=f'<a href="ListePersonne.dc.html" style="{BTN}">Valider</a>'
def sel(lab,val,w): return f'<label style="display: flex; flex-direction: column; gap: 4px; {w}"><span style="font-size: 13px; color: #57534e">{lab}</span><span role="combobox" aria-label="{lab}" style="{FIELD}; display: flex; align-items: center; justify-content: space-between; gap: 6px; padding-right: 8px">{val}<span style="display: flex; color: #78716c">{DOWN}</span></span></label>'
LK='min-height: 44px; display: inline-flex; align-items: center; font-size: 15px; font-weight: 700; color: #57534e; text-decoration: underline'
P={}
P['ProcheNaissance']=(pg(844,f'''{tete('Sa date de naissance')}
    <div role="group" aria-label="Date de naissance" style="display: flex; gap: 8px">{sel('Jour','14','width: 84px')}{sel('Mois','mars','flex: 1')}{sel('Année','2020','width: 108px')}</div>
    {VAL}
    <p style="margin: 0; text-align: center"><a href="#" style="{LK}">Effacer la date</a></p>''','Mes proches — la date de naissance, sur une page'),844,'Date de naissance : une page, trois listes, pas de calendrier')
def sz(n,on=False): return f'<button role="checkbox" aria-checked="{"true" if on else "false"}" style="height: 44px; border: {"2px solid #b8483a" if on else "1px solid #dccbad"}; border-radius: 10px; background: {"#f6e2dd" if on else "#fffdf9"}; color: {"#8a2f27" if on else "#292524"}; font-family: inherit; font-size: 16px; font-weight: 700">{n}</button>'
def grid(a,b,on=()): return '<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 8px">'+''.join(sz(n,n in on) for n in range(a,b+1))+'</div>'
P['ProchePointure']=(pg(920,f'''{tete('Sa ou ses pointures')}
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Enfant</h2>{grid(16,34,(30,31))}</section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Ado et adulte</h2>{grid(35,50)}</section>
    {VAL}
    <p style="margin: 0; text-align: center"><a href="#" style="{LK}">Tout effacer</a></p>''','Mes proches — la pointure, à choisir dans une grille'),920,'Pointure : on choisit dans une grille, une ou deux')
P['ProcheTaille']=(pg(844,f'''{tete('Sa taille de vêtements')}
    <div style="display: flex; flex-direction: column; gap: 6px"><input id="t" aria-label="Taille de vêtements" maxlength="40" placeholder="6 ans, M, 38, plutôt grand…" style="{FIELD}"><span style="align-self: flex-end; font-size: 13px; color: #57534e">0 / 40</span></div>
    {VAL}''','Mes proches — la taille de vêtements, un champ d’une ligne'),844,'Taille de vêtements : une page, un champ d’une ligne, libre')
P['ProcheAdresse']=(pg(844,f'''{tete('Son adresse email')}
    <div style="display: flex; flex-direction: column; gap: 6px"><input id="e" aria-label="Adresse email" type="email" inputmode="email" placeholder="prenom@exemple.fr" style="{FIELD}"></div>
    {VAL}''','Mes proches — l’adresse email, un champ d’une ligne'),844,'Adresse email : une page, un champ d’une ligne')
# la fiche : ses lignes restent, et mènent à ces pages ; plus « Son compte » et « Supprimer »
p=PJ+'ListePersonne.dc.html'; h=open(p).read()
if 'data-fiche="2"' not in h:
    h=h.replace('<span style="flex-grow: 1; font-weight: 600; font-size: 16px">Date de naissance</span><span style="font-size: 15px; color: #57534e">14 mars 2020 · 6 ans</span>','<span style="flex-grow: 1; font-weight: 600; font-size: 16px">Date de naissance</span><span style="font-size: 15px; color: #57534e">14 mars 2020 · 6 ans</span>',1)
    k=0
    for lab,href in [('Date de naissance','ProcheNaissance.dc.html'),('Taille de vêtements','ProcheTaille.dc.html'),('Pointure','ProchePointure.dc.html')]:
        i=h.index(f'font-size: 16px">{lab}</span>'); a=h.rindex('<a href="#"',0,i); h=h[:a]+f'<a href="{href}"'+h[a+len('<a href="#"'):]
    h=h.replace('<span style="font-size: 15px; color: #57534e">30</span>','<span style="font-size: 15px; color: #57534e">30 ou 31</span>',1)
    i=h.index('Ce qu’on demande toujours.'); j=h.index('</section>',i)+10  # avant de retirer la phrase
    row=f'<li><a href="ProcheAdresse.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #292524"><span style="flex-grow: 1; font-weight: 600; font-size: 16px">Adresse email</span><span style="font-size: 15px; color: #a8a29e">Aucune</span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
    compte=f'''
    <section data-fiche="2" style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Son compte</h2>
      <ul style="{UL}">{row}</ul>
    </section>'''
    h=h[:j]+compte+h[j:]
    h=re.sub(r'\s*<p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Ce qu’on demande toujours\.[^<]*</p>','',h,count=1)
    h=re.sub(r'\s*<p style="[^"]*">Les mêmes questions que les pistes de cadeaux d’un tirage\.[^<]*</p>','',h,count=1)
    k=h.rindex('</main>')
    # la ligne rouge habituelle des actions qui ne se rattrapent pas, tout en bas (comme « Supprimer le groupe »)
    sup=('<section style="display: flex; flex-direction: column; gap: 6px"><ul style="list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad"><li>'
         '<a href="FamilleSupprimer.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #961d35">'
         '<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #fbe1e5; color: #961d35; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg></span>'
         '<span style="flex-grow: 1; font-weight: 600; font-size: 16px">Supprimer de mes proches</span>'
         f'<span style="color: #78716c; display: flex; flex-shrink: 0">{CHEV}</span></a></li></ul></section>')
    h=h[:k]+'  '+sup+chr(10)+'  '+h[k:]
    h=re.sub(r'width: 390px; height: \d+px','width: 390px; height: 1020px',h,count=1); h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1020}',h)
    h=re.sub(r'<title>[^<]*</title>','<title>Listes — la fiche d’un proche : chaque ligne ouvre une page</title>',h,count=1)
    open(p,'w').write(h)
names=[x for x in json.load(open('/tmp/names.json')) if x not in('ListePersonneSaisie.dc.html','ListePersonneEnregistre.dc.html')]; meta={}
for k2,(hh,ht,t) in P.items():
    open(PJ+k2+'.dc.html','w').write(hh); meta[k2]=[ht,t]
    if k2+'.dc.html' not in names: names.append(k2+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(meta)
