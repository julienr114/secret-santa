# Retirer quelqu'un d'une liste, sans passer par « ses goûts » (Julien, 19 novembre 2026) :
# pour ceux qui tiennent la liste, un bouton « ⋯ » au bout de chaque prénom ; le lien « ses goûts » leur est retiré (il reste par le lien).
# À lancer après burger.py.
import re,glob,os,json
PJ='/home/claude/utt/project/'
DOTS='<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>'
def btn(name,open_=False): return f'<button data-pmenu="1" aria-label="Options pour {name}" aria-expanded="{"true" if open_ else "false"}" style="margin-left: auto; width: 40px; height: 40px; border: 0; border-radius: 50%; background: {"#f1e8d8" if open_ else "transparent"}; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{DOTS}</button>'
HEAD=re.compile(r'(<h2 style="margin: 0; font-family: [^>]*font-size: 26px[^>]*>([^<]+)</h2>\s*)<p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">(.*?)</p>(\s*</div>)(?!<button data-pmenu)',re.S)
LINK=re.compile(r'(?: · )?<a href="ListePersonne\.dc\.html" style="[^"]*">ses goûts</a>')
def fix(m):
    meta=LINK.sub('',m.group(3)).strip()
    p=f'<p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">{meta}</p>' if meta else ''
    return m.group(1)+p+m.group(4)+btn(m.group(2))
fait=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if n in('ListeNouvelleForme','ListePersonneMenu'): continue
    h=open(f).read()
    if 'data-pub="1"' not in h: continue
    h2=HEAD.sub(fix,h)
    if h2!=h: open(f,'w').write(h2); fait.append(n)
# L'icône d'une personne sans compte se change depuis la liste et depuis sa fiche : un petit crayon dessus (Julien, 19 novembre 2026).
# Une personne reliée à un compte choisit la sienne : pas de crayon (ici « Moi », 🦌).
PEN='<span aria-hidden="true" data-pen="1" style="position: absolute; right: -4px; bottom: -4px; width: 22px; height: 22px; border-radius: 50%; background: #fffdf9; box-shadow: 0 0 0 1px #cdb48a; color: #57534e; display: flex; align-items: center; justify-content: center"><svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/></svg></span>'
AV=re.compile(r'(?<!data-av="1" style="position: relative; display: flex; flex-shrink: 0; border-radius: 50%; text-decoration: none">)(<span aria-hidden="true" style="width: (52|64)px; height: (?:52|64)px; border-radius: 50%;[^>]*>)([^<🦌]+)(</span>)')
def pen(m): return f'<a href="PanneauAvatarGrand.dc.html" aria-label="Changer l’icône" data-av="1" style="position: relative; display: flex; flex-shrink: 0; border-radius: 50%; text-decoration: none">{m.group(1)}{m.group(3)}{m.group(4)}{PEN}</a>'
pens=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if n=='ListeNouvelleForme': continue
    h=open(f).read()
    if not ('data-pub="1"' in h or n in('ListePersonne','ListePersonneCompte')): continue
    if n=='ListePersonneCompte': continue  # reliée à un compte : elle choisit elle-même
    h2=AV.sub(pen,h)
    if h2!=h: open(f,'w').write(h2); pens.append(n)
print('crayons',pens)
# le menu ouvert, sur Hugo
h=open(PJ+'ListeTeneur.dc.html').read()
b=btn('Hugo'); assert h.count(b)==1
def ic(d): return f'<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{d}</svg>'
IT='min-height: 48px; padding: 0 16px; display: flex; align-items: center; gap: 10px; font-size: 16px; font-weight: 600; text-decoration: none'
menu=(f'<div style="position: relative; margin-left: auto; flex-shrink: 0">{btn("Hugo",True).replace("margin-left: auto; ","")}'
 f'<div role="menu" style="position: absolute; top: 44px; right: 0; z-index: 3; width: 248px; padding: 6px 0; border-radius: 16px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad, 0 12px 28px rgba(41, 37, 36, 0.18); display: flex; flex-direction: column">'
 f'<a role="menuitem" href="ListePersonne.dc.html" style="{IT}; color: #292524">{ic(chr(60)+"path d=\"M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4\"/>")}Sa fiche et ses goûts</a>'
 f'<a role="menuitem" href="#" style="{IT}; color: #292524; border-top: 1px solid #f1e8d8">{ic(chr(60)+"circle cx=\"10\" cy=\"8\" r=\"3.5\"/><path d=\"M3 20a7 7 0 0 1 12.5-4.3M16 18h6\"/>")}Retirer de cette liste</a>'
 # supprimer pour de bon : la personne n'est plus proposée dans « Ajouter quelqu'un » (Julien, 19 novembre 2026)
 f'<a role="menuitem" href="FamilleSupprimer.dc.html" style="{IT}; color: #8a2f27; border-top: 1px solid #f1e8d8">{ic(chr(60)+"path d=\"M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3\"/>")}Supprimer de ma famille</a></div></div>')
h=h.replace(b,menu)
h=re.sub(r'<title>[^<]*</title>','<title>Listes — le menu d’une personne : sa fiche, la retirer</title>',h,count=1)
open(PJ+'ListePersonneMenu.dc.html','w').write(h)
names=json.load(open('/tmp/names.json'))
if 'ListePersonneMenu.dc.html' not in names: names.append('ListePersonneMenu.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print(fait)
