import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
exec(open('/home/claude/gen/manuel.py').read().split("# ---------- relance ----------")[0].split("# ---------- panneaux ----------")[1])
OUT.clear()
def rep(t, pairs):
    for a, b in pairs:
        assert t.count(a) >= 1, a[:80]
        t = t.replace(a, b)
    return t
STAR14 = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="#d9a62e" style="flex-shrink: 0; margin-top: 4px"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
HEART = '<path d="M12 20s-7-4.500-7-10a4 4 0 0 1 7-2.500A4 4 0 0 1 19 10c0 5.500-7 10-7 10z"/>'
BAN = '<circle cx="12" cy="12" r="9"/><path d="m5.600 5.600 12.800 12.800"/>'
BULB = '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.500c.700.700 1 1.500 1 2.500h6c0-1 .300-1.800 1-2.500A6 6 0 0 0 12 3z"/>'
def lead(path, tone='primary'):
    bg, fg = {'primary': ('#f6e2dd', '#a43a2f'), 'quiet': ('#f1e8d8', '#57534e'), 'pine': ('#dbe9dd', '#274e34')}[tone]
    return f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(path)}</span>'
def textrow(text, first=True):
    return f'''        <li>
          <a href="PistesRubrique.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 12px 16px; box-sizing: border-box; text-decoration: none; color: #292524">
            <span style="flex-grow: 1; min-width: 0; font-size: 16px; line-height: 1.45">{text}</span>
            {CHEV}
          </a>
        </li>
'''
def idea(text, link='', first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    l = f'<span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: #8a2f27; font-weight: 600">{ic(I["link"], 13, 2.2)}{link}</span>' if link else ''
    return f'''        <li>
          <a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 10px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            {STAR14.replace('; margin-top: 4px', '')}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; line-height: 1.35">{text}</span>{l}</span>
            {CHEV}
          </a>
        </li>
'''
NOTICE = f'''<div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 14px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 1px; color: #274e34">{ic('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', 18, 2)}</span>
      <span>Seule la personne qui t’offre un cadeau les verra, une fois le tirage fait.</span>
    </div>'''
ASK = f'''<div style="display: flex; align-items: flex-start; gap: 10px; padding: 14px; border-radius: 12px; background: #fdf8ea; border: 1px solid #ecd38a; color: #66431d; font-size: 15px; line-height: 1.45">
      <span aria-hidden="true" style="display: flex; margin-top: 2px; color: #79511d">{ic(BULB, 20, 2)}</span>
      <span><strong>La personne qui t’offre un cadeau cherche l’inspiration.</strong> Six questions à choix suffisent, trente secondes.</span>
    </div>'''
def page(name, title, h, secs, top=NOTICE, extra=''):
    main = f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      <p style="margin: 0; font-size: 14px; color: #57534e">Famille Camille · Noël 2026</p>
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Mes pistes de cadeaux</h1>
      <p style="margin: 4px 0 0; font-size: 15px; line-height: 1.45; color: #57534e">Aide la personne qui t’offre un cadeau. Tout est facultatif.</p>
    </div>
    {top}
    {extra}
    {secs}
    <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Tu peux les modifier jusqu’à la fête.</p>
  </main>'''
    t = (P/'Souhaits.dc.html').read_text()
    i = t.index('<main'); j = t.index('</main>') + 7
    save(name, t[:i] + main + t[j:], title, h)
addrow = lambda icon, title, sub, first=True: row(lead(icon), title, sub, first=first)
SPARK = '<path d="M12 3l1.800 5.200L19 10l-5.200 1.800L12 17l-1.800-5.200L5 10l5.200-1.800z"/><path d="M19 16v4M17 18h4"/>'
TOOL = '<path d="M14.500 6.500a4 4 0 0 0-5.300 5.300L3 18l3 3 6.200-6.200a4 4 0 0 0 5.300-5.300l-2.500 2.500-2-2z"/>'
ANSWERS = ['Plutôt utile', 'Un moment', 'À consommer', 'À partager', 'D’occasion, oui', 'J’aime la surprise']
chip = lambda t: f'<li style="padding: 6px 12px; border-radius: 999px; background: #f1e8d8; font-size: 14px; font-weight: 600; line-height: 1.3">{t}</li>'
CHIPS = '<ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-wrap: wrap; gap: 8px">' + ''.join(chip(t) for t in ANSWERS) + '</ul>'
QFILLED = f'''<section style="{CARD} padding: 16px 20px 20px; display: flex; flex-direction: column; gap: 12px">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 20px">Moi et les cadeaux</h2>
        <a href="PistesQuestion.dc.html" style="min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: #8a2f27">Modifier</a>
      </div>
      {CHIPS}
    </section>'''
QEMPTY = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">Pour commencer</p>
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 22px; line-height: 1.2">Six questions, trente secondes</h2>
        <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Utile ou surprenant ? Un objet ou un moment ? Tu réponds d’un doigt, sans rien écrire.</p>
      </div>
      <a href="PistesQuestion.dc.html" style="{BTN}">Commencer</a>
    </section>'''
IDEAFOOT = 'Une idée précise ne gâche rien : beaucoup préfèrent offrir à coup sûr.'
page('Pistes.dc.html', 'Mes pistes de cadeaux — remplies', 1500,
  section('En ce moment', textrow('Je me mets à la course à pied, je lis des BD et je cuisine le dimanche.')) +
  '\n    ' + section('Ce qui me servirait', textrow('Une bonne lampe de lecture. De quoi ranger mes épices.')) +
  '\n    ' + section('J’évite, ou j’ai déjà', textrow('Pas de bougies ni d’alcool. J’ai déjà trop de mugs.')) +
  '\n    ' + section('Une idée précise, si tu sèches', idea('Un roman policier', first=True) + idea('Un jeu de société pour deux', 'boutique-jeux.example') + row(lead(I['plus']), 'Ajouter une idée', 'Encore 8 possibles'), IDEAFOOT), extra=QFILLED)
EMPTY = (section('En ce moment', addrow(SPARK, 'Dire ce qui m’occupe', 'Un loisir qui démarre, une lecture, un projet…')) +
  '\n    ' + section('Ce qui me servirait', addrow(TOOL, 'Dire ce qui me servirait', 'Ce que tu utilises tous les jours, ce qui te manque…')) +
  '\n    ' + section('J’évite, ou j’ai déjà', addrow(BAN, 'Dire ce que j’évite', 'Une allergie, ce que tu as en trop…')) +
  '\n    ' + section('Une idée précise, si tu sèches', addrow(I['plus'], 'Ajouter une idée', 'Un objet, avec un lien si tu veux'), IDEAFOOT))
REUSE = f'<ul style="{LIST}">\n' + row(lead(I['copy'], 'quiet'), 'Reprendre mes pistes de Noël 2025', 'Tu pourras les retoucher', first=True) + '      </ul>'
page('PistesVide.dc.html', 'Mes pistes de cadeaux — vides', 1380, EMPTY, extra=QEMPTY + '\n    ' + REUSE)
page('PistesDemande.dc.html', 'Mes pistes de cadeaux — quelqu’un demande des pistes', 1340, EMPTY, top=ASK, extra=QEMPTY)

# ---------- une question ----------
def qcard(icon, title, sub, on=False):
    st = 'border: 2px solid #b8483a; background: #fbf3f1' if on else 'border: 1px solid #dccbad; background: #fffdf9'
    return f'''<button aria-pressed="{'true' if on else 'false'}" style="width: 100%; min-height: 120px; padding: 16px; box-sizing: border-box; border-radius: 16px; {st}; color: #292524; font-family: inherit; text-align: left; display: flex; align-items: center; gap: 14px">
        <span aria-hidden="true" style="width: 56px; height: 56px; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(icon, 28, 1.8)}</span>
        <span style="display: flex; flex-direction: column; gap: 4px"><span style="font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.15">{title}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{sub}</span></span>
      </button>'''
GIFT = '<rect x="3" y="9" width="18" height="12" rx="2"/><path d="M3 13h18M12 9v12M12 9c-2-4-6-3-5 0M12 9c2-4 6-3 5 0"/>'
TICKET = '<path d="M3 9a2 2 0 0 0 0 6v3h18v-3a2 2 0 0 1 0-6V6H3z"/><path d="M14 6v12" stroke-dasharray="2 3"/>'
dots = ''.join(f'<span style="width: {22 if i == 1 else 8}px; height: 8px; border-radius: 999px; background: {"#b8483a" if i == 1 else ("#2f613f" if i < 1 else "#dccbad")}"></span>' for i in range(6))
qmain = f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 16px 16px 24px">
    <div style="display: flex; align-items: center; justify-content: space-between">
      <div role="img" aria-label="Question 2 sur 6" style="display: flex; align-items: center; gap: 6px">{dots}</div>
      <a href="Pistes.dc.html" style="min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 600; color: #57534e">Plus tard</a>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <p style="margin: 0; font-size: 14px; color: #57534e">Moi et les cadeaux · 2 sur 6</p>
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Un objet, ou un moment ?</h1>
    </div>
    <div style="display: flex; flex-direction: column; gap: 12px">
      {qcard(GIFT, 'Un objet', 'Quelque chose à garder ou à utiliser.')}
      {qcard(TICKET, 'Un moment', 'Une sortie, un repas, un atelier.')}
    </div>
    <button style="height: 48px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600">Les deux me vont</button>
    <p style="margin: auto 0 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Un appui, et on passe à la suite. Tu pourras changer d’avis.</p>
  </main>'''
t = (P/'Souhaits.dc.html').read_text(); i = t.index('<main'); j = t.index('</main>') + 7
save('PistesQuestion.dc.html', t[:i] + qmain + t[j:], 'Mes pistes de cadeaux — une des six questions', 844)

# ---------- panneau d'une rubrique ----------
def sheet2(name, title, h, back, label, h1, desc, inner, primary, secondary, top):
    html = (P/'ConfirmerTirage.dc.html').read_text()
    a = html.index('<div style="width: 390px'); b = html.index('</x-dc>')
    body = f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #8f877b; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; justify-content: flex-end">
  <div aria-hidden="true" style="height: {top}px; flex-shrink: 0; padding: 20px 16px; box-sizing: border-box; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; color: #5c554c">{back}</div>
  <section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15">{h1}</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{desc}</p>
    </div>
    {inner}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">{primary}</button>
      <a href="#" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">{secondary}</a>
    </div>
  </section>
</div>
'''
    save(name, html[:a] + body + html[b:], title, h)
sheet2('PistesRubrique.dc.html', 'Mes pistes de cadeaux — modifier « En ce moment »', 844, 'Mes pistes de cadeaux', 'En ce moment', 'En ce moment', 'Ce qui t’occupe ou te fait envie ces temps-ci. Pas besoin d’objets précis.',
  '''<div style="display: flex; flex-direction: column; gap: 6px">
      <label for="aime" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%)">En ce moment</label>
      <textarea id="aime" rows="4" style="width: 100%; box-sizing: border-box; padding: 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.45; resize: none">Je me mets à la course à pied, je lis des BD et je cuisine le dimanche.</textarea>
      <p style="margin: 0; display: flex; justify-content: space-between; font-size: 13px; color: #57534e"><span>Un loisir qui démarre, une lecture, un projet…</span><span>71 / 300</span></p>
    </div>''', 'Valider', 'Annuler', 330)

# ---------- résultat ----------
res = (P/'TirageResultat.dc.html').read_text()
k = res.index('<div style="display: flex; flex-direction: column; gap: 12px">\n        <h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 20px">Ses idées de cadeaux</h2>')
e = res.index('</section>', k); e = res.rindex('</div>', k, e) + 6
LBL = 'margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
blk = lambda t, body: f'<div style="display: flex; flex-direction: column; gap: 4px"><p style="{LBL}">{t}</p>{body}</div>'
TXT = lambda s: f'<p style="margin: 0; font-size: 16px; line-height: 1.45">{s}</p>'
ideas = f'''<ul style="list-style: none; margin: 4px 0 0; padding: 0; display: flex; flex-direction: column; gap: 10px">
          <li style="display: flex; align-items: flex-start; gap: 10px">{STAR14}<span style="font-size: 16px; line-height: 1.4">Un roman policier</span></li>
          <li style="display: flex; align-items: flex-start; gap: 10px">{STAR14}<span style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><span style="font-size: 16px; line-height: 1.4">Un jeu de société pour deux</span><a href="#lien" style="min-height: 32px; display: flex; align-items: center; gap: 5px; font-size: 14px; font-weight: 600; color: #8a2f27">Voir le lien {ic('<path d="M7 17 17 7M9 7h8v8"/>', 14, 2.2)}</a></span></li>
        </ul>'''
H2R = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 20px"
def result(name, title, h, inner):
    t = res[:k] + f'<div style="display: flex; flex-direction: column; gap: 14px">\n        {inner}\n      </div>' + res[e:]
    t = rep(t, [('>Ma liste de souhaits</span>', '>Mes pistes de cadeaux</span>'), ("3 idées · modifiable jusqu'à la fête", "Remplies · modifiables jusqu'à la fête")])
    save(name, t, title, h)
result('PistesResultat.dc.html', 'Page d’un tirage — résultat avec les pistes', 1420,
  f'<h2 style="{H2R}">Pour t’aider à choisir</h2>' + CHIPS + blk('En ce moment', TXT('Se met à la course à pied, lit des BD, cuisine le dimanche.')) + blk('Ce qui lui servirait', TXT('Une bonne lampe de lecture. De quoi ranger ses épices.')) + blk('À éviter', TXT('Pas de bougies ni d’alcool. Déjà trop de mugs.')) + blk('Si tu sèches', ideas))
OUTB = 'width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px'
result('PistesResultatVide.dc.html', 'Page d’un tirage — résultat sans piste', 1080,
  f'<h2 style="{H2R}">Pour t’aider à choisir</h2>' + TXT('Inès n’a pas encore laissé de pistes.').replace('font-size: 16px', 'font-size: 15px; color: #57534e') + f'<button style="{OUTB}">{ic(BULB, 18, 2)}Lui demander des pistes</button><p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Sans dire que ça vient de toi.</p>')
result('PistesResultatDemande.dc.html', 'Page d’un tirage — demande de pistes envoyée', 1060,
  f'<h2 style="{H2R}">Pour t’aider à choisir</h2>' + f'<div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #f0f6f1; color: #223f2d; font-size: 15px; line-height: 1.45"><span aria-hidden="true" style="display: flex; margin-top: 2px; color: #274e34">{ic(I["check"], 18, 2.5)}</span><span><strong>Demande envoyée.</strong> Inès vient de recevoir un email, sans savoir que ça vient de toi. Tu recevras un email dès que des pistes arrivent.</span></div>')
sheet('PistesDemander.dc.html', 'Page d’un tirage — demander des pistes', 844, 'Salut Camille !', 'Demander des pistes',
  'Demander des pistes à Inès ?', 'Inès reçoit un email qui l’invite à noter ses goûts et ce qu’il vaut mieux éviter.',
  item('Ton nom n’apparaît nulle part', 'Ni dans l’email, ni dans le journal, ni pour l’organisateur.', True) + item('Une seule demande par tirage', 'Pas de relance possible : personne n’est harcelé.'),
  '', 'Envoyer la demande', 'Pas maintenant', top=230)

# ---------- l'email reçu ----------
t = (P/'Souhaits.dc.html').read_text()
a = t.index('<div style="width: 390px'); b = t.index('</x-dc>')
mail = '''<div style="width: 390px; height: 844px; box-sizing: border-box; background: #ffffff; color: #1c1917; font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; display: flex; flex-direction: column">
  <div style="padding: 16px; border-bottom: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 4px">
    <h1 style="margin: 0; font-size: 18px; font-weight: 700; line-height: 1.3">Quelqu’un cherche une idée de cadeau pour toi</h1>
    <p style="margin: 0; font-size: 13px; color: #57534e">Under the Tree · à ines-demo@example.com</p>
  </div>
  <div style="padding: 16px; display: flex; flex-direction: column; gap: 14px; font-size: 16px; line-height: 1.5">
    <p style="margin: 0">Bonjour Inès,</p>
    <p style="margin: 0">La personne qui t’offre un cadeau pour Noël 2026 (Famille Camille) ne sait pas quoi choisir.</p>
    <p style="margin: 0">Aide-la : six questions à choix, trente secondes, et quelques mots si tu veux.</p>
    <p style="margin: 0"><a href="#" style="color: #1d4ed8; text-decoration: underline">Donner quelques pistes</a></p>
    <p style="margin: 0">On ne te dira pas qui demande : c’est un Secret Santa. Tu ne recevras ce message qu’une fois.</p>
    <p style="margin: 0">Under the Tree</p>
  </div>
</div>
'''
save('PistesEmail.dc.html', t[:a] + mail + t[b:], 'L’email « quelqu’un cherche une idée »', 844)

# ---------- réglage du groupe ----------
def radio(label, sub, on, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    bg = ' background: #fbf3f1;' if on else ''
    return f'''<label style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 10px 14px; box-sizing: border-box;{bt}{bg}">
        <input type="radio" name="g"{' checked' if on else ''} style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
        <span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">{label}</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span></span>
      </label>'''
sheet2('PistesReglage.dc.html', 'Réglages du groupe — pistes de cadeaux', 844, 'Réglages', 'Pistes de cadeaux', 'Pistes de cadeaux', 'Ce que chacun peut noter pour aider la personne qui lui offre un cadeau.',
  f'<div role="radiogroup" aria-label="Pistes de cadeaux" style="border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column">{radio("Portrait et idées précises", "Les six questions, les envies du moment, et des idées d’objets", False, True)}{radio("Portrait seulement", "Sans idée d’objet : la surprise reste entière", True)}{radio("Aucune piste", "Chacun se débrouille", False)}</div>', 'Valider', 'Annuler', 250)

# ---------- canevas ----------
cv = json.loads((P/'canvas.json').read_text())
rows = [('p1', 'Mes pistes de cadeaux (remplace « Ma liste de souhaits »)', ['Pistes', 'PistesVide', 'PistesQuestion', 'PistesRubrique', 'PistesReglage'], ['Remplies', 'Vides', 'Une des six questions', 'Modifier une rubrique', 'Réglage du groupe']),
        ('p2', 'Celui qui offre : lire les pistes, ou en demander', ['PistesResultat', 'PistesResultatVide', 'PistesDemander', 'PistesResultatDemande', 'PistesEmail', 'PistesDemande'], ['Résultat avec les pistes', 'Résultat sans piste', 'Demander des pistes', 'Demande envoyée', 'L’email reçu', 'Sa page, avec la demande'])]
if not any(p['id'] == 'pistes' for p in cv['pages']):
    cv['pages'].insert(len(cv['pages']) - 1, {'id': 'pistes', 'name': 'Pistes de cadeaux'})
y = 0
for nid, text, names, titles in rows:
    mh = 0
    for i, (n, ti) in enumerate(zip(names, titles)):
        f = n + '.dc.html'; h = OUT[f]; mh = max(mh, h)
        cv['boards'][f] = {'x': i * 470, 'y': y, 'w': 390, 'h': h, 'title': ti, 'page': 'pistes'}
        if f not in cv['order']: cv['order'].append(f)
    cv['notes'][nid] = {'x': 0, 'y': y - 300, 'text': text, 'kind': 'title1', 'maxW': len(names) * 470 - 80, 'page': 'pistes'}
    if nid not in cv['noteOrder']: cv['noteOrder'].append(nid)
    y += mh + 420
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)
