import re,os,shutil,json
PJ='/home/claude/utt/project/'; out='/mnt/user-data/outputs/prix3'; os.makedirs(out,exist_ok=True)
src=open(PJ+'DevineStory5.dc.html').read()
a=src.index('<div style="width: 390px'); head=src[:a]; tail=src[src.index('</x-dc>'):]
P={'Camille':('🦌','#ead2e2'),'Hugo':('🐧','#f6e3ad'),'Inès':('🍭','#f3d3cc'),'Lou':('🌰','#ecdfc6'),'Sacha':('🍷','#d6e6ef'),'Yanis':('🦉','#cfe2d3')}
TH={'prune':('#5b3a55','#fffdf9','#ead2e2'),'moutarde':('#e6b94a','#3d2c08','#66431d'),'brique':('#a43a2f','#fffdf9','#f6d9d3'),'sapin':('#274e34','#fffdf9','#cfe2d3')}
ROT=['moutarde','prune','sapin','brique']
def av(n,ml=0,size=112):
    e,bg=P[n]; s=f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 4px rgba(255, 253, 249, 0.9), 0 12px 30px rgba(0, 0, 0, 0.25); display: flex; align-items: center; justify-content: center; font-size: {size//2}px; flex-shrink: 0">{e}</span>'
    return s if not ml else f'<span style="margin-left: {ml}px; display: flex">{s}</span>'
def group(*names):
    size=112 if len(names)<3 else 96
    return '<div style="display: flex">'+''.join(av(n,-24 if i else 0,size) for i,n in enumerate(names))+'</div>'
def arrow(c): return f'<svg aria-hidden="true" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 6px"><path d="M4 12h16M14 6l6 6-6 6"/></svg>'
def rule(rows,note=''):
    r=''.join(f'<div style="display: flex; flex-direction: column; gap: 2px"><dt style="font-size: 11px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: #8a2f27">{k}</dt><dd style="margin: 0; font-size: 14px; line-height: 1.4; color: #292524">{v}</dd></div>' for k,v in rows)
    n=f'<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">{note}</p>' if note else ''
    return f'''  <section aria-label="Règle du prix" style="height: 380px; box-sizing: border-box; background: #fffdf9; border-top: 2px dashed #dccbad; padding: 16px 16px 20px; display: flex; flex-direction: column; gap: 12px; font-family: 'Nunito', system-ui, sans-serif; color: #292524">
    <p style="margin: 0; font-size: 12px; font-weight: 700; color: #57534e">La règle · ne fait pas partie de l’écran</p>
    <dl style="margin: 0; display: flex; flex-direction: column; gap: 10px">{r}</dl>
    {n}
  </section>
'''
def story(theme,label,visual,big,phrase,pos,total,rows,note='',bigsize=44):
    bg,fg,soft=TH[theme]
    bar=''.join(f'<span style="flex: 1; height: 3px; border-radius: 999px; background: {fg}; opacity: {1 if i<pos else 0.3}"></span>' for i in range(total))
    return head+f'''<div style="width: 390px; height: 1224px; display: flex; flex-direction: column">
<div style="width: 390px; height: 844px; flex-shrink: 0; box-sizing: border-box; background: {bg}; color: {fg}; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column; padding: 14px 16px 28px">
  <div role="img" aria-label="Écran {pos} sur {total}" style="display: flex; gap: 4px">{bar}</div>
  <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 10px">
    <span style="display: flex; align-items: center; gap: 6px; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 16px"><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>Devine qui · Noël 2026</span>
    <button aria-label="Fermer" style="width: 44px; height: 44px; margin-right: -10px; border: 0; background: transparent; color: {fg}; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
  </div>
  <div style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 22px; text-align: center">
    <p style="margin: 0; font-size: 14px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; color: {soft}">{label}</p>
    {visual}
    <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: {bigsize}px; line-height: 1.08">{big}</p>
    <p style="margin: 0; max-width: 300px; font-size: 18px; line-height: 1.4; color: {soft}">{phrase}</p>
  </div>
  <p style="margin: 0; text-align: center; font-size: 14px; color: {soft}">Touche pour continuer</p>
</div>
{rule(rows,note)}</div>
'''+tail
T=14
def soft(t): return TH[t][2]
S=[
('DevineStoryDemasques','Démasqués',lambda t:story(t,'Démasqués',group('Camille','Lou','Sacha'),'Camille, Lou<br>et Sacha','Ils avaient deviné leur Père Noël.',4,T,
  [('Calcul','Tous ceux qui ont deviné leur propre Père Noël.'),('S’affiche si','Au moins une personne.'),('À plusieurs','Jusqu’à trois noms ; au-delà, « 4 personnes avaient deviné leur Père Noël ».')],'Jamais sauté par le plafond de huit écrans.',38)),
('DevineStory4','Le détective',lambda t:story(t,'Le détective',av('Lou'),'Lou','4 bons pronostics sur 5, dont deux que personne d’autre n’avait trouvés.',5,T,
  [('Calcul','Chaque bon pronostic vaut 1 point, plus la part des autres joueurs de cette ligne qui se sont trompés (donc entre 1 et 2 ; 1,5 s’il était seul). Une erreur ne coûte rien.'),('S’affiche si','Au moins 2 bons pronostics. Mode « Toutes les paires ».'),('Départage','La meilleure précision, puis le moins de pronostics.')])),
('DevineStorySansFaute','Le sans-faute',lambda t:story(t,'Le sans-faute',av('Lou'),'Lou','Cinq pronostics, cinq bons. Rien à redire.',5,T,
  [('Calcul','Tous ses pronostics comptés sont justes.'),('S’affiche si','Au moins 3 pronostics.'),('Avec le détective','S’il est aussi le détective, cet écran remplace celui du détective.')],'Prend la même place, donc la même couleur, que le détective.')),
('DevineStoryTransparent','Le plus transparent',lambda t:story(t,'Le plus transparent',av('Yanis'),'Yanis','Quatre personnes sur cinq l’ont démasqué. Pas facile, de garder un secret.',6,T,
  [('Calcul','La note (trompés + 1) ÷ (tentatives + 2), la plus basse.'),('S’affiche si','Démasqué par autant de personnes que le seuil du groupe. Le seuil du groupe : un joueur sur quatre, au moins 2, au plus 5.'),('Départage','Démasqué par le plus de monde. Jamais la même personne que le mieux caché.')])),
('DevineStory5','Le mieux caché',lambda t:story(t,'Le mieux caché',av('Hugo'),'Hugo','Cinq personnes l’ont cherché, aucune ne l’a trouvé. Du grand art.',7,T,
  [('Calcul','La note (trompés + 1) ÷ (tentatives + 2), la plus haute. Les tentatives sont les pronostics faits sur la personne à qui il offre.'),('S’affiche si','Cherché par autant de personnes que le seuil du groupe. Le seuil du groupe : un joueur sur quatre, au moins 2, au plus 5.'),('Départage','Le plus de personnes trompées. À égalité parfaite : jusqu’à trois noms.')])),
('DevineStoryRumeur','La rumeur',lambda t:story(t,'La rumeur',f'<div style="display: flex; align-items: center">{av("Lou")}{arrow(soft(t))}{av("Hugo")}</div>','Lou offrait<br>à Hugo ?','Quatre d’entre vous en étaient sûrs. C’était faux.',8,T,
  [('Calcul','La fausse piste la plus partagée : (joueurs qui y ont cru + 1) ÷ (tentatives sur cette ligne + 2).'),('S’affiche si','Autant de joueurs que le seuil du groupe y ont cru. Le seuil du groupe : un joueur sur quatre, au moins 2, au plus 5.'),('Départage','Une seule rumeur : celle crue par le plus de joueurs, puis celle qui vise le Père Noël le mieux caché, puis la plus ancienne.')])),
('DevineStory6','Le suspect idéal',lambda t:story(t,'Le suspect idéal',av('Sacha'),'Sacha','Cité 6 fois comme Père Noël. À tort, à chaque fois.',9,T,
  [('Calcul','Le plus souvent cité à tort comme Père Noël.'),('S’affiche si','Cité à tort autant de fois que le seuil du groupe. Le seuil du groupe : un joueur sur quatre, au moins 2, au plus 5.'),('Départage','Celui qui n’a jamais été cité à raison. À égalité parfaite : jusqu’à trois noms.')])),
('DevineStoryJumeaux','Les jumeaux',lambda t:story(t,'Les jumeaux',group('Sacha','Yanis'),'Sacha et Yanis','Quatre pronostics identiques sur cinq, dont trois erreurs. Vous vous êtes concertés ?',10,T,
  [('Calcul','Points d’accord : 2 par erreur commune, 1 par bonne réponse commune. Note : (points + 1) ÷ (2 × lignes communes + 2).'),('S’affiche si','Au moins 3 pronostics identiques.'),('Départage','Une seule paire : la meilleure note, puis celle dont aucun membre n’a déjà un prix à l’écran, puis celle qui s’est fixée la première.')])),
('DevineStoryTriples','Les triplés',lambda t:story(t,'Les triplés',group('Sacha','Yanis','Lou'),'Sacha, Yanis<br>et Lou','Les mêmes pronostics, à trois. Il y a eu des messes basses.',10,T,
  [('Calcul','Trois joueurs dont les trois paires remplissent chacune la condition des jumeaux.'),('S’affiche si','À la place des jumeaux, quand ce trio existe et contient la meilleure paire.'),('Au-delà de trois','On revient à la meilleure paire.')],'Prend la même place, donc la même couleur, que les jumeaux.',38)),
('DevineStoryFil','Sur le fil',lambda t:story(t,'Sur le fil',av('Inès'),'Inès','A tranché quatre minutes avant la fin des pronostics.',11,T,
  [('Calcul','Le dernier pronostic enregistré avant la fin.'),('S’affiche si','Fait dans la dernière heure avant la fin des pronostics.'),('Départage','Aucun : il n’y a qu’un dernier.')])),
('DevineStoryGirouette','La girouette',lambda t:story(t,'La girouette',av('Hugo'),'Hugo','A changé d’avis sept fois avant de se décider.',12,T,
  [('Calcul','Le plus de changements d’avis, tous ses pronostics confondus.'),('S’affiche si','Au moins 3 changements.'),('Départage','Celui qui a fait le moins de pronostics. À égalité parfaite : jusqu’à trois noms.')],'Demande d’enregistrer les réponses précédentes de chaque pronostic.')),
('DevineStoryGroupe','Le score du groupe',lambda t:story(t,'À vous tous',f'<p style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 84px; line-height: 1">8 sur 19</p>','bons pronostics','Au hasard, vous en auriez eu 5. Pas mal du tout.',13,T,
  [('Calcul','Bons pronostics sur pronostics comptés. Le hasard : pronostics comptés ÷ (participants − 2), arrondi.'),('S’affiche si','Au moins 6 pronostics comptés. Dernier écran avant la fin.'),('Trois tons','Nettement mieux que le hasard, à peu près pareil, ou moins bien : « les Pères Noël étaient bien cachés ».')],'Jamais sauté par le plafond de huit écrans.')),
]
rank={'DevineStoryDemasques':0,'DevineStory4':1,'DevineStorySansFaute':1,'DevineStoryTransparent':2,'DevineStory5':3,'DevineStoryRumeur':4,'DevineStory6':5,'DevineStoryJumeaux':6,'DevineStoryTriples':6,'DevineStoryFil':7,'DevineStoryGirouette':8,'DevineStoryGroupe':9}
made=[]
for k,t,f in S:
    h=f(ROT[rank[k]%4]); h=re.sub(r'<title>[^<]*</title>',f'<title>Devine qui — {t}</title>',h)
    open(PJ+k+'.dc.html','w').write(h); shutil.copy(PJ+k+'.dc.html',f'{out}/{k}.html'); made.append((k,t,ROT[rank[k]%4]))
# personnel
h=story('brique','Si près du but',av('Lou'),'Presque !','Tu avais trouvé le Père Noël de Lou… puis tu as changé d’avis. L’instinct avait raison.',4,T,
  [('Calcul','Sur une ligne, j’avais la bonne réponse, puis j’ai changé pour une mauvaise.'),('S’affiche si','Au moins une ligne dans ce cas. Écran personnel : seul le joueur concerné le voit, juste après « mon Père Noël ».'),('Départage','S’il y a plusieurs lignes, celle du Père Noël le mieux caché.')],'Demande d’enregistrer les réponses précédentes. Toujours brique, comme « mon Père Noël ».')
h=re.sub(r'<title>[^<]*</title>','<title>Devine qui — Si près du but</title>',h)
open(PJ+'DevineStoryPresDuBut.dc.html','w').write(h); shutil.copy(PJ+'DevineStoryPresDuBut.dc.html',f'{out}/DevineStoryPresDuBut.html'); made.append(('DevineStoryPresDuBut','Si près du but','brique'))
print(made)
ks=[m[0] for m in made]
print(json.dumps([{"as":f"project/{k}.dc.html","path":f"{PJ}{k}.dc.html"} for k in ks]))
print(json.dumps([{"stagedPath":f"{out}/{k}.html","devicePath":f"/Users/julien.rabin/Workspace/personnal/secret-santa/docs/refonte/maquettes/{k}.html"} for k in ks]))
