# « Mes proches » (Julien, 19 novembre 2026) : le nom, la place (dans « Listes »), et la croix sur la pastille d'un proche qui n'est sur aucune liste.
# À lancer en dernier (après personnemenu.py, bis24.py, famille.py).
import re,glob,os,json
PJ='/home/claude/utt/project/'
REP=[('Ton mot pour la famille','Ton mot d’accueil'),('Ajouter un mot pour la famille','Ajouter un mot d’accueil'),('idées de cadeaux de ta famille','idées de cadeaux de tes proches'),('Ce que la famille demande toujours','Ce qu’on demande toujours'),('Gérer ma famille','Mes proches'),('Toute ta famille est déjà sur la liste.','Tous tes proches sont déjà sur la liste.'),('Supprimer de ma famille','Supprimer de mes proches'),
     ('Il reste dans ta famille.','Il reste dans tes proches.'),('>Ma famille<','>Mes proches<'),('en le gardant dans ta famille','en le gardant dans tes proches'),
     ('Listes — une personne de ma famille','Listes — un de mes proches'),('Compte — supprimer quelqu’un de ma famille','Listes — supprimer un de mes proches'),('Compte — ma famille','Listes — mes proches'),
     ('<h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Ma famille</h1>','<h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Mes proches</h1>')]
X='<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
CHIP=('<span data-x="1" style="height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; display: flex; align-items: center">'
 '<button style="height: 42px; padding: 0 6px 0 6px; border: 0; border-radius: 999px 0 0 999px; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px"><span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #f3d3cc; box-shadow: 0 0 0 1px #e09e92; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0">🧶</span>Mamie</button>'
 f'<button aria-label="Supprimer Mamie de mes proches" style="width: 36px; height: 42px; padding: 0; border: 0; border-left: 1px solid #e9dcc5; border-radius: 0 999px 999px 0; background: transparent; color: #78716c; display: flex; align-items: center; justify-content: center">{X}</button></span>')
HUGO=re.compile(r'(<button style="height: 44px; padding: 0 14px 0 6px;[^>]*><span aria-hidden="true"[^>]*>🐧</span>Hugo</button>)(?!<span data-x)')
fait=[]
for f in sorted(glob.glob(PJ+'Liste*.dc.html')+glob.glob(PJ+'Famille*.dc.html')+glob.glob(PJ+'NavListe.dc.html')+glob.glob(PJ+'ProcheSupprime.dc.html')):
    n=os.path.basename(f)[:-8]
    if n in('ListeNouvelleForme',): continue
    h=open(f).read(); h0=h
    for a,b in REP: h=h.replace(a,b)
    if 'Ajouter quelqu’un</h2>' in h:
        i=h.index('Ajouter quelqu’un</h2>'); j=h.index('</section>',i)
        sec=HUGO.sub(lambda m:m.group(1)+CHIP,h[i:j],count=1)
        if 'data-x="1"' in sec and 'data-xh="1"' not in sec:
            sec=sec.replace('<p data-fam="1"','<p data-xh="1" style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La croix supprime un proche qui n’est sur aucune liste.</p>\n      <p data-fam="1"',1)
        h=h[:i]+sec+h[j:]
    if h!=h0: open(f,'w').write(h); fait.append(n)
# la page « Mes proches » est dans « Listes », pas dans « Mon compte »
p=PJ+'Famille.dc.html'; h=open(p).read()
h=h.replace('color: #57534e">Mon compte</p>','color: #57534e">Listes</p>',1).replace('Les personnes pour qui tu tiens des listes. Toi seul les vois ici.','Les personnes pour qui tu tiens des listes de cadeaux. Toi seul les vois ici.')
h=h.replace('Hugo</span><span style="font-size: 14px; color: #57534e">sur 1 liste','Hugo</span><span style="font-size: 14px; color: #57534e">sur 1 liste · relié à son compte')
open(p,'w').write(h)
# l'entrée, sur l'accueil des listes
p=PJ+'ListesAccueil.dc.html'; h=open(p).read()
a='Chacun coche ce qu’il offre.</p></div>'
if 'data-proches' not in h:
    assert h.count(a)==1
    h=h.replace(a,'Chacun coche ce qu’il offre.</p><a data-proches="1" href="Famille.dc.html" style="align-self: flex-start; min-height: 32px; display: flex; align-items: center; gap: 2px; font-size: 14px; font-weight: 700; color: #57534e; text-decoration: underline">Mes proches</a></div>'); open(p,'w').write(h); fait.append('ListesAccueil')
# juste après la croix : c'est fait, avec « Annuler »
h=open(PJ+'ListeNouvelle.dc.html').read()
i=h.index('<span data-x="1"'); j=h.index('</span>',h.index('aria-label="Supprimer Mamie',i))+7
h=h[:i]+h[j:]
toast='<div role="status" style="position: sticky; bottom: 16px; margin-top: auto; align-self: stretch; min-height: 52px; padding: 0 8px 0 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; justify-content: space-between; gap: 12px; font-size: 15px; font-weight: 600">Mamie supprimée de tes proches<button style="min-height: 44px; padding: 0 10px; border: 0; background: transparent; color: #f6c9c0; font-family: inherit; font-size: 15px; font-weight: 700">Annuler</button></div>\n  '
k=h.rindex('</main>'); h=h[:k]+'  '+toast+h[k:]
h=re.sub(r'<title>[^<]*</title>','<title>Listes — un proche vient d’être supprimé par la croix de sa pastille</title>',h,count=1)
open(PJ+'ProcheSupprime.dc.html','w').write(h)
names=json.load(open('/tmp/names.json'))
if 'ProcheSupprime.dc.html' not in names: names.append('ProcheSupprime.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print(fait)
# La note « Pour un enfant » de la fiche d'une personne reliée ne se comprenait pas (Julien, 19 novembre 2026) : on l'enlève.
p=PJ+'ListePersonneCompte.dc.html'; h=open(p).read()
m=re.search(r'\s*<section style="display: flex; flex-direction: column; gap: 8px"><h2 [^>]*>Pour un enfant</h2><p [^>]*>[^<]*</p>\s*</section>',h)
if m: h=h.replace(m.group(0),''); open(p,'w').write(h); print('note enfant retirée')
