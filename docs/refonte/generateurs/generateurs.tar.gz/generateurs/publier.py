# Publier, partager, dépublier : trois choses distinctes (Julien, 19 novembre 2026).
# Publier = la liste a un lien public. Partager = envoyer ce lien (copier, message, email). Dépublier = le lien ne marche plus.
# Retouche les sources après nav2.py, avant transparence.py.
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
GLOBE=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',16)
COPY=ic('<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',18)
MAIL=ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',18)
SM='margin: 0; font-size: 14px; line-height: 1.45; color: #57534e'
# 1. la partie blanche en haut du document : l'état, qui se déplie sur place (Julien, 19 novembre 2026). Pas d'écran à part.
UP=ic('<path d="m18 15-6-6-6 6"/>',20); DOWN=ic('<path d="m6 9 6 6 6-6"/>',20)
LOCK=ic('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',20)
GLOBE20=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',20)
# comme la barre du mode anonyme (Julien, 19 novembre 2026) : une ligne, l'interrupteur toujours visible ; publiée, la barre est verte, texte blanc
def switch(on):
    return (f'<span role="switch" aria-checked="{"true" if on else "false"}" aria-label="Partage par lien" style="width: 48px; height: 28px; border-radius: 999px; background: {"#2f613f" if on else "#d6d3d1"}; position: relative; flex-shrink: 0">'
            f'<span style="position: absolute; top: 3px; left: {23 if on else 3}px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>')
def _bar(pub,open_):
    bg='#fffdf9'; fg='#292524'; sub='#57534e'
    t='Partage par lien'  # un nom neutre, ni action ni état : l'interrupteur dit oui ou non (Julien, 19 novembre 2026) ; le même titre dans les deux états (Julien, 19 novembre 2026) ; brouillon : rien à déplier
    row=(f'<span style="display: flex; color: {"#274e34" if pub else "#57534e"}">{GLOBE20 if pub else LOCK}</span>'
         f'<button aria-expanded="{"true" if open_ else "false"}" aria-controls="publication" style="flex-grow: 1; min-width: 0; min-height: 44px; padding: 0; border: 0; background: transparent; color: {fg}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px; text-align: left">{t}<span style="display: {"flex" if pub else "none"}; color: {sub}">{UP if open_ else DOWN}</span></button>'
         f'{switch(pub)}')
    more=''
    if open_ and not pub:
        more=''  # pas de texte d'explication pour publier (Julien, 19 novembre 2026)
    if open_ and pub:
        more=f"""<div id="publication" style="padding: 0 14px 14px; display: flex; flex-direction: column; gap: 10px">
        <div style="display: flex; align-items: center; gap: 10px; padding: 8px 8px 8px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 15px; font-weight: 600; color: #292524; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/l/k3Fq9xT2</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; flex-shrink: 0">{COPY}Copier</button></div>
        <button style="{BTN2}; border-color: #dccbad; color: #292524">{SHARE}Partager</button>
        <p style="margin: 0; font-size: 13px; line-height: 1.45; color: {sub}">Toute personne qui a le lien voit la liste et peut cocher.</p>
        <p style="margin: 0; display: flex; flex-wrap: wrap; gap: 4px 16px; font-size: 14px; font-weight: 700"><a href="PersonnaliserMessage.dc.html" style="min-height: 32px; display: flex; align-items: center; color: #57534e; text-decoration: underline">Personnaliser le message</a><a href="#" style="min-height: 32px; display: flex; align-items: center; color: #57534e; text-decoration: underline">Changer de lien</a></p>
      </div>"""
    return (f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {bg}; color: {fg}; box-shadow: 0 0 0 1px #dccbad, 0 4px 14px rgba(41, 37, 36, 0.08)">'  # collée en haut au défilement, comme la barre du mode anonyme (Julien, 19 novembre 2026)
            f'<div style="min-height: 48px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 8px">{row}</div>{more}</div>')
def bar(pub): return _bar(pub,False)
def bar_open(pub): return _bar(pub,True)
OLD=re.compile(r'<a href="ListePartager\.dc\.html" style="min-height: 48px; box-sizing: border-box; padding: 6px 8px 6px 14px; border-radius: 999px;.*?</a>',re.S)  # la barre V1
fait=[]
for n in ('ListeNouvelle','ListeNouvelleReprendre','ListeReprise','ListeTeneur','ListeLiveTeneur','NavListe'):
    p=PJ+n+'.dc.html'; h=open(p).read()
    def sub(m): return bar('Partagée avec la famille' in m.group(0))
    g=OLD.sub(sub,h)
    if g!=h: open(p,'w').write(g); fait.append(n)
# Une liste sans personne : un choix de plus dans « Ajouter quelqu'un », pas d'écran à part (Julien, 19 novembre 2026)
def sansperso(h):
    if 'Une liste sans personne' in h: return h
    m=re.search(r'(<a href="ListePersonne\.dc\.html" style="height: 44px;[^"]*">.*?Quelqu’un d’autre</a>)',h,re.S)
    if not m: return h
    chip=m.group(1).replace('href="ListePersonne.dc.html"','href="ListeSansPersonne.dc.html"')
    chip=re.sub(r'<svg.*?</svg>','',chip,flags=re.S).replace('Quelqu’un d’autre','Une liste sans personne')
    h=h.replace(m.group(1),m.group(1)+chip,1)
    return h.replace('Touche un prénom : il s’ajoute à la liste, avec ses idées qui n’ont pas été offertes la dernière fois.','Touche un prénom : il s’ajoute à la liste, avec ses idées qui n’ont pas été offertes la dernière fois. Pour un mariage ou une crémaillère, « Une liste sans personne » : les idées, l’une sous l’autre.',1)
for n in ('ListeNouvelle','ListeNouvelleReprendre'):
    p=PJ+n+'.dc.html'; h=open(p).read(); g=sansperso(h)
    if g!=h: open(p,'w').write(g); fait.append(n+' (sans personne)')
P={}
def save(k,html,h,title):
    html=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%h,html); P[k]=(html,h,title)
# 2. deux états dépliés, sur place
def grow(h,d):
    m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+d
    return h.replace(m.group(0),f'width: 390px; height: {H}px',1),H
for k,src,pub,d,t in (('ListeEtatBrouillon','ListeNouvelle',False,90,'Brouillon : la partie du haut, dépliée'),('ListeEtatPubliee','ListeTeneur',True,250,'Publiée : la partie du haut, dépliée (copier, envoyer, par email)')):
    h=open(PJ+src+'.dc.html').read(); assert h.count(bar(pub))==1,k
    h=h.replace(bar(pub),bar_open(pub)); h,H=grow(h,d)
    h=re.sub(r'<title>[^<]*</title>',f'<title>Listes — {t}</title>',h,count=1)
    save(k,h,H,t)
names=[n for n in json.load(open('/tmp/names.json')) if n not in ('ListePublier.dc.html','ListePublication.dc.html','ListeDepublier.dc.html','ListePartager.dc.html')]
for k,(h,ht,t) in P.items():
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
print('barre :',fait,'| pages :',list(P))
