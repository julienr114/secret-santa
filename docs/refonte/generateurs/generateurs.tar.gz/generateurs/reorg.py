import pathlib, json, re
P = pathlib.Path('/home/claude/utt/project')
PAGES = [
 ('accueil', 'Accueil et connexion', [
   ('Connexion', [('Connexion', 'Sans session'), ('ConnexionCreer', 'Créer un compte'), ('ConnexionEnvoye', 'Regarde ta boîte mail'), ('ConnexionConfirmer', 'Confirmer sur cet appareil'), ('ConnexionLienInvalide', 'Lien expiré')]),
   ('Accueil connecté', [('AccueilVide', 'Compte sans tirage'), ('Accueil', 'Un seul tirage'), ('AccueilPlusieurs', 'Plusieurs tirages, sans organiser'), ('AccueilOrganisateur', 'Plusieurs groupes, organisateur'), ('AccueilMenu', 'Menu ouvert'), ('PanneauAvatar', 'Appui sur l’avatar'), ('TiragesPasses', 'Tirages passés')]),
   ('Demander ou créer un groupe', [('PanneauDemandeGroupe', 'Demander un groupe'), ('AccueilDemandeAttente', 'Demande en attente'), ('AccueilDemandeRefusee', 'Demande refusée'), ('AccueilDemandeAcceptee', 'Demande acceptée'), ('GroupeNouveau', 'Créer un groupe')]),
   ('Mon compte', [('Compte', 'Mon compte')]),
 ]),
 ('participant', 'Participant', [
   ('Page d’un tirage : tous les états', [('TirageAttente', 'A · Avant le tirage'), ('TirageDecouvrir', 'B · Tirage fait, à découvrir'), ('TirageResultat', 'C · Résultat affiché'), ('TirageRevoir', 'D · Déjà découvert, résultat caché'), ('TirageCloture', 'E · Édition clôturée'), ('TirageLienInvalide', 'F · Lien invalide'), ('CarteCompte', 'Carte de compte, 3 cas'), ('TirageAlerteJournal', 'Alerte au journal')]),
   ('Liste de souhaits', [('Souhaits', 'Liste remplie'), ('SouhaitsVide', 'Liste vide'), ('SouhaitsIdee', 'Ajouter ou modifier une idée'), ('SouhaitsFigee', 'Édition clôturée')]),
   ('Rejoindre un groupe par lien', [('Rejoindre', 'Sans session'), ('RejoindreConnecte', 'Connecté'), ('RejoindreFait', 'C’est fait'), ('RejoindreFerme', 'Lien fermé')]),
 ]),
 ('edition', 'Organisateur · édition', [
   ('Étape 1 · Préparer', [('Main', 'Édition à préparer'), ('PreparerVide', 'Aucun participant'), ('PreparerImpossible', 'Tirage impossible'), ('AjouterParticipants', 'Ajouter des participants'), ('DateFete', 'Date de la fête'), ('ConfirmerTirage', 'Confirmation du tirage')]),
   ('Étape 2 · Tirage fait', [('Suivi', 'Suivi'), ('SuiviSansDate', 'Édition existante sans date'), ('FicheParticipant', 'Fiche d’un participant'), ('PanneauRegenerer', 'Régénérer un lien'), ('AnnulerTirage', 'Annuler le tirage')]),
   ('Envoyer les liens', [('SelectionEmail', 'Sélection par email'), ('Envoi', 'Envoyer à une personne'), ('EnvoiSansEmail', 'Personne sans adresse email'), ('Renvoi', 'Renvoyer à quelqu’un'), ('EtatConfirmation', 'Confirmation après un envoi')]),
   ('Voir un seul résultat (dernier recours)', [('VoirResultat', 'Formulaire'), ('ChoisirPersonne', 'Choisir une personne, 10 ou moins'), ('ChoisirPersonneRecherche', 'Choisir une personne, avec recherche'), ('VoirResultatAffiche', 'Résultat affiché')]),
   ('Étape 3 · Fêter', [('DevoilerAvant', 'Dévoiler avant la fête (forcé)'), ('Feter', 'Fêter, à dévoiler'), ('Devoiler', 'Confirmation du dévoilement'), ('Cloturee', 'Résultats dévoilés'), ('ClotureeSecrete', 'Clôturée sans dévoiler')]),
   ('Grands groupes (100 participants)', [('Preparer100', 'Édition à préparer'), ('ConfirmerTirageGrand', 'Confirmation du tirage'), ('Suivi100', 'Suivi après tirage'), ('SelectionEmail100', 'Sélection par email'), ('GroupeMembres100', 'Membres')]),
 ]),
 ('groupe', 'Organisateur · groupe', [
   ('Le groupe', [('Groupe', 'Accueil du groupe, édition en cours'), ('GroupeSansEdition', 'Pas d’édition en cours'), ('EditionNouvelle', 'Nouvelle édition')]),
   ('Membres et exclusions', [('GroupeMembres', 'Membres'), ('GroupePersonne', 'Fiche d’une personne'), ('PersonneNouvelle', 'Nouvelle personne'), ('GroupeInvitation', 'Inviter par lien'), ('GroupeExclusions', 'Exclusions'), ('PanneauExclusion', 'Nouvelle exclusion')]),
   ('Réglages', [('GroupeReglages', 'Réglages'), ('PanneauChoix', 'Panneau · choisir une valeur'), ('PanneauTexte', 'Panneau · saisir un texte'), ('PanneauNombre', 'Panneau · régler un nombre'), ('PanneauDate', 'Panneau · date facultative'), ('PanneauOrganisateur', 'Nouvel organisateur'), ('PanneauSupprimerGroupe', 'Supprimer le groupe')]),
 ]),
 ('journal', 'Journal', [
   ('Journal du groupe', [('Journal', 'L’essentiel'), ('JournalTout', 'Tout, regroupement déplié'), ('JournalPersonne', 'Tout, filtré sur moi'), ('JournalDetail', 'Explication d’une alerte'), ('JournalAide', '« À quoi sert-il ? »')]),
 ]),
 ('admin', 'Administration', [
   ('Y accéder', [('AdminAcces', 'Depuis l’accueil'), ('AdminAccesMenu', 'Par le menu')]),
   ('Demandes, comptes et groupes', [('Admin', 'Accueil de l’administration'), ('AdminPlusieursDemandes', 'Plusieurs demandes'), ('AdminDemande', 'Répondre à une demande'), ('AdminComptes', 'Comptes'), ('AdminCompte', 'Un compte'), ('AdminGroupes', 'Groupes')]),
 ]),
 ('divers', 'États et idées', [
   ('Chargement et erreurs', [('EtatChargement', 'Chargement'), ('EtatErreur', 'Erreur')]),
   ('Idées futures, non planifiées', [('FuturAccueil', 'Accueil avec « Devine qui a qui »'), ('FuturListes', 'Onglet Listes')]),
 ]),
]
boards, notes, noteOrder, order, seen = {}, {}, [], [], set()
ni = 0
for pid, pname, rows in PAGES:
    y = 0
    for rtitle, items in rows:
        hs = []
        for i, (stem, title) in enumerate(items):
            f = stem + '.dc.html'; t = (P/f).read_text()
            h = int(re.search(r'"height":(\d+)', t).group(1))
            assert f not in seen, f; seen.add(f)
            boards[f] = {"x": i * 470, "y": y, "w": 390, "h": h, "title": title, "page": pid}
            order.append(f); hs.append(h)
        ni += 1; nid = f't{ni:02d}'
        if len(items) > 1: noteOrder.append(nid)
        if len(items) > 1: notes[nid] = {"x": 0, "y": y - 300, "text": rtitle, "kind": "title1", "maxW": max(len(items) * 470 - 80, 1330), "page": pid}
        y += max(hs) + 120 + 300
allf = {p.name for p in P.glob('*.dc.html')}
print('missing from layout:', sorted(allf - seen), '| unknown:', sorted(seen - allf), '| count', len(seen))
order.remove('Main.dc.html'); order.insert(0, 'Main.dc.html')
canvas = {"v": 3, "attachments": {}, "boards": boards, "createdOnFiles": {"at": "2026-11-15T07:45:00Z", "v": 1}, "designSystems": [],
          "launch": {"view": "canvas", "page": "accueil"}, "noteOrder": noteOrder, "notes": notes, "order": order,
          "pages": [{"id": pid, "name": pname} for pid, pname, _ in PAGES], "title": "Under the Tree — propositions de maquettes"}
(P/'canvas.json').write_text(json.dumps(canvas, ensure_ascii=False, indent=2))
