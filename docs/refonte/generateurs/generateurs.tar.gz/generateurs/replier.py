import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
END_P = [('Théo', '🎁', 'mustard'), ('Valentine', '⛸️', 'kraft'), ('Victor', '🛷', 'brick'), ('Violette', '🥨', 'mustard'), ('Yanis', '🦉', 'pine'), ('Zélie', '🧣', 'plum'), ('Zoé', '🍪', 'kraft')]
mailof = lambda n: n.lower().replace("é", "e") + '@exemple.fr'
def unfold(src, name, title, h, mk):
    # The page is shown scrolled to the end of the unfolded list. The fold row
    # stays last, where it was, with its look and the gap under it: only its
    # words and its chevron change.
    t = (P/src).read_text()
    a = t.index('<li style="border-top: 1px solid #e9dcc5"><button aria-expanded="false"'); a = t.rindex('\n', 0, a) + 1
    k = t.index('</button></li>', a) + len('</button></li>\n')
    assert t[k:].lstrip().startswith('<li aria-hidden="true" style="height: 10px'), 'no gap'
    k = t.index('</li>', k) + 6
    seg = t[a:k]
    for x, y in [('aria-expanded="false"', 'aria-expanded="true"'), ('Voir les', 'Replier les'), ('<path d="m6 9 6 6 6-6"/>', '<path d="m6 15 6-6 6 6"/>')]:
        assert seg.count(x) == 1, x; seg = seg.replace(x, y)
    # No small avatars and no count on the row that folds back: its words are enough.
    i = seg.index('<span aria-hidden="true" style="position: relative; width: 44px; height: 40px; flex-shrink: 0">'); j = seg.index('<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">', i)
    seg = seg[:i] + seg[j:]
    seg = re.sub(r'Replier les \d+ autres', 'Replier la liste', seg)
    ul_a = t.rindex('<ul', 0, a); ul_b = t.index('>', ul_a) + 1
    m = t.index('<main'); m_b = t.index('>', m) + 1
    rows = ''.join(mk(n, e, c, i == 0) for i, (n, e, c) in enumerate(END_P))
    t = t[:m_b] + '\n    <section style="display: flex; flex-direction: column; gap: 6px">\n      ' + t[ul_a:ul_b] + '\n' + rows + seg + t[k:]
    t = t.replace("flex-direction: column; gap: 24px; padding: 20px 16px 32px", "flex-direction: column; gap: 24px; padding: 0 16px 32px", 1)
    save(name, t, title, h)
unfold('GroupeMembres100.dc.html', 'GroupeMembres100Deplie.dc.html', 'Membres — fin de la liste dépliée', 920, lambda n, e, c, f: lrow(n, e, c, mailof(n), first=f))
unfold('Preparer100.dc.html', 'Preparer100Deplie.dc.html', 'Édition à préparer — fin de la liste dépliée', 960, lambda n, e, c, f: lrow(n, e, c, first=f))
unfold('Suivi100.dc.html', 'Suivi100Deplie.dc.html', 'Tirage fait — fin d’une série dépliée', 1360, lambda n, e, c, f: lrow(n, e, c, DASH + 'Pas encore envoyé', SENDB(n), first=f))
cv = json.loads((P/'canvas.json').read_text())
for f, ti in [('GroupeMembres100Deplie.dc.html', 'Membres, fin de la liste dépliée'), ('Preparer100Deplie.dc.html', 'Édition à préparer, fin de la liste dépliée'), ('Suivi100Deplie.dc.html', 'Suivi, fin d’une série dépliée')]:
    cv['boards'][f]['h'] = OUT[f]; cv['boards'][f]['title'] = ti
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT)
