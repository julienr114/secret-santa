import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
MAIL = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg>'
def cta(label, hint):
    return f'''<a href="SelectionEmail.dc.html" style="height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
        {MAIL}
        {label}
      </a>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">{hint}</p>'''
def swap(name, label, hint):
    t = (P/name).read_text()
    a = t.index('<button style="width: 100%; height: 48px; border: 0; border-radius: 6px; background: #b8483a')
    b = t.index('</button>', t.index('</button>', a) + 1) + len('</button>')
    assert t.count('<button style="width: 100%; height: 48px; border: 0; border-radius: 6px; background: #b8483a') == 1
    (P/name).write_text(t[:a] + cta(label, hint) + t[b:])
swap('Main.dc.html', 'Envoyer les invitations par email', 'Sans adresse email ? Le bouton de chaque ligne partage le lien par WhatsApp ou SMS.')
swap('Suivi.dc.html', 'Prévenir par email', 'Sans adresse email ? Le bouton de chaque ligne partage le lien par WhatsApp ou SMS.')

# Envoi: email primary, share + copy secondary
t = (P/'Envoi.dc.html').read_text()
a = t.index('<button style="width: 100%; height: 52px')
b = t.index('</div>', t.index('Par email', a)) + len('</div>')
SEC = 'height: 46px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 6px; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px'
new = f'''<button style="width: 100%; min-height: 56px; padding: 6px 12px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 10px">
        {MAIL}
        <span style="display: flex; flex-direction: column; align-items: flex-start">
          <span style="font-size: 17px; font-weight: 700; line-height: 1.2">Envoyer par email</span>
          <span style="font-size: 13px; font-weight: 500; line-height: 1.2">lou-demo@example.com</span>
        </span>
      </button>
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">
        <button style="{SEC}">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/></svg>
          Partager
        </button>
        <button style="{SEC}">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>
          Copier
        </button>
      </div>'''
t = t[:a] + new + t[b:]
t = t.replace('Une fois partagé, le panneau passe à', 'Une fois envoyé, le panneau passe à')
(P/'Envoi.dc.html').write_text(t)

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['SelectionEmail.dc.html'] = {"x": 470, "y": 0, "w": 390, "h": 900, "title": "2 · Envoyer par email, sélection"}
b['Envoi.dc.html'].update(x=940, title="3 · Panneau « Envoyer à… » (une personne)")
b['ConfirmerTirage.dc.html'].update(x=1410, title="4 · Confirmation du tirage")
b['Suivi.dc.html'].update(x=1880, title="5 · Édition tirée, suivi")
c['order'].insert(1, 'SelectionEmail.dc.html')
c['notes']['t-orga']['maxW'] = 2270
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
