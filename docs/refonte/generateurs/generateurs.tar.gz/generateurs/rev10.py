import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
src = (P/'ConfirmerTirage.dc.html').read_text()
SH = {'brick': ('#f3d3cc', '#e09e92'), 'pine': ('#cfe2d3', '#8db898'), 'mustard': ('#f6e3ad', '#e6b94a'), 'kraft': ('#ecdfc6', '#cdb48a'), 'frost': ('#d6e6ef', '#94bbd0'), 'plum': ('#ead2e2', '#c493b4')}
def av(e, color):
    bg, ring = SH[color]
    return f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0">{e}</span>'
CHECK = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#a43a2f" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
def opt(e, color, label_html, selected=False, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li role="option" aria-selected="{str(selected).lower()}">
          <button style="width: 100%; min-height: 56px; padding: 8px 14px; box-sizing: border-box; border: 0;{bt} background: {'#fbf3f1' if selected else 'transparent'}; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 12px; text-align: left">
            {av(e, color)}
            <span style="flex-grow: 1">{label_html}</span>
            {CHECK if selected else ''}
          </button>
        </li>
'''
H1 = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.15"
def sheet(name, title, filler, inner):
    t = src
    a = t.index('<section aria-label="Lancer le tirage"'); b = t.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="Le résultat de qui ?" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 14px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
{inner}
  </section>'''
    t = t[:a] + sec + t[b:]
    for old, new in [('<title>Confirmation du tirage</title>', f'<title>{title}</title>'), ('height: 150px', f'height: {filler}px'), ('font-size: 30px; color: #5c554c">Noël 2026', 'font-size: 30px; color: #5c554c">Voir un seul résultat')]:
        assert old in t, old; t = t.replace(old, new)
    (P/name).write_text(t)
m = lambda pre, hit, post: f'{pre}<mark style="background: #f9eecb; color: inherit; border-radius: 3px">{hit}</mark>{post}'
sheet('ChoisirPersonneRecherche.dc.html', 'Choisir une personne — avec recherche', 150, f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <h1 style="{H1}">Le résultat de qui ?</h1>
      <p style="margin: 0; font-size: 14px; color: #57534e">42 participants</p>
    </div>
    <div style="position: relative">
      <label for="search-person" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%)">Chercher un prénom</label>
      <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#57534e" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; left: 14px; top: 15px"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500"/></svg>
      <input id="search-person" type="search" value="lo" placeholder="Chercher un prénom" style="width: 100%; height: 48px; box-sizing: border-box; padding: 0 44px 0 42px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
      <button aria-label="Effacer la recherche" style="position: absolute; right: 2px; top: 2px; width: 44px; height: 44px; border: 0; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0">
        <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
    <p aria-live="polite" style="margin: 0; font-size: 13px; color: #57534e">4 prénoms sur 42</p>
    <ul role="listbox" aria-label="Participants" style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden">
{opt('🎄', 'mustard', m('', 'Lo', 'uis'), False, True)}{opt('⛄', 'frost', m('', 'Lo', 'la'))}{opt('🧦', 'brick', m('Chlo', '', 'é').replace('Chlo<mark', 'Ch<mark').replace('"></mark>é', '">lo</mark>é'))}{opt('🕯️', 'pine', m('É', 'lo', 'die'))}    </ul>
    <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">La recherche ignore les accents et les majuscules.</p>''')

sheet('ChoisirPersonne.dc.html', 'Choisir une personne — petit groupe', 330, f'''    <div style="display: flex; flex-direction: column; gap: 2px">
      <h1 style="{H1}">Le résultat de qui ?</h1>
      <p style="margin: 0; font-size: 14px; color: #57534e">5 participants</p>
    </div>
    <ul role="listbox" aria-label="Participants" style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden">
{opt('🦌', 'plum', 'Camille', False, True)}{opt('🐧', 'mustard', 'Hugo', True)}{opt('🍭', 'mustard', 'Inès')}{opt('🎄', 'mustard', 'Louis')}{opt('🐧', 'plum', 'Rose')}    </ul>''')

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['ChoisirPersonne.dc.html'] = {"y": 0, "w": 390, "h": 844, "title": "Choisir une personne · 10 participants ou moins"}
b['ChoisirPersonneRecherche.dc.html'] = {"y": 0, "w": 390, "h": 844, "title": "Choisir une personne · plus de 10, avec recherche"}
order = c['order']; k = order.index('TirageAttente.dc.html'); row = order[:k]
p = row.index('VoirResultat.dc.html') + 1
row[p:p] = ['ChoisirPersonne.dc.html', 'ChoisirPersonneRecherche.dc.html']
for i, f in enumerate(row): b[f]['x'] = i * 470
c['order'] = row + order[k:]
c['notes']['t-orga']['maxW'] = len(row) * 470 - 80
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
