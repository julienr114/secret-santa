import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
CAL = '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>'
PEN = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#57534e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.800 2.800 0 1 1 4 4L7.500 20.500 2 22l1.500-5.500z"/></svg>'
def chip(date):
    return f'''<a href="DateFete.dc.html" aria-label="Fête le {date}. Modifier la date" style="align-self: flex-start; margin-top: 6px; min-height: 44px; box-sizing: border-box; padding: 0 12px; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; color: #292524; font-size: 15px; font-weight: 600; text-decoration: none; display: flex; align-items: center; gap: 8px">
        {CAL}
        Fête le {date}
        {PEN}
      </a>'''
def rep(name, old, new):
    t = (P/name).read_text(); assert old in t, (name, old)
    (P/name).write_text(t.replace(old, new))
rep('Main.dc.html', '<p style="margin: 0; font-size: 15px; color: #57534e">Amis de Camille · Budget 20 € · le 19 décembre</p>',
    '<p style="margin: 0; font-size: 15px; color: #57534e">Amis de Camille · Budget 20 €</p>\n      ' + chip('19 décembre'))
rep('Main.dc.html', 'height: 1040px', 'height: 1090px'); rep('Main.dc.html', '"height":1040', '"height":1090')
rep('Suivi.dc.html', '<p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille · le 25 décembre</p>',
    '<p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille</p>\n      ' + chip('25 décembre'))
rep('Suivi.dc.html', 'height: 1320px', 'height: 1370px'); rep('Suivi.dc.html', '"height":1320', '"height":1370')

src = (P/'ConfirmerTirage.dc.html').read_text()
a = src.index('<section aria-label="Lancer le tirage"'); b = src.index('</section>', a) + len('</section>')
sec = f'''<section aria-label="Date de la fête" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15">Date de la fête</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Le jour où vous échangez les cadeaux.</p>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="party-date" style="font-size: 15px; font-weight: 600">Date</label>
      <div style="position: relative">
        <input id="party-date" type="text" value="25/12/2026" style="width: 100%; height: 52px; box-sizing: border-box; padding: 0 48px 0 14px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 18px; font-weight: 600">
        <button aria-label="Ouvrir le calendrier" style="position: absolute; right: 4px; top: 4px; width: 44px; height: 44px; border: 0; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0">{CAL.replace('width="16" height="16"', 'width="20" height="20"')}</button>
      </div>
      <p style="margin: 0; font-size: 13px; color: #57534e">Vendredi 25 décembre 2026 · dans 40 jours</p>
    </div>
    <ul style="margin: 0; padding: 0 0 0 18px; display: flex; flex-direction: column; gap: 6px; font-size: 14px; line-height: 1.45; color: #57534e">
      <li>Les participants la voient sur leur page, avec le compte à rebours.</li>
      <li>Les résultats peuvent être dévoilés à partir de ce jour.</li>
      <li>Le changement est inscrit au journal du groupe.</li>
    </ul>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
      <a href="Suivi.dc.html" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    </div>
  </section>'''
t = src[:a] + sec + src[b:]
t = t.replace('<title>Confirmation du tirage</title>', '<title>Date de la fête</title>').replace('height: 150px', 'height: 250px')
(P/'DateFete.dc.html').write_text(t)

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['Main.dc.html']['h'] = 1090; b['Suivi.dc.html']['h'] = 1370
b['DateFete.dc.html'] = {"y": 0, "w": 390, "h": 844, "title": "Date de la fête · modifiable depuis l'édition"}
order = c['order']; k = order.index('TirageAttente.dc.html'); row = order[:k]
row.insert(row.index('Main.dc.html') + 1, 'DateFete.dc.html')
for i, f in enumerate(row): b[f]['x'] = i * 470
c['order'] = row + order[k:]
c['notes']['t-orga']['maxW'] = len(row) * 470 - 80
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
