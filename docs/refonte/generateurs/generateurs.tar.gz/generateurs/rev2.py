import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
STAR = '<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
CHEV = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
SEND = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg>'
def step(kind, label, line=None, num=''):
    dots = {
      'done': f'<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; border-radius: 50%; background: #2f613f; color: #ffffff; display: flex; align-items: center; justify-content: center">{CHECK}</span>',
      'now': f'<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; border-radius: 50%; background: #b8483a; box-shadow: 0 0 0 4px #f6e2dd; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700">{num or STAR}</span>',
      'todo': f'<span aria-hidden="true" style="position: relative; width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; background: #f7f2e9; border: 2px solid #dccbad; color: #57534e; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700">{num}</span>',
    }
    ln = f'<span aria-hidden="true" style="position: absolute; top: 11px; left: 50%; width: 100%; height: 2px; background: {line}"></span>' if line else ''
    lab = 'font-weight: 700; color: #8a2f27' if kind == 'now' else 'font-weight: 600; color: #57534e'
    cur = ' aria-current="step"' if kind == 'now' else ''
    return f'''      <li{cur} style="display: flex; flex-direction: column; align-items: center; gap: 6px; position: relative">
        {ln}
        {dots[kind]}
        <span style="font-size: 12px; {lab}">{label}</span>
      </li>
'''
def stepper(items):
    return '<ol aria-label="Étapes de l\'édition" style="list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr))">\n' + ''.join(items) + '    </ol>'
def sub(t, start, close, new):
    i = t.index(start); j = t.index(close, i) + len(close)
    return t[:i] + new + t[j:]

AV = {'🦌': ('#ead2e2', '#c493b4'), '🌰': ('#f6e3ad', '#e6b94a'), '🍷': ('#ead2e2', '#c493b4'), '🦉': ('#cfe2d3', '#8db898'),
      '🍭': ('#f6e3ad', '#e6b94a'), '🎄': ('#f6e3ad', '#e6b94a'), '🐧r': ('#ead2e2', '#c493b4'), '🐧h': ('#f6e3ad', '#e6b94a')}
def avatar(key, size=40, fs=18):
    bg, ring = AV[key]
    return f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: {fs}px; flex-shrink: 0">{key[0]}</span>'
LIST = 'list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad'
H2 = "margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e"
CARD = 'background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05);'

# ---------- Main: Préparer ----------
t = (P/'Main.dc.html').read_text()
def prow(key, name, subline='', first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    s = f'<span style="font-size: 13px; color: #57534e">{subline}</span>' if subline else ''
    return f'''        <li{''}>
          <a href="#fiche" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            {avatar(key)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{name}</span>
              {s}
            </span>
            {CHEV}
          </a>
        </li>
'''
def lrow(href, icon, title, subline, first=False, tint=('#f6e2dd', '#a43a2f')):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li>
          <a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {tint[0]}; color: {tint[1]}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{icon}</svg>
            </span>
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{title}</span>
              <span style="font-size: 14px; color: #57534e">{subline}</span>
            </span>
            {CHEV}
          </a>
        </li>
'''
I_ADD = '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>'
I_MAIL = '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>'
I_BAN = '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>'
MAIN = f'''<main style="display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 32px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Noël 2026</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">Amis de Camille · Budget 20 € · le 19 décembre</p>
    </div>

    {stepper([step('now', 'Préparer', '#e9dcc5', '1'), step('todo', 'Tirer', '#e9dcc5', '2'), step('todo', 'Fêter', None, '3')])}

    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">À faire maintenant</p>
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 22px; line-height: 1.2">Vérifie la liste, puis lance le tirage</h2>
        <p style="margin: 0; display: flex; align-items: center; gap: 6px; font-size: 14px; color: #57534e">
          <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2f613f" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
          4 participants, toutes les règles sont respectées.
        </p>
      </div>
      <a href="ConfirmerTirage.dc.html" style="height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
        <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>
        Lancer le tirage
      </a>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Tu préviendras tout le monde juste après, par email.</p>
    </section>

    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">4 participants</h2>
      <ul style="{LIST}">
{prow('🦌', 'Camille', '2 idées de cadeaux', True)}{prow('🌰', 'Lou')}{prow('🍷', 'Sacha')}{prow('🦉', 'Yanis', 'Messages en anglais')}{lrow('#ajouter', I_ADD, 'Ajouter des participants', 'Léa ne participe pas encore')}      </ul>
    </section>

    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Si tu veux</h2>
      <ul style="{LIST}">
{lrow('SelectionEmail.dc.html', I_MAIL, 'Prévenir avant le tirage', 'Facultatif : chacun peut déjà noter ses idées', True, ('#f1e8d8', '#57534e'))}{lrow('#exclusions', I_BAN, 'Exclusions', "Aucune pour l'instant", False, ('#f1e8d8', '#57534e'))}      </ul>
    </section>
  </main>'''
i = t.index('<main'); j = t.index('</main>') + len('</main>')
t = t[:i] + MAIN + t[j:]
t = t.replace('<title>Édition — étape Invitations</title>', '<title>Édition — étape Préparer</title>')
t = t.replace('height: 1300px', 'height: 1040px').replace('"height":1300', '"height":1040')
(P/'Main.dc.html').write_text(t)

# ---------- Suivi: 3 steps ----------
t = (P/'Suivi.dc.html').read_text()
t = sub(t, '<ol aria-label', '</ol>', stepper([step('done', 'Préparer', '#2f613f'), step('now', 'Tirage fait', '#e9dcc5'), step('todo', 'Fêter', None, '3')]))
(P/'Suivi.dc.html').write_text(t)

# ---------- Confirmation: replace invitations warning ----------
t = (P/'ConfirmerTirage.dc.html').read_text()
a = t.index('<li style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-top: 1px solid #e9dcc5; background: #fdf8ea">')
b = t.index('</li>', a) + 5
new = '''<li style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-top: 1px solid #e9dcc5; background: #fdf8ea">
        <span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: #f9eecb; color: #79511d; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M12 7v6M12 17h.01"/></svg>
        </span>
        <span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px">
          <span style="font-size: 15px; font-weight: 600; color: #66431d">Léa ne participe pas encore</span>
          <span style="font-size: 13px; line-height: 1.4; color: #66431d">Elle est dans le groupe mais pas dans cette édition. Après le tirage, il faudra l'annuler pour l'ajouter.</span>
        </span>
      </li>'''
t = t[:a] + new + t[b:]
(P/'ConfirmerTirage.dc.html').write_text(t)

# ---------- Envoi: post-draw, Inès ----------
t = (P/'Envoi.dc.html').read_text()
a = t.index('<div role="radiogroup"'); b = t.index('</div>', a) + 6
seg = lambda label, on: (f'<button role="radio" aria-checked="true" style="height: 40px; border: 0; border-radius: 7px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12); color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">{label}</button>' if on else f'<button role="radio" aria-checked="false" style="height: 40px; border: 0; border-radius: 7px; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 600">{label}</button>')
t = t[:a] + f'''<div role="radiogroup" aria-label="Message" style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 10px; background: #f1e8d8">
      {seg('Tirage fait', True)}
      {seg('Relance', False)}
      {seg('Nouveau tirage', False)}
    </div>''' + t[b:]
for old, new in [
  ('Panneau Envoyer à Lou', 'Panneau Envoyer à Inès'), ('aria-label="Envoyer à Lou"', 'aria-label="Envoyer à Inès"'),
  ('Envoyer à Lou</h1>', 'Envoyer à Inès</h1>'), ('Encore 3 personnes à inviter', 'Encore 3 personnes à prévenir'),
  ('>🌰</span>', '>🍭</span>'),
  ('Salut Lou ! 🎁 Tu participes au Secret Santa de Amis de Camille (Noël 2026). Ouvre ton lien et note quelques idées de cadeaux :', 'Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :'),
  ('lou-demo@example.com', 'ines-demo@example.com'),
  ('background: #ead2e2; box-shadow: 0 0 0 1px #c493b4; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0">🍷', 'background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0">🎄'),
  ('<strong>Sacha</strong>', '<strong>Louis</strong>'),
]:
    assert old in t, old
    t = t.replace(old, new)
(P/'Envoi.dc.html').write_text(t)

# ---------- SelectionEmail: post-draw, Famille Camille ----------
t = (P/'SelectionEmail.dc.html').read_text()
a = t.index('<div role="radiogroup"'); b = t.index('</div>', a) + 6
t = t[:a] + f'''<div role="radiogroup" aria-label="Message" style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 10px; background: #e9dcc5">
        {seg('Tirage fait', True)}
        {seg('Relance', False)}
        {seg('Nouveau tirage', False)}
      </div>''' + t[b:]
def crow(key, name, line, checked, first=False, ok=False, warn=False):
    bt = '' if first else ' style="border-top: 1px solid #e9dcc5"'
    ic = ''
    if ok: ic = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2f613f" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
    if warn: ic = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#79511d" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
    return f'''        <li{bt}>
          <label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">
            {avatar(key)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{name}</span>
              <span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: #57534e">{ic}{line}</span>
            </span>
            <input type="checkbox"{' checked' if checked else ''} style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
          </label>
        </li>
'''
a = t.index('<ul style="list-style: none; margin: 0 -16px'); b = t.index('</ul>', a) + 5
t = t[:a] + f'<ul style="{LIST}">\n' + crow('🍭', 'Inès', 'ines-demo@example.com', True, True) + crow('🎄', 'Louis', 'louis-demo@example.com', True) + crow('🐧h', 'Hugo', 'Envoyé, pas encore consulté', False, warn=True) + crow('🦌', 'Camille', 'Résultat déjà consulté', False, ok=True) + '      </ul>' + t[b:]
for old, new in [
  ('Destinataires · 2 sur 3', 'Destinataires · 2 sur 4'),
  ('background: #cfe2d3; box-shadow: 0 0 0 1px #8db898; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0">🦉', 'background: #ead2e2; box-shadow: 0 0 0 1px #c493b4; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0">🐧'),
  ('>Yanis<', '>Rose<'), ('#fiche-yanis', '#fiche-rose'),
  ('Aperçu, pour Lou', 'Aperçu, pour Inès'),
  ('Salut Lou ! 🎁 Tu participes au Secret Santa de Amis de Camille (Noël 2026). Ouvre ton lien et note quelques idées de cadeaux…', 'Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau…'),
  ('href="Main.dc.html"', 'href="Suivi.dc.html"'),
  ('height: 900px', 'height: 960px'), ('"height":900', '"height":960'),
]:
    assert old in t, old
    t = t.replace(old, new)
(P/'SelectionEmail.dc.html').write_text(t)

# ---------- canvas ----------
c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['Main.dc.html'].update(x=0, h=1040, title="1 · Édition à préparer (plus d'étape Invitations)")
b['ConfirmerTirage.dc.html'].update(x=470, title="2 · Confirmation du tirage")
b['Suivi.dc.html'].update(x=940, title="3 · Tirage fait, suivi")
b['SelectionEmail.dc.html'].update(x=1410, h=960, title="4 · Prévenir par email, sélection")
b['Envoi.dc.html'].update(x=1880, title="5 · Envoyer à une personne")
top = ['Main.dc.html', 'ConfirmerTirage.dc.html', 'Suivi.dc.html', 'SelectionEmail.dc.html', 'Envoi.dc.html']
c['order'] = top + [o for o in c['order'] if o not in top]
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
