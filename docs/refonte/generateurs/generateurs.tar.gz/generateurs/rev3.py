import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
t = (P/'ConfirmerTirage.dc.html').read_text()
a = t.index('<span aria-hidden="true" style="display: flex">'); b = t.index('</span>\n      </li>', a) + len('</span>')
def av(e, bg, first=False):
    ml = '' if first else ' margin-left: -8px;'
    return f'<span style="width: 30px; height: 30px;{ml} border-radius: 50%; background: {bg}; box-shadow: 0 0 0 2px #fffdf9; display: flex; align-items: center; justify-content: center; font-size: 14px">{e}</span>'
stack = f'''<span aria-hidden="true" style="display: flex; align-items: center">
          {av('🦌', '#ead2e2', True)}
          {av('🌰', '#f6e3ad')}
          {av('🍷', '#ead2e2')}
          {av('🦉', '#cfe2d3')}
          <span style="height: 30px; min-width: 30px; box-sizing: border-box; margin-left: -8px; padding: 0 8px; border-radius: 999px; background: #e9dcc5; box-shadow: 0 0 0 2px #fffdf9; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #292524">+96</span>
        </span>'''
t = t[:a] + stack + t[b:]
for old, new in [
  ('<title>Confirmation du tirage</title>', '<title>Confirmation du tirage, grand groupe</title>'),
  ('>4 participants<', '>100 participants<'),
  ('Aucune exclusion · personne ne se tire soi-même', '12 exclusions · personne ne se tire soi-même'),
  ('Léa ne participe pas encore', '7 personnes ne participent pas encore'),
  ("Elle est dans le groupe mais pas dans cette édition. Après le tirage, il faudra l'annuler pour l'ajouter.", "Léa, Tom, Zoé et 4 autres sont dans le groupe mais pas dans cette édition."),
]:
    assert old in t, old
    t = t.replace(old, new)
# link to see the missing people
t = t.replace('sont dans le groupe mais pas dans cette édition.</span>', 'sont dans le groupe mais pas dans cette édition.</span>\n          <a href="#ajouter" style="min-height: 32px; display: flex; align-items: center; font-size: 13px; font-weight: 700; color: #66431d">Voir et ajouter</a>')
(P/'ConfirmerTirageGrand.dc.html').write_text(t)
c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['ConfirmerTirageGrand.dc.html'] = {"x": 940, "y": 0, "w": 390, "h": 844, "title": "2 bis · Confirmation, 100 participants"}
b['Suivi.dc.html']['x'] = 1410; b['SelectionEmail.dc.html']['x'] = 1880; b['Envoi.dc.html']['x'] = 2350
c['order'].insert(2, 'ConfirmerTirageGrand.dc.html')
c['notes']['t-orga']['maxW'] = 2740
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
