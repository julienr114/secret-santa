import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
LIST = 'list-style: none; margin: 0 -16px; padding: 0; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad'
H2 = "margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e"
SEND = '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg>'
AV = {'🦌': ('#ead2e2', '#c493b4'), '🍭': ('#f6e3ad', '#e6b94a'), '🎄': ('#f6e3ad', '#e6b94a'), '🐧r': ('#ead2e2', '#c493b4'), '🐧h': ('#f6e3ad', '#e6b94a')}
def avatar(key):
    bg, ring = AV[key]
    return f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0">{key[0]}</span>'
ICON = {
 'todo': ('<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#57534e" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="3.500 4"><circle cx="12" cy="12" r="9"/></svg>', '#57534e'),
 'wait': ('<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#79511d" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>', '#79511d'),
 'ok': ('<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2f613f" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>', '#57534e'),
}
def status(kind, text):
    ic, col = ICON[kind]
    return f'<span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: {col}">{ic}{text}</span>'

# ---- Suivi ----
def row(key, name, kind, text, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    if kind == 'todo':
        btn = f'<button aria-label="Envoyer le lien de {name}" style="width: 44px; height: 44px; border: 0; border-radius: 50%; background: #f6e2dd; color: #a43a2f; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{SEND}</button>'
    else:
        btn = f'<button aria-label="Renvoyer le lien de {name}" style="width: 44px; height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{SEND}</button>'
    return f'''        <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">
          {avatar(key)}
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
            <span style="font-weight: 600; font-size: 16px">{name}</span>
            {status(kind, text)}
          </span>
          {btn}
        </li>
'''
t = (P/'Suivi.dc.html').read_text()
S = '<section style="display: flex; flex-direction: column; gap: 6px">'
a = t.index(S); b = t.rindex(S)
new = f'''<section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">5 participants</h2>
      <ul style="{LIST}">
{row('🍭', 'Inès', 'todo', 'Pas encore envoyé', True)}{row('🎄', 'Louis', 'todo', 'Pas encore envoyé')}{row('🐧r', 'Rose', 'todo', 'Pas encore envoyé')}{row('🐧h', 'Hugo', 'wait', 'Envoyé, pas encore consulté')}{row('🦌', 'Camille', 'ok', 'Résultat consulté · 2×')}      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Ceux qui restent à prévenir sont en premier.</p>
    </section>

    '''
t = t[:a] + new + t[b:]
t = t.replace('height: 1400px', 'height: 1320px').replace('"height":1400', '"height":1320')
(P/'Suivi.dc.html').write_text(t)

# ---- SelectionEmail: one list ----
def crow(key, name, line, checked, first=False, disabled=False):
    bt = '' if first else ' style="border-top: 1px solid #e9dcc5"'
    dis = ' disabled' if disabled else ''
    extra = '<a href="#fiche-rose" style="min-height: 44px; padding: 0 4px; display: flex; align-items: center; font-size: 14px; font-weight: 700; flex-shrink: 0">Ajouter</a>' if disabled else ''
    box = '' if disabled else f'<input type="checkbox"{" checked" if checked else ""} style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">'
    tag = 'div' if disabled else 'label'
    return f'''        <li{bt}>
          <{tag} style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">
            {avatar(key)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{name}</span>
              {line}
            </span>
            {box}{extra}
          </{tag}>
        </li>
'''
mail = lambda m: f'<span style="font-size: 13px; color: #57534e; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{m}</span>'
t = (P/'SelectionEmail.dc.html').read_text()
a = t.index('<ul style="list-style: none; margin: 0 -16px'); b = t.index('</ul>', a) + 5
t = t[:a] + f'<ul style="{LIST}">\n' + crow('🍭', 'Inès', mail('Pas encore envoyé · ines-demo@example.com'), True, True) + crow('🎄', 'Louis', mail('Pas encore envoyé · louis-demo@example.com'), True) + crow('🐧r', 'Rose', status('todo', "Pas d'adresse email"), False, disabled=True) + crow('🐧h', 'Hugo', status('wait', 'Envoyé, pas encore consulté'), False) + crow('🦌', 'Camille', status('ok', 'Résultat consulté · 2×'), False) + '      </ul>' + t[b:]
# drop the "Sans adresse email" section
a = t.index('<section style="display: flex; flex-direction: column; gap: 6px">\n      <h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Sans adresse email')
b = t.index('</section>', a) + len('</section>')
t = t[:a].rstrip() + '\n  ' + t[b:].lstrip('\n ')
t = t.replace('Destinataires · 2 sur 4', '2 sélectionnés sur 5')
t = t.replace('height: 960px', 'height: 920px').replace('"height":960', '"height":920')
(P/'SelectionEmail.dc.html').write_text(t)

c = json.loads((P/'canvas.json').read_text())
c['boards']['Suivi.dc.html']['h'] = 1320
c['boards']['SelectionEmail.dc.html']['h'] = 920
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
