import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
exec(open('/home/claude/gen/rev2.py').read().split("# ---------- Main: Préparer ----------")[0])  # helpers: step, stepper, sub, LIST, H2, CARD, CHEV, CHECK
AV = {'🦌': ('#ead2e2', '#c493b4'), '🍭': ('#f6e3ad', '#e6b94a'), '🎄': ('#f6e3ad', '#e6b94a'), '🐧r': ('#ead2e2', '#c493b4'), '🐧h': ('#f6e3ad', '#e6b94a')}
def avatar(key, size=40, fs=18):
    bg, ring = AV[key]
    return f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: {fs}px; flex-shrink: 0">{key[0]}</span>'
OK = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2f613f" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'
WAIT = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#79511d" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
ARCH = '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>'
def lrow(href, icon, title, subline, first=False, danger=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    bg, fg, tc = ('#fbe1e5', '#961d35', '#961d35') if danger else ('#f1e8d8', '#57534e', '#292524')
    return f'''        <li>
          <a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: {tc}">
            <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{icon}</svg>
            </span>
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{title}</span>
              <span style="font-size: 14px; color: #57534e">{subline}</span>
            </span>
            {CHEV}
          </a>
        </li>
'''
def head(sub_):
    return f'''<div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1">Noël 2026</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">{sub_}</p>
    </div>'''
src = (P/'Suivi.dc.html').read_text()
def build(name, title, main, h):
    t = src
    i = t.index('<main'); j = t.index('</main>') + len('</main>')
    t = t[:i] + main + t[j:]
    t = t.replace('<title>Édition tirée — suivi</title>', f'<title>{title}</title>')
    t = t.replace('height: 1320px', f'height: {h}px').replace('"height":1320', f'"height":{h}')
    assert f'height: {h}px' in t
    (P/name).write_text(t)

# ---- A: Fêter, à clôturer ----
def srow(key, name, ic, text, col='#57534e', first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li>
          <a href="#fiche" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt} text-decoration: none; color: #292524">
            {avatar(key)}
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">{name}</span>
              <span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: {col}">{ic}{text}</span>
            </span>
            {CHEV}
          </a>
        </li>
'''
A = f'''<main style="display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 32px">
    {head('Famille Camille · fêté le 25 décembre')}

    {stepper([step('done', 'Préparer', '#2f613f'), step('done', 'Tirage fait', '#2f613f'), step('now', 'Fêter', None)])}

    <section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">À faire maintenant</p>
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 22px; line-height: 1.2">La fête est passée : clôture l'édition</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Elle ne sera plus modifiable et servira d'historique : l'an prochain, personne ne retombera sur la même personne.</p>
      </div>
      <div style="display: flex; flex-direction: column; gap: 6px">
        <div role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" aria-label="Résultats consultés" style="height: 8px; border-radius: 999px; background: #e9dcc5; overflow: hidden">
          <div style="width: 80%; height: 100%; border-radius: 999px; background: #2f613f"></div>
        </div>
        <p style="margin: 0; font-size: 13px; color: #57534e">4 sur 5 ont consulté leur résultat</p>
      </div>
      <button style="width: 100%; height: 48px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{ARCH}</svg>
        Clôturer l'édition
      </button>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Après la clôture, le tirage n'est plus secret pour toi.</p>
    </section>

    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">5 participants</h2>
      <ul style="{LIST}">
{srow('🐧r', 'Rose', WAIT, 'Envoyé, pas encore consulté', '#79511d', True)}{srow('🦌', 'Camille', OK, 'Résultat consulté · 3×')}{srow('🐧h', 'Hugo', OK, 'Résultat consulté')}{srow('🍭', 'Inès', OK, 'Résultat consulté · 2×')}{srow('🎄', 'Louis', OK, 'Résultat consulté')}      </ul>
    </section>

    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">En cas de pépin</h2>
      <ul style="{LIST}">
{lrow('#voir', '<path d="M2.500 12S6 5 12 5s9.500 7 9.500 7-3.500 7-9.500 7-9.500-7-9.500-7z"/><circle cx="12" cy="12" r="3"/>', 'Voir un résultat', 'Dernier recours, inscrit au journal', True)}{lrow('#annuler', '<path d="M3 12a9 9 0 1 0 3-6.700L3 8M3 3v5h5"/>', 'Annuler et relancer le tirage', 'Désistement, oubli… journalisé', False, True)}      </ul>
    </section>
  </main>'''
build('Feter.dc.html', 'Édition — étape Fêter, à clôturer', A, 1180)

# ---- B: clôturée ----
ARROW = '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'
def pair(g, gname, r, rname, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">
          {avatar(g)}
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
            <span style="font-weight: 600; font-size: 16px">{gname}</span>
            <span style="font-size: 13px; color: #57534e">a offert à {rname}</span>
          </span>
          {ARROW}
          {avatar(r, 32, 15)}
        </li>
'''
B = f'''<main style="display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 32px">
    {head('Famille Camille · fêté le 25 décembre')}

    {stepper([step('done', 'Préparer', '#2f613f'), step('done', 'Tirage fait', '#2f613f'), step('done', 'Fêté', None)])}

    <section style="{CARD} padding: 20px; display: flex; align-items: flex-start; gap: 14px">
      <span aria-hidden="true" style="width: 44px; height: 44px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{ARCH}</svg>
      </span>
      <div style="display: flex; flex-direction: column; gap: 4px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 22px; line-height: 1.2">Édition clôturée</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">En lecture seule. Elle sert d'historique pour le tirage de l'an prochain.</p>
      </div>
    </section>

    <section style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Le tirage · 5 participants</h2>
      <ul style="{LIST}">
{pair('🦌', 'Camille', '🍭', 'Inès', True)}{pair('🐧h', 'Hugo', '🦌', 'Camille')}{pair('🍭', 'Inès', '🎄', 'Louis')}{pair('🎄', 'Louis', '🐧r', 'Rose')}{pair('🐧r', 'Rose', '🐧h', 'Hugo')}      </ul>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">L'édition est clôturée : ses résultats ne sont plus secrets.</p>
    </section>

    <ul style="{LIST}">
{lrow('#exclusions', '<circle cx="12" cy="12" r="9"/><path d="m5.600 5.600 12.800 12.800"/>', 'Exclusions appliquées au tirage', 'Aucune', True)}{lrow('#journal', '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h6"/>', 'Journal du groupe', "Tout ce qui s'est passé, à la vue de tous")}    </ul>

    <a href="#nouvelle" style="height: 48px; box-sizing: border-box; border: 1px solid #b8483a; border-radius: 6px; color: #8a2f27; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
      <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
      Préparer l'édition suivante
    </a>
  </main>'''
build('Cloturee.dc.html', 'Édition — clôturée', B, 1060)

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['Feter.dc.html'] = {"y": 0, "w": 390, "h": 1180}
b['Cloturee.dc.html'] = {"y": 0, "w": 390, "h": 1060}
seq = [('Main.dc.html', 'Étape 1 · Préparer'), ('ConfirmerTirage.dc.html', 'Étape 1 · Confirmation du tirage'), ('ConfirmerTirageGrand.dc.html', 'Étape 1 · Confirmation, 100 participants'),
       ('Suivi.dc.html', 'Étape 2 · Tirage fait, suivi'), ('Feter.dc.html', 'Étape 3 · Fêter, à clôturer'), ('Cloturee.dc.html', 'Étape 3 · Édition clôturée'),
       ('SelectionEmail.dc.html', 'Envoi · sélection par email'), ('Envoi.dc.html', 'Envoi · une personne')]
for i, (f, title) in enumerate(seq):
    b[f]['x'] = i * 470; b[f]['title'] = title
names = [f for f, _ in seq]
c['order'] = names + [o for o in c['order'] if o not in names]
c['notes']['t-orga']['maxW'] = 3680
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
