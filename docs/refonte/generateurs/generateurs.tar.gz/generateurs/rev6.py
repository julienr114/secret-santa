import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
t = (P/'Envoi.dc.html').read_text()
a = t.index('<div style="margin-top: auto;'); b = t.index('</section>', a)
MAIL = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg>'
def alt(icon, label):
    return f'''<button style="min-height: 68px; padding: 8px 4px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 8px; background: transparent; color: #292524; font-family: inherit; font-size: 13px; font-weight: 600; line-height: 1.2; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px">
          <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{icon}</svg>
          {label}
        </button>'''
bottom = f'''<div style="margin-top: auto; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 2px">
        <button style="width: 100%; min-height: 56px; padding: 6px 12px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 10px">
          {MAIL}
          <span style="display: flex; flex-direction: column; align-items: flex-start">
            <span style="font-size: 17px; font-weight: 700; line-height: 1.2">Renvoyer par email</span>
            <span style="font-size: 13px; font-weight: 500; line-height: 1.2">hugo-demo@example.com</span>
          </span>
        </button>
        <a href="#fiche-hugo" style="align-self: center; min-height: 44px; display: flex; align-items: center; font-size: 14px; font-weight: 700; color: #8a2f27">Ce n'est pas la bonne adresse ? La corriger</a>
      </div>
      <div style="display: flex; flex-direction: column; gap: 8px">
        <h2 style="margin: 0; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">L'email n'arrive pas ? Passe par un autre chemin</h2>
        <div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px">
        {alt('<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.600 13.500 6.800 4M15.400 6.500l-6.800 4"/>', 'Partager')}
        {alt('<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>', 'Copier le message')}
        {alt('<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>', 'Copier le lien seul')}
        </div>
        <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Partager ouvre WhatsApp, SMS… Le lien de Hugo ne change pas : rien de tout ça ne révèle son résultat.</p>
      </div>
    </div>
  '''
t = t[:a] + bottom + t[b:]
CLOCK = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
on = 'style="height: 40px; border: 0; border-radius: 7px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12); color: #292524; font-family: inherit; font-size: 14px; font-weight: 700"'
off = 'style="height: 40px; border: 0; border-radius: 7px; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 600"'
for old, new in [
  ('Panneau Envoyer à Inès', 'Panneau Renvoyer à Hugo'), ('aria-label="Envoyer à Inès"', 'aria-label="Renvoyer à Hugo"'),
  ('Envoyer à Inès</h1>', 'Renvoyer à Hugo</h1>'),
  ('<p style="margin: 0; font-size: 14px; color: #57534e">Encore 3 personnes à prévenir</p>', f'<p style="margin: 0; display: flex; align-items: center; gap: 5px; font-size: 14px; color: #79511d">{CLOCK}Envoyé par email, pas encore consulté</p>'),
  ('>🍭</span>', '>🐧</span>'),
  (f'<button role="radio" aria-checked="true" {on}>Tirage fait</button>', f'<button role="radio" aria-checked="false" {off}>Tirage fait</button>'),
  (f'<button role="radio" aria-checked="false" {off}>Relance</button>', f'<button role="radio" aria-checked="true" {on}>Relance</button>'),
  ('Inès, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :', "Petit rappel Hugo : ton lien t'attend, pense à l'ouvrir. Ton lien :"),
  ('under-the-tree.party/p/aIFR…', 'under-the-tree.party/p/k9Qd…'),
]:
    assert old in t, old
    t = t.replace(old, new)
t = t.replace('height: 844px', 'height: 880px').replace('"height":844', '"height":880')
(P/'Renvoi.dc.html').write_text(t)
c = json.loads((P/'canvas.json').read_text())
c['boards']['Renvoi.dc.html'] = {"x": 8 * 470, "y": 0, "w": 390, "h": 880, "title": "Envoi · renvoyer à quelqu'un"}
c['order'].insert(8, 'Renvoi.dc.html')
c['notes']['t-orga']['maxW'] = 4150
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
