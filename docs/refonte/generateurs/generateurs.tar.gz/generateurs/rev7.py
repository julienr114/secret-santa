import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
EYE = '<path d="M2.500 12S6 5 12 5s9.500 7 9.500 7-3.500 7-9.500 7-9.500-7-9.500-7z"/><circle cx="12" cy="12" r="3"/>'
svg = lambda inner, s=20, sw=2: f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{inner}</svg>'

# ---- Feter ----
t = (P/'Feter.dc.html').read_text()
a = t.index('<button style="width: 100%; height: 48px; border: 0; border-radius: 6px; background: #b8483a')
b = t.index('</p>', t.index('</button>', a)) + 4
new = f'''<div style="display: flex; flex-direction: column; gap: 4px">
        <a href="Devoiler.dc.html" style="height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
          {svg(EYE)}
          Dévoiler les résultats
        </a>
        <button style="width: 100%; height: 44px; border: 0; border-radius: 6px; background: transparent; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 600">Clôturer sans dévoiler</button>
      </div>
      <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e; text-align: center">Pour l'instant, toi seul verras qui a offert à qui.</p>'''
t = t[:a] + new + t[b:]
for old, new in [
  ("La fête est passée : clôture l'édition", "La fête est passée : dévoile les résultats"),
  ("Elle ne sera plus modifiable et servira d'historique : l'an prochain, personne ne retombera sur la même personne.", "C'est facultatif, et définitif : l'édition passe ensuite en lecture seule et sert d'historique pour l'an prochain."),
  ('<title>Édition — étape Fêter, à clôturer</title>', '<title>Édition — étape Fêter, à dévoiler</title>'),
  ('height: 1180px', 'height: 1230px'), ('"height":1180', '"height":1230'),
]:
    assert old in t, old; t = t.replace(old, new)
(P/'Feter.dc.html').write_text(t)

# ---- Suivi: row ----
t = (P/'Suivi.dc.html').read_text()
a = t.index('<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box">\n          <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e')
b = t.index('</li>', a) + 5
new = f'''<li>
          <a href="DevoilerAvant.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: #292524">
            <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
              {svg('<path d="M12 2l2.200 7.800L22 12l-7.800 2.200L12 22l-2.200-7.800L2 12l7.800-2.200z"/>')}
            </span>
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">Dévoiler les résultats</span>
              <span style="font-size: 14px; color: #57534e">Prévu après la fête, le 25 décembre</span>
            </span>
            <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
          </a>
        </li>'''
t = t[:a] + new + t[b:]
assert 'Voir un résultat' in t
t = t.replace('<span style="font-weight: 600; font-size: 16px">Voir un résultat</span>', '<span style="font-weight: 600; font-size: 16px">Voir un seul résultat</span>')
(P/'Suivi.dc.html').write_text(t)

# ---- Cloturee -> Résultats dévoilés ----
t = (P/'Cloturee.dc.html').read_text()
for old, new in [
  ('Édition clôturée</h2>', 'Résultats dévoilés</h2>'),
  ("En lecture seule. Elle sert d'historique pour le tirage de l'an prochain.", "L'édition est en lecture seule. Elle sert d'historique pour le tirage de l'an prochain."),
  ("L'édition est clôturée : ses résultats ne sont plus secrets.", "Pour l'instant, toi seul vois cette liste."),
  ('<title>Édition — clôturée</title>', '<title>Édition — résultats dévoilés</title>'),
]:
    assert old in t, old; t = t.replace(old, new)
(P/'Cloturee.dc.html').write_text(t)

# ---- sheets ----
src = (P/'ConfirmerTirage.dc.html').read_text()
def sheet(name, title, label, inner):
    t = src
    a = t.index('<section aria-label="Lancer le tirage"'); b = t.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="{label}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
{inner}
  </section>'''
    t = t[:a] + sec + t[b:]
    t = t.replace('<title>Confirmation du tirage</title>', f'<title>{title}</title>')
    (P/name).write_text(t)
def li(kind, title, sub_, first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    if kind == 'ok':
        badge = ('#dbe9dd', '#274e34', '<path d="M20 6 9 17l-5-5"/>', 3); bg = ''; tc = '#292524'; sc = '#57534e'
    elif kind == 'warn':
        badge = ('#f9eecb', '#79511d', '<path d="M12 7v6M12 17h.010"/>', 2.6); bg = ' background: #fdf8ea;'; tc = '#66431d'; sc = '#66431d'
    else:
        badge = ('#f1e8d8', '#57534e', EYE, 2); bg = ''; tc = '#292524'; sc = '#57534e'
    return f'''      <li style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px;{bt}{bg}">
        <span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: {badge[0]}; color: {badge[1]}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{badge[3]}" stroke-linecap="round" stroke-linejoin="round">{badge[2]}</svg>
        </span>
        <span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px">
          <span style="font-size: 15px; font-weight: 600; color: {tc}">{title}</span>
          <span style="font-size: 13px; line-height: 1.4; color: {sc}">{sub_}</span>
        </span>
      </li>
'''
H1 = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15"
LOCK = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#57534e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; margin-top: 1px"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'
sheet('Devoiler.dc.html', 'Dévoiler les résultats', 'Dévoiler les résultats', f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1}">Dévoiler les résultats ?</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">Tu vas voir qui a offert à qui.</p>
    </div>
    <ul style="list-style: none; margin: 0; padding: 0; border: 1px solid #dccbad; border-radius: 12px; overflow: hidden">
{li('ok', 'La fête a eu lieu', 'Elle était prévue le 25 décembre.', True)}{li('warn', "Rose n'a pas consulté son résultat", 'Les 4 autres participants l’ont ouvert.')}{li('eye', 'Toi seul verras la liste', 'Les participants ne la voient pas pour l’instant.')}    </ul>
    <div style="display: flex; align-items: flex-start; gap: 10px">
      {LOCK}
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">C'est définitif : l'édition passe en lecture seule, listes de souhaits comprises, et le journal du groupe l'indique.</p>
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <a href="Cloturee.dc.html" style="height: 52px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
        {svg(EYE)}
        Dévoiler les résultats
      </a>
      <a href="Feter.dc.html" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Pas encore</a>
    </div>''')

bullet = lambda s: f'<li style="display: flex; align-items: flex-start; gap: 8px"><span aria-hidden="true" style="width: 6px; height: 6px; margin-top: 8px; border-radius: 50%; background: #961d35; flex-shrink: 0"></span><span>{s}</span></li>'
sheet('DevoilerAvant.dc.html', 'Dévoiler avant la fête', 'Dévoiler avant la fête', f'''    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1}">Dévoiler avant la fête ?</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">La fête est prévue le 25 décembre, dans 40 jours.</p>
    </div>
    <div role="alert" style="border: 2px solid #b3243f; border-radius: 12px; background: #fdf2f4; padding: 14px; display: flex; flex-direction: column; gap: 10px; color: #6b1c2e">
      <p style="margin: 0; display: flex; align-items: center; gap: 8px; font-family: 'Fraunces', Georgia, serif; font-size: 19px; font-weight: 700; line-height: 1.2">
        <svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="M10.300 3.900 1.800 18a2 2 0 0 0 1.700 3h17a2 2 0 0 0 1.700-3L13.700 3.900a2 2 0 0 0-3.400 0zM12 9v4M12 17h.010"/></svg>
        Le secret s'arrête ici, pour de bon
      </p>
      <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; font-size: 14px; line-height: 1.4">
        {bullet('Tu connaîtras tous les résultats avant la fête.')}
        {bullet('Plus personne ne pourra modifier sa liste de souhaits.')}
        {bullet('Le journal l’affichera à tout le groupe.')}
        {bullet('Impossible de revenir en arrière.')}
      </ul>
    </div>
    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="confirm-sentence" style="font-size: 15px; font-weight: 600">Recopie : dévoiler avant la fête</label>
      <input id="confirm-sentence" type="text" placeholder="dévoiler avant la fête" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 8px">
      <a href="Suivi.dc.html" style="height: 52px; border-radius: 6px; background: #2f613f; color: #ffffff; font-size: 17px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Attendre la fête</a>
      <button disabled style="width: 100%; height: 48px; box-sizing: border-box; border: 1px solid #f6c3cc; border-radius: 6px; background: transparent; color: #b3243f; opacity: 0.55; font-family: inherit; font-size: 16px; font-weight: 700">Dévoiler quand même</button>
      <p style="margin: 0; text-align: center; font-size: 13px; color: #57534e">Le bouton s'active une fois la phrase recopiée.</p>
    </div>''')

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['Devoiler.dc.html'] = {"y": 0, "w": 390, "h": 844}
b['DevoilerAvant.dc.html'] = {"y": 0, "w": 390, "h": 844}
b['Feter.dc.html']['h'] = 1230
seq = [('Main.dc.html', None), ('ConfirmerTirage.dc.html', None), ('ConfirmerTirageGrand.dc.html', None), ('Suivi.dc.html', None),
       ('DevoilerAvant.dc.html', 'Étape 2 · Dévoiler avant la fête (forcé)'),
       ('Feter.dc.html', 'Étape 3 · Fêter, à dévoiler'), ('Devoiler.dc.html', 'Étape 3 · Confirmation du dévoilement'),
       ('Cloturee.dc.html', 'Étape 3 · Résultats dévoilés'),
       ('SelectionEmail.dc.html', None), ('Envoi.dc.html', None), ('Renvoi.dc.html', None)]
for i, (f, title) in enumerate(seq):
    b[f]['x'] = i * 470
    if title: b[f]['title'] = title
names = [f for f, _ in seq]
c['order'] = names + [o for o in c['order'] if o not in names]
c['notes']['t-orga']['maxW'] = 11 * 470 - 80
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
