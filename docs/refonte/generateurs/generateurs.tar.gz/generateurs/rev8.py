import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
def rep(name, pairs):
    t = (P/name).read_text()
    for old, new in pairs:
        assert old in t, (name, old); t = t.replace(old, new)
    (P/name).write_text(t)
rep('Feter.dc.html', [
  ("C'est facultatif, et définitif : l'édition passe ensuite en lecture seule et sert d'historique pour l'an prochain.", "C'est facultatif, et définitif. Les listes de souhaits restent modifiables tant que l'édition n'est pas clôturée."),
])
rep('Devoiler.dc.html', [
  ("C'est définitif : l'édition passe en lecture seule, listes de souhaits comprises, et le journal du groupe l'indique.", "C'est définitif, et le journal du groupe l'indique. Les listes de souhaits restent modifiables."),
])
t = (P/'DevoilerAvant.dc.html').read_text()
a = t.index('<li style="display: flex; align-items: flex-start; gap: 8px"><span aria-hidden="true" style="width: 6px; height: 6px; margin-top: 8px; border-radius: 50%; background: #961d35; flex-shrink: 0"></span><span>Plus personne')
b = t.index('</li>', a) + 5
t = t[:a] + t[b:]
(P/'DevoilerAvant.dc.html').write_text(t)
CHEV = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#78716c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
ARCH = '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>'
t = (P/'Cloturee.dc.html').read_text()
old = "L'édition est en lecture seule. Elle sert d'historique pour le tirage de l'an prochain."
assert old in t
t = t.replace(old, "Les listes de souhaits restent modifiables jusqu'à la clôture de l'édition.")
# add "Clôturer l'édition" row at end of the last list
k = t.index("Journal du groupe"); e = t.index('</li>', k) + 5
row = f'''
        <li>
          <a href="#cloturer" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration: none; color: #292524">
            <span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{ARCH}</svg>
            </span>
            <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column">
              <span style="font-weight: 600; font-size: 16px">Clôturer l'édition</span>
              <span style="font-size: 14px; color: #57534e">Fige l'édition et les listes de souhaits</span>
            </span>
            {CHEV}
          </a>
        </li>'''
t = t[:e] + row + t[e:]
t = t.replace('height: 1060px', 'height: 1120px').replace('"height":1060', '"height":1120')
(P/'Cloturee.dc.html').write_text(t)

# ---- Suivi sans date ----
t = (P/'Suivi.dc.html').read_text()
CARD = 'background: #fdf8ea; border-radius: 16px; box-shadow: 0 0 0 1px #ebc762;'
card = f'''<section style="{CARD} padding: 20px; display: flex; flex-direction: column; gap: 12px">
      <div style="display: flex; flex-direction: column; gap: 4px">
        <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 20px; line-height: 1.2; color: #3a240c">Quand a lieu la fête ?</h2>
        <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #66431d">Sans date, pas de compte à rebours pour les participants, et les résultats ne peuvent pas être dévoilés.</p>
      </div>
      <div style="display: flex; flex-direction: column; gap: 6px">
        <label for="party-date" style="font-size: 15px; font-weight: 600; color: #3a240c">Date de la fête</label>
        <div style="display: flex; gap: 8px">
          <input id="party-date" type="text" placeholder="jj/mm/aaaa" style="flex-grow: 1; min-width: 0; height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #94651c; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
          <button style="height: 48px; padding: 0 18px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 16px; font-weight: 700; flex-shrink: 0">Valider</button>
        </div>
      </div>
    </section>

    '''
S = '<section style="display: flex; flex-direction: column; gap: 6px">'
a = t.index(S)
t = t[:a] + card + t[a:]
for old, new in [
  ('Famille Camille · le 25 décembre', 'Famille Camille · date de la fête à préciser'),
  ('Prévu après la fête, le 25 décembre', "Ajoute d'abord la date de la fête"),
  ('<title>Édition tirée — suivi</title>', '<title>Édition tirée — sans date de fête</title>'),
  ('height: 1320px', 'height: 1560px'), ('"height":1320', '"height":1560'),
]:
    assert old in t, old; t = t.replace(old, new)
(P/'SuiviSansDate.dc.html').write_text(t)

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['SuiviSansDate.dc.html'] = {"y": 0, "w": 390, "h": 1560, "title": "Étape 2 · Édition existante sans date de fête"}
b['Cloturee.dc.html']['h'] = 1120
order = c['order']
row = order[:order.index('TirageAttente.dc.html')]
row.insert(row.index('Suivi.dc.html') + 1, 'SuiviSansDate.dc.html')
for i, f in enumerate(row): b[f]['x'] = i * 470
c['order'] = row + order[order.index('TirageAttente.dc.html'):]
c['notes']['t-orga']['maxW'] = len(row) * 470 - 80
# row 2 must clear the tallest board
tall = max(b[f]['h'] for f in row)
y2 = tall + 120 + 300
for f in c['order'][len(row):]: b[f]['y'] = y2
c['notes']['t-tirage']['y'] = y2 - 300
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
print(y2)
