import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
src = (P/'Suivi.dc.html').read_text()
def build(name, title, main, h):
    t = src
    i = t.index('<main'); j = t.index('</main>') + len('</main>')
    t = t[:i] + main + t[j:]
    t = t.replace('<title>Édition tirée — suivi</title>', f'<title>{title}</title>')
    t = t.replace('height: 1320px', f'height: {h}px').replace('"height":1320', f'"height":{h}')
    assert f'height: {h}px' in t
    (P/name).write_text(t)
ic = lambda inner, s=18: f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; margin-top: 1px">{inner}</svg>'
EYE = '<path d="M2.500 12S6 5 12 5s9.500 7 9.500 7-3.500 7-9.500 7-9.500-7-9.500-7z"/><circle cx="12" cy="12" r="3"/>'
def av(e, bg, ring, size=40, fs=18):
    return f'<span aria-hidden="true" style="width: {size}px; height: {size}px; border-radius: 50%; background: {bg}; box-shadow: 0 0 0 1px {ring}; display: flex; align-items: center; justify-content: center; font-size: {fs}px; flex-shrink: 0">{e}</span>'
HUGO = lambda s=40, f=18: av('🐧', '#f6e3ad', '#e6b94a', s, f)
CAM = lambda s=40, f=18: av('🦌', '#ead2e2', '#c493b4', s, f)
H1 = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 30px; line-height: 1.1"
warn = lambda icon, text: f'<li style="display: flex; align-items: flex-start; gap: 10px">{ic(icon)}<span>{text}</span></li>'
FORM = f'''<main style="display: flex; flex-direction: column; gap: 22px; padding: 20px 16px 32px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1}">Voir un seul résultat</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille · Noël 2026</p>
    </div>

    <section style="background: #fdf8ea; border-radius: 16px; box-shadow: 0 0 0 1px #ebc762; padding: 16px; display: flex; flex-direction: column; gap: 10px; color: #66431d">
      <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 19px; line-height: 1.2; color: #3a240c">À n'utiliser qu'en dernier recours</h2>
      <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px; font-size: 14px; line-height: 1.4">
        {warn('<path d="M12 7v6M12 17h.010"/><circle cx="12" cy="12" r="9"/>', "Un désaccord, un doute sur un bug… Tu ne vois qu'un résultat à la fois.")}
        {warn('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h6"/>', "Tout le groupe le saura : c'est inscrit au journal, avec le prénom.")}
        {warn('<path d="M3 3l18 18M10.600 10.600a2 2 0 0 0 2.800 2.800M9.400 5.200A9.500 9.500 0 0 1 12 5c6 0 9.500 7 9.500 7a15 15 0 0 1-2.600 3.500M6.200 6.200A15 15 0 0 0 2.500 12S6 19 12 19a9.400 9.400 0 0 0 4-.900"/>', "Le résultat ne s'affiche qu'ici et disparaît quand tu quittes l'écran.")}
      </ul>
    </section>

    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="who" style="font-size: 15px; font-weight: 600">Le résultat de qui ?</label>
      <button id="who" aria-haspopup="listbox" style="min-height: 56px; box-sizing: border-box; padding: 6px 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 12px; text-align: left">
        {HUGO()}
        <span style="flex-grow: 1">Hugo</span>
        <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#57534e" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      </button>
    </div>

    <div style="display: flex; flex-direction: column; gap: 6px">
      <p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">Ce que le groupe lira dans le journal</p>
      <div style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad">
        <span aria-hidden="true" style="width: 32px; height: 32px; border-radius: 50%; background: #e6b94a; color: #3a240c; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(EYE, 16).replace(' margin-top: 1px', '')}</span>
        <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 600; font-size: 16px; line-height: 1.35">L'organisateur a consulté le résultat de Hugo (accès de dernier recours)</p>
      </div>
    </div>

    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="sentence" style="font-size: 15px; font-weight: 600">Recopie : JE VEUX VOIR LE TIRAGE</label>
      <input id="sentence" type="text" autocomplete="off" style="height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px">
    </div>

    <label style="display: flex; align-items: flex-start; gap: 12px; min-height: 44px; font-size: 15px; line-height: 1.4">
      <input type="checkbox" style="width: 22px; height: 22px; margin: 1px 0 0; accent-color: #b8483a; flex-shrink: 0">
      Je comprends que tout le groupe saura que j'ai regardé
    </label>

    <div style="display: flex; flex-direction: column; gap: 6px">
      <a href="VoirResultatAffiche.dc.html" style="height: 48px; border-radius: 6px; background: #292524; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px">
        {ic(EYE, 20).replace(' margin-top: 1px', '')}
        Voir le résultat de Hugo
      </a>
      <a href="Suivi.dc.html" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Finalement non</a>
    </div>
  </main>'''
build('VoirResultat.dc.html', 'Voir un seul résultat — formulaire', FORM, 1060)

SHOWN = f'''<main style="display: flex; flex-direction: column; gap: 22px; padding: 20px 16px 32px">
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1}">Voir un seul résultat</h1>
      <p style="margin: 0; font-size: 15px; color: #57534e">Famille Camille · Noël 2026</p>
    </div>

    <section aria-live="polite" style="background: #fffdf9; border-radius: 16px; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05); padding: 24px 20px; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">
      <div style="display: flex; align-items: center; gap: 14px">
        {HUGO(64, 28)}
        <svg aria-hidden="true" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#b8483a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        {CAM(64, 28)}
      </div>
      <div style="display: flex; flex-direction: column; gap: 2px">
        <p style="margin: 0; font-size: 15px; color: #57534e">Hugo offre un cadeau à</p>
        <p style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 40px; line-height: 1.05; color: #a43a2f">Camille</p>
      </div>
    </section>

    <div role="status" style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px; border-radius: 12px; background: #fdf8ea; box-shadow: 0 0 0 1px #ebc762; color: #66431d; font-size: 14px; line-height: 1.45">
      {ic(EYE)}
      <span>Ta consultation est inscrite au journal du groupe. Le résultat disparaît quand tu quittes cet écran.</span>
    </div>

    <div style="display: flex; flex-direction: column; gap: 6px">
      <a href="Suivi.dc.html" style="height: 48px; border-radius: 6px; background: #b8483a; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center">Cacher et revenir à l'édition</a>
      <a href="VoirResultat.dc.html" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Voir un autre résultat</a>
    </div>
  </main>'''
build('VoirResultatAffiche.dc.html', 'Voir un seul résultat — affiché', SHOWN, 844)

# link from Suivi row
t = (P/'Suivi.dc.html').read_text()
assert 'href="#voir"' in t
(P/'Suivi.dc.html').write_text(t.replace('href="#voir"', 'href="VoirResultat.dc.html"'))

c = json.loads((P/'canvas.json').read_text())
b = c['boards']
b['VoirResultat.dc.html'] = {"y": 0, "w": 390, "h": 1060, "title": "Étape 2 · Voir un seul résultat"}
b['VoirResultatAffiche.dc.html'] = {"y": 0, "w": 390, "h": 844, "title": "Étape 2 · Résultat affiché à l'organisateur"}
order = c['order']
k = order.index('TirageAttente.dc.html')
row = order[:k]
p = row.index('SuiviSansDate.dc.html') + 1
row[p:p] = ['VoirResultat.dc.html', 'VoirResultatAffiche.dc.html']
for i, f in enumerate(row): b[f]['x'] = i * 470
c['order'] = row + order[k:]
c['notes']['t-orga']['maxW'] = len(row) * 470 - 80
(P/'canvas.json').write_text(json.dumps(c, ensure_ascii=False, indent=2))
