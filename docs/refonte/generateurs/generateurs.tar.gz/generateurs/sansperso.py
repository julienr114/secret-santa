# Une liste sans personne : l'événement, puis les cadeaux (un mariage, une crémaillère, une naissance) — 19 novembre 2026
NO_WRITE=True
import io,contextlib,json
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
src=open('/home/claude/gen/publier.py').read(); exec(src[src.index('GLOBE='):src.index('OLD=re.compile')])  # GLOBE, COPY, MAIL, SM, bar()
W={}
def head(sub,intro,extra=''):
    return f'''<div style="display: flex; flex-direction: column; gap: 10px">
      {tile('💍','prune',72)}
      <h1 style="margin: 4px 0 0; font-family: {F}; font-weight: 700; font-size: 34px; line-height: 1.1">Le mariage de Camille et Hugo</h1><p style="margin: 0; font-size: 15px; line-height: 1.4; color: #57534e">{sub}</p>
      <p style="margin: 0; font-size: 16px; line-height: 1.5">{intro}</p>{extra}
    </div>'''
MOT='Votre présence est le plus beau des cadeaux. Si vous voulez nous gâter, voici quelques idées : cochez ce que vous offrez, et personne n’aura la même.'
def ideas(lines): return f'<ul style="list-style: none; margin: 0; padding: 0">{"".join(lines)}</ul>'
SEP='padding-top: 16px; border-top: 1px solid #dccbad'
# piste B retenue par Julien (19 novembre 2026) : le « Ajouter quelqu'un » habituel, pas de lien « Séparer par personne »
SECB='''<section style="display: flex; flex-direction: column; gap: 10px; padding-top: 16px; border-top: 1px solid #dccbad">
      <h2 style="margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.2">Ajouter quelqu’un</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 8px"><a href="ListePersonne.dc.html" style="height: 44px; box-sizing: border-box; padding: 0 14px; border: 1px dashed #cdb48a; border-radius: 999px; color: #8a2f27; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px"><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>Une personne</a></div>
      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">La liste sera alors rangée par personne. Les idées déjà écrites iront à la première.</p>
    </section>'''
# 1. celui qui tient la liste
W['ListeSansPersonne']=(page(1240,bar(True)+'\n    '+head('Le 12 juin 2027',MOT,'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">6 cadeaux déjà prévus. Toi seul vois les prénoms.<br>Touche un texte pour le modifier.</p>')
  +ideas([tl('taken','Le service à raclette de nos rêves : '+lk('lien'),'Mamie'),tl('free','Un week-end à la mer, en bon cadeau'),
          gline('group','Le robot pâtissier',['Mamie','Tonton'],0,'À plusieurs : Mamie, Tonton','','ListePlusieursLigne.dc.html'),
          tl('taken','Des draps en lin, 160 × 200','Tonton'),tl('free','Une participation au voyage de noces'),ghost('la liste',True).replace('Une idée pour la liste…','Une autre idée…')])
  +SECB,'Listes — une liste sans personne'),1240,'Une liste sans personne : l’événement, puis les cadeaux')
# 2. la même, par son lien
W['ListeSansPersonneVisiteur']=(page(1100,head('Le 12 juin 2027 · la liste de Camille et Hugo',MOT,'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Tu offres 1 cadeau : seuls Camille et Hugo savent que c’est toi.</p>')
  +ideas([dline('taken','Le service à raclette de nos rêves : '+lk('lien')),dline('mine','Un week-end à la mer, en bon cadeau',f'Tu l’offres · seul, sous ton prénom · <span style="{A}; font-weight: 700">Changer</span>','ListeReserver.dc.html'),
          gline('group','Le robot pâtissier',['Mamie','Tonton'],0,'À plusieurs · on cherche encore du monde','join','ListeRejoindre.dc.html'),dline('taken','Des draps en lin, 160 × 200'),dline('free','Une participation au voyage de noces')])
  +f'<a href="ListeHorsListe.dc.html" style="align-self: flex-start; min-height: 44px; display: flex; align-items: center; font-size: 15px; font-weight: 700; {A}">J’offre autre chose</a>','Listes — une liste sans personne, par son lien'),1100,'La même, par son lien')
names=[n for n in json.load(open('/tmp/names.json')) if n!='ListeNouvelleForme.dc.html']
for k,(h,ht,t) in W.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
print(list(W))
