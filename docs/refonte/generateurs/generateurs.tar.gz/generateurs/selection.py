import pathlib, re, shutil
P = pathlib.Path('/home/claude/utt/project')
LINK = 'min-height: 44px; padding: 0; color: #8a2f27; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px; text-decoration: none'
CH = '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
H2 = 'margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e'
def redo(name, who):
    t = (P/f'{name}.dc.html').read_text()
    if 'PersonnaliserMessagePlusieurs' in t: return
    i = t.index('<main'); i = t.index('>', i) + 1
    j = t.index('<section', i)
    msg = f'''
    <div style="display: flex; flex-direction: column; gap: 6px">
      <h2 style="{H2}">Aperçu, pour {who}</h2>
      <div style="align-self: flex-start; max-width: 92%; background: #f1e8d8; border-radius: 16px 16px 16px 4px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.45">
        <p style="margin: 0">{who}, le tirage est fait ! 🎁 Ouvre ton lien pour découvrir à qui tu offres un cadeau :</p>
        <p style="margin: 0; font-weight: 600; color: #8a2f27">under-the-tree.party/p/aIFR…</p>
      </div>
      <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Chacun le reçoit avec son prénom, son lien et dans sa langue.</p>
      <a href="PersonnaliserMessagePlusieurs.dc.html" style="{LINK}; align-self: flex-start; padding-left: 4px">Personnaliser le message{CH}</a>
    </div>

    '''
    t = t[:i] + msg + t[j:]
    # footer: only the button
    f1 = t.index('<footer'); f2 = t.index('</footer>', f1)
    foot = t[f1:f2]
    b1 = foot.index('<button style="width: 100%; height: 52px;'); b2 = foot.index('</button>', b1) + 9
    hint = re.search(r'<p style="margin: 0; text-align: center; font-size: 12px[^>]*>([^<]*)</p>', foot)
    newfoot = foot[:foot.index('>') + 1].replace('display: flex; flex-direction: column; gap: 12px', 'display: flex; flex-direction: column') + '\n    ' + foot[b1:b2] + '\n  '
    t = t[:f1] + newfoot + t[f2:]
    if hint:
        m = t.rindex('</main>')
        t = t[:m] + f'  <p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">{hint.group(1)}</p>\n  ' + t[m:]
    (P/f'{name}.dc.html').write_text(t)
    shutil.copy(P/f'{name}.dc.html', f'/mnt/user-data/outputs/refonte9/{name}.html')
redo('SelectionEmail', 'Inès'); redo('SelectionEmail100', 'Adèle')
