import pathlib, json
P = pathlib.Path('/home/claude/utt/project')
src = (P/'ConfirmerTirage.dc.html').read_text()
H1 = "margin: 0; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 24px; line-height: 1.15"
def sheet(name, title, back, filler, heading, desc, inner, cancel_href):
    t = src
    a = t.index('<section aria-label="Lancer le tirage"'); b = t.index('</section>', a) + len('</section>')
    sec = f'''<section aria-label="{heading}" style="flex-grow: 1; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 18px">
    <span aria-hidden="true" style="align-self: center; width: 44px; height: 5px; border-radius: 999px; background: #dccbad"></span>
    <div style="display: flex; flex-direction: column; gap: 4px">
      <h1 style="{H1}">{heading}</h1>
      <p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">{desc}</p>
    </div>
{inner}
    <div style="margin-top: auto; display: flex; flex-direction: column; gap: 6px">
      <button style="width: 100%; height: 52px; border: 0; border-radius: 6px; background: #b8483a; color: #ffffff; font-family: inherit; font-size: 17px; font-weight: 700">Valider</button>
      <a href="{cancel_href}" style="height: 46px; border-radius: 6px; color: #292524; font-size: 16px; font-weight: 600; text-decoration: none; display: flex; align-items: center; justify-content: center">Annuler</a>
    </div>
  </section>'''
    t = t[:a] + sec + t[b:]
    for old, new in [('<title>Confirmation du tirage</title>', f'<title>{title}</title>'), ('height: 150px', f'height: {filler}px'), ('font-size: 30px; color: #5c554c">Noël 2026', f'font-size: 30px; color: #5c554c">{back}')]:
        assert old in t, old; t = t.replace(old, new)
    (P/name).write_text(t)
def radio(label, sub, on, first=False, name='g'):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    bg = ' background: #fbf3f1;' if on else ''
    s = f'<span style="font-size: 13px; line-height: 1.35; color: #57534e">{sub}</span>' if sub else ''
    return f'''      <label style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 14px; box-sizing: border-box;{bt}{bg}">
        <input type="radio" name="{name}"{' checked' if on else ''} style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0">
        <span style="display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">{label}</span>{s}</span>
      </label>
'''
BOX = 'border: 1px solid #dccbad; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column'
# 1 choix
sheet('PanneauChoix.dc.html', 'Panneau — choisir une valeur', 'Réglages', 190, 'Éviter la même personne', 'Personne n’offre à quelqu’un qu’il a déjà eu ces dernières années.',
 f'''    <div role="radiogroup" aria-label="Éviter la même personne" style="{BOX}">
{radio('Non, peu importe', '', False, True)}{radio('Pas la même que l’an dernier', '', True)}{radio('Pas la même que les 2 dernières années', '', False)}{radio('Pas la même que les 3 dernières années', 'Le tirage devient très contraint dans un petit groupe', False)}    </div>''', 'GroupeReglages.dc.html')
# 2 texte
sheet('PanneauTexte.dc.html', 'Panneau — saisir un texte', 'Réglages', 150, 'Mot ajouté aux messages', 'Ajouté tel quel à chaque message et email envoyé aux participants. Tu peux encore le modifier au moment d’envoyer.',
 f'''    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="note" style="font-size: 15px; font-weight: 600">Ton mot</label>
      <textarea id="note" rows="3" style="box-sizing: border-box; width: 100%; padding: 10px 12px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; line-height: 1.4; resize: none">On ouvre les cadeaux après le dessert !</textarea>
      <p style="margin: 0; display: flex; justify-content: space-between; font-size: 13px; color: #57534e"><span>Envoyé tel quel, quelle que soit la langue.</span><span>39 / 500</span></p>
    </div>
    <fieldset style="margin: 0; padding: 0; border: 0; display: flex; flex-direction: column; gap: 6px">
      <legend style="padding: 0; margin-bottom: 6px; font-size: 15px; font-weight: 600">Où le placer</legend>
      <div style="{BOX}">
{radio('Au-dessus du message', '', False, True, 'pos')}{radio('En dessous du message', '', True, False, 'pos')}      </div>
    </fieldset>''', 'GroupeReglages.dc.html')
# 3 nombre
SBTN = 'width: 52px; height: 52px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: #fffdf9; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0'
sheet('PanneauNombre.dc.html', 'Panneau — régler un nombre', 'Inviter par lien', 330, 'Places restantes', 'Combien de personnes peuvent encore rejoindre le groupe par ce lien.',
 f'''    <div role="group" aria-label="Places restantes" style="display: flex; align-items: center; justify-content: center; gap: 24px">
      <button aria-label="Une place de moins" style="{SBTN}"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M5 12h14"/></svg></button>
      <output aria-live="polite" style="min-width: 72px; text-align: center; font-family: 'Fraunces', Georgia, serif; font-weight: 700; font-size: 52px; line-height: 1">10</output>
      <button aria-label="Une place de plus" style="{SBTN}"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></button>
    </div>
    <p style="margin: 0; text-align: center; font-size: 13px; line-height: 1.4; color: #57534e">Le groupe peut encore accueillir 10 personnes au plus.</p>''', 'GroupeInvitation.dc.html')
# 4 date facultative
CAL = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>'
sheet('PanneauDate.dc.html', 'Panneau — date facultative', 'Inviter par lien', 290, 'Date limite', 'Facultatif. Le lien ne marche plus après ce jour.',
 f'''    <div style="display: flex; flex-direction: column; gap: 6px">
      <label for="until" style="font-size: 15px; font-weight: 600">Date</label>
      <div style="position: relative">
        <input id="until" type="text" value="10/12/2026" style="width: 100%; height: 52px; box-sizing: border-box; padding: 0 48px 0 14px; border: 2px solid #b8483a; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 18px; font-weight: 600">
        <button aria-label="Ouvrir le calendrier" style="position: absolute; right: 4px; top: 4px; width: 44px; height: 44px; border: 0; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0">{CAL}</button>
      </div>
      <p style="margin: 0; font-size: 13px; color: #57534e">Jeudi 10 décembre 2026 · dans 25 jours</p>
    </div>
    <button style="align-self: flex-start; min-height: 44px; padding: 0 4px; border: 0; background: transparent; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 700; text-decoration: underline">Pas de date limite</button>''', 'GroupeInvitation.dc.html')
print('ok')
