import pathlib, json, re
exec(open('/home/claude/gen/etats.py').read().split("# ---------- grands groupes")[0])
OUT.clear()
A = '#e9dcc5'; Bc = '#f1e8d8'
SK = lambda w, h, bg=A, r=8, extra='': f'<span style="display: block; width: {w}; height: {h}px; border-radius: {r}px; background: {bg}; flex-shrink: 0;{extra}"></span>'
DOT = lambda s, bg=A: f'<span style="display: block; width: {s}px; height: {s}px; border-radius: 50%; background: {bg}; flex-shrink: 0"></span>'
CARDS = 'border-radius: 16px; background: #fffdf9; box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05);'
def put(src, name, title, main, h=844):
    t = (P/src).read_text(); i = t.index('<main'); j = t.index('</main>') + 7
    save(name, t[:i] + main + t[j:], title, h)
frise = f'<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); justify-items: center; gap: 8px">' + ''.join(f'<span style="display: flex; flex-direction: column; align-items: center; gap: 8px; width: 100%">{DOT(24)}{SK("60%", 10)}</span>' for _ in range(3)) + '</div>'
lrow_sk = lambda first=False, icon=36: f'<li style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 10px 16px; box-sizing: border-box;{"" if first else " border-top: 1px solid #e9dcc5;"}">{DOT(icon, Bc)}<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 8px">{SK("45%", 14, Bc)}{SK("70%", 10, Bc)}</span></li>'

# la page d'un tirage, côté participant
put('TirageDecouvrir.dc.html', 'ChargementTirage.dc.html', 'Chargement — la page d’un tirage', f'''<main aria-busy="true" aria-label="Chargement" style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    <div style="display: flex; align-items: center; gap: 12px">{DOT(56)}<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 8px">{SK("65%", 26)}{SK("45%", 12)}</span></div>
    {frise}
    <div style="{CARDS} padding: 28px 24px 24px; display: flex; flex-direction: column; align-items: center; gap: 16px">{SK("150px", 104, Bc, 12)}{SK("70%", 22, Bc)}{SK("90%", 12, Bc)}{SK("60%", 12, Bc)}{SK("100%", 48, Bc, 6)}</div>
    <ul style="{LIST}">{lrow_sk(True)}{lrow_sk()}</ul>
  </main>''')

# l'accueil
gcard = f'<div style="{CARDS} padding: 16px; display: flex; flex-direction: column; gap: 12px">{SK("50%", 20, Bc)}{SK("70%", 12, Bc)}<span style="display: flex; gap: 8px">{SK("50%", 44, Bc, 6)}{SK("50%", 44, Bc, 6)}</span></div>'
put('AccueilOrganisateur.dc.html', 'ChargementAccueil.dc.html', 'Chargement — l’accueil', f'''<main aria-busy="true" aria-label="Chargement" style="flex-grow: 1; display: flex; flex-direction: column; gap: 24px; padding: 20px 16px 32px">
    <div style="display: flex; align-items: center; gap: 16px">{DOT(56)}{SK("55%", 30)}</div>
    <div style="{CARDS} padding: 20px; display: flex; flex-direction: column; gap: 14px">{SK("35%", 12, Bc)}{SK("85%", 24, Bc)}{SK("65%", 12, Bc)}{SK("100%", 48, Bc, 6)}</div>
    <div style="display: flex; flex-direction: column; gap: 12px">{SK("30%", 12)}{gcard}{gcard}</div>
  </main>''')

# le journal
ev = lambda w: f'<li style="display: flex; align-items: flex-start; gap: 12px"><span style="width: 40px; display: flex; justify-content: center; flex-shrink: 0">{DOT(32, "#fffdf9")}</span><span style="flex-grow: 1; display: flex; align-items: center; gap: 12px; padding-top: 9px">{SK(w, 14)}<span style="margin-left: auto">{SK("36px", 10)}</span></span></li>'
day = lambda ws: f'<div style="display: flex; flex-direction: column; gap: 14px">{SK("40%", 12)}<ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 18px; position: relative"><span aria-hidden="true" style="position: absolute; left: 19px; top: 8px; bottom: 8px; width: 2px; background: {A}"></span>{"".join(ev(w) for w in ws)}</ul></div>'
put('Journal.dc.html', 'ChargementJournal.dc.html', 'Chargement — le journal', f'''<main aria-busy="true" aria-label="Chargement" style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 20px 16px 32px">
    <div style="display: flex; flex-direction: column; gap: 8px">{SK("70%", 30)}{SK("40%", 14)}</div>
    {SK("100%", 48, Bc, 10)}
    <div style="display: flex; gap: 8px">{SK("110px", 40, Bc, 999)}{SK("130px", 40, Bc, 999)}</div>
    {day(["70%", "55%", "62%"])}
    {day(["48%", "66%"])}
  </main>''')

cv = json.loads((P/'canvas.json').read_text()); B = cv['boards']
names = [('ChargementAccueil', 'Chargement de l’accueil'), ('ChargementTirage', 'Chargement de la page d’un tirage'), ('ChargementJournal', 'Chargement du journal')]
if 'ChargementAccueil.dc.html' not in B:
    # after "Chargement d'une liste" (x=470): shift the rest of the row
    for k, v in B.items():
        if v['page'] == 'divers' and v['y'] == 0 and v['x'] > 470: v['x'] += 470 * 3
    for k, (n, ti) in enumerate(names):
        f = n + '.dc.html'; B[f] = {'x': 470 * (2 + k), 'y': 0, 'w': 390, 'h': 844, 'title': ti, 'page': 'divers'}
        cv['order'].insert(cv['order'].index('ChargementListe.dc.html') + 1 + k, f)
    cv['notes']['t20']['maxW'] = 470 * 10 - 80
(P/'canvas.json').write_text(json.dumps(cv, ensure_ascii=False, indent=2))
print(OUT, sorted((v['x'], k) for k, v in B.items() if v['page'] == 'divers' and v['y'] == 0))
