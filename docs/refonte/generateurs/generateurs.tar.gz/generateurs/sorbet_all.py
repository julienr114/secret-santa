import re,json,os
src=open('/home/claude/gen/styles.py').read(); exec(src[:src.index('boards=[]; pub=[]')])
OUT='/home/claude/s/'
t=dict(TH['Sorbet']); t.update(primary='#d93a2b',primaryDark='#b92d1f',accentText='#c93425',success='#0b7a5b',successText='#0b7a5b',faint='#796987',
  radius={'16px':'28px','6px':'16px','10px':'16px','12px':'18px','8px':'14px','5px':'8px','11px':'14px','7px':'10px','18px':'24px','14px':'18px','20px 20px 0 0':'32px 32px 0 0','16px 16px 16px 4px':'24px 24px 24px 6px'})
t.update(backdrop='#a8959d',backdropText='#6b5661')
# plus de jaune : tout ce qui signale passe au lilas (19 novembre 2026)
t.update(gold='#b993dd',goldSoft='#f1e8fc',goldText='#6a3db3',goldLine='#cbb2ee')
S.update({'a8a29e':'lineStrong','3d2c08':'ink','8f877b':'backdrop','ebc762':'goldLine','d99a1c':'gold','ecd38a':'gold','fbf0cf':'goldSoft','e3d5bb':'line','efe6d6':'soft','f8f1e5':'soft','fbf6ec':'soft','b89a63':'lineStrong','a8916a':'lineStrong','a9cdb2':'success','fbeeea':'accentSoft','e0b4ab':'lineStrong','5b430f':'goldText','1f3d29':'successText'})
T.update({'a8a29e':'faint','3d2c08':'ink','5c554c':'backdropText','5b430f':'goldText','3a240c':'goldText','94651c':'goldText','1f3d29':'successText','a8916a':'faint','b89a63':'faint','ebc762':'gold'})
import sys,hashlib; sys.path.insert(0,'/home/claude/gen')
from ill_sorbet import ILL
# les six couleurs d'avatar, refaites pour Sorbet : (fond, bord) d'origine -> (fond, bord)
AV={('f3d3cc','e09e92'):('ffd0c8','ff8478'),('cfe2d3','8db898'):('c6f1e2','4fcaa3'),('f6e3ad','e6b94a'):('ffe9a8','f4b82e'),('ecdfc6','cdb48a'):('ffe2c4','f2a65a'),('d6e6ef','94bbd0'):('cfe6ff','6eb0f2'),('ead2e2','c493b4'):('e6d6f8','b993dd')}
def avatars(h):
    def one(m):
        st=m.group(0)
        if 'border-radius: 50%' not in st: return st
        for (bg,bd),(nbg,nbd) in AV.items():
            if 'background: #'+bg in st: st=st.replace('#'+bg,'#'+nbg).replace('#'+bd,'#'+nbd)
        return st
    return re.sub(r'style="[^"]*"',one,h)
def illus(n,h):
    if n=='Connexion.dc.html':
        m=re.search(r'<svg role="img" aria-label="Under the Tree" width="64" height="64".*?</svg>',h,flags=re.S); assert m
        h=h.replace(m.group(0),ILL['connexion']); h=h.replace('width: 390px; height: 844px','width: 390px; height: 944px',1)
    if n=='AccueilVide.dc.html':
        a='<h2 style="margin: 0; font-family: \'Outfit\', system-ui, sans-serif; font-weight: 600; font-size: 22px; line-height: 1.2">Aucun tirage pour l\'instant</h2>'; assert h.count(a)==1
        h=h.replace(a,'<div style="display: flex; justify-content: center; margin: -4px 0 4px">'+ILL['vide']+'</div>'+a)
    if n=='TirageDecouvrir.dc.html':
        m=re.search(r'<svg aria-hidden="true" width="184" height="128".*?</svg>',h,flags=re.S); assert m
        h=h.replace(m.group(0),ILL['enveloppe']); h=h.replace('width: 390px; height: 1006px','width: 390px; height: 1030px',1)
    return h
def journal(h):
    # l'entrée « le palmarès est arrivé » : vert plein, texte blanc
    def pal(m):
        b=m.group(0)
        if 'background: #f0f6f1; box-shadow: 0 0 0 1px #a9cdb2' not in b: return b
        return b.replace('background: #f0f6f1; box-shadow: 0 0 0 1px #a9cdb2','background: #0b7a5b; box-shadow: 0 3px 0 #075a43').replace('color: #223f2d','color: #ffffff').replace('color: #274e34','color: #ffffff').replace('color: #57534e','color: #d3f3e8')
    h=re.sub(r'<li style="display: flex; align-items: flex-start; gap: 12px">.*?</li>',pal,h,flags=re.S)
    # les alertes du journal : lilas au lieu du jaune
    if '#3a240c' in h:
        h=h.replace('background: #e6b94a; color: #3a240c','background: #7b4bc4; color: #ffffff')
        for x,y in [('#3a240c','#3b2463'),('background: #fdf8ea','background: #f1e8fc'),('#ebc762','#cbb2ee'),('#66431d','#6a3db3'),('#94651c','#6a3db3')]: h=h.replace(x,y)
    # le bandeau « Le tirage n'est plus secret » : même lilas
    if 'plus secret' in h:
        for x,y in [('background: #fbf0cf; color: #5b430f','background: #f1e8fc; color: #3b2463'),('background: #e6b94a; color: #3d2c08','background: #7b4bc4; color: #ffffff'),('color: #5b430f','color: #6a3db3')]: h=h.replace(x,y)
    return h
import illus2
def essais(n,h):
    # illustrations dans le style des anciennes (19 novembre 2026), posées avant l'habillage : elles en prennent les couleurs
    import illus
    def top(h,title,kind,w=184):
        k=h.index(title); a=h.rfind('<section',0,k); b=h.index('>',a)+1
        return h[:b]+'<div style="display: flex; justify-content: center; margin: -4px 0 0">'+illus2.svg(kind,w)+'</div>'+h[b:]
    def taller(h,d):
        m=re.search(r'width: 390px; height: (\d+)px',h); return h.replace(m.group(0),f'width: 390px; height: {int(m.group(1))+d}px',1)
    m=re.search(r'<svg role="img" aria-label="Under the Tree" width="64" height="64".*?</svg>',h,flags=re.S) if n.startswith('Connexion') else None
    if m:
        h=taller(h.replace(m.group(0),illus2.svg('connexion',200,'Under the Tree')),76)
    if n in ('Rejoindre.dc.html','RejoindreConnecte.dc.html'):
        m=re.search(r'<svg role="img" aria-label="Under the Tree" width="56" height="56".*?</svg>',h,flags=re.S); assert m,n
        h=h.replace(m.group(0),illus2.svg('wreath',168,'Under the Tree'))
    if n=='AccueilVide.dc.html':
        m=re.search(r'<h2 [^>]*>Aucun tirage pour l\'instant</h2>',h); assert m
        h=h.replace(m.group(0),'<div style="display: flex; justify-content: center; margin: -4px 0 4px">'+illus2.svg('empty',184)+'</div>'+m.group(0))
    if n=='ListesVide.dc.html':
        m=re.search(r'<span aria-hidden="true" style="width: 72px; height: 72px; border-radius: 18px;[^>]*>🎁</span>',h); assert m
        h=h.replace(m.group(0),illus2.svg('liste',184))
    if n=='PistesVide.dc.html': h=taller(top(h,'Six questions, trente secondes','tag'),150)
    if n=='AccueilDemandeAcceptee.dc.html': h=taller(top(h,'Ta demande est acceptée','accepted'),116)
    if n=='PreparerVide.dc.html': h=taller(top(h,'Ajoute les participants','guests'),150)
    if n=='RejoindreFait.dc.html':
        m=re.search(r'<span aria-hidden="true" style="width: 64px; height: 64px; border-radius: 50%; background: #dbe9dd;.*?</span>',h,flags=re.S); assert m
        h=h.replace(m.group(0),illus2.svg('welcome',184))
    # pas d'image dans les emails (Julien, 19 novembre 2026)
    return h
# --- Icônes en autocollant dégradé (Julien, 19 novembre 2026) ---------------------------------------------
# Personne : rond, dégradé doux (blanc en haut à gauche, pastel, teinte soutenue en bas à droite), liseré blanc, ombre portée.
# Liste : carré arrondi, dégradé du pastel à la teinte soutenue, même liseré, même ombre, penché de 3 degrés.
TON={'corail':('#ffd0c8','#ff8478'),'menthe':('#c6f1e2','#4fcaa3'),'citron':('#ffe9a8','#f4b82e'),'peche':('#ffe2c4','#f2a65a'),'ciel':('#cfe6ff','#6eb0f2'),'lilas':('#e6d6f8','#b993dd')}
RING={bg:rg for bg,rg in TON.values()}
# les six couleurs de liste d'origine -> les six teintes
LTON={'274e34':'menthe','a43a2f':'corail','e6b94a':'citron','5b3a55':'lilas','2c4a63':'ciel','b89565':'peche'}
def lisere(sz): return max(2,round(sz*0.05))
def ombre(sz): return '0 3px 8px rgba(90, 40, 60, 0.22)' if sz>=36 else '0 2px 5px rgba(90, 40, 60, 0.2)'
def tuiles(h):
    # avant l'habillage : on marque les tuiles de liste, l'habillage ne doit pas toucher à leurs coins ni à leurs couleurs
    LCX='|'.join(LTON)
    h=re.sub(r'width: (\d+)px; height: \1px; border-radius: \d+px; background: #(%s); box-shadow: 0 2px 6px rgba\(60, 30, 10, 0\.18\)'%LCX,
             lambda m:f'width: {m.group(1)}px; height: {m.group(1)}px; @@TILE:{m.group(1)}:{LTON[m.group(2)]}@@',h)
    # le panneau d'icône : la tuile choisie et les pastilles de couleur, à plat (dégradé seul)
    h=re.sub(r'(width: (\d+)px; height: \2px;(?: padding: 0; border: 0;)?) border-radius: \d+px; background: #(%s); box-shadow: (none|0 0 0 2px #fffdf9, 0 0 0 4px #b8483a)'%LCX,
             lambda m:f'{m.group(1)} @@SW:{m.group(2)}:{LTON[m.group(3)]}@@; box-shadow: {m.group(4)}',h)
    return h
def autocollant(h):
    def tl(m):
        sz=int(m.group(2)); bg,rg=TON[m.group(3)]; g=f'border-radius: {round(sz*0.3)}px; background: linear-gradient(150deg, {bg} 0%, {rg} 110%)'
        return g if m.group(1)=='SW' else g+f'; box-shadow: 0 0 0 {lisere(sz)}px #ffffff, {ombre(sz)}; transform: rotate(-3deg)'
    h=re.sub(r'@@(TILE|SW):(\d+):(\w+)@@',tl,h)
    def one(m):
        st=m.group(1)
        if 'border-radius: 50%' not in st: return m.group(0)
        b=re.search(r'background: (#[0-9a-f]{6})\b',st); w=re.search(r'(?:^|; )width: (\d+)px',st)
        if not b or b.group(1) not in RING or not w or int(w.group(1))<20: return m.group(0)
        bg=b.group(1); rg=RING[bg]; sz=int(w.group(1))
        st=st.replace('background: '+bg,f'background: linear-gradient(150deg, #ffffff 0%, {bg} 42%, {rg} 135%)',1)
        a=f'box-shadow: 0 0 0 1px {rg}'
        if 'font-size' not in st and sz<=32: st=st.replace(a,'box-shadow: none',1)                     # une pastille de couleur : le dégradé seul
        elif a+',' in st: st=st.replace(a+',',f'box-shadow: 0 0 0 {lisere(sz)}px #ffffff,',1)           # une ombre est déjà là
        else: st=st.replace(a,f'box-shadow: 0 0 0 {lisere(sz)}px #ffffff, {ombre(sz)}',1)
        st=re.sub(r'(0 0 0 2px #ffffff), 0 0 0 3px %s'%rg,r'\1',st)                                  # les icônes qui se chevauchent : le liseré seul
        return 'style="'+st+'"'
    return re.sub(r'style="([^"]*)"',one,h)
OLD={n:hashlib.sha256(open(OUT+n,'rb').read()).hexdigest() for n in os.listdir(OUT)}
names=json.load(open('/tmp/names.json'))
skip={'ManuelValider.dc.html'}
pub=[]
# une « capture d'écran » : une maquette déjà habillée, réduite dans un cadre de téléphone (page de présentation)
# l'inclinaison : R = en perspective, tournée vers la droite ; L = vers la gauche ; r, l = à peine penchée ; 0 = droite
TILT={'R':('rotateY(16deg) rotateX(5deg) rotateZ(-2deg)',-20),'L':('rotateY(-16deg) rotateX(5deg) rotateZ(2deg)',20),'r':('rotate(3deg)',0),'l':('rotate(-3deg)',0),'0':('none',0)}
def capture(m):
    # un vrai téléphone plutôt qu'un cadre : tranche en métal, boutons, bord noir, barre d'état, encoche, reflet, ombres en couches
    n,w,hh=m.group(1),int(m.group(2)),int(m.group(3)); tr,dx=TILT[m.group(4) or '0']; src=open(OUT+n+'.dc.html').read()
    body=src[src.index('<div style="width: 390px'):src.index('</x-dc>')]; k=w/390
    bg=re.search(r'background: (#[0-9a-f]{6})',body).group(1); r_,g_,b_=(int(bg[i:i+2],16) for i in (1,3,5)); dark=(0.299*r_+0.587*g_+0.114*b_)<128
    ink='#ffffff' if dark else '#2b1b3d'
    R=round(w*0.19); sb=round(w*0.118); fs=round(w*0.05)
    bars=f'<svg width="{round(fs*1.5)}" height="{fs}" viewBox="0 0 18 12" fill="{ink}"><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="5" y="5.500" width="3" height="6.500" rx="1"/><rect x="10" y="3" width="3" height="9" rx="1"/><rect x="15" y="0" width="3" height="12" rx="1"/></svg>'
    batt=f'<svg width="{round(fs*2.1)}" height="{fs}" viewBox="0 0 26 12" fill="none"><rect x="0.500" y="0.500" width="22" height="11" rx="3.500" stroke="{ink}" opacity="0.45"/><rect x="2" y="2" width="16" height="8" rx="2" fill="{ink}"/><rect x="23.500" y="4" width="2" height="4" rx="1" fill="{ink}" opacity="0.45"/></svg>'
    btn=lambda side,top,h: f'<span style="position: absolute; {side}: -3px; top: {top}%; width: 3px; height: {h}px; border-radius: {"2px 0 0 2px" if side=="left" else "0 2px 2px 0"}; background: linear-gradient({"90deg" if side=="left" else "270deg"}, #1a1026, #5d4b70)"></span>'
    return (f'<div aria-hidden="true" inert style="flex-shrink: 0; perspective: 1600px">'
      f'<div style="position: relative; padding: 3px; border-radius: {R}px; background: linear-gradient(140deg, #8c7a9e 0%, #3a2a4c 22%, #1a1026 55%, #6d5b80 100%); '
      f'box-shadow: 0 1px 2px rgba(43, 27, 61, 0.3), {dx}px 34px 60px -18px rgba(90, 40, 60, 0.45), {dx//2}px 14px 24px -10px rgba(43, 27, 61, 0.28); transform: {tr}">'
      f'{btn("left",17,round(w*0.07))}{btn("left",26,round(w*0.12))}{btn("left",37,round(w*0.12))}{btn("right",29,round(w*0.19))}'
      f'<div style="padding: {round(w*0.028)}px; border-radius: {R-3}px; background: #0d0614; box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08)">'
      f'<div style="position: relative; width: {w}px; height: {hh}px; overflow: hidden; border-radius: {R-3-round(w*0.028)}px; background: {bg}">'
      f'<div style="height: {sb}px; box-sizing: border-box; padding: {round(sb*0.18)}px {round(w*0.085)}px 0; display: flex; align-items: center; justify-content: space-between; font-family: \'DM Sans\', system-ui, sans-serif; font-weight: 700; font-size: {fs}px; line-height: 1; color: {ink}"><span>9:41</span><span style="display: flex; align-items: center; gap: {round(fs*0.4)}px">{bars}{batt}</span></div>'
      f'<div style="width: 390px; transform: scale({k:.4f}); transform-origin: 0 0; text-align: left">{body}</div>'
      f'<span style="position: absolute; top: {round(sb*0.26)}px; left: 50%; width: {round(w*0.3)}px; height: {round(sb*0.62)}px; margin-left: -{round(w*0.15)}px; border-radius: 999px; background: #0d0614"></span>'
      f'<span style="position: absolute; bottom: {round(w*0.025)}px; left: 50%; width: {round(w*0.36)}px; height: {max(3,round(w*0.016))}px; margin-left: -{round(w*0.18)}px; border-radius: 999px; background: {ink}; opacity: 0.35"></span>'
      f'<span style="position: absolute; inset: 0; background: linear-gradient(118deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.05) 22%, rgba(255, 255, 255, 0) 38%); pointer-events: none"></span>'
      f'</div></div></div></div>')
names=[n for n in names if '@@SHOT' not in open(PJ+n).read()]+[n for n in names if '@@SHOT' in open(PJ+n).read()]
for n in names:
    if n in skip: continue
    h=open(PJ+n).read()
    if 'Outfit' in h: raise SystemExit('déjà habillé : '+n)
    if n.startswith('DevineStory'):
        # le palmarès en images garde ses couleurs foncées d'origine (Julien, 19 novembre 2026) : seules les polices, les coins et les avatars changent
        _S,_T=dict(S),dict(T); S.clear(); T.clear()
        h=avatars(h)
        # ... puis rendues compatibles avec Sorbet en restant foncées : corail foncé, menthe foncée, violet, prune nuit
        for x,y in [('#e6b94a','#5f37a6'),('#3d2c08','#ffffff'),('#66431d','#e6d6f8'),('#a43a2f','#b92d1f'),('#8a2f27','#c93425'),('#b8483a','#d93a2b'),
                    ('#274e34','#085a43'),('#cfe2d3','#c6f1e2'),('#5b3a55','#2b1b3d'),('#ead2e2','#e6d6f8'),('#fffdf9','#ffffff'),('#f7f2e9','#fff6f1'),
                    ('#dccbad','#ffd9cc'),('#292524','#2b1b3d'),('#57534e','#6b5a7a')]: h=h.replace(x,y)
        h=autocollant(skin(h,t)); S.update(_S); T.update(_T)
    else:
        h=autocollant(skin(tuiles(avatars(journal(essais(n,h)))),t).replace('rgba(60, 30, 10,','rgba(90, 40, 60,'))
    h=re.sub(r'@@SHOT:(\w+):(\d+):(\d+)(?::(\w))?@@',capture,h)
    h=re.sub(r'@@ILL:(\w+):(\d+):([^@]*)@@',lambda m:illus2.svg(m.group(1),int(m.group(2)),m.group(3) or None),h)  # les essais gardent leurs couleurs d'origine
    open(OUT+n,'w').write(h)
    if OLD.get(n)!=hashlib.sha256(h.encode()).hexdigest(): pub.append({"as":"project/"+n,"path":OUT+n})
json.dump(pub,open('/tmp/sorbet_pub.json','w'),separators=(',',':'))
print(len(pub), sum(1 for p in pub if 'Fraunces' in open(p['path']).read()))
