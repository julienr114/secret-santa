# Rayon du cadre pour décocher : 16 -> 10 ; essai : pastilles calées sous la case (Julien, 20 novembre 2026). Après decocher2.py.
import json,re
PJ='/home/claude/utt/project/'
f=PJ+'ListeDecocher.dc.html'; s=open(f,encoding='utf-8').read()
s=s.replace('padding: 0 10px 2px; border-radius: 16px; background: #f1e8d8','padding: 0 10px 2px; border-radius: 10px; background: #f1e8d8')
assert 'border-radius: 10px; background: #f1e8d8">' in s
open(f,'w',encoding='utf-8').write(s)
# l'essai « pastilles sous la case » a été refusé (Julien, 20 novembre 2026) : elles restent alignées au texte.
print('ok')
