# Lot 35 : ne plus recevoir d'emails, signaler, l'adresse bloquée vue par celui qui la saisit (19 novembre 2026)
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
S={}
ML='color: #1d4ed8; text-decoration: underline'
def mail(subject,to,body,title,h=844):
    s=HEAD+f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #ffffff; color: #1c1917; font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; display: flex; flex-direction: column">
  <div style="padding: 16px; border-bottom: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 4px">
    <h1 style="margin: 0; font-size: 18px; font-weight: 700; line-height: 1.3">{subject}</h1>
    <p style="margin: 0; font-size: 13px; color: #57534e">Under the Tree · à {to}</p>
  </div>
  <div style="padding: 16px; display: flex; flex-direction: column; gap: 14px; font-size: 16px; line-height: 1.5">
    {body}
  </div>
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
def scr(h,main,title,back=True):
    hd=header('FR') if back else header('FR').replace('<div><button aria-label="Retour"','<div><button hidden aria-label="Retour"')
    s=HEAD+f'''<div style="width: 390px; height: {h}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {hd}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 16px 16px 24px">
    {main}
  </main>
</div>
'''+TAIL
    return re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',s)
H1=f'margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1'
P='margin: 0; font-size: 16px; line-height: 1.5'
SM='margin: 0; font-size: 14px; line-height: 1.45; color: #57534e'
NOTE='border-radius: 12px; background: #fbf0cf; border: 1px solid #ebc762; color: #5b430f; padding: 14px; display: flex; align-items: flex-start; gap: 12px; font-size: 15px; line-height: 1.45'
NOMAIL=ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7M4 20 20 4"/>',20)
# 1. le premier email à une adresse saisie par quelqu'un d'autre, et son pied
S['StopEmail']=(mail('Camille t’a ajouté à un Secret Santa','hugo-demo@example.com',f'''<p style="margin: 0">Bonjour Hugo,</p>
    <p style="margin: 0">Camille organise le Secret Santa « Famille Camille · Noël 2026 » et t’y a ajouté.</p>
    <p style="margin: 0"><a href="#" style="{ML}; font-weight: 700">Ouvrir mon lien personnel</a></p>
    <p style="margin: 0">Ce que l’application sait de toi : ton prénom et cette adresse, donnés par Camille. Rien d’autre.</p>
    <p style="margin: 0">Under the Tree</p>
    <div style="margin-top: 8px; padding-top: 14px; border-top: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 8px; font-size: 13px; line-height: 1.45; color: #57534e">
      <p style="margin: 0">Tu ne veux pas de ces emails ? <a href="StopDemande.dc.html" style="{ML}">Ne plus recevoir d’emails d’Under the Tree</a></p>
      <p style="margin: 0">Tu ne connais pas Camille ? <a href="#" style="{ML}">Signaler cet envoi</a></p>
      <p style="margin: 0"><a href="#" style="{ML}">Ce que l’application fait de tes données</a></p>
    </div>''','Emails — le premier email, et son pied'),844,'Le premier email à une adresse, et le pied de chaque email')
# 2. le lien ouvre une page qui demande : un robot de messagerie qui suit les liens ne bloque rien
S['StopDemande']=(scr(844,f'''<div style="display: flex; flex-direction: column; gap: 10px">
      <h1 style="{H1}">Ne plus recevoir d’emails ?</h1>
      <p style="{P}">Under the Tree n’écrira plus à <strong>hugo-demo@example.com</strong>, quel que soit le groupe, la liste ou la personne qui t’ajoute.</p>
    </div>
    <ul style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; font-size: 15px; line-height: 1.45; color: #57534e">
      <li>Tes liens personnels continuent de marcher : on peut te les envoyer autrement.</li>
      <li>Ceux qui saisissent ton adresse verront que tu as demandé à ne plus recevoir d’emails. Ils ne sauront ni quand ni pourquoi.</li>
      <li>Une seule exception : l’email de connexion, quand tu le demandes toi-même.</li>
    </ul>
    <div style="display: flex; flex-direction: column; gap: 10px"><a href="StopConfirme.dc.html" style="{BTN}">Oui, ne plus m’écrire</a><a href="#" style="{BTN2}">Non, je garde les emails</a></div>
    <p style="{SM}; text-align: center"><a href="#" style="{A}">Ce que l’application fait de tes données</a></p>''','Emails — ne plus recevoir d’emails, la question',back=False),844,'Le lien du pied d’email : la question')
S['StopConfirme']=(scr(844,f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; padding-top: 24px">
      <span aria-hidden="true" style="width: 64px; height: 64px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center">{ic('<path d="m5 12 5 5 9-10"/>',30,2.6)}</span>
      <h1 style="{H1}">C’est noté</h1>
      <p style="{P}">Under the Tree n’écrira plus à <strong>hugo-demo@example.com</strong>.</p>
      <p style="{SM}">Tu changes d’avis ? Reviens sur cette page par le lien de n’importe quel ancien email.</p>
    </div>
    <a href="StopDemande.dc.html" style="{BTN2}">Annuler : je veux bien les emails</a>''','Emails — ne plus recevoir d’emails, c’est noté',back=False),844,'Après « Oui, ne plus m’écrire »')
# 3. celui qui saisit une adresse bloquée
FIELD='height: 48px; box-sizing: border-box; padding: 0 12px; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px'
S['StopSaisie']=(scr(844,f'''<div style="display: flex; align-items: center; gap: 14px">{av('Hugo',56)}<div style="display: flex; flex-direction: column; gap: 2px"><h1 style="{H1}">Hugo</h1><p style="{SM}">Famille Camille</p></div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="font-size: 15px; font-weight: 600">Adresse email</label><input id="e" type="email" value="hugo-demo@example.com" style="{FIELD}"></div>
    <div role="status" style="{NOTE}"><span aria-hidden="true" style="display: flex; flex-shrink: 0; margin-top: 1px">{NOMAIL}</span><span><strong>La personne qui a cette adresse a demandé à ne plus recevoir d’emails d’Under the Tree.</strong> Tu peux garder l’adresse, mais aucun email ne lui partira. Envoie-lui son lien autrement.</span></div>
    <a href="#" style="{BTN2}">{SHARE}Partager son lien</a>''','Emails — une adresse qui ne reçoit pas d’emails, à la saisie'),844,'Celui qui saisit une adresse bloquée le voit')
def prow(n,sub,right,top=True): return f'<li style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}">{av(n,40)}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="font-size: 14px; color: #57534e">{sub}</span></span>{right}</li>'
CB='<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 5px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; background: #b8483a; color: #ffffff">'+CHECK+'</span>'
SH=f'<a href="#" style="{A}; font-size: 14px; font-weight: 700; flex-shrink: 0">Partager</a>'
S['StopEnvoi']=(scr(900,f'''<div style="display: flex; flex-direction: column; gap: 6px"><h1 style="{H1}">Envoyer par email</h1><p style="{SM}">Famille Camille · Noël 2026</p></div>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Recevront l’email · 3</h2><ul style="{UL}">{prow('Léo','leo-demo@example.com',CB,False)}{prow('Zoé','zoe-demo@example.com',CB)}{prow('Tonton','tonton-demo@example.com',CB)}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">À prévenir autrement · 2</h2><ul style="{UL}">{prow('Mamie','Pas d’adresse',SH,False)}{prow('Hugo','A demandé à ne plus recevoir d’emails',SH)}</ul></section>
    <a href="#" style="{BTN}; margin-top: auto">Envoyer à 3 personnes</a>''','Emails — l’envoi groupé et une adresse bloquée'),900,'L’envoi groupé range l’adresse bloquée avec ceux qui n’ont pas d’adresse')
names=json.load(open('/tmp/names.json'))
for k,(h,ht,t) in S.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    open(PJ+k+'.dc.html','w').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w'))
json.dump([(k,ht,t) for k,(h,ht,t) in S.items()],open('/tmp/stop_boards.json','w'),ensure_ascii=False)
print(list(S))
