import re,json
PJ='/home/claude/utt/project/'
SCREENS=[('Accueil','L’accueil'),('TirageDecouvrir','La page d’un tirage, enveloppe à ouvrir'),('TirageResultat','La page d’un tirage, enveloppe ouverte'),('Suivi','La gestion d’un tirage'),('Groupe','L’accueil d’un groupe'),('DevinePaires','Le jeu « Devine qui »')]
TH={
'Givre':dict(label='Givre · clair et net',fonts='family=Plus+Jakarta+Sans:wght@400;500;600;700;800',display="'Plus Jakarta Sans', system-ui, sans-serif",body="'Plus Jakarta Sans', system-ui, sans-serif",
  ink='#0f172a',muted='#475569',faint='#64748b',accentText='#c2333a',onAccent='#ffffff',successText='#116149',goldText='#7a4d00',
  page='#f4f6f8',card='#ffffff',soft='#eef1f4',line='#e3e7ec',lineStrong='#cbd2da',primary='#e5484d',primaryDark='#c2333a',accentSoft='#fde8e8',success='#1a7f5a',successSoft='#e3f4ec',gold='#f5b83d',goldSoft='#fdf1d3',dark='#0f172a',
  radius={'16px':'20px','6px':'12px','10px':'12px','12px':'14px'},shadow='0 1px 2px rgba(15, 23, 42, 0.06), 0 8px 24px rgba(15, 23, 42, 0.06)'),
'Nuit':dict(label='Nuit de Noël · sombre et doré',fonts='family=Sora:wght@400;600;700&family=Inter:wght@400;500;600;700',display="'Sora', system-ui, sans-serif",body="'Inter', system-ui, sans-serif",
  ink='#f4f1ea',muted='#a9b4c0',faint='#8593a1',accentText='#f0c866',onAccent='#1a1408',successText='#6fd0a1',goldText='#f0c866',
  page='#0f1419',card='#1a2129',soft='#232c36',line='#2c3743',lineStrong='#3d4a59',primary='#e5b84c',primaryDark='#c99a2e',accentSoft='#3a2f14',success='#3fae7c',successSoft='#173326',gold='#e5b84c',goldSoft='#3a2f14',dark='#f4f1ea',
  radius={'16px':'18px','6px':'10px','10px':'10px','12px':'12px'},shadow='0 0 0 1px #2c3743'),
'Sorbet':dict(label='Sorbet · rond et joyeux',fonts='family=Outfit:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700',display="'Outfit', system-ui, sans-serif",body="'DM Sans', system-ui, sans-serif",
  ink='#2b1b3d',muted='#6b5a7a',faint='#8a7a98',accentText='#d93a2b',onAccent='#ffffff',successText='#0b7a5b',goldText='#7a5200',
  page='#fff6f1',card='#ffffff',soft='#ffeae1',line='#ffd9cc',lineStrong='#f5b8a5',primary='#ff5c4d',primaryDark='#d93a2b',accentSoft='#ffe3de',success='#12a37a',successSoft='#dcf7ee',gold='#ffc94a',goldSoft='#fff1c9',dark='#2b1b3d',
  radius={'16px':'28px','6px':'16px','10px':'16px','12px':'18px'},shadow='0 3px 0 #ffd9cc, 0 0 0 1.5px #ffd9cc'),
'Papier':dict(label='Papier · éditorial, noir et blanc',fonts='family=Newsreader:opsz,wght@6..72,500;6..72,600;6..72,700&family=Inter:wght@400;500;600;700',display="'Newsreader', Georgia, serif",body="'Inter', system-ui, sans-serif",
  ink='#111111',muted='#555555',faint='#777777',accentText='#c8321e',onAccent='#ffffff',successText='#1f6b45',goldText='#6b4e00',
  page='#ffffff',card='#ffffff',soft='#f4f4f2',line='#e4e4e0',lineStrong='#bdbdb7',primary='#111111',primaryDark='#000000',accentSoft='#f6e6e2',success='#1f6b45',successSoft='#e6f1ea',gold='#e9c46a',goldSoft='#faf1d6',dark='#111111',
  radius={'16px':'4px','6px':'2px','10px':'4px','12px':'4px'},shadow='0 0 0 1px #d6d6d0'),
'Sapin':dict(label='Sapin · vert profond, moderne',fonts='family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Inter:wght@400;500;600;700',display="'Bricolage Grotesque', system-ui, sans-serif",body="'Inter', system-ui, sans-serif",
  ink='#14251b',muted='#4a5d50',faint='#6b7d70',accentText='#166534',onAccent='#ffffff',successText='#0f766e',goldText='#6f4e00',
  page='#f3f5f0',card='#ffffff',soft='#e8eee6',line='#d9e2d6',lineStrong='#b3c4b0',primary='#166534',primaryDark='#114d28',accentSoft='#dcefe1',success='#0f766e',successSoft='#d5f1ee',gold='#e9b949',goldSoft='#fbefcf',dark='#14251b',
  radius={'16px':'16px','6px':'10px','10px':'12px','12px':'12px'},shadow='0 1px 2px rgba(20, 37, 27, 0.06), 0 6px 18px rgba(20, 37, 27, 0.06)'),
}
T={'292524':'ink','3c1e0a':'ink','57534e':'muted','78716c':'faint','cdb48a':'faint','dccbad':'faint','a43a2f':'accentText','8a2f27':'accentText','b8483a':'accentText','702a24':'accentText','ffffff':'onAccent','fffdf9':'onAccent','2f613f':'successText','274e34':'successText','223f2d':'successText','79511d':'goldText','66431d':'goldText','e6b94a':'gold'}
S={'f7f2e9':'page','fffdf9':'card','ffffff':'card','f1e8d8':'soft','efe3cd':'soft','efe4cf':'soft','f8f1e3':'soft','ecdfc6':'soft','e9dcc5':'line','dccbad':'line','e2d2b4':'line','d9c7a6':'line','cdb48a':'lineStrong','b8483a':'primary','a43a2f':'primary','e09e92':'primary','8a2f27':'primaryDark','702a24':'primaryDark','f6e2dd':'accentSoft','fbf3f1':'accentSoft','f3d3cc':'accentSoft','2f613f':'success','274e34':'success','223f2d':'success','8db898':'success','dbe9dd':'successSoft','f0f6f1':'successSoft','cfe2d3':'successSoft','e6b94a':'gold','d9a93a':'gold','d9a62e':'gold','f6e3ad':'goldSoft','f9eecb':'goldSoft','fdf8ea':'goldSoft','292524':'dark','3c1e0a':'dark','57534e':'muted','78716c':'faint','79511d':'goldText','66431d':'goldText'}
HEX=re.compile(r'#([0-9a-fA-F]{6})\b')
SH='0 1px 2px rgba(60, 30, 10, 0.08), 0 0 0 1px rgba(0, 0, 0, 0.05)'
TEXTP={'color','fill','stroke','caret-color','text-decoration-color'}
def skin(html,t):
    html=html.replace(SH,'@@SHADOW@@')
    def col(m,mp): 
        k=m.group(1).lower(); return t[mp[k]] if k in mp else m.group(0)
    def decl(m):
        prop,val=m.group(1),m.group(2)
        if prop=='border-radius':
            v=val.strip(); return f'{prop}: {t["radius"].get(v,v)}'
        mp=T if prop in TEXTP else S
        return prop+':'+HEX.sub(lambda x:col(x,mp),val)
    html=re.sub(r'\b(color|fill|stroke|caret-color|text-decoration-color|background|background-color|border|border-top|border-bottom|border-left|border-right|border-color|box-shadow|accent-color|outline|border-radius)\s*:([^;"{}]+)',decl,html)
    html=re.sub(r'\b(fill|stroke|stop-color)="#([0-9a-fA-F]{6})"',lambda m:f'{m.group(1)}="{t[S[m.group(2).lower()]] if m.group(2).lower() in S else "#"+m.group(2)}"',html)
    html=html.replace('@@SHADOW@@',t['shadow'])
    html=html.replace("'Fraunces', Georgia, serif",t['display']).replace("'Nunito', system-ui, sans-serif",t['body'])
    html=re.sub(r'family=Fraunces[^"]*?(?=&amp;display|&display)',t['fonts'].replace('&','&amp;') if '&amp;display' in html else t['fonts'],html)
    return html
boards=[]; pub=[]
y=0
for si,(k,sl) in enumerate(SCREENS):
    src=open(PJ+k+'.dc.html').read()
    h=int(re.search(r'<div style="width: 390px; height: (\d+)px',src).group(1))
    cols=[('Actuel','Aujourd’hui',src)]+[(n,t['label'],skin(src,t)) for n,t in TH.items()]
    for ci,(n,lab,html) in enumerate(cols):
        name=f'Style{n}{k}'
        html=re.sub(r'<title>[^<]*</title>',f'<title>{lab} — {sl}</title>',html,count=1)
        open(PJ+name+'.dc.html','w').write(html)
        boards.append((name,ci*470,y,h,lab)); pub.append({"as":f"project/{name}.dc.html","path":f"{PJ}{name}.dc.html"})
    y+=h+420
json.dump(pub,open('/tmp/spub.json','w'))
b=''.join(f'"{n}.dc.html": {json.dumps({"x":x,"y":yy,"w":390,"h":h,"title":lab,"page":"styles"},ensure_ascii=False)},\n    ' for n,x,yy,h,lab in boards)
o=''.join(f'"{n}.dc.html",\n    ' for n,*_ in boards)
notes=''; no=''; yy=0
for si,(k,sl) in enumerate(SCREENS):
    h=[bb for bb in boards if bb[0]=='StyleActuel'+k][0][3]
    notes+=f'"y{si}": {json.dumps({"kind":"title1","maxW":2740,"page":"styles","text":sl,"w":240,"x":0,"y":yy-300},ensure_ascii=False)},\n    '; no+=f'"y{si}",\n    '; yy+=h+420
edits=[{"old_text":'"PistesQuestion.dc.html": {',"new_text":b+'"PistesQuestion.dc.html": {'},{"old_text":'"order": [\n    ',"new_text":'"order": [\n    '+o},{"old_text":'"notes": {\n    ',"new_text":'"notes": {\n    '+notes},{"old_text":'"noteOrder": [\n    ',"new_text":'"noteOrder": [\n    '+no},{"old_text":'{\n      "id": "divers",',"new_text":'{\n      "id": "styles",\n      "name": "Pistes de style"\n    },\n    {\n      "id": "divers",'}]
json.dump(edits,open('/tmp/sedits.json','w'),ensure_ascii=False)
print(len(boards))
