import pathlib, json, re
src = open('/home/claude/gen/etats.py').read()
head_ = src.split("# ---------- grands groupes ----------")[0]
exec(head_)
CLK = ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 14, 2.2)
OKI = '<span style="color: #2f613f; display: flex">' + ic('<path d="M20 6 9 17l-5-5"/>', 14, 2.5) + '</span>'
RESEND = lambda n: f'<button aria-label="Renvoyer le lien de {n}" style="width: 44px; height: 44px; box-sizing: border-box; border: 1px solid #dccbad; border-radius: 50%; background: transparent; color: #57534e; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{ic("<path d=\'M22 2 11 13M22 2l-7 20-4-9-9-4z\'/>", 18)}</button>'
def lrow2(n, e, c, sub, trail, col='#57534e', first=False):
    bt = '' if first else ' border-top: 1px solid #e9dcc5;'
    return f'''        <li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{bt}">
          {bav(e, c)}
          <span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{n}</span><span style="display: flex; align-items: center; gap: 5px; font-size: 13px; color: {col}">{sub}</span></span>
          {trail}
        </li>
'''
A = [('Adèle', '🎅', 'brick'), ('Agathe', '🍪', 'kraft'), ('Albane', '⛄', 'frost')]
B = [('Basile', '🦊', 'pine'), ('Camille', '🦌', 'plum'), ('Clément', '🧤', 'mustard')]
C = [('Alexis', '🧣', 'plum'), ('Ambre', '🌰', 'mustard')]
body = ''.join(lrow2(n, e, c, DASH + 'Pas encore envoyé', SENDB(n), first=(i == 0)) for i, (n, e, c) in enumerate(A)) + foldrow(61, DASH + 'Pas encore envoyé') \
     + ''.join(lrow2(n, e, c, CLK + 'Envoyé, pas encore consulté', RESEND(n), '#79511d') for n, e, c in B) + foldrow(18, '<span style="color: #79511d; display: flex; align-items: center; gap: 5px">' + CLK + 'Envoyé, pas encore consulté</span>') \
     + ''.join(lrow2(n, e, c, OKI + 'Résultat consulté', RESEND(n)) for n, e, c in C) + foldrow(13, OKI + 'Résultat consulté', False)
t = (P/'Suivi.dc.html').read_text()
a, b = cut_section(t, '>5 participants</h2>')
t2 = t[:a] + lsec('100 participants', body, 'Une seule liste, dans l’ordre habituel. Une ligne « Voir les N autres » déplie la suite d’une série, sur place.') + t[b:]
for old, new in [('line-height: 1; color: #8a2f27">3</dd>', 'line-height: 1; color: #8a2f27">64</dd>'), ('line-height: 1; color: #79511d">1</dd>', 'line-height: 1; color: #79511d">21</dd>'), ('line-height: 1; color: #274e34">1</dd>', 'line-height: 1; color: #274e34">15</dd>'), ('Famille Camille</p>', 'Comité d’entreprise</p>'), ('Prévenir par email', 'Prévenir les 64 par email')]:
    assert old in t2, old; t2 = t2.replace(old, new)
save('Suivi100.dc.html', t2, 'Tirage fait — 100 participants', 1830)
print(OUT)
