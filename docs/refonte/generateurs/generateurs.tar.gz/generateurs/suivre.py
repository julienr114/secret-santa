# Suivre une liste qui n'est pas la mienne, ou une seule personne d'une liste (19 novembre 2026). Part de ListeVisiteurMes (V2).
import re,json
PJ='/home/claude/utt/project/'
h=open(PJ+'ListeVisiteurMes.dc.html').read()
def bell(on): return f'<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="{"currentColor" if on else "none"}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0"/></svg>'
SUIVIS={'Léo'}
def person(m):
    name=m.group(2); on=name in SUIVIS
    btn=(f'<span style="flex-grow: 1"></span><button aria-pressed="{"true" if on else "false"}" aria-label="{"Ne plus suivre" if on else "Suivre"} {name}" '
         f'style="width: 44px; height: 44px; margin-right: -10px; border: 0; background: transparent; color: {"#8a2f27" if on else "#78716c"}; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{bell(on)}</button>')
    return m.group(1)+btn
h,n=re.subn(r'(<div style="min-width: 0; display: flex; flex-direction: column; gap: 2px">\s*<h2 [^>]*>([^<]+)</h2>\s*<p [^>]*>.*?</p>\s*</div>)',person,h,flags=re.S)
assert n>=2,n
a='seule Camille sait que c’est toi.</p>'; assert h.count(a)==1
h=h.replace(a,a+f'<p style="margin: 0; display: flex; align-items: center; gap: 8px; font-size: 14px; line-height: 1.45; color: #57534e"><span style="display: flex; color: #8a2f27">{bell(True)}</span><span>Tu es prévenu des nouvelles idées pour Léo. <a href="#" style="color: #8a2f27; text-decoration: underline; font-weight: 700">Suivre toute la liste</a></span></p>')
m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+48
h=h.replace(m.group(0),f'width: 390px; height: {H}px',1)
h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,h)
h=re.sub(r'<title>[^<]*</title>','<title>Listes — suivre une liste, ou une personne</title>',h,count=1)
open(PJ+'ListeSuivre.dc.html','w').write(h)
names=json.load(open('/tmp/names.json'))
if 'ListeSuivre.dc.html' not in names: names.append('ListeSuivre.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print(n,H)
