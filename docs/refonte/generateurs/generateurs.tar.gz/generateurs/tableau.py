# L'administration et le tableau de bord, fusionnés, et un onglet « Admin » dans la barre du bas pour le super-admin (19 novembre 2026). Chiffres d'exemple.
import io,contextlib,json
NO_WRITE=True
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/listes.py').read())
H=1920
SM='margin: 0; font-size: 14px; line-height: 1.45; color: #57534e'
def seg(items,on):
    return '<div role="tablist" style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 10px; background: #f1e8d8">'+''.join(f'<button role="tab" aria-selected="{"true" if i==on else "false"}" style="height: 40px; border: 0; border-radius: 7px; background: {"#fffdf9" if i==on else "transparent"};{" box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12);" if i==on else ""} color: {"#292524" if i==on else "#57534e"}; font-family: inherit; font-size: 15px; font-weight: {"700" if i==on else "600"}">{t}</button>' for i,t in enumerate(items))+'</div>'
def num(v,l,d=''): return f'<div style="{CARD}; padding: 14px 16px; display: flex; flex-direction: column; gap: 2px"><span style="font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">{v}</span><span style="font-size: 14px; font-weight: 600">{l}</span>'+(f'<span style="font-size: 13px; color: #57534e">{d}</span>' if d else '')+'</div>'
def gauge(l,v,mx,txt,warn=False):
    pct=round(100*v/mx); c='#b8483a' if warn else '#2f613f'
    return f'<div style="display: flex; flex-direction: column; gap: 6px"><div style="display: flex; justify-content: space-between; gap: 12px; font-size: 15px"><span style="font-weight: 600">{l}</span><span style="color: #57534e">{txt}</span></div><div role="img" aria-label="{l} : {pct} % du plafond" style="height: 8px; border-radius: 999px; background: #e9dcc5; overflow: hidden"><span style="display: block; width: {pct}%; height: 100%; border-radius: 999px; background: {c}"></span></div></div>'
def line(t,v,top=True,alert=False): return f'<li style="display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 52px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} font-size: 16px"><span>{t}</span><span style="font-weight: 700; color: #292524; display: flex; align-items: center; gap: 6px">{pill(v) if alert else v}<span style="color: #78716c; display: flex">{CHEV}</span></span></li>'
OK=f'<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{CHECK}</span>'
def health(t,d,top=True): return f'<li style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}">{OK}<span style="display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span></li>'
def tab(href,label,icon,on,n=0):
    # une pastille intégrée : le nombre de choses à traiter, sur l'onglet
    b=(f'<span aria-hidden="true" style="position: absolute; top: -5px; right: -11px; min-width: 18px; height: 18px; padding: 0 5px; box-sizing: border-box; border-radius: 999px; background: #b8483a; color: #ffffff; box-shadow: 0 0 0 2px #fffdf9; font-size: 11px; font-weight: 700; line-height: 1; display: flex; align-items: center; justify-content: center">{n}</span>' if n else '')
    sr=f'<span style="position: absolute; width: 1px; height: 1px; overflow: hidden">, {n} à traiter</span>' if n else ''
    return f'<a href="{href}" {"aria-current=\"page\" " if on else ""}style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: {"#8a2f27" if on else "#57534e"}; font-size: 12px; font-weight: {"700" if on else "600"}"><span style="position: relative; display: flex">{icon}{b}</span>{label}{sr}</a>'
def pill(n): return f'<span style="min-width: 22px; height: 22px; padding: 0 7px; box-sizing: border-box; border-radius: 999px; background: #b8483a; color: #ffffff; font-size: 12px; font-weight: 700; display: flex; align-items: center; justify-content: center">{n}</span>'
NAV3=('<nav aria-label="Sections" style="margin-top: auto; flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad">'
  +tab('Accueil.dc.html','Tirages',ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',22),False)
  +tab('ListesAccueil.dc.html','Listes',ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',22),False)
  +tab('Admin.dc.html','Admin',ic('<path d="M12 3 4 6v6c0 4.500 3.400 8 8 9 4.600-1 8-4.500 8-9V6z"/><path d="m9 12 2 2 4-4"/>',22),True,4)+'</nav>')
BURGER='<button aria-label="Menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; color: #292524; display: flex; align-items: center; justify-content: center; padding: 0"><svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>'
def link(t,d,icon,top=True): return f'<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{icon}</span><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
# Ce qui attend une décision passe en premier, avec des pastilles (Julien, 19 novembre 2026)
def todo(t,d,n,href,top=True): return f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 16px">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span>{pill(n)}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
def sw(on,label):
    return (f'<span role="switch" aria-checked="{"true" if on else "false"}" aria-label="{label}" style="width: 48px; height: 28px; border-radius: 999px; background: {"#b8483a" if on else "#d6d3d1"}; position: relative; flex-shrink: 0">'
            f'<span style="position: absolute; top: 3px; left: {23 if on else 3}px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25)"></span></span>')
def urg(t,d,top=True): return f'<li style="display: flex; align-items: center; gap: 12px; min-height: 64px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">{t}</span><span style="font-size: 14px; color: #57534e">{d}</span></span>{sw(False,t)}</li>'
DEM=f'''<section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; display: flex; align-items: center; gap: 8px">À traiter {pill(4)}</h2>
      <ul style="{UL}">{todo('Demandes de groupe','Léa Martin · le 14 novembre',1,'AdminDemande.dc.html',False)}{todo('Demandes de participants','Bureau 3e · 45 demandés',1,'AdminDemandeParticipants.dc.html')}{todo('Signalements','Le plus récent : il y a 2 h',2,'AdminSignalements.dc.html')}</ul>
      <p style="{SM}">Quand tout est traité, ce bloc dit « Rien à traiter » et l’onglet n’a plus de pastille.</p>
    </section>'''
URG=f'''<section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">En cas d’urgence</h2>
      <ul style="{UL}">{urg('Suspendre les emails','Plus aucun email ne part, sauf les liens de connexion',False)}{urg('Suspendre les inscriptions','Ni nouveau compte, ni nouveau groupe')}</ul>
      <p style="{SM}">Les emails se suspendent tout seuls quand la dépense du mois atteint son plafond.</p>
    </section>'''
# Refait le 19 novembre 2026 (Julien) : les chiffres en premier, cliquables ; le gros chiffre est le total depuis toujours,
# la ligne dessous suit la période choisie. Les demandes sont fusionnées avec « À surveiller ».
def tile(v,l,d,href): return f'<a href="{href}" style="{CARD}; padding: 14px 12px 14px 16px; display: flex; align-items: center; gap: 4px; text-decoration: none; color: #292524"><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">{v}</span><span style="font-size: 14px; font-weight: 700">{l}</span><span style="font-size: 13px; color: #57534e">{d}</span></span><span style="color: #78716c; display: flex; flex-shrink: 0">{CHEV}</span></a>'
def watch(t,d,v,href='#',top=True,n=0):
    r=pill(n) if n else f'<span style="font-weight: 700">{v}</span>'
    sub=f'<span style="font-size: 14px; color: #57534e">{d}</span>' if d else ''
    return f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: {64 if d else 52}px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""} text-decoration: none; color: #292524"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-weight: {700 if n else 400}; font-size: 16px">{t}</span>{sub}</span>{r}<span style="color: #78716c; display: flex">{CHEV}</span></a></li>'
main=f'''<div style="display: flex; flex-direction: column; gap: 6px"><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">Administration</h1></div>
    <section style="display: flex; flex-direction: column; gap: 10px"><h2 style="{H2}">Qui s’en sert</h2>
      <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">{tile('148','comptes','+12 · 61 actifs','AdminComptes.dc.html')}{tile('23','groupes','+3 · 9 tirages en cours','AdminGroupes.dc.html')}{tile('41','listes','+9 · 27 partagées','#')}{tile('1 284','emails envoyés','+212','#')}</div>
      {seg(['7 jours','30 jours','12 mois'],0)}
      <p style="{SM}">Le grand chiffre compte depuis le début. La ligne dessous, les 7 derniers jours.</p>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}; display: flex; align-items: center; gap: 8px">À traiter et à surveiller {pill(4)}</h2>
      <ul style="{UL}">{watch('Demandes','Un groupe de plus, plus de participants','','AdminDemandes.dc.html',False,2)}{watch('Signalements','Le plus récent : il y a 2 h','','AdminSignalements.dc.html',True,2)}{watch('Demandes refusées pour débit, aujourd’hui','','14')}{watch('Connexions échouées, aujourd’hui','','3')}{watch('Adresses qui ont refusé les emails','','5')}{watch('Emails rejetés','','1')}{watch('Erreurs du serveur','','0')}</ul>
      <p style="{SM}">Une pastille : quelque chose attend ta décision. Un chiffre : à regarder de temps en temps.</p>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Les plafonds</h2>
      <div style="{CARD}; padding: 16px; display: flex; flex-direction: column; gap: 16px">{gauge('Emails, aujourd’hui',62,100,'62 sur 100')}{gauge('Emails, ce mois',2460,3000,'2 460 sur 3 000',True)}{gauge('Requêtes, aujourd’hui',8400,100000,'8 400 sur 100 000')}{gauge('Dépense, ce mois',5.4,9,'5,40 $ sur 9 $')}<p style="{SM}">À 70 % d’un plafond, tu es prévenu.</p></div>
    </section>
    {URG}
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Ce qui tourne tout seul</h2>
      <ul style="{UL}">{health('Résumé du matin','Passé aujourd’hui à 8 h 02 · 34 emails',False)}{health('Rappels avant la fête','Passé aujourd’hui à 9 h 00 · 2 groupes')}{health('Version en ligne','1b5d6f5 · déployée hier à 22 h 14')}</ul>
    </section>
    <section style="display: flex; flex-direction: column; gap: 8px"><h2 style="{H2}">Outils</h2>
      <ul style="{UL}">{link('Guide de style','Outil du développeur',ic('<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/>',18),False)}</ul>
    </section>'''
s=HEAD+f'''<div style="width: 390px; height: {H}px; box-sizing: border-box; background: #f7f2e9; color: #292524; font-family: 'Nunito', system-ui, sans-serif; display: flex; flex-direction: column">
  {header(BURGER).replace('<div><button aria-label="Retour" style="','<div><button aria-label="Retour" tabindex="-1" style="visibility: hidden; ')}
  <main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 24px">
    {main}
  </main>
  {NAV3}
</div>
'''+TAIL
s=re.sub(r'<title>[^<]*</title>','<title>Administration — l’accueil du super-admin, avec son tableau de bord</title>',s)
s=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%H,s)
open(PJ+'Admin.dc.html','w').write(s)
# L'administration n'est plus dans l'accueil des tirages ni dans le menu : un troisième onglet, avec sa pastille, sur tous les écrans du super-admin (Julien, 19 novembre 2026)
def nav3(on): return ('<nav aria-label="Sections" style="margin-top: auto; flex-shrink: 0; display: flex; background: #fffdf9; border-top: 1px solid #dccbad">'
  +tab('Accueil.dc.html','Tirages',ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/>',22),on==0)
  +tab('ListesAccueil.dc.html','Listes',ic('<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',22),on==1)
  +tab('Admin.dc.html','Admin',ic('<path d="M12 3 4 6v6c0 4.500 3.400 8 8 9 4.600-1 8-4.500 8-9V6z"/><path d="m9 12 2 2 4-4"/>',22),on==2,4)+'</nav>')
t=open(PJ+'ListesAccueil.dc.html').read()
m=re.search(r'<nav aria-label="Sections".*?</nav>',t,re.S); assert m
t=t.replace(m.group(0),nav3(1))
t=re.sub(r'<title>[^<]*</title>','<title>Administration — l’onglet « Admin » et sa pastille, sur les écrans d’un super-admin</title>',t,count=1)
open(PJ+'AdminOnglet.dc.html','w').write(t)
names=json.load(open('/tmp/names.json'))
names=[n for n in names if n not in('AdminAcces.dc.html','AdminAccesMenu.dc.html')]+(['AdminOnglet.dc.html'] if 'AdminOnglet.dc.html' not in names else [])
names=[n for n in names if n!='AdminTableau.dc.html']; json.dump(names,open('/tmp/names.json','w'))
print(len(s))
