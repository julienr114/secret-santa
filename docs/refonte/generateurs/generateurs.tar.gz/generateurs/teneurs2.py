# Tenir une liste à plusieurs : deux niveaux, des proches proposés, et la page d'invitation (proposition du 19 novembre 2026, soir)
import io,contextlib,json
NO_WRITE=True
src=open('/home/claude/gen/garde2.py').read()
with contextlib.redirect_stdout(io.StringIO()): exec(src.split("# ---------- Lot 39 : signaler")[0])
BTNN='height: 48px; box-sizing: border-box; border: 1px solid #a8a29e; border-radius: 6px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 16px; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 8px'
DOWN=ic('<path d="m6 9 6 6 6-6"/>',16,2.4)
M={}
def lvl(t): return f'<button style="height: 36px; padding: 0 8px 0 12px; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 4px; flex-shrink: 0">{t}<span style="display: flex; color: #78716c">{DOWN}</span></button>'
def hrow(n,sub,right,top=True,mail=False):
    a=av(n,40) if not mail else f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic("<rect x=\'3\' y=\'5\' width=\'18\' height=\'14\' rx=\'2\'/><path d=\'m3 7 9 7 9-7\'/>".replace(chr(39),chr(34)),18)}</span>'
    return f'<li style="display: flex; align-items: center; gap: 12px; min-height: 68px; padding: 8px 16px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}">{a}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 700; font-size: 16px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{n}</span><span style="font-size: 14px; color: #57534e">{sub}</span></span>{right}</li>'
def chip(n,on=False): return f'<button aria-pressed="{"true" if on else "false"}" style="height: 44px; padding: 0 14px 0 6px; border: {"2px solid #b8483a" if on else "1px solid #dccbad"}; border-radius: 999px; background: {"#f6e2dd" if on else "#fffdf9"}; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px">{av(n,32)}{n}</button>'
def rad2(t,d,on=False,top=True):
    dot='<span style="width: 10px; height: 10px; border-radius: 50%; background: #b8483a"></span>' if on else ''
    return f'<label style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; box-sizing: border-box;{" border-top: 1px solid #e9dcc5;" if top else ""}"><span role="radio" aria-checked="{"true" if on else "false"}" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 50%; border: 2px solid {"#b8483a" if on else "#a8a29e"}; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px">{dot}</span><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 700">{t}</span><span style="font-size: 14px; line-height: 1.4; color: #57534e">{d}</span></span></label>'
# Inviter : la rangée de pastilles (les proches reliés, puis « Quelqu'un d'autre »), choisie par Julien le 19 novembre 2026 contre la « ligne à écrire ».
# Dans la liste : l'invitation en attente dit jusqu'à quand elle vaut ; expirée, elle se renvoie ; refusée, elle s'efface.
def other(on=False): return f'<button aria-pressed="{"true" if on else "false"}" style="height: 44px; box-sizing: border-box; padding: 0 14px; border: {"2px solid #b8483a" if on else "1px dashed #cdb48a"}; border-radius: 999px; background: {"#f6e2dd" if on else "transparent"}; color: #8a2f27; font-family: inherit; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px">{PLUS}Quelqu’un d’autre</button>'
def small(t): return f'<button style="height: 36px; padding: 0 12px; border: 1px solid #dccbad; border-radius: 999px; background: #fffdf9; color: #292524; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">{t}</button>'
GREY=lambda r: r.replace('<span style="font-weight: 700; font-size: 16px; overflow: hidden','<span style="font-weight: 700; font-size: 16px; color: #78716c; overflow: hidden',1)
def rows(etats=False):
    r=hrow('Camille','C’est toi',tag('Gère la liste'),False)+hrow('Hugo','Là en ce moment',lvl('Aide à écrire'))+hrow('mamie-demo@example.com','Invitée le 18 novembre · valable jusqu’au 25',lvl('Aide à écrire'),True,True)
    if etats: r+=GREY(hrow('paul-demo@example.com','<span style="color: #8a2f27; font-weight: 700">Invitation expirée</span> · le 12 novembre',small('Renvoyer'),True,True))+GREY(hrow('Papi','<span style="color: #8a2f27; font-weight: 700">A refusé</span> · le 19 novembre',small('Effacer')))
    return r
HEADT=f'<div style="display: flex; flex-direction: column; gap: 6px"><p style="{SM}">Listes · Noël 2026</p><h1 style="{H1}">Ceux qui tiennent la liste</h1></div>'
def teneurs(adresse):
    chips=chip('Tonton',not adresse)+chip('Inès')+other(adresse)
    champ=f"""<div style="display: flex; flex-direction: column; gap: 6px"><label for="e" style="font-size: 15px; font-weight: 600">Son adresse email</label><input id="e" type="email" value="lea-demo@example.com" style="{FIELD}">{who('Elle sert à lui envoyer l’invitation. Il verra que c’est toi qui l’invites.')}</div>""" if adresse else ''
    return f"""{HEADT}
    <ul style="{UL}">{rows(not adresse)}</ul>
    <section style="display: flex; flex-direction: column; gap: 12px; padding-top: 16px; border-top: 1px solid #dccbad">
      <h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Inviter quelqu’un</h2>
      <div style="display: flex; flex-wrap: wrap; gap: 8px">{chips}</div>
      {champ}
      <div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 15px; font-weight: 600">Ce qu’il pourra faire</span>
        <div role="radiogroup" aria-label="Niveau" style="{RGS}">{rad2('Aider à écrire','Ajoute et corrige les idées de tout le monde, et voit qui offre quoi. Ne peut ni partager la liste, ni inviter, ni la supprimer.',True,False)}{rad2('Gérer la liste','Tout, comme toi : en plus, partager le lien, inviter ou retirer quelqu’un, supprimer la liste.')}</div></div>
      <a href="ListeInvitation.dc.html" style="{BTN}">{"Envoyer l’invitation" if adresse else "Inviter Tonton"}</a>
      <p style="{SM}">Il reçoit un email, et peut refuser. L’invitation vaut 7 jours.</p>
    </section>"""
M['ListeTeneurs']=(scr(1180,teneurs(False),'Listes — ceux qui tiennent la liste : inviter un proche, et les invitations en attente, expirée, refusée'),1180,'Tenir la liste à plusieurs : inviter d’une pastille ; en attente, expirée, refusée')
M['ListeTeneursAdresse']=(scr(1100,teneurs(True),'Listes — ceux qui tiennent la liste : inviter par une adresse'),1100,'« Quelqu’un d’autre » : le champ d’adresse n’apparaît qu’alors')
def mrow(t,d,on=False,top=True,red=False):
    ck=f'<span style="display: flex; color: #b8483a; flex-shrink: 0">{ic(CK0,18,2.6)}</span>' if on else '<span style="width: 18px; flex-shrink: 0"></span>'
    dd=f'<span style="font-size: 13px; line-height: 1.4; color: #57534e">{d}</span>' if d else ''
    return f'<a role="menuitem" href="#" style="display: flex; align-items: flex-start; gap: 10px; padding: 12px 14px;{" border-top: 1px solid #f1e8d8;" if top else ""} text-decoration: none; color: {"#8a2f27" if red else "#292524"}">{ck}<span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 700">{t}</span>{dd}</span></a>'
CK0='<path d="m5 12 5 5 9-10"/>'
MENU=(f'<div style="position: relative; flex-shrink: 0">{lvl("Aide à écrire")}<div role="menu" style="position: absolute; top: 42px; right: 0; z-index: 3; width: 300px; border-radius: 16px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad, 0 12px 28px rgba(41, 37, 36, 0.18); display: flex; flex-direction: column">'
      +mrow('Aide à écrire','Écrit les idées et voit qui offre quoi.',True,False)+mrow('Gère la liste','En plus : partager, inviter, supprimer la liste.')+mrow('Retirer Hugo','',False,True,True)+'</div></div>')
M['ListeTeneursNiveau']=(scr(844,f'''{HEADT}
    <ul style="{UL}">{hrow('Camille','C’est toi',tag('Gère la liste'),False)}{hrow('Hugo','Là en ce moment',MENU)}{hrow('mamie-demo@example.com','Invitée le 18 novembre · valable jusqu’au 25',lvl('Aide à écrire'),True,True)}</ul>''','Listes — ceux qui tiennent la liste : le niveau d’une personne'),844,'Le niveau d’une personne : deux choix expliqués, et « Retirer »')
CK='<path d="m5 12 5 5 9-10"/>'; XX='<path d="M6 6l12 12M18 6 6 18"/>'
YES=f'<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #dbe9dd; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px">{ic(CK,14,3)}</span>'
NOI=f'<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 50%; background: #f6e2dd; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px">{ic(XX,12,3)}</span>'
def li(i,t): return f'<li style="display: flex; align-items: flex-start; gap: 10px; font-size: 15px; line-height: 1.45">{i}<span>{t}</span></li>'
LS='list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px'
def inv(compte):
    # avec un compte, la page s'adresse à la personne : son icône et son prénom (Julien, 19 novembre 2026)
    QUI=(f'<p style="margin: 0; display: flex; align-items: center; gap: 8px; padding: 4px 14px 4px 4px; border-radius: 999px; background: #fffdf9; box-shadow: 0 0 0 1px #dccbad; font-size: 15px; font-weight: 700">{av("Tonton",32)}Tonton, Camille t’invite</p>' if compte else f'<p style="{SM}">Camille t’invite</p>')
    top=f'''<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; padding-top: 8px">{tile('🎄','sapin',72)}
      {QUI}<h1 style="{H1}">Tenir la liste « Noël 2026 » avec elle</h1></div>
    <ul style="{LS}">{li(YES,'Tu ajoutes et corriges les idées de cadeaux de tout le monde.')}{li(YES,'Tu vois qui offre quoi.')}{li(NOI,'Partager la liste, inviter quelqu’un, la supprimer : ça reste à Camille.')}</ul>'''
    if compte:
        mid=f'''<div style="display: flex; flex-direction: column; gap: 10px"><a href="ListeTeneur.dc.html" style="{BTN}">Accepter l’invitation</a><a href="#" style="{BTNN}">Non merci</a>
    <p style="{SM}; text-align: center">Tu n’es pas Tonton ? Ce lien est le sien : ne l’ouvre pas à sa place.</p></div>'''
    else:
        mid=f'''<div style="display: flex; flex-direction: column; gap: 6px"><label for="p" style="font-size: 15px; font-weight: 600">Ton prénom</label><input id="p" autocomplete="given-name" style="{FIELD}">{who('Vu par ceux avec qui tu tiens une liste ou fais un tirage.')}</div>
    <p style="{SM}">Ton compte sera créé à l’adresse <strong style="color: #292524">tonton-demo@example.com</strong>, celle où tu as reçu l’invitation. Rien d’autre à remplir.</p>
    <div style="display: flex; flex-direction: column; gap: 10px"><a href="ListeTeneur.dc.html" style="{BTN}">Accepter, et créer mon compte</a><a href="#" style="{BTNN}">Non merci</a>
    <p style="{SM}; text-align: center">En créant ton compte, tu acceptes <a href="Regles.dc.html" style="{A}">les règles d’usage</a>. Voir aussi <a href="Confidentialite.dc.html" style="{A}">tes données, en clair</a>.</p></div>'''
    # un mot sur ce qu'est l'application, pour qui arrive sans la connaître (Julien, 19 novembre 2026)
    quoi='' if compte else f'<p style="margin: 0; padding: 12px 14px; border-radius: 12px; background: #f1e8d8; font-size: 14px; line-height: 1.45; color: #57534e"><strong style="color: #292524">Under the Tree</strong>, c’est une application gratuite et sans publicité pour tenir des listes de cadeaux et faire des tirages au sort entre proches.</p>'
    return top+mid+quoi+f'<p style="{SM}; text-align: center">Tu ne connais pas Camille ? <a href="Signaler.dc.html" style="{A}">Signaler</a> · <a href="StopDemande.dc.html" style="{A}">Ne plus recevoir d’emails</a></p>'
M['ListeInvitation']=(scr(980,inv(False),'Listes — l’invitation à tenir une liste, sans compte',back=False),980,'Le lien de l’email, sans compte : un prénom, et c’est fait')
M['ListeInvitationCompte']=(scr(844,inv(True),'Listes — l’invitation à tenir une liste, avec un compte',back=False),844,'Le même lien, quand on a déjà un compte')
M['ListeInvitationEmail']=(mail('Camille t’invite à tenir la liste « Noël 2026 »','tonton-demo@example.com',f'''<p style="margin: 0">Bonjour,</p>
    <p style="margin: 0">Camille t’invite à tenir avec elle la liste de cadeaux « Noël 2026 » : écrire les idées de tout le monde, et voir qui offre quoi.</p>
    <p style="margin: 0"><a href="ListeInvitation.dc.html" style="{ML}; font-weight: 700">Voir l’invitation</a></p>
    <p style="margin: 0">Elle vaut 7 jours, jusqu’au 26 novembre. Tu peux aussi la refuser.</p>
    <p style="margin: 0">Under the Tree est une application gratuite et sans publicité, pour tenir des listes de cadeaux et faire des tirages au sort entre proches.</p>
    <p style="margin: 0">Under the Tree</p>
    <div style="margin-top: 8px; padding-top: 14px; border-top: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 8px; font-size: 13px; line-height: 1.45; color: #57534e">
      <p style="margin: 0">Tu ne veux pas de ces emails ? <a href="StopDemande.dc.html" style="{ML}">Ne plus recevoir d’emails d’Under the Tree</a></p>
      <p style="margin: 0">Tu ne connais pas Camille ? <a href="Signaler.dc.html" style="{ML}">Signaler cet envoi</a></p>
      <p style="margin: 0"><a href="Confidentialite.dc.html" style="{ML}">Ce que l’application fait de tes données</a></p>
    </div>''','Emails — l’invitation à tenir une liste',720),720,'L’email d’invitation : qui, quoi, jusqu’à quand, et ce qu’est l’application')
names=json.load(open('/tmp/names.json')); meta={}
for k,(h,ht,t) in M.items():
    h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h); open(PJ+k+'.dc.html','w').write(h); meta[k]=[ht,t]
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
json.dump(names,open('/tmp/names.json','w')); print(meta)
