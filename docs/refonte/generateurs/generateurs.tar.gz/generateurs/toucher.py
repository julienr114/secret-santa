# Sans « Changer » : toucher une idée que j'offre (la ligne ou sa case) ouvre le panneau (Julien, 20 novembre 2026). Après air.py.
import json,re
PJ='/home/claude/utt/project/'
s=open(PJ+'ListeVisiteurAnonyme.dc.html',encoding='utf-8').read()
i=s.index('Tu l’offres en anonyme'); a=s.rfind('<li',0,i); b=s.index('</li>',a)
li=s[a:b]
assert li.startswith('<li>'), li[:60]
li='<li style="position: relative; margin: 2px -10px; padding: 0 10px; border-radius: 10px; background: #f1e8d8">'+li[4:]
li=re.sub(r'<a href="[^"]*"','<a href="ListeReserver.dc.html"',li,count=1)
li+='<span aria-hidden="true" style="position: absolute; right: 56px; top: 50%; width: 44px; height: 44px; margin-top: -22px; border-radius: 50%; background: rgba(91, 58, 85, 0.18); box-shadow: 0 0 0 6px rgba(91, 58, 85, 0.08)"></span>'
t=s[:a]+li+s[b:]
k='ListeVisiteurToucher'
open(PJ+k+'.dc.html','w',encoding='utf-8').write(t)
names=json.load(open('/tmp/names.json'))
if k+'.dc.html' not in names: names.append(k+'.dc.html'); json.dump(names,open('/tmp/names.json','w'))
print('ok',re.search(r'"\$preview":\{[^}]*\}',t).group(0))
