# Données personnelles : dire, à chaque endroit où l'on en saisit, qui les verra (Julien, 19 novembre 2026 : « exemplaire et le plus transparent possible »).
# Retouche les sources en place ; peut être relancé (chaque retouche vérifie qu'elle n'est pas déjà là). À lancer après nav2.py, avant sorbet_all.py.
import re,json
PJ='/home/claude/utt/project/'
A='color: #8a2f27; text-decoration: underline'
SM='margin: 0; font-size: 13px; line-height: 1.4; color: #57534e'
fait=[]
def edit(n,fn):
    p=PJ+n+'.dc.html'; h=open(p).read(); g=fn(h)
    if g!=h: open(p,'w').write(g); fait.append(n)
def grow(h,d):
    m=re.search(r'width: 390px; height: (\d+)px',h); H=int(m.group(1))+d
    h=h.replace(m.group(0),f'width: 390px; height: {H}px',1)
    return re.sub(r'"\$preview":\{"width":(\d+),"height":\d+\}',lambda m:'"$preview":{"width":%s,"height":%d}'%(m.group(1),H),h)
# 1. mon adresse : à quoi elle sert, qui la voit
def mon_adresse(h):
    if 'Tes données, en clair' in h: return h
    m=re.search(r'<p style="[^"]*">Pas de mot de passe : tu reçois un lien valable 15 minutes\.</p>',h)
    if not m: return h
    return grow(h.replace(m.group(0),m.group(0)+f'\n        <p style="{SM}">Ton adresse sert à te connecter et à te prévenir. Les organisateurs des groupes que tu rejoins la voient, personne d’autre. <a href="Confidentialite.dc.html" style="{A}">Tes données, en clair</a></p>',1),56)
for n in ('Connexion','ConnexionCreer','Rejoindre'): edit(n,mon_adresse)
# 2. l'adresse de quelqu'un d'autre : elle saura qui l'a ajoutée, et pourra refuser
NOTE=f'<p style="{SM}">Elle recevra un email qui dit que c’est toi qui l’as ajoutée. Elle pourra refuser les emails de l’application.</p>'
def autre_adresse(h):
    if 'qui dit que c’est toi' in h: return h
    i=h.find('Adresse email')
    if i<0: return h
    j=h.find('<input',i); k=h.find('>',j)+1
    return grow(h[:k]+'\n        '+NOTE+h[k:],44)
for n in ('PersonneNouvelle','GroupePersonne'): edit(n,autre_adresse)
def envoi_ajout(h):
    a='Tu pourras ensuite lui envoyer son lien par email. Elle servira aussi à Rose pour retrouver ses tirages.</p>'
    if 'qui dit que c’est toi' in h or a not in h: return h
    return h.replace(a,a+'\n        '+NOTE.replace('Elle recevra','Rose recevra').replace('Elle pourra','Elle pourra'),1)
edit('EnvoiAjouterEmail',envoi_ajout)
def teneurs(h):
    a='Il reçoit un email. La liste apparaît dans ses listes dès qu’il se connecte.</p>'
    if 'qui dit que c’est toi' in h or a not in h: return h
    return h.replace(a,'Il reçoit un email qui dit que c’est toi qui l’invites, et peut refuser. La liste apparaît dans ses listes dès qu’il se connecte.</p>',1)
edit('ListeTeneurs',teneurs)
# 3. les pistes : seul celui qui m'offre les lit ; ne pas inviter à écrire des données de santé
def pistes(h):
    h=h.replace('placeholder="Une allergie, ce que tu as en trop…"','placeholder="Ce que tu n’aimes pas, ce que tu as en trop…"')
    if 'Seul ton Père Noël' in h: return h
    return h.replace('<span></span><span style="flex-shrink: 0">','<span>Seul ton Père Noël lira ces lignes.</span><span style="flex-shrink: 0">',1)
for n in ('PistesTexteMoment','PistesTexteServirait','PistesTexteEviter','NavRedaction'): edit(n,pistes)
# 4. partager une liste : ce que voit celui qui a le lien
def partager(h):
    a='Un message tout prêt pour la conversation de la famille.</p>'
    if 'Toute personne qui a ce lien' in h or a not in h: return h
    return grow(h.replace(a,a+'\n      <p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">Toute personne qui a ce lien voit les prénoms, les âges, les tailles et les idées. Tu peux changer de lien quand tu veux : l’ancien ne marchera plus.</p>',1),64)
edit('ListePartager',partager)
# 5. le pied de chaque email
ML='color: #1d4ed8; text-decoration: underline'
def pied(login=False):
    l1='<p style="margin: 0">Tu reçois cet email parce que tu viens de le demander.</p>' if login else f'<p style="margin: 0">Tu ne veux pas de ces emails ? <a href="StopDemande.dc.html" style="{ML}">Ne plus recevoir d’emails d’Under the Tree</a></p>'
    return f'''    <div style="margin-top: 8px; padding-top: 14px; border-top: 1px solid #d6d3d1; display: flex; flex-direction: column; gap: 8px; font-size: 13px; line-height: 1.45; color: #57534e">
      {l1}
      <p style="margin: 0"><a href="Confidentialite.dc.html" style="{ML}">Ce que l’application fait de tes données</a></p>
    </div>
'''
def email(login):
    def f(h):
        end='\n  </div>\n</div>\n</x-dc>'
        if 'Ce que l’application fait de tes données' in h or end not in h: return h
        i=h.index(end)+1
        return grow(h[:i]+pied(login)+h[i:],96 if not login else 84)
    return f
for n in ('DevineEmailOrgaFin','DevineEmailOrgaPoint','DevineEmailPalmares','DevineEmailRappelAuto','DevineEmailRappelEncore','PistesEmail','NotifEmailResume'): edit(n,email(False))
edit('ConnexionCodeEmail',email(True))
def stop_lien(h): return h.replace('<a href="#" style="'+ML+'">Ce que l’application fait de tes données</a>','<a href="Confidentialite.dc.html" style="'+ML+'">Ce que l’application fait de tes données</a>')
edit('StopEmail',stop_lien)
print('retouchées :',fait)
json.dump(fait,open('/tmp/transp_fait.json','w'))
