# Les trois dernières retouches de la liste avant de publier (Julien, 20 novembre 2026). Après v3.py.
# 1. décocher pour quelqu'un : plus d'encart ni de phrase, une pastille d'action à côté du prénom touché ;
# 2. en mode anonyme, « Dire à … que c'est moi » est verrouillé ; 3. « Tu l'offres » doit montrer qu'on peut agir.
import json,re
PJ='/home/claude/utt/project/'
def ic(p,sz=12,sw=2.6): return f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0">{p}</svg>'
X=ic('<path d="M6 6l12 12M18 6 6 18"/>')
CHEVR=ic('<path d="m9 6 6 6-6 6"/>',12,2.8)
MASK=ic('<path d="M2.5 9.5c0-1.5 1-2.5 2.5-2.5 2.5 0 4.5 1.5 7 1.5s4.5-1.5 7-1.5c1.5 0 2.5 1 2.5 2.5 0 4.5-2.5 7.5-5.5 7.5-2 0-2.7-1.8-4-1.8s-2 1.8-4 1.8c-3 0-5.5-3-5.5-7.5z"/><path d="M7 11.5h2.5M14.5 11.5H17"/>',20,2)
LOCK=ic('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',18,2)
CH='display: inline-flex; align-items: center; gap: 4px; font-size: 12px; line-height: 20px; font-weight: 600; letter-spacing: 0.01em; border-radius: 999px; text-decoration: none; white-space: nowrap; '
names=json.load(open('/tmp/names.json')); P={}
# ---------- 1 : retravaillé (Julien : « la pastille Décocher, j'aime pas ») ----------
s=open(PJ+'ListeDecocher.dc.html',encoding='utf-8').read()
i=s.index('data-dec="2"'); a=s.rfind('<li',0,i); b=s.index('</li>',i)+5
li=s[a:b]
li=li.replace('<li style="margin: 4px -10px; padding: 0 10px 2px; border-radius: 10px; background: #f1e8d8">','<li>',1)
li=re.sub(r'<span data-dec="2".*?</button></span>','',li,flags=re.S)
li=li.replace('; background: #292524; color: #ffffff" aria-expanded="true">Mamie</span>','">Mamie</span>',1)
base=s[:a]+li+s[b:]
# a. la case grise se touche : elle décoche tout de suite, avec « Annuler » (l'écran d'après est ListeDecocheFait)
lia=li.replace('flex-shrink: 0; margin-top: 1px; background: #a8a29e; color: #ffffff"','flex-shrink: 0; margin-top: 1px; background: #a8a29e; color: #ffffff; box-shadow: 0 0 0 8px rgba(184, 72, 58, 0.22)"',1)
assert lia!=li
P['ListeDecocherCase']=(s[:a]+lia+s[b:],'Décocher pour quelqu’un · A, la case : toucher la case grise décoche tout de suite, puis « Annuler » (ListeDecocheFait)')
# b. la pastille ouvre un panneau : qui, quand, « Décocher »
SHEETD=('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
  '<div role="dialog" aria-label="Circuit de billes, coché par Mamie" style="position: absolute; left: 0; right: 0; top: 560px; z-index: 5; background: #fffdf9; border-radius: 20px 20px 0 0; padding: 10px 16px 24px; display: flex; flex-direction: column; gap: 14px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
  '<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>'
  '<div style="display: flex; flex-direction: column; gap: 4px"><h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 22px; line-height: 1.2">Circuit de billes</h2><p style="margin: 0; font-size: 15px; color: #57534e">Coché par Mamie, le 12 novembre</p></div>'
  '<button style="height: 52px; border: 1px solid #e0b4ab; border-radius: 6px; background: #fffdf9; color: #8a2f27; font-family: inherit; font-size: 17px; font-weight: 700">Décocher pour Mamie</button>'
  '<button style="height: 46px; border: 0; background: transparent; color: #57534e; font-family: inherit; font-size: 16px; font-weight: 700">Fermer</button></div>')
hb=base.replace("display: flex; flex-direction: column\">","display: flex; flex-direction: column; position: relative\">",1)
hb=hb.replace('</main>','</main>'+SHEETD,1)
assert 'position: relative' in hb and SHEETD in hb
P['ListeDecocherPanneau']=(hb,'Décocher pour quelqu’un · B, le panneau : toucher le prénom ouvre qui, quand, et « Décocher pour Mamie »')
# ---------- 2 ----------
r=open(PJ+'ListeReserver.dc.html',encoding='utf-8').read()
old=re.search(r'<label style="display: flex; align-items: center; gap: 12px; min-height: 56px"><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">Dire à Camille que c’est moi</span>.*?</label>',r,re.S).group(0)
SWLOCK='<span role="switch" aria-checked="false" aria-disabled="true" style="width: 48px; height: 28px; border-radius: 999px; background: #d9c9d4; position: relative; flex-shrink: 0"><span style="position: absolute; top: 3px; left: 3px; width: 22px; height: 22px; border-radius: 50%; background: #ffffff; color: #5b3a55; display: flex; align-items: center; justify-content: center">'+ic('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',12,2.6)+'</span></span>'
new=(f'<div role="group" aria-disabled="true" style="display: flex; flex-direction: column; gap: 10px; padding: 12px 14px; border-radius: 12px; border: 1px solid #e6d6e1">'
     f'<div style="display: flex; align-items: center; gap: 12px; color: #a8a29e"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Dire à Camille que c’est moi</span>{SWLOCK}</div>'
     f'<div style="display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: 10px; background: #f1e6ee; color: #5b3a55"><span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 50%; background: #5b3a55; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+ic('<path d="M2.5 9.5c0-1.5 1-2.5 2.5-2.5 2.5 0 4.5 1.5 7 1.5s4.5-1.5 7-1.5c1.5 0 2.5 1 2.5 2.5 0 4.5-2.5 7.5-5.5 7.5-2 0-2.7-1.8-4-1.8s-2 1.8-4 1.8c-3 0-5.5-3-5.5-7.5z"/><path d="M7 11.5h2.5M14.5 11.5H17"/>',16,2)+'</span><span style="font-size: 14px; font-weight: 600; line-height: 1.35">Tu es en mode anonyme : Camille verra « Anonyme ».</span></div></div>')
r2=r.replace(old,new,1)
# « à plusieurs » demande un prénom : verrouillé aussi en anonyme (proposition)
r2=r2.replace('<label style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 10px 14px; box-sizing: border-box; border-top: 1px solid #e9dcc5;"><input type="radio" name="r" style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">On l’offre à plusieurs</span><span style="font-size: 13px; line-height: 1.35; color: #57534e">D’autres pourront se joindre à toi</span></span></label>',
              '<label aria-disabled="true" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 10px 14px; box-sizing: border-box; border-top: 1px solid #e9dcc5; color: #a8a29e"><input type="radio" name="r" disabled style="width: 22px; height: 22px; margin: 0; flex-shrink: 0"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 600">On l’offre à plusieurs</span><span style="font-size: 13px; line-height: 1.35">Pas en anonyme : les autres doivent savoir avec qui</span></span></label>',1)
assert new in r2 and 'Pas en anonyme' in r2
r2=r2.replace('>Le circuit de billes, c’est noté<','>Le circuit de billes, c’est noté<',1)
P['ListeReserverAnonyme']=(r2,'En mode anonyme · le panneau de ce que j’offre : « Dire à Camille » est verrouillé, « à plusieurs » aussi')
# ---------- 3 : trois façons de montrer qu'on peut agir sur ce qu'on offre ----------
v=open(PJ+'ListeVisiteurMes.dc.html',encoding='utf-8').read()
i=v.index('>Tu l’offres<'); a=v.rfind('<li',0,i); b=v.index('</li>',i)+5; L=v[a:b]
chipA=re.sub(r'(<span data-chip="etat" style=")([^"]*)(">)(.*?)Tu l’offres</span>',lambda m:m.group(1)+m.group(2).replace('padding: 1px 9px 1px 7px','padding: 1px 6px 1px 7px; box-shadow: inset 0 0 0 1.5px #8fc39c')+m.group(3)+m.group(4)+'Tu l’offres'+CHEVR+'</span>',L,count=1,flags=re.S)
DOTS='<span aria-hidden="true" style="align-self: center; width: 36px; height: 36px; border-radius: 50%; box-shadow: inset 0 0 0 1px #dccbad; background: #fffdf9; color: #57534e; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg></span>'
chipB=L.replace('</span></a></li>','</span>'+DOTS+'</a></li>',1)
TOAST='<div role="status" style="margin-top: 8px; display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 8px 8px 8px 16px; border-radius: 14px; background: #2b1b3d; color: #ffffff; font-size: 14px; line-height: 1.35; box-shadow: 0 8px 20px rgba(43, 27, 61, 0.25)"><span style="flex-grow: 1">C’est noté. Touche la ligne pour changer d’avis.</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: rgba(255, 255, 255, 0.14); color: #ffffff; font-family: inherit; font-size: 14px; font-weight: 700">OK</button></div>'
def blk(tag,title,sub,line,extra=''):
    return (f'<section style="display: flex; flex-direction: column; gap: 6px"><p style="margin: 0; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #8a2f27">{tag}</p>'
            f'<h2 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 20px">{title}</h2><p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">{sub}</p>'
            f'<ul style="list-style: none; margin: 4px -16px 0; padding: 0 16px 0 22px; background: #fffdf9; border-top: 1px solid #dccbad; border-bottom: 1px solid #dccbad">{line}</ul>{extra}</section>')
body=blk('Retenue (Julien)','La pastille montre qu’elle se touche','Un filet et une flèche dans « Tu l’offres », « Tu l’offres en anonyme », « Tu participes ».',chipA)
head=v[:v.index('<header')]; tail=v[v.rindex('</div>\n</x-dc>'):]
page=(re.sub(r'<title>[^<]*</title>','<title>« Tu l’offres » : montrer qu’on peut agir</title>',head,count=1)
      +f'<main style="display: flex; flex-direction: column; gap: 28px; padding: 24px 16px 32px"><h1 style="margin: 0; font-family: \'Fraunces\', Georgia, serif; font-weight: 700; font-size: 26px; line-height: 1.15">Ce que j’offre : montrer qu’on peut agir</h1>{body}</main>'+tail)
page=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":520}',page)
P['ListeJOffreAgir']=(page,'« Tu l’offres » : un filet et une flèche, la pastille se touche')
out={}
for k,(h,t) in P.items():
    h=re.sub(r'<title>[^<]*</title>',f'<title>{t}</title>',h,count=1)
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
    out[k]=(int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1)),t)
json.dump(names,open('/tmp/names.json','w')); json.dump(out,open('/tmp/trois.json','w'),ensure_ascii=False); print(out)
