# Harmonie de la ligne d'une idée (Julien, 20 novembre 2026) : titre 16/22, lien 13/18, pastilles 12 px demi-gras hautes de 22, marges 2 puis 6. Après lien3.py.
import glob,json,re
PJ='/home/claude/utt/project/'
n=[]
def chip(m):
    st=m.group(1)
    st=st.replace('font-size: 13px; font-weight: 700','font-size: 12px; line-height: 20px; font-weight: 600; letter-spacing: 0.01em')
    st=re.sub(r'padding: 1px 8px 1px 6px','padding: 1px 9px 1px 7px',st)
    st=re.sub(r'padding: 1px 9px 1px 6px','padding: 1px 9px 1px 7px',st)
    st=re.sub(r'padding: 1px 8px(?! 1px)','padding: 1px 9px',st)
    return 'style="'+st+'"'
for f in sorted(glob.glob(PJ+'*.dc.html')):
    s=open(f,encoding='utf-8').read()
    if 'data-par="1"' not in s and 'data-lien="3"' not in s: continue
    t=s
    # la rangée : 6 px au-dessus, 6 px entre les pastilles
    t=t.replace('<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 3px; text-decoration: none">','<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; text-decoration: none">')
    t=t.replace('<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 4px; text-decoration: none">','<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 6px; text-decoration: none">')
    # les pastilles
    t=re.sub(r'style="((?:display: inline-block; text-decoration: none; |display: inline-flex; align-items: center; gap: 4px; )font-size: 13px; font-weight: 700[^"]*)"',chip,t)
    # le lien
    t=t.replace('<span data-lien="3" style="display: flex; align-items: center; gap: 5px; margin-top: 1px; font-size: 13px; line-height: 1.5; font-style: italic; font-weight: 500;','<span data-lien="3" style="display: flex; align-items: center; gap: 5px; margin-top: 2px; font-size: 13px; line-height: 18px; font-style: italic; font-weight: 400;')
    if t!=s: open(f,'w',encoding='utf-8').write(t); n.append(f.split('/')[-1])
print(len(n)); json.dump(n,open('/tmp/typo.json','w'))
