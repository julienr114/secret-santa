# V3 (Julien, 20 novembre 2026) : les écrans de l'ancien groupe, devenus ceux de la fête, et la liste qui dit dans quelles fêtes elle est.
# Dérivés des maquettes existantes ; en-tête par l'icône du compte, barre « Accueil · Quoi de neuf ». Après fete3.py.
import json,re
src=open('/home/claude/gen/fete3.py',encoding='utf-8').read()
exec(src.split("names=json.load(open('/tmp/names.json'))\nfor k in ('FetePartagee'")[0])
BURG=re.compile(r'<button aria-label="Menu[^"]*"[^>]*>.*?</button>',re.S)
AVB='<button aria-label="Mon compte" aria-haspopup="menu" style="justify-self: end; width: 44px; height: 44px; border: 0; background: transparent; display: flex; align-items: center; justify-content: center; padding: 0"><span aria-hidden="true" style="width: 34px; height: 34px; border-radius: 50%; background: #f6e3ad; box-shadow: 0 0 0 1px #e6b94a; display: flex; align-items: center; justify-content: center; font-size: 18px">🐧</span></button>'
NAVRE=re.compile(r'<nav aria-label="Sections".*?</nav>',re.S)
def v3(h,title):
    h=BURG.sub(AVB,h,count=1); h=NAVRE.sub(nav(),h,count=1)
    h=re.sub(r'<title>[^<]*</title>',f'<title>{title}</title>',h,count=1)
    return h.replace('<button hidden aria-label="Retour" style="','<button hidden aria-label="Retour" style="visibility: hidden; ')
def fete_words(h):
    for a,b in [('Quelqu’un rejoint le groupe par le lien','Quelqu’un rejoint la fête par le lien'),('Supprimer le groupe','Supprimer la fête'),
                ('et rejoint le groupe, et le tirage en cours','et rejoint la fête, et son tirage'),('Tu es invité au Secret Santa « Famille Camille »','Tu es invité à la fête « Famille Camille »'),
                ('Groupe — ','Fête — ')]:
        h=h.replace(a,b)
    return h
R=lambda f: open(PJ+f+'.dc.html',encoding='utf-8').read()
P7={}
ROWS=lambda items: ''.join(items)
# ---------- 1. réglages de la fête : la fête d'abord (catégorie, date, revient), puis les réglages du groupe d'aujourd'hui ----------
h=fete_words(R('GroupeReglages'))
h=h.replace('>Réglages<','>Réglages de la fête<',1)
CALI='<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: '+MUT+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+ic('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',18)+'</span>'
SET=f'''<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {MUT}">La fête</h2><ul style="{UL}">
      {irow(cat('Noël',36),'Catégorie','Noël','',True)}
      {irow(CALI,'Date','Le 25 décembre · proposée pour chaque tirage')}
      <li><div style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; border-top: 1px solid {SOFT}"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M3 12a9 9 0 0 1 15.5-6.3L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.3L3 16"/><path d="M3 21v-5h5"/>',18)}</span><span style="flex-grow: 1; font-weight: 600; font-size: 15px">Revient chaque année</span>{SW}</div></li>
    </ul></section>'''
m=re.search(r'<main[^>]*>',h); 
# placer la section après le titre de la page (premier </h1> dans main)
k=h.index('</h1>',m.end())
k=h.index('</div>',k)+6 if h[k:k+400].find('</div>')!=-1 and h[k:k+400].find('</div>')<h[k:k+400].find('<section') else k+5
h=h[:k]+'\n    '+SET+h[k:]
P7['FeteReglages']=(v3(h,'Fête — réglages'),1420,'V3 · 5. les réglages d’une fête : la catégorie, la date, « revient chaque année », puis ceux du groupe d’aujourd’hui')
# ---------- 2. membres ----------
P7['FeteMembres']=(v3(fete_words(R('GroupeMembres')),'Fête — membres'),930,'V3 · 6. les membres d’une fête (l’ancienne page des membres du groupe)')
# ---------- 3. inviter ----------
P7['FeteInviter']=(v3(fete_words(R('GroupeInvitation')),'Fête — inviter par lien'),960,'V3 · 7. inviter dans une fête, par lien')
# ---------- 4. le tirage de l'année : la date de la fête, proposée, modifiable ----------
h=R('EditionNouvelle')
for a,b in [('Nouvelle édition','Le tirage 2027'),('Nom de l’édition','Nom du tirage'),('Créer l’édition','Créer le tirage'),('participants repris.','membres repris du tirage 2026.')]:
    h=h.replace(a,b)
h=h.replace('<input id="dt" type="text" placeholder="jj/mm/aaaa"','<input id="dt" type="text" value="25/12/2027" placeholder="jj/mm/aaaa"',1)
h=re.sub(r'<button style="align-self: flex-start; min-height: 44px;[^>]*>Proposer le 25 décembre 2027</button>','<p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">La date de la fête.</p>',h,count=1)
assert 'La date de la fête.' in h
P7['TirageNouveau']=(v3(h,'Fête — le tirage de l’année'),900,'V3 · 8. le tirage de l’année : la date de la fête est proposée, et se change')
# ---------- 5. la liste : la barre dit dans quelles fêtes elle est ----------
PEOPLE=ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',20)
def vbar(t,sub):
    return (f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); min-height: 52px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 10px">'
            f'<span style="display: flex; color: #274e34">{PEOPLE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; min-height: 48px"><span style="font-size: 14px; font-weight: 700">{t}</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">{sub}</span></span>'
            f'<a href="FeteChoisir.dc.html" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">Modifier</a></div>')
def swap_bar(h,new):
    i=h.index('<div data-pub="1"'); j=i; d=0
    for mm in re.finditer(r'<div\b|</div>',h[i:]):
        d+=1 if mm.group(0)!='</div>' else -1
        if d==0: j=i+mm.end(); break
    return h[:i]+new+h[j:]
P7['ListeV3']=(swap_bar(R('ListeTeneur'),vbar('Famille Camille, Chez Mamie','21 membres la voient')),None,'V3 · 9. ma liste : la barre dit dans quelles fêtes elle est, « Modifier » rouvre « Qui verra ta liste ? »')
h=swap_bar(R('ListeNouvelle'),vbar('Famille Camille, Chez Mamie','21 membres la verront'))
h=h.replace('>Nom de l’événement<','>Noël 2026<',1).replace('>Ajouter une date<','>Le 25 décembre<',1)
P7['ListeV3Nouvelle']=(h,None,'V3 · 10. la nouvelle liste : le nom et la date viennent de la fête, et la barre dit qui la verra')
names=json.load(open('/tmp/names.json'))
out={}
for k,(h,ht,t) in P7.items():
    h=BURG.sub(AVB,h,count=1) if 'aria-label="Menu' in h else h
    if ht: h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    ht=int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1))
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
    out[k]=(ht,t)
json.dump(names,open('/tmp/names.json','w')); json.dump(out,open('/tmp/v3.json','w'),ensure_ascii=False); print(out)
