# V3 : le jeu de maquettes de la fête, sur sa page de canevas (Julien, 20 novembre 2026, après la séance de questions).
# Les maquettes V2 ne sont pas touchées. Tous les fichiers s'appellent V3*.
import json,re
src=open('/home/claude/gen/v3.py',encoding='utf-8').read()
exec(src.split("P7={}")[0])
CAT.pop('Pot de départ',None); CAT['Crémaillère']=('🏡','#f3d3cc')
CAT={k:CAT[k] for k in ('Noël','Anniversaire','Naissance','Mariage','Crémaillère','Autre')}
AV.update({'🍭':('#f3d3cc','#e09e92'),'🎄':('#cfe2d3','#8db898'),'⛄':('#d6e6ef','#94bbd0')})
V={}
# Julien, 23 novembre 2026 (piste B) : l'icône d'un événement est une tuile en couleur, mise en avant ; les icônes des lignes dessous
# (Secret Santa, liste, jeu) n'ont plus de rond coloré : le trait seul. L'œil va d'abord à l'événement.
GRAD={'Noël':('#d9f5df','#58c07a'),'Anniversaire':('#fff0b8','#f4b82e'),'Naissance':('#dcefff','#6eb0f2'),'Mariage':('#f7dcec','#d977ae'),'Crémaillère':('#ffe1d6','#f08a6c'),'Autre':('#efe6fb','#a98be0')}
def cat(c,sz=32):
    e=CAT[c][0]; a,b=GRAD[c]; ring=('0 0 0 2px #ffffff, 0 3px 8px rgba(90, 40, 60, 0.22)' if sz>=36 else '0 0 0 1.5px #ffffff, 0 1px 3px rgba(90, 40, 60, 0.2)')
    return f'<span aria-hidden="true" data-evt="1" style="width: {sz}px; height: {sz}px; border-radius: {13 if sz>=40 else 9}px; background: linear-gradient(150deg, {a} 0%, {b} 115%); box-shadow: {ring}; display: flex; align-items: center; justify-content: center; font-size: {round(sz*0.52)}px; flex-shrink: 0">{e}</span>'
_TLC,_LLC=tl,ll   # les deux icônes en couleur, gardées là où l'on choisit quoi créer
def _trait(p,couleur): return f'<span aria-hidden="true" data-trait="1" style="width: 44px; height: 36px; color: {couleur}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(p,20)}</span>'
tl=lambda: _trait(I_TIR,MUT); ll=lambda: _trait(I_LIS,'#5f37a6')
def put(k,h,ht,t,row,col):
    if ht is not None: h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    V[k]=(h,ht,t,row,col)
def rel(h):
    k=h.index('<div style="width: 390px;',h.index('<x-dc>')); e=h.index('">',k)
    return h[:e]+'; position: relative'+h[e:]
def sheet(h,inner,top,label):
    S=(f'<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
       f'<div role="dialog" aria-label="{label}" style="position: absolute; left: 0; right: 0; top: {top}px; min-height: {844-top}px; box-sizing: border-box; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
       f'<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>{inner}</div>')
    h=rel(h); z=h.rindex('</div>\n</x-dc>'); return h[:z]+S+h[z:]
def chip(c,t,color='#274e34'): return f'<span style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px 0 8px; border-radius: 999px; background: {CAT[c][1]}; font-size: 13px; font-weight: 700; color: {color}">{CAT[c][0]} {t}</span>'
def fhead(c,ct,name,when):
    return f'<div style="display: flex; flex-direction: column; gap: 8px; padding: 4px 4px 0">{chip(c,ct)}<h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{name}</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: {DRED}">{when}</p></div>'
def members(es,n,invite=False):
    inv=f'<span style="font-size: 14px; font-weight: 700; color: {DRED}">Inviter</span>' if invite else ''
    return f'<a href="V3FeteMembres.dc.html" style="{CARDS}; min-height: 56px; padding: 0 14px; display: flex; align-items: center; gap: 12px; text-decoration: none; color: {INK}">{stack(es)}<span style="flex-grow: 1; font-weight: 600">{n} membres</span>{inv}<span style="color: #78716c; display: flex">{CHEV}</span></a>'
ICO=lambda p: f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(p,18)}</span>'
GIFTI=ICO('<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8"/><path d="M12 8c-1.5-4-6-4.5-6-1.5C6 8 9 8 12 8zm0 0c1.5-4 6-4.5 6-1.5C18 8 15 8 12 8z"/>')
GEAR=ic('<circle cx="12" cy="12" r="3"/><path d="M19.400 15a1.700 1.700 0 0 0 .300 1.800l.100.100a2 2 0 1 1-2.800 2.800l-.100-.100a1.700 1.700 0 0 0-2.800 1.200V21a2 2 0 1 1-4 0v-.100a1.700 1.700 0 0 0-2.900-1.200l-.100.100a2 2 0 1 1-2.800-2.800l.100-.100a1.700 1.700 0 0 0-1.200-2.800H3a2 2 0 1 1 0-4h.100a1.700 1.700 0 0 0 1.200-2.900l-.100-.100a2 2 0 1 1 2.800-2.800l.100.100a1.700 1.700 0 0 0 2.900-1.200V3a2 2 0 1 1 4 0v.100a1.700 1.700 0 0 0 2.800 1.200l.100-.100a2 2 0 1 1 2.800 2.800l-.100.100a1.700 1.700 0 0 0 1.200 2.900H21a2 2 0 1 1 0 4h-.100a1.700 1.700 0 0 0-1.500 1z"/>',20)
def foot(): return f'<div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="V3FeteNouvelle.dc.html" style="{BTN2}">{PLUS}Nouvelle fête</a></div>'
def propose(c,name,when,act,href):
    return (f'<section style="border-radius: 16px; border: 1.5px dashed #cdb48a; padding: 12px 12px 12px 16px; display: flex; align-items: center; gap: 10px">{cat(c)}'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-family: {F}; font-weight: 700; font-size: 17px; line-height: 1.2">{name}</span><span style="font-size: 13px; color: {MUT}">{when}</span></span>'
            f'<a href="{href}" style="{BTN2}; height: 40px; padding: 0 12px; font-size: 14px; flex-shrink: 0">{act}</a></section>')

# « Une fête » en général (pas une catégorie) : une icône au trait, comme le tirage et la liste (retour de Julien)
I_FETE='<path d="M5.8 11.3 2 22l10.7-3.79"/><path d="M4 3h.01"/><path d="M22 8h.01"/><path d="M15 2h.01"/><path d="M22 20h.01"/><path d="m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10"/><path d="m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17"/><path d="m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7"/><path d="M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z"/>'
fl=lambda: '<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #dcefe0; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+ic(I_FETE,18)+'</span>'
# Une date = les trois listes du téléphone, comme la date de naissance d'un proche (retour de Julien) : plus de calendrier dessiné
_pn=open('/home/claude/utt/v2/ProcheNaissance.dc.html',encoding='utf-8').read()
_i=_pn.index('<div role="group" aria-label="Date de naissance"'); _j=_pn.index('</label></div>',_i)+len('</label></div>')
_G=_pn[_i:_j]
assert _G.count('>14<span')==1 and _G.count('>mars<span')==1 and _G.count('>2020<span')==1
def date3(d,m,y,label):
    return _G.replace('aria-label="Date de naissance"','aria-label="'+label+'"',1).replace('>14<span','>'+d+'<span',1).replace('>mars<span','>'+m+'<span',1).replace('>2020<span','>'+y+'<span',1)
# L'en-tête d'une fête se touche aussi : même flèche que les lignes (retour de Julien)
def fcard2(c,title,when,rows,add='',href='V3Fete.dc.html'):
    body=rows+((addrow(add).replace(f"border-top: 1px solid {SOFT}; ","",1) if not rows else addrow(add)) if add else '')
    return (f'<section style="{CARDS}; overflow: hidden"><a href="{href}" style="min-height: 66px; box-sizing: border-box; padding: 10px 16px; display: flex; align-items: center; gap: 12px; text-decoration: none; color: {INK}">{cat(c,44)}<h3 style="flex-grow: 1; min-width: 0; margin: 0; font-family: {F}; font-weight: 700; font-size: 18px; line-height: 1.2">{title}</h3><span style="font-size: 13px; font-weight: 700; color: {MUT}; white-space: nowrap">{when}</span><span style="color: #78716c; display: flex">{CHEV}</span></a>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">{body}</ul></section>')
# =================== ACCUEIL ===================
NOEL=(season('Noël 2026','dans 35 jours')
  +fcard2('Noël','Bureau, 3e étage','19 déc.',irow(tl(),'Le tirage','Tu sais à qui tu offres · tu l’organises','',True),'Nouvelle liste',href='V3FeteOrganisateur.dc.html')
  +fcard2('Noël','Chez Mamie','24 déc.',irow(ll(),'La liste de Mamie','Tu offres 2 cadeaux','',True)+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi dans Famille Camille','',False,'V3Liste.dc.html'),href='V3Fete.dc.html')
  +fcard2('Noël','Famille Camille','25 déc.',irow(tl(),'Le tirage','Camille te demande des pistes',dot(),True,'V3TirageVersListe.dc.html')+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',False,'V3Liste.dc.html')+irow(ll(),'La liste de Camille','Tu offres 1 cadeau','',False,'V3ListeMembre.dc.html'),href='V3Fete.dc.html'))
BIENTOT=(f'<div style="padding-top: 10px">{SEC("Bientôt")}</div>'+propose('Anniversaire','L’anniversaire de Zoé','14 décembre · dans 24 jours · ses 4 ans','Préparer','V3FeteNouvelle.dc.html'))
TARD=(f'<div style="padding-top: 10px">{SEC("Plus tard")}</div>'+fcard2('Anniversaire','Les 40 ans de Tonton','8 févr.',irow(ll(),'La liste de Tonton','3 nouvelles idées',dot(),True),href='V3FeteAnniversaire.dc.html'))
BAS=f'<ul style="{UL}; margin-top: 10px">'+irow(CLOCKI,'Les fêtes passées','Les 6 ans de Léo et 4 autres','',True,'V3FetesPassees.dc.html')+irow(GIFTI,'Ce que j’offre ailleurs','Le mariage de Karim et Sofia · 1 cadeau','',False,'V3OffreAilleurs.dc.html')+'</ul>'
MAINA=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}{NOEL}{BIENTOT}{TARD}{BAS}
  </main>'''
HA=1320
put('V3Accueil',page('V3 · accueil',MAINA,HA),HA,'Accueil · mes fêtes : leurs tirages et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs',0,0)
def big(c,title,txt,btn,href,primary=False):
    return (f'<section style="{CARDS}; padding: 18px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; align-items: center; gap: 12px">{c}<h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">{title}</h2></div>'
            f'<p style="margin: 0; font-size: 15px; line-height: 1.45; color: {MUT}">{txt}</p><a href="{href}" style="{BTN if primary else BTN2}">{btn}</a></section>')
put('V3AccueilVide',page('V3 · accueil d’un compte tout neuf',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo','Par quoi on commence ?')}
    {big(_TLC(),'Un Secret Santa','Chacun tire au sort la personne à qui il offre un cadeau.','Organiser un Secret Santa','V3FeteNouvelle.dc.html',True)}
    {big(_LLC(),'Une liste de cadeaux','Tes idées, que tes proches cochent pour ne pas offrir deux fois la même chose.','Écrire ma liste','V3FeteNouvelle.dc.html')}
  </main>''',844),844,'Accueil · un compte tout neuf : un Secret Santa ou une liste ; on ne parle pas de « fête », c’est leur première étape',0,1)
MAINY=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {season('Noël 2027','dans 61 jours')}
    {fcard2('Noël','Bureau, 3e étage','19 déc.','',add='Préparer Noël 2027',href='V3TirageNouveau.dc.html')}
    <p style="margin: -6px 4px 0; font-size: 13px; line-height: 1.4; color: {MUT}">Tu l’organises. Les 8 membres de l’an dernier sont repris.</p>
    {fcard2('Noël','Chez Mamie','24 déc.','',add='Reprendre ma liste de l’an dernier',href='V3Fete.dc.html')}
    {fcard2('Noël','Famille Camille','25 déc.',irow(ll(),'La liste de Camille','Elle vient de la créer · 4 idées',dot(),True),add='Reprendre ma liste de l’an dernier',href='V3Fete.dc.html')}
    <ul style="{UL}; margin-top: 10px">{irow(CLOCKI,'Les fêtes passées','Noël 2026, les 40 ans de Tonton et 3 autres','',True,'V3FetesPassees.dc.html')}</ul>
  </main>'''
put('V3AccueilAnnee',page('V3 · accueil, l’année suivante',MAINY,980),980,'Accueil · l’année suivante (fin octobre 2027) : « Préparer Noël 2027 », « Reprendre ma liste de l’an dernier »',0,2)

# =================== FÊTE ===================
def fete_main(extra_bottom=''):
    return f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {fhead('Noël','Noël · tous les ans','Famille Camille','25 décembre 2026 · dans 35 jours')}
    {members(['🦌','👵','🎸','🍭','🐧'],12)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le tirage')}<ul style="{UL}">{irow(tl(),'Le tirage 2026','Camille te demande des pistes',dot(),True,'V3TirageVersListe.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes')}<ul style="{UL}">{irow(av('🐧',36),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',True,'V3Liste.dc.html')}{irow(av('🦌',36),'La liste de Camille','Tu offres 1 cadeau','',False,'V3ListeMembre.dc.html')}{irow(av('👵',36),'La liste de Mamie','Tu offres 2 cadeaux · 1 nouvelle idée',dot())}</ul>
      <div style="padding-top: 8px; display: flex"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts','',True,'V3FeteAnneePassee.dc.html')}{irow(yr('2024'),'Noël 2024','Tu offrais à Camille')}</ul></section>
    <ul style="{UL}">{irow(ICO('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>'),'Quitter cette fête','Tu n’y verras plus les listes','',True,'V3FeteQuitter.dc.html')}</ul>{extra_bottom}
  </main>'''
HF=980
fete_page=page('V3 · une fête, vue par un membre',fete_main(),HF).replace(HEADER,hd,1)
put('V3Fete',fete_page,HF,'Fête · vue par un membre : ses membres, son tirage, les listes, les années passées, « Quitter »',1,0)
QUIT=(f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Quitter « Famille Camille » ?</h2>'
      f'<ul style="margin: 0; padding: 0 20px 0 38px; display: flex; flex-direction: column; gap: 8px; font-size: 15px; line-height: 1.45; color: {INK}"><li>Ta liste sortira de cette fête. Elle reste chez Mamie.</li><li>Les cadeaux que tu as cochés restent prévus.</li><li>Tu ne participeras plus à son tirage l’an prochain.</li></ul>'
      f'<div style="padding: 4px 16px 0; display: flex; flex-direction: column; gap: 6px"><button style="height: 52px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 17px; font-weight: 700">Quitter la fête</button><a href="V3Fete.dc.html" style="min-height: 46px; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 700; color: {MUT}; text-decoration: none">Rester</a></div>')
put('V3FeteQuitter',sheet(fete_page,QUIT,430,'Quitter la fête'),HF,'Fête · quitter : ce qui sort, ce qui reste',1,5)
orga=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; align-items: flex-start; gap: 8px"><div style="flex-grow: 1">{fhead('Noël','Noël · tous les ans','Bureau, 3e étage','19 décembre 2026 · dans 29 jours')}</div><a href="V3FeteReglages.dc.html" aria-label="Réglages de la fête" style="width: 44px; height: 44px; border-radius: 50%; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{GEAR}</a></div>
    {members(['🧶','🍭','🎄','⛄','🐧'],8,True)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les tirages')}<ul style="{UL}">{irow(tl(),'Le tirage 2026','Fait · 6 sur 8 ont découvert','',True)}{addrow('Un autre tirage','V3TirageNouveau.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px">{SEC('Les listes')}<p style="margin: 0; padding: 0 4px; font-size: 15px; line-height: 1.45; color: {MUT}">Personne n’a encore mis de liste dans cette fête.</p><div style="display: flex"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Inès','',True)}</ul></section>
  </main>'''
put('V3FeteOrganisateur',page('V3 · une fête, vue par son organisateur',orga,900).replace(HEADER,hd,1),900,'Fête · vue par son organisateur : « Inviter », les réglages, « Un autre tirage »',1,1)
anniv=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {fhead('Anniversaire','Anniversaire · tous les ans','L’anniversaire de Zoé','14 décembre 2026 · dans 24 jours · ses 4 ans')}
    {members(['🐧','🦌','👵','🎸'],6,True)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Sa liste')}<ul style="{UL}">{irow(av('🦄',36),'La liste de Zoé','Tu la tiens · 5 idées, 1 cadeau prévu','',True,'V3Liste.dc.html')}</ul></section>
    <div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="V3TirageNouveau.dc.html" style="{BTN2}">{PLUS}Organiser un tirage</a></div>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Ses 3 ans','7 cadeaux offerts à Zoé','',True)}</ul></section>
  </main>'''
put('V3FeteAnniversaire',page('V3 · une fête pour quelqu’un',anniv,844).replace(HEADER,hd,1),844,'Fête · « pour quelqu’un » (un anniversaire) : sa liste d’abord ; un tirage reste possible',1,2)
def tile2(c,sel=False):
    e,bg=CAT[c]
    return (f'<button role="radio" aria-checked="{"true" if sel else "false"}" style="height: 84px; border: 0; border-radius: 14px; background: {bg if sel else CARD}; box-shadow: {"0 0 0 2px "+RED if sel else "0 0 0 1px "+LINE}; font-family: inherit; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; color: {INK}"><span aria-hidden="true" style="font-size: 26px; line-height: 1">{e}</span><span style="font-size: 13px; font-weight: 700">{c}</span></button>')
nouv=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Pour quelle occasion ?</h1>
    <div role="radiogroup" aria-label="C’est pour" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px">{"".join(tile2(c,c=="Anniversaire") for c in CAT)}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Pour qui ?</span><div style="display: flex; flex-wrap: wrap; gap: 8px">{"".join(f'<span style="height: 40px; padding: 0 12px 0 6px; border-radius: 999px; background: {"#f6e3ad" if n=="Zoé" else CARD}; box-shadow: {"0 0 0 2px "+RED if n=="Zoé" else "0 0 0 1px "+LINE}; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 700">{av(e,28)}{n}</span>' for e,n in (("🚀","Léo"),("🦄","Zoé"),("🐧","Moi")))}<span style="height: 40px; padding: 0 12px; border-radius: 999px; border: 1px dashed #cdb48a; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: {DRED}">Quelqu’un d’autre</span></div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son nom</label><div style="{FIELD}">L’anniversaire de Zoé</div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Sa date</span>{date3('14','décembre','2026','Date de la fête')}</div>
    <div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 4px"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Elle revient chaque année</span>{SW}</div>
    <a href="V3FeteMembresReprendre.dc.html" style="{BTN}; margin-top: 4px">Continuer</a>
  </main>'''
put('V3FeteNouvelle',page('V3 · une nouvelle fête',nouv,1000,withnav=False).replace(HEADER,hd,1),1000,'Première étape d’un Secret Santa ou d’une liste, quand l’occasion est nouvelle : « Pour quelle occasion ? », la catégorie d’abord, qui remplit le reste',1,3)
def pick(n,sel): return f'<span style="height: 40px; padding: 0 14px 0 10px; border-radius: 999px; background: {"#dcefe0" if sel else CARD}; box-shadow: {"0 0 0 2px #2f613f" if sel else "0 0 0 1px "+LINE}; display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 700; white-space: nowrap">🎄 {n}</span>'
mem=''.join(chk(av(e,36),n,s,on,i==0) for i,(e,n,s,on) in enumerate((('🦌','Camille','camille@exemple.fr',True),('👵','Mamie','mamie@exemple.fr',True),('🎸','Tonton','tonton@exemple.fr',True),('🍭','Inès','ines@exemple.fr',True),('🎄','Louis','louis@exemple.fr',False),('⛄','Tom','Pas d’adresse email',False))))
rep=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><p style="margin: 0; font-size: 14px; font-weight: 700; color: {MUT}">🎂 L’anniversaire de Zoé</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Qui est de la fête ?</h1></div>
    <div style="display: flex; flex-direction: column; gap: 8px">{SEC('Reprendre les membres de')}<div style="display: flex; gap: 8px; overflow: hidden; margin: 0 -16px; padding: 2px 16px">{pick('Famille Camille',True)}{pick('Chez Mamie',False)}{pick('Bureau, 3e étage',False)}</div></div>
    <ul style="{UL}">{mem}</ul>
    <ul style="{UL}">{irow(ICO('<path d="M10 14a4.500 4.500 0 0 0 6.400 0l3-3a4.500 4.500 0 0 0-6.400-6.400l-1 1"/><path d="M14 10a4.500 4.500 0 0 0-6.400 0l-3 3a4.500 4.500 0 0 0 6.400 6.400l1-1"/>'),'Inviter d’autres personnes','Par un lien, après avoir créé la fête','',True)}</ul>
    <a href="V3FeteAnniversaire.dc.html" style="{BTN}">Créer la fête · 5 membres</a>
  </main>'''
put('V3FeteMembresReprendre',page('V3 · reprendre les membres d’une autre fête',rep,900,withnav=False).replace(HEADER,hd,1),900,'Fête · nouvelle, suite : « Reprendre les membres d’une autre fête », on coche qui',1,4)

# =================== pages dérivées du groupe ===================
CALI=ICO('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>')
h=fete_words(R('GroupeReglages')).replace('>Réglages<','>Réglages de la fête<',1)
SET=f'''<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {MUT}">La fête</h2><ul style="{UL}">
      {irow(cat('Noël',36),'Catégorie','Noël','',True)}
      {irow(CALI,'Date','Le 25 décembre · proposée chaque année')}
      <li><div style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; border-top: 1px solid {SOFT}"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M3 12a9 9 0 0 1 15.500-6.300L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.500 6.300L3 16"/><path d="M3 21v-5h5"/>',18)}</span><span style="flex-grow: 1; font-weight: 600; font-size: 15px">Revient chaque année</span>{SW}</div></li>
    </ul></section>'''
m=re.search(r'<main[^>]*>',h); k=h.index('</h1>',m.end()); k=h.index('</div>',k)+6
h=h[:k]+'\n    '+SET+h[k:]
put('V3FeteReglages',v3(h,'V3 · réglages d’une fête'),1420,'Fête · réglages : la catégorie, la date, la récurrence, puis ceux du groupe d’aujourd’hui',2,0)
put('V3FeteMembres',v3(fete_words(R('GroupeMembres')),'V3 · membres d’une fête'),930,'Fête · ses membres (certains sans compte : ils participent au tirage, ils ne voient pas les listes)',2,1)
put('V3FeteInviter',v3(fete_words(R('GroupeInvitation')),'V3 · inviter dans une fête'),960,'Fête · inviter par lien',2,2)
rj=R('Rejoindre')
for a,b in [('Tu es invité au Secret Santa','Tu es invité à la fête'),('Noël 2026 · échange le 25 décembre · 5 personnes inscrites','🎄 Noël · le 25 décembre 2026 · 5 membres'),('Connecte-toi avec ton adresse email pour le rejoindre.','Connecte-toi avec ton adresse email pour la rejoindre : tu verras son tirage et les listes de ses membres.'),('Les organisateurs des groupes que tu rejoins la voient','Les organisateurs des fêtes que tu rejoins la voient'),('Rejoindre un groupe — sans session','V3 · rejoindre une fête')]:
    assert a in rj,a; rj=rj.replace(a,b)
put('V3FeteRejoindre',rj,900,'Fête · le lien d’invitation, sans compte : plus de « Secret Santa », on rejoint une fête',2,3)

# =================== TIRAGE ===================
h=R('EditionNouvelle')
for a,b in [('Nouvelle édition','Le tirage 2027'),('Nom de l’édition','Nom du tirage'),('Créer l’édition','Créer le tirage'),('participants repris.','membres repris du tirage 2026.')]: h=h.replace(a,b)
h=h.replace('<input id="dt" type="text" placeholder="jj/mm/aaaa"','<input id="dt" type="text" value="25/12/2027" placeholder="jj/mm/aaaa"',1)
h=re.sub(r'<button style="align-self: flex-start; min-height: 44px;[^>]*>Proposer le 25 décembre 2027</button>','',h,count=1)
_a=h.index('<div style="position: relative">',h.index('<label for="dt"')); _b=h.index('</div>',h.index('aria-label="Ouvrir le calendrier"'))+len('</div>')
h=h[:_a]+date3('25','décembre','2027','Date de la fête')+h[_b:]
h=h.replace('<label for="dt" style=','<span style=',1)
assert h.count('Date de la fête</label>')==1; h=h.replace('Date de la fête</label>','Date de la fête</span>',1)
# Retour de Julien : les pistes de cadeaux et le mot des messages se règlent dès la création
_i=h.index('<li><a href="EditionMot.dc.html"'); _j=h.index('</li>',_i)+5; _li=h[_i:_j]
assert _li.count('Petit mot pour les participants')==1 and _li.count('>Aucun<')==1
_bt=_li.replace('min-height: 56px;','min-height: 56px; border-top: 1px solid #dccbad;',1); assert _bt!=_li
_pistes=_li.replace('Petit mot pour les participants','Pistes de cadeaux',1).replace('Facultatif. Affiché avec le résultat.','Portrait et idées précises',1).replace('<span style="font-size: 15px; color: #57534e">Aucun</span>','',1).replace('EditionMot.dc.html','#',1)
_mot=_bt.replace('Petit mot pour les participants','Mot ajouté aux messages',1).replace('<span style="font-size: 13px; color: #57534e">Facultatif. Affiché avec le résultat.</span>','',1).replace('EditionMot.dc.html','#',1)
assert 'Aucun' not in _pistes and 'Facultatif' not in _mot
h=h[:_i]+_pistes+_bt+_mot+h[_j:]
# Retour de Julien : le nom, la date et le budget ont la même tête que les autres lignes (une ligne, sa valeur, un chevron ; toucher ouvre une page, comme la fiche d'un proche)
_SUB='<span style="font-size: 13px; color: #57534e">Facultatif. Affiché avec le résultat.</span>'
_VAL='<span style="font-size: 15px; color: #57534e">Aucun</span>'
assert _li.count(_SUB)==1 and _li.count(_VAL)==1
def _row(t,val='',sub='',first=False):
    x=(_li if first else _bt).replace('EditionMot.dc.html','#',1).replace('Petit mot pour les participants',t,1)
    x=x.replace(_SUB,'<span style="font-size: 13px; color: #57534e">'+sub+'</span>' if sub else '',1)
    return x.replace(_VAL,'<span style="font-size: 15px; color: #57534e">'+val+'</span>' if val else '',1)
_ROWS=(_row('Nom','Noël 2027',first=True)+_row('Date de la fête','25 décembre 2027')+_row('Budget','30 €')+_row('Devine qui','Qui m’offre ?')
       +_row('Petit mot pour les participants','Aucun')+_row('Mot ajouté aux messages','Aucun'))
_u=h.rindex('<ul',0,h.index('Pistes de cadeaux')); _u2=h.index('>',_u)+1; _v=h.index('</ul>',_u)
h=h[:_u2]+_ROWS+h[_v:]
_a=h.rindex('<div',0,h.index('<label for="nm"')); _b=h.index('</div>',h.index('id="bg"'))+6
assert h[_a:_b].count('<label for="nm"')==1 and h[_a:_b].count('role="group"')==1
h=h[:_a]+h[_b:].lstrip()
h=re.sub(r'\s*<p\b[^>]*>[^<]*Affiché avec le résultat\.</p>','',h)
_n=1
h=re.sub(r'\s*<p\b[^>]*>[^<]*Affiché avec le résultat\.</p>','',h,count=1)
put('V3TirageNouveau',v3(h,'V3 · le tirage de l’année'),900,'Tirage · celui de l’année : la date de la fête est déjà là, et se change',3,0)
# Plus de demande pendant la bêta (Julien, 20 novembre 2026) : la limite de 3 Secret Santa par compte suffit
_lim=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Tu organises déjà 3 Secret Santa</h1>
    <p style="margin: 0; padding: 0 4px; font-size: 15px; line-height: 1.45; color: {MUT}">C’est le maximum pour un compte.</p>
    <ul style="{UL}">{irow(tl(),'Bureau, 3e étage','Noël 2026 · tirage fait','',True)}{irow(tl(),'Les cousins','Week-end d’été 2027 · pas encore tiré')}{irow(tl(),'Le club de lecture','Noël 2026 · tirage fait')}</ul>
  </main>'''
put('V3TirageLimite',page('V3 · la limite de 3 Secret Santa',_lim,844,withnav=False).replace(HEADER,hd,1),844,'Secret Santa · la limite : 3 par compte, sans demande à personne',3,1)
h=R('PistesResultatListe')
for a,b in [('Sa liste de cadeaux : Noël 2026','La liste de cadeaux d’Inès'),('Journal du groupe','Journal de la fête'),('>Mes pistes de cadeaux<','>Ma liste de cadeaux<'),('Remplies, modifiables jusqu\'à la fête','Vue seulement par celui qui m’a tiré'),('href="Pistes.dc.html"','href="V3ListeSecret.dc.html"'),('href="ListeVisiteurTirage.dc.html"','href="V3ListeSurligne.dc.html"')]:
    assert a in h,a; h=h.replace(a,b)
put('V3TirageVersListe',v3(h,'V3 · du tirage à la liste'),1422,'Tirage · du résultat à la liste : celle d’Inès est dans la même fête, le mode anonyme s’active seul',3,2)
RESULT=h
for a,b in [('Famille Camille · Noël 2026','Les cousins · Week-end d’été 2027'),('ven. 25 décembre','sam. 12 juin'),('Fête · dans 40 jours','Fête · dans 23 jours'),('On ouvre les cadeaux après le dessert !','On s’offre ça le samedi soir, au bord du lac.')]:
    assert a in h,a; h=h.replace(a,b)
put('V3TirageNeutre',v3(h,'V3 · un Secret Santa hors de Noël'),1426,'Tirage · hors de Noël (catégorie « Autre ») : aucun mot de Noël, ni « Père Noël » ni « Secret Santa »',3,3)

PEOPLE=ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',20)
def vbar(t,sub):
    return (f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); min-height: 52px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 10px">'
            f'<span style="display: flex; color: #274e34">{PEOPLE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; min-height: 48px"><span style="font-size: 14px; font-weight: 700">{t}</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">{sub}</span></span>'
            f'<a href="FeteChoisir.dc.html" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">Modifier</a></div>')
def swap_bar(h,new):
    i=h.index('<div data-pub="1"'); j=i; d=0
    for mm in re.finditer(r'<div\b|</div>',h[i:]):
        d+=1 if mm.group(0)!='</div>' else -1
        if d==0: j=i+mm.end(); break
    return h[:i]+new+h[j:]

# =================== LISTES ===================
def seg(sel):
    def b(t,on): return ('<button role="radio" aria-checked="'+('true' if on else 'false')+'" style="height: 40px; padding: 0 14px; border: 0; border-radius: 999px; background: '+('#f1e8fc' if on else CARD)+'; box-shadow: '+('0 0 0 2px '+RED if on else '0 0 0 1px '+LINE)+'; font-family: inherit; font-size: 14px; font-weight: 700; color: '+INK+'">'+t+'</button>')
    return '<li><div role="radiogroup" aria-label="Dans Famille Camille, qui la verra" style="display: flex; flex-wrap: wrap; gap: 8px; padding: 0 16px 14px 64px">'+b('Toute la fête',sel==0)+b('Celui qui m’a tiré',sel==1)+'</div></li>'
def qui(sel,mamie):
    return (QUI0.replace('<!--SEG-->',seg(sel),1) if mamie else QUI0.replace('<!--SEG-->',seg(sel),1).replace(chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',True),chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',False),1))
QUI0=(f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px">Qui verra ta liste ?</h2>'
     f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'
     +chk(cat('Noël'),'Famille Camille','Noël · 12 membres',True,True)+'<!--SEG-->'+chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',True)+chk(cat('Noël'),'Bureau, 3e étage','Noël · 8 membres',False)+chk(cat('Anniversaire'),'Les 40 ans de Tonton','Anniversaire · 15 membres',False)+'<li><a href="V3FeteNouvelle.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid '+SOFT+'; text-decoration: none; color: '+INK+'"><span aria-hidden="true" style="width: 32px; height: 32px; box-sizing: border-box; border-radius: 9px; border: 1.5px dashed #cdb48a; color: '+DRED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+PLUS+'</span><span style="flex-grow: 1; font-weight: 600; font-size: 16px">Une autre occasion</span><span style="color: #78716c; display: flex">'+CHEV+'</span></a></li>'+'</ul>'
     f'<div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 20px"><span style="display: flex; color: {MUT}">{GLOBE}</span><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">Tout le monde, avec un lien</span><span style="font-size: 13px; color: {MUT}">Une liste publique : pour un mariage, ou quelqu’un hors de tes fêtes</span></span>{SWOFF}</div>'
     f'<div style="padding: 0 16px"><a href="V3ListeNouvelle.dc.html" style="{BTN}">Continuer</a></div>')
put('V3ListeQui',sheet(page('V3 · qui verra ta liste ?',MAINA,HA),qui(0,True),250,'Qui verra ta liste ?'),HA,'Liste · première étape : « Qui verra ta liste ? », une ou plusieurs de mes fêtes ou une autre occasion ; en plus, tout le monde avec un lien',4,0)
put('V3Liste',v3(swap_bar(R('ListeTeneur'),vbar('Famille Camille, Chez Mamie','21 membres la voient').replace('FeteChoisir.dc.html','V3ListeQui.dc.html')),'V3 · ma liste, dans ses fêtes'),None,'Liste · la mienne : la barre dit dans quelles fêtes elle est ; « Modifier » rouvre « Qui verra ta liste ? »',4,1)
pubbar=(f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); padding: 6px 8px 8px 14px; display: flex; flex-direction: column; gap: 6px">'
        f'<div style="display: flex; align-items: center; gap: 10px; min-height: 44px"><span style="display: flex; color: #274e34">{GLOBE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 14px; font-weight: 700">Publique, avec un lien</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">Et dans la fête « Notre mariage »</span></span><a href="V3ListeQui.dc.html" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">Modifier</a></div>'
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 6px 6px 6px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/l/k3Fq9xT2</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; flex-shrink: 0">{SHARE}Partager</button></div></div>')
put('V3ListePublique',v3(swap_bar(R('ListeSansPersonne'),pubbar),'V3 · une liste publique'),None,'Liste · publique (un mariage) : dans sa fête, et ouverte à tous par un lien, sans compte pour cocher',4,3)
h=swap_bar(R('ListeNouvelle'),vbar('Famille Camille, Chez Mamie','21 membres la verront').replace('FeteChoisir.dc.html','V3ListeQui.dc.html'))
h=h.replace('>Nom de l’événement<','>Noël 2026<',1).replace('>Ajouter une date<','>Le 25 décembre<',1).replace('>🎁<','>🎄<',1)
put('V3ListeNouvelle',v3(h,'V3 · une nouvelle liste, dans une fête'),None,'Liste · nouvelle : le nom, la date et l’icône viennent de la fête',4,2)
h=R('ListeGroupeFil')
FRB=re.compile(r'<button aria-label="Langue : français"[^>]*>FR</button>')
h=FRB.sub(AVB,h,count=1)
m=re.search(r'<main[^>]*>',h)
CHR12=ic('<path d="m9 6 6 6-6 6"/>',12,2.8)
NOELBG=CAT['Noël'][1]
h=h[:m.end()]+'\n    <a href="V3Fete.dc.html" style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 10px 0 8px; border-radius: 999px; background: '+NOELBG+'; font-size: 13px; font-weight: 700; color: #274e34; text-decoration: none">🎄 Famille Camille'+CHR12+'</a>'+h[m.end():]
h=re.sub(r'<title>[^<]*</title>','<title>V3 · la liste d’un autre membre</title>',h,count=1)
put('V3ListeMembre',h,None,'Liste · celle d’un autre membre : on y arrive par la fête, sans lien ; la fête est rappelée en haut',4,4)
ail=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Ce que j’offre ailleurs','Les listes publiques où tu as coché quelque chose.')}
    <ul style="{UL}">{irow(cat('Mariage',36),'Le mariage de Karim et Sofia','Le 12 juin · tu offres : un plaid en laine','',True,'V3ListePublique.dc.html')}{irow(cat('Crémaillère',36),'La crémaillère d’Inès','Cette liste n’est plus partagée · tu offrais : une plante')}</ul>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: {MUT}">Ouvrir une liste sans rien cocher ne laisse aucune trace ici.</p>
  </main>'''
put('V3OffreAilleurs',page('V3 · ce que j’offre ailleurs',ail,844).replace(HEADER,hd,1),844,'Liste · « Ce que j’offre ailleurs » : les listes publiques où j’ai coché, pas celles que j’ai seulement ouvertes',4,5)

# =================== LE « + » DE L'ACCUEIL ===================
MAINB=MAINA
PLUS24=ic('<path d="M12 5v14M5 12h14"/>',24,2.4)
ROND='border-radius: 999px; background: '+RED+'; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; text-decoration: none'
# Julien n'aime ni le rond rouge en bas, ni le rond rouge à côté du titre : deux autres pistes, sans rond rouge
PLUSC=ic('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',22)
TABC=('<a href="V3AccueilPlusOuvert.dc.html" style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: '+MUT+'; font-size: 12px; font-weight: 600"><span style="position: relative; display: flex">'+PLUSC+'</span>Créer</a>')
assert nav().count('</a><a ')==1
NAVP=nav().replace('</a><a ','</a>'+TABC+'<a ',1)
def pagep(title,main,h):
    x=page(title,main,h); assert x.count(nav())==1
    return x.replace(nav(),NAVP,1)
H1P=('<div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 4px 4px 0"><h1 style="margin: 0; font-family: '+F+'; font-weight: 700; font-size: 30px; line-height: 1.1">Bonjour Hugo</h1>'
     '<a href="V3AccueilPlusOuvert.dc.html" style="height: 40px; padding: 0 14px 0 10px; border-radius: 999px; background: '+CARD+'; box-shadow: 0 0 0 1px '+LINE+'; color: '+INK+'; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px; flex-shrink: 0">'+PLUS+'Créer</a></div>')
assert MAINB.count(H1('Bonjour Hugo'))==1
MAINC=MAINB.replace(H1('Bonjour Hugo'),H1P,1)
# Retenu par Julien : la piste D seule, l'onglet « Créer » ; il est posé sur toutes les pages qui ont la barre du bas, à la fin (voir « ONGLET CRÉER »)
CREER=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px">Créer</h2>'
       '<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'">'
       +irow(_TLC(),'Un tirage','Dans une de tes fêtes, ou dans une nouvelle','',True,'V3TirageQuelleFete.dc.html')
       +irow(_LLC(),'Une liste','Dans une de tes fêtes, ou publique avec un lien','',False,'V3ListeQui.dc.html')+'</ul>')
def sheetb(h,inner,label):
    S=('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
       '<div role="dialog" aria-label="'+label+'" style="position: absolute; left: 0; right: 0; bottom: 0; box-sizing: border-box; z-index: 5; background: '+CARD+'; border-radius: 20px 20px 0 0; padding: 10px 0 28px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
       '<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>'+inner+'</div>')
    h=rel(h); z=h.rindex('</div>\n</x-dc>'); return h[:z]+S+h[z:]
put('V3AccueilPlusOuvert',sheetb(page('V3 · accueil, « Créer » touché',MAINB,1320),CREER,'Créer'),1320,'Accueil · l’onglet « Créer » touché : un Secret Santa ou une liste ; la fête est la première étape des deux',0,3)

# =================== UN TIRAGE : DANS QUELLE FÊTE ? ===================
def rad(lead,t,sub,on,first=False):
    b=('<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; border: 2px solid '+RED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><span style="width: 12px; height: 12px; border-radius: 50%; background: '+RED+'"></span></span>' if on else
       '<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; border: 2px solid #a8a29e; flex-shrink: 0"></span>')
    return ('<li><button role="radio" aria-checked="'+('true' if on else 'false')+'" style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border: 0;'+('' if first else ' border-top: 1px solid '+SOFT+';')+' background: transparent; font-family: inherit; text-align: left; color: '+INK+'">'
            +lead+'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">'+t+'</span><span style="font-size: 13px; line-height: 1.35; color: '+MUT+'">'+sub+'</span></span>'+b+'</button></li>')
NEWF='<span aria-hidden="true" style="width: 36px; height: 36px; box-sizing: border-box; border-radius: 10px; border: 1.5px dashed #cdb48a; color: '+DRED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+PLUS+'</span>'
QUELLE=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px">Un tirage dans quelle fête ?</h2>'
        '<ul role="radiogroup" aria-label="La fête du Secret Santa" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'; border-bottom: 1px solid '+SOFT+'">'
        +rad(cat('Noël'),'Bureau, 3e étage','Noël · 8 membres · déjà un tirage cette année',True,True)
        +rad(NEWF,'Une autre occasion','Elle se crée avec le tirage : un nom, une date',False)+'</ul>'
        '<p style="margin: 0; padding: 0 20px; font-size: 13px; line-height: 1.4; color: '+MUT+'">Dans tes autres fêtes, c’est l’organisateur qui lance le tirage.</p>'
        '<div style="padding: 0 16px"><a href="V3TirageNouveau.dc.html" style="'+BTN+'">Continuer</a></div>')
put('V3TirageQuelleFete',sheetb(page('V3 · un tirage dans quelle fête ?',MAINB,1320),QUELLE,'Pour quelle occasion ?'),1320,'x',0,4)

# =================== PISTES ET LISTES FUSIONNÉES ===================
# Julien, 20 novembre 2026 : plus de « pistes » ; celui qui m'a tiré voit ma liste, que je peux ne montrer qu'à lui.
_ls=swap_bar(R('ListeTeneur'),vbar('Famille Camille','Seul celui qui m’a tiré la voit').replace('FeteChoisir.dc.html','V3ListeQuiSecret.dc.html'))
_a='<a href="V3ListeNouvelle.dc.html" style="'+BTN+'">Continuer</a>'; _qs=qui(1,False); assert _qs.count(_a)==1; _qs=_qs.replace(_a,'<a href="V3ListeSecret.dc.html" style="'+BTN+'">Enregistrer</a>')
put('V3ListeQuiSecret',sheet(v3(_ls,'V3 · qui verra ta liste ? celui qui m’a tiré'),_qs,250,'Qui verra ta liste ?'),None,'x',4,6)
put('V3ListeSecret',v3(_ls,'V3 · ma liste, pour celui qui m’a tiré'),None,'Liste · la mienne, montrée seulement à celui qui m’a tiré : les anciennes « pistes de cadeaux »',4,7)
_T=('<div role="status" style="position: sticky; bottom: 16px; z-index: 6; margin: 0 16px 16px; min-height: 52px; padding: 10px 8px 10px 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; gap: 12px; font-size: 15px; font-weight: 600">'
    '<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span>C’est enregistré</span><span style="font-size: 13px; font-weight: 400; line-height: 1.35">Un compte a été créé avec ton adresse, pour retrouver ta liste.</span></span>'
    '<button style="height: 40px; padding: 0 14px; border: 0; border-radius: 999px; background: rgba(255, 255, 255, 0.16); color: #ffffff; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Compris</button></div>')
_lc=v3(_ls,'V3 · le compte se crée à la première idée'); _z=_lc.rindex('</div>\n</x-dc>')
put('V3ListeCompteCree',_lc[:_z]+_T+_lc[_z:],None,'Liste · sans compte, par son lien : le compte se crée tout seul à la première chose écrite, et on le dit',4,8)

# Sans adresse email (lien copié) : pas de liste sans adresse, on la demande au moment d'écrire sa liste (Julien)
_ad=R('ProcheAdresse')
for _x,_y in [('Mes proches · Léo','Famille Camille · Secret Santa 2026'),('>Son adresse email<','>Ton adresse email, pour écrire ta liste<'),('href="ListePersonne.dc.html"','href="V3ListeSecret.dc.html"')]:
    assert _ad.count(_x)==1,_x; _ad=_ad.replace(_x,_y)
_MENU=re.search(r'<button aria-label="Menu"[^>]*>.*?</button>',_ad,re.S).group(0)
_FR='<button aria-label="Langue : français" style="justify-self: end; height: 44px; min-width: 44px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600">FR</button>'
_ad=_ad.replace(_MENU,_FR,1)
_k=_ad.index('</main>')
_ad=_ad[:_k]+'  <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Elle crée ton compte, sans mot de passe : tu reçois un lien pour la confirmer. <a href="Confidentialite.dc.html" style="color: #8a2f27; text-decoration: underline">Tes données, en clair</a></p>\n  '+_ad[_k:]
_ad=re.sub(r'<title>[^<]*</title>','<title>V3 · une adresse pour écrire sa liste</title>',_ad,count=1)
put('V3ListeAdresse',_ad,None,'Liste · arrivé par un lien copié, sans adresse email : on la demande au moment d’écrire sa liste ; pas de liste sans adresse',4,9)
# Celui qui m'a tiré arrive sur la liste entière, ma partie surlignée (Julien)
_sl=V['V3ListeMembre'][0]
_tv=open('/home/claude/utt/v2/ListeVisiteurTirage.dc.html',encoding='utf-8').read()
_i=_tv.index('<div data-mode="anonyme"'); _d=0
for _mm in re.finditer(r'<div\b|</div>',_tv[_i:]):
    _d+=1 if _mm.group(0)!='</div>' else -1
    if _d==0: _j=_i+_mm.end(); break
_bar=_tv[_i:_j]; _n=_bar.index('<div data-note="tirage"'); _d=0
for _mm in re.finditer(r'<div\b|</div>',_bar[_n:]):
    _d+=1 if _mm.group(0)!='</div>' else -1
    if _d==0: _bar=_bar[:_n]+_bar[_n+_mm.end():]; break
_m=re.search(r'<main[^>]*>',_sl); _sl=_sl[:_m.end()]+'\n    '+_bar+_sl[_m.end():]
_c=_sl.index('>Camille</h2>'); _s0=_sl.rindex('<section',0,_c); _s1=_sl.index('</section>',_c)+10
_sec=_sl[_s0:_s1]
for _x,_y in [('>Camille</h2>','>Inès</h2>'),('>🦌</span>','>🍭</span>')]:
    assert _sec.count(_x)==1,(_x,_sec.count(_x)); _sec=_sec.replace(_x,_y)
_sl=_sl[:_s0]+_sec+_sl[_s1:]
for _x,_y in [('La liste de Camille et Hugo. Camille seule voit qui a coché quoi.','La liste d’Inès.')]:
    assert _sl.count(_x)==1,_x; _sl=_sl.replace(_x,_y)
_sl=re.sub(r'<title>[^<]*</title>','<title>V3 · la liste de la personne tirée</title>',_sl,count=1)
put('V3ListeSurligne',_sl,None,'Secret Santa · la liste de la personne tirée : la liste entière, la page s’ouvre calée sur sa partie (ici Inès, en bas), le mode anonyme déjà activé',3,5)

# =================== RÉGLAGES : ceux de la fête, ceux du Secret Santa ===================
# Retour de Julien : les pistes de cadeaux (et ce qui ne concerne que le tirage) ne sont plus un réglage de la fête.
_h,_ht,_t,_row,_col=V['V3FeteReglages']
_secs=list(re.finditer(r'<section\b.*?</section>',_h,re.S)); assert len(_secs)==6
def _name(x): return re.search(r'<h2[^>]*>([^<]*)</h2>',x).group(1) if '<h2' in x else ''
_by={_name(m.group(0)):m.group(0) for m in _secs}
assert set(_by)=={'La fête','Tirage','Participants','M’écrire par email','Organisateurs',''},set(_by)
_mail=_by['M’écrire par email']; _lis=re.findall(r'<li\b.*?</li>',_mail,re.S); assert len(_lis)==3
def _keep(sec,lis):
    i=sec.index(_lis[0]); j=sec.index(_lis[2])+len(_lis[2]); return sec[:i]+'\n        '.join(lis)+sec[j:]
_pre=_h[:_secs[0].start()]; _post=_h[_secs[-1].end():]
_SSROW=('<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: '+MUT+'">Secret Santa</h2><ul style="'+UL+'">'
        +irow(tl(),'Le Secret Santa 2026','Ses réglages : mot des messages, rappels','',True,'V3TirageReglages.dc.html')+'</ul></section>')
# Julien, 21 novembre 2026 : le lien d'invitation est celui d'un Secret Santa ; son email (« quelqu'un s'inscrit par le lien ») part avec lui dans les réglages du Secret Santa.
_f=_pre+'\n    '.join([_by['La fête'],_SSROW,_by['Organisateurs'],_by['']])+_post
V['V3FeteReglages']=(_f,1000,'Fête · réglages : la catégorie, la date, la récurrence, les organisateurs ; ceux du Secret Santa sont sur le Secret Santa',_row,_col)
_NOTE='<p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Repris tels quels quand tu prépares le Secret Santa de l’année suivante.</p>'
_pl=re.findall(r'<li\b.*?</li>',_by['Participants'],re.S); assert len(_pl)==2 and 'Pistes de cadeaux' in _pl[0]
_part=_by['Participants'].replace(_pl[0],'',1).replace('>Participants</h2>','>Les messages</h2>',1)
_dq=_by['Tirage']; assert _dq.count('Éviter la même personne')==1 and _dq.count('Que l’an dernier')==1
_dq=re.sub(r'\s*<p\b[^>]*>Plus la période est longue[^<]*</p>','',_dq.replace('>Tirage</h2>','>Devine qui</h2>',1).replace('Éviter la même personne','Pronostics',1).replace('Que l’an dernier','Qui m’offre ?',1))
# Q-015 (Claude Code, 21 novembre) : le nom, la date, le budget et le petit mot d'un Secret Santa déjà créé se changent ici, en tête, dans l'ordre du formulaire de création.
_t1=re.findall(r'<li\b.*?</li>',_by['Tirage'],re.S); assert len(_t1)==1
def _essl(k,v,first):
    x=_t1[0]; assert x.count('Éviter la même personne')==1 and x.count('Que l’an dernier')==1
    x=x.replace('Éviter la même personne',k,1).replace('Que l’an dernier',v,1)
    assert x.count('box-sizing: border-box; text-decoration: none')==1
    return x if first else x.replace('box-sizing: border-box; text-decoration: none','box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration: none',1)
_essr=[('Nom','Noël 2026'),('Date','25 décembre 2026'),('Budget','30 €'),('Petit mot pour les participants','Aucun')]
_ess=_by['Tirage'].replace('>Tirage</h2>','>Le Secret Santa</h2>',1).replace(_t1[0],'\n        '.join(_essl(k,v,i==0) for i,(k,v) in enumerate(_essr)),1)
_g=_pre+'\n    '.join([_ess,_by['Tirage'].replace('>Tirage</h2>','>Le tirage au sort</h2>',1),_dq,_part,_mail])+_post
assert _g.count('>Réglages de la fête<')==1 and _g.count('>Famille Camille</a></nav>')==1
_g=_g.replace('>Réglages de la fête<','>Réglages<',1).replace('>Famille Camille</a></nav>','>Famille Camille · Secret Santa 2026</a></nav>',1)
_g=re.sub(r'<title>[^<]*</title>','<title>V3 · réglages d’un Secret Santa</title>',_g,count=1)
put('V3TirageReglages',_g,1060,'Secret Santa · ses réglages : son nom, sa date, son budget et son petit mot d’abord ; puis éviter la même personne, Devine qui, le mot des messages, les emails du tirage',3,4)

# =================== CE QUI RESTAIT À DESSINER (tickets de conception D01 à D03) ===================
# D01 · « Les fêtes passées », et une année passée d'une fête
I_DEV='<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>'   # la loupe : l'icône du jeu, partout (Julien, 23 novembre 2026)
dl=lambda: _trait(I_DEV,MUT)
def _an(y,rows): return f'<section style="display: flex; flex-direction: column; gap: 6px">{SEC(y)}<ul style="{UL}">{rows}</ul></section>'
_fp=f"""<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Les fêtes passées')}
    {_an('2026',irow(cat('Anniversaire',36),'Les 6 ans de Léo','12 septembre · 8 cadeaux offerts','',True)+irow(cat('Crémaillère',36),'La crémaillère d’Inès','14 mars · tu as offert 1 cadeau'))}
    {_an('2025',irow(cat('Noël',36),'Famille Camille','25 décembre · tu offrais à Zoé','',True,'V3FeteAnneePassee.dc.html')+irow(cat('Noël',36),'Chez Mamie','24 décembre · tu as offert 3 cadeaux')+irow(cat('Noël',36),'Bureau, 3e étage','19 décembre · tu offrais à Inès'))}
    {_an('2024',irow(cat('Noël',36),'Famille Camille','25 décembre · tu offrais à Camille','',True))}
  </main>"""
put('V3FetesPassees',page('V3 · les fêtes passées',_fp,900).replace(HEADER,hd,1),900,'Accueil · « Les fêtes passées » : par année, la plus récente en haut ; une fête qui revient y laisse une ligne par année',0,5)
_ap=f"""<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {fhead('Noël','Noël 2025','Famille Camille','25 décembre 2025').replace(f'font-weight: 700; color: {DRED}">25 décembre 2025',f'font-weight: 700; color: {MUT}">25 décembre 2025')}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le Secret Santa')}<ul style="{UL}">{irow(tl(),'Le Secret Santa 2025','Tu offrais à Zoé','',True,'TirageClotureDevoile.dc.html')}{irow(dl(),'Devine qui','Le palmarès','',False,'DevinePalmaresVu.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes')}<ul style="{UL}">{irow(av('🐧',36),'Ma liste','Léo, Zoé et moi · 9 idées','',True)}{irow(av('🦌',36),'La liste de Camille','Tu as offert 1 cadeau')}{irow(av('👵',36),'La liste de Mamie','Tu as offert 2 cadeaux')}</ul></section>
  </main>"""
assert f'color: {MUT}">25 décembre 2025' in _ap
put('V3FeteAnneePassee',page('V3 · une année passée d’une fête',_ap,844).replace(HEADER,hd,1),844,'Fête · une année passée (Noël 2025) : son Secret Santa et ses listes, en lecture seule ; rien à créer, rien à régler',1,6)

# D02 · l'accueil quand le jeu est là : « Devine qui » ouvert dans une fête, un Secret Santa dévoilé dans une autre (jamais un résultat de tirage sur l'accueil)
_LM=irow(ll(),'La liste de Mamie','Tu offres 2 cadeaux','',True)+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi dans Famille Camille','',False,'V3Liste.dc.html')
NOELJ=(season('Noël 2026','dans 3 jours')
  +fcard2('Noël','Bureau, 3e étage','19 déc.',irow(tl(),'Le Secret Santa','Dévoilé · qui a offert à qui',dot(),True,'TirageClotureDevoile.dc.html')+irow(dl(),'Devine qui','Le palmarès est là',dot(),False,'DevinePalmares.dc.html'),href='V3FeteOrganisateur.dc.html')
  +fcard2('Noël','Chez Mamie','24 déc.',_LM,href='V3Fete.dc.html')
  +fcard2('Noël','Famille Camille','25 déc.',irow(tl(),'Le Secret Santa','Tu sais à qui tu offres','',True,'V3TirageVersListe.dc.html')+irow(dl(),'Devine qui','À toi de jouer · jusqu’au 25 décembre à 18 h',dot(),False,'DevineChoisir.dc.html')+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',False,'V3Liste.dc.html')+irow(ll(),'La liste de Camille','Tu offres 1 cadeau','',False,'V3ListeMembre.dc.html'),href='V3Fete.dc.html'))
MAINJ=f"""<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}{NOELJ}{TARD}{BAS}
  </main>"""
put('V3AccueilJeu',page('V3 · accueil, le jeu',MAINJ,1260),1260,'Accueil · le 22 décembre : « Devine qui » ouvert dans une fête, un Secret Santa dévoilé et son palmarès dans une autre ; aucun résultat de tirage sur l’accueil',0,6)

# D03 · la limite de 30 membres par fête, vue par l'organisateur (celui qui ouvre un lien complet voit « RejoindreFerme »)
_mc=V['V3FeteMembres'][0]
_i=_mc.index('Ajouter une personne'); _a=_mc.rindex('<li>',0,_i); _b=_mc.index('</li>',_i)+5
_full=(f'<li><div style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid #e9dcc5; color: #292524">'
       f'<span aria-hidden="true" style="width: 40px; height: 40px; border-radius: 50%; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic("<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><path d=\"M22 21v-2a4 4 0 0 0-3-3.870\"/><path d=\"M16 3.130a4 4 0 0 1 0 7.750\"/>",20)}</span>'
       f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-weight: 600; font-size: 16px">La fête est complète</span><span style="font-size: 14px; line-height: 1.35; color: #57534e">30 membres, c’est le maximum</span></span></div></li>')
_mc=_mc[:_a]+_full+_mc[_b:]
for a,b in [('Actif · 10 places restantes','En pause · la fête est complète'),('>Membres</h1>','>Membres</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: #57534e">30 sur 30</p>'),('V3 · membres d’une fête','V3 · une fête complète')]:
    assert _mc.count(a)==1,(a,_mc.count(a)); _mc=_mc.replace(a,b)
_i=_mc.index('Ou laisse-les s’inscrire'); _a=_mc.rindex('<h2',0,_i); _b=_mc.index('</h2>',_i)+5
_mc=_mc[:_a]+_mc[_b:]
put('V3FeteMembresComplet',_mc,930,'Fête · complète, vue par l’organisateur : 30 membres, plus d’« Ajouter une personne », le lien d’invitation en pause',2,4)

# D05 · l'administration sans demandes : des fêtes, des comptes, la limite de Secret Santa d'un compte, et « Suspendre les nouveaux Secret Santa »
def _sw(h,a,b,n=1):
    assert h.count(a)==n,(a,h.count(a)); return h.replace(a,b)
_ad0=R('Admin')
_navadm=re.search(r'<a href="Admin\.dc\.html" aria-current="page".*?</a>',NAVRE.search(_ad0).group(0),re.S).group(0)
_navadm=_sw(_sw(_navadm,'>4</span>','>2</span>'),', 4 à traiter',', 2 à traiter').replace('href="Admin.dc.html"','href="V3Admin.dc.html"')
_nv0=nav('aucun'); assert 'aria-current' not in _nv0
NAVADM3=_nv0.replace('</a><a ','</a>'+TABC+'<a ',1).replace('</nav>',_navadm+'</nav>',1)
_a=BURG.sub(AVB,_ad0,count=1); _a=NAVRE.sub(lambda m:NAVADM3,_a,count=1)
_a=re.sub(r'<title>[^<]*</title>','<title>V3 · administration</title>',_a,count=1)
_i=_a.index('>Demandes<'); _x=_a.rindex('<li',0,_i); _y=_a.index('</li>',_i)+5; _a=_a[:_x]+_a[_y:]
_i=_a.index('>Signalements<'); _x=_a.rindex('<li',0,_i); _seg=_a[_x:_i]; assert _seg.count('border-top: 1px solid #e9dcc5; ')==1
_a=_a[:_x]+_seg.replace('border-top: 1px solid #e9dcc5; ','')+_a[_i:]
_i=_a.index('Demandes refusées pour débit'); _x=_a.rindex('<li',0,_i); _y=_a.index('</li>',_i)+5; _cnt=_a[_x:_y]
def _c(t,n): return _sw(_sw(_cnt,'Demandes refusées pour débit, aujourd’hui',t),'>14<','>%s<'%n)
_a=_a[:_x]+_c('Comptes à leur limite de Secret Santa','2')+_c('Fêtes à 30 membres','1')+_c('Requêtes refusées pour débit, aujourd’hui','14')+_a[_y:]
_i=_a.index('Suspendre les inscriptions'); _x=_a.rindex('<li',0,_i); _y=_a.index('</li>',_i)+5; _s=_a[_x:_y]
_s2=_sw(_sw(_s,'Suspendre les inscriptions','Suspendre les nouveaux Secret Santa',2),'Ni nouveau compte, ni nouveau groupe','Ceux qui existent continuent')
_a=_a[:_y]+_s2+_a[_y:]
for a,b in [('>groupes<','>fêtes<'),('+3 · 9 tirages en cours','+3 · 9 Secret Santa en cours'),('Ni nouveau compte, ni nouveau groupe','Ni nouveau compte, ni nouvelle fête'),('Passé aujourd’hui à 9 h 00 · 2 groupes','Passé aujourd’hui à 9 h 00 · 2 fêtes'),('href="AdminComptes.dc.html"','href="V3AdminComptes.dc.html"')]:
    assert a in _a,a; _a=_a.replace(a,b)
_i=_a.index('À traiter et à surveiller'); _y=_a.index('</h2>',_i); _seg=_a[_i:_y]; assert _seg.count('>4<')==1,_seg; _a=_a[:_i]+_seg.replace('>4<','>2<')+_a[_y:]
put('V3Admin',_a,1980,'Administration · le tableau de bord : des fêtes, plus de « Demandes » ; les limites atteintes se surveillent ; « Suspendre les nouveaux Secret Santa » avec les autres interrupteurs',5,0)
_a=v3(R('AdminComptes'),'V3 · administration, les comptes')
_i=_a.index('>À traiter<'); _x=_a.rindex('<span',0,_i); _y=_a.index('</span>',_i)+7; _a=_a[:_x]+_a[_y:]
_i=_a.index('Les demandes à traiter sont en premier'); _x=_a.rindex('<p',0,_i); _y=_a.index('</p>',_i)+4; _a=_a[:_x]+_a[_y:]
for a,b in [('5 comptes actifs · 1 demande en attente','5 comptes actifs'),('lea-demo@example.com · aucun groupe','lea-demo@example.com · inscrite hier'),('camille-demo@example.com · 2 groupes · vue le 15 nov.','camille-demo@example.com · 2 fêtes · vue le 15 nov.'),
            ('Super-admin · 2 groupes · vu le 15 nov.','Super-admin · 2 fêtes · vu le 15 nov.'),('paul-demo@example.com · 1 groupe · vu le 14 nov.','paul-demo@example.com · à sa limite de Secret Santa'),
            ('marc-demo@example.com · peut créer 1 groupe','marc-demo@example.com · aucune fête'),('nora-demo@example.com · demande refusée','nora-demo@example.com · 1 fête · vue le 2 nov.')]:
    _a=_sw(_a,a,b)
_a=_sw(_a,'href="AdminCompte.dc.html"','href="V3AdminCompte.dc.html"',6)
put('V3AdminComptes',_a,900,'Administration · les comptes : plus de demande à traiter ; un compte à sa limite de Secret Santa se voit',5,1)
_a=v3(R('AdminCompte'),'V3 · administration, un compte')
_i=_a.index('>Famille Camille<'); _x=_a.rindex('<li>',0,_i)
_H2=_a[_a.rindex('<h2',0,_a.index('>Groupes</h2>')):_a.index('>Groupes</h2>')+13]; _ULo=_a[_a.index('<ul',_a.index('>Groupes</h2>')):_a.index('>',_a.index('<ul',_a.index('>Groupes</h2>')))+1]
_a=_a[:_x]+'</ul>\n    </section>\n    <section style="display: flex; flex-direction: column; gap: 6px">\n      '+_H2.replace('>Groupes<','>Fêtes<')+'\n      '+_ULo+'\n        '+_a[_x:]
_i=_a.index('>Famille Camille<'); _x=_a.rindex('<li>',0,_i); _seg=_a[_x:_i]; assert _seg.count('border-top: 1px solid #e9dcc5; ')==1
_a=_a[:_x]+_seg.replace('border-top: 1px solid #e9dcc5; ','')+_a[_i:]
for a,b in [('>Groupes</h2>','>Secret Santa</h2>'),('>Peut en créer 3<','>Peut en organiser 3<'),('2 déjà créés · il lui en reste 1','2 en cours · il lui en reste 1'),('aria-label="Groupes qu’il peut créer"','aria-label="Secret Santa qu’elle peut organiser"'),
            ('aria-label="Un groupe de moins"','aria-label="Un de moins"'),('aria-label="Un groupe de plus"','aria-label="Un de plus"'),('Organisatrice · 5 membres · tirage fait','Organisatrice · 5 membres · Secret Santa tiré'),
            ('Organisatrice · 4 membres · à préparer','Organisatrice · 4 membres · Secret Santa à préparer'),('>Participante<','>Membre<')]:
    _a=_sw(_a,a,b)
_a=_sw(_a,'href="Groupe.dc.html"','href="V3FeteOrganisateur.dc.html"',3)
put('V3AdminCompte',_a,900,'Administration · un compte : sa limite de Secret Santa (3 au départ, le super-admin la change), ses fêtes ; plus de demande',5,2)
_pa=f"""<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Les nouveaux Secret Santa sont en pause</h1>
    <p style="margin: 0; padding: 0 4px; font-size: 15px; line-height: 1.45; color: {MUT}">Ceux qui existent continuent. Reviens dans quelques jours.</p>
  </main>"""
put('V3TiragePause',page('V3 · les nouveaux Secret Santa en pause',_pa,844,withnav=False).replace(HEADER,hd,1),844,'Secret Santa · en pause : ce que voit quelqu’un qui veut en créer un quand le super-admin a suspendu les nouveaux',3,6)

# D04 · une liste publique : ce qui était déplié sous « Partage par lien » (le lien, son message, en changer) passe derrière « Modifier », dans « Qui verra ta liste ? »
SWLIEN=SWOFF.replace('aria-checked="false"','aria-checked="true"').replace('background: #d6d3d1','background: #2f613f').replace('left: 3px','left: 23px')
assert SWLIEN!=SWOFF and 'left: 23px' in SWLIEN
def qui_pub(confirm=False):
    lien=(f'<div style="margin: 0 16px; display: flex; align-items: center; gap: 10px; padding: 6px 6px 6px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/l/k3Fq9xT2</span>'
          f'<button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Copier</button></div>')
    def ln(t,sub,href,first=False):
        return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 6px 16px 6px 20px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">{t}</span>'
                +(f'<span style="font-size: 13px; color: {MUT}">{sub}</span>' if sub else '')+f'</span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>')
    if confirm:
        bas=(f'<div role="alertdialog" aria-label="Changer de lien" style="margin: 0 16px; padding: 14px; border-radius: 14px; box-shadow: 0 0 0 1px {LINE}; display: flex; flex-direction: column; gap: 10px"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 18px">Changer de lien ?</h3>'
             f'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: {INK}">L’ancien lien ne marchera plus : il faudra renvoyer le nouveau. Ceux qui ont déjà coché un cadeau gardent la liste.</p>'
             f'<div style="display: flex; gap: 8px"><a href="V3ListeQuiLien.dc.html" style="{BTN2}; flex: 1">Annuler</a><button style="flex: 1; height: 44px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 15px; font-weight: 700">Changer</button></div></div>')
    else:
        bas=(f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'+ln('Le message qui accompagne le lien','','PersonnaliserMessage.dc.html',True)+ln('Changer de lien','','V3ListeLienChanger.dc.html')+'</ul>'
             f'<div style="padding: 0 16px"><a href="V3ListePublique.dc.html" style="{BTN}">Enregistrer</a></div>')
    return (f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px">Qui verra ta liste ?</h2>'
     f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'
     +chk(cat('Mariage'),'Notre mariage','Mariage · 64 membres',True,True)+chk(cat('Noël'),'Famille Camille','Noël · 12 membres',False)+'</ul>'
     f'<div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 20px"><span style="display: flex; color: #274e34">{GLOBE}</span><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Tout le monde, avec un lien</span>{SWLIEN}</div>'
     +lien+bas)
_pp=V['V3ListePublique'][0]
put('V3ListeQuiLien',re.sub(r'<title>[^<]*</title>','<title>V3 · une liste publique, son lien</title>',sheet(_pp,qui_pub(),230,'Qui verra ta liste ?'),count=1),1244,'Liste · publique, « Modifier » touché : le lien, « Copier », le message qui l’accompagne, « Changer de lien » ; ce qui était déplié sous « Partage par lien »',4,10)
put('V3ListeLienChanger',re.sub(r'<title>[^<]*</title>','<title>V3 · changer le lien d’une liste publique</title>',sheet(_pp,qui_pub(True),230,'Qui verra ta liste ?'),count=1),1244,'Liste · publique, changer de lien : la conséquence avant le geste',4,11)

# D06 · « Reprendre ma liste de l'an dernier » : la liste reprise, dans sa fête (le nom, la date et l'icône viennent de la fête)
_h=swap_bar(R('ListeReprise'),vbar('Famille Camille, Chez Mamie','21 membres la voient').replace('FeteChoisir.dc.html','V3ListeQui.dc.html'))
for a,b in [('>Nom de l’événement<','>Noël 2027<'),('>Ajouter une date<','>Le 25 décembre<'),('>❄️<','>🎄<'),('Reprise de Noël 2025.','Reprise de Noël 2026.'),(' Toi seul vois cette marque, elle disparaît au partage.',' Toi seul vois cette marque.')]:
    assert a in _h,a; _h=_h.replace(a,b,1)
_h=re.sub(r'<span aria-hidden="true" style="display: inline-block; width: 2px; height: 32px; background: #b8483a; vertical-align: -5px; margin-right: 2px"></span>','',_h,count=1)
_h=_h.replace("font-size: 34px; line-height: 1.1; color: #a8a29e","font-size: 34px; line-height: 1.1; color: #292524",1)
put('V3ListeReprise',v3(_h,'V3 · ma liste, reprise de l’an dernier'),None,'Liste · reprise de l’an dernier (« Reprendre ma liste de l’an dernier ») : dans sa fête, les idées pas offertes marquées pour moi seul',4,12)

# D09 · « Quoi de neuf », regroupé par fête (remplace NotifCentre)
def _nw(lead,t,sub,new=False,first=False,href='#'):
    r=irow(lead,t,sub,dot() if new else '',first,href)
    return r.replace('font-weight: 600; font-size: 15px">'+t,'font-weight: 700; font-size: 15px">'+t,1) if new else r.replace('font-weight: 600; font-size: 15px">'+t,'font-weight: 500; font-size: 15px">'+t,1)
def _nf(c,name,rows): return f'<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; display: flex; align-items: center; gap: 8px; font-family: {F}; font-weight: 700; font-size: 18px">{cat(c,30)}{name}</h2><ul style="{UL}">{rows}</ul></section>'
BELLI=ICO('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>')
_qn=f"""<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Quoi de neuf')}
    {_nf('Noël','Famille Camille',_nw(tl(),'Quelqu’un te demande des idées de cadeaux','Aujourd’hui, 9 h 12',True,True,'V3ListeSecret.dc.html')+_nw(ll(),'2 cadeaux ont été cochés sur ta liste','Aujourd’hui, 8 h 40',True,False,'V3Liste.dc.html')+_nw(ll(),'Camille a ajouté des idées à sa liste','Hier, 18 h 02',True,False,'V3ListeMembre.dc.html')+_nw(ll(),'Camille t’invite à tenir sa liste avec elle','Dimanche'))}
    {_nf('Noël','Chez Mamie',_nw(ll(),'Mamie se joint au vélo, à plusieurs','Hier, 14 h 30',False,True))}
    {_nf('Noël','Bureau, 3e étage',_nw(tl(),'Le tirage est fait : ton enveloppe t’attend','Lundi',False,True))}
    {_nf('Mariage','Le mariage de Karim et Sofia',_nw(ll(),'3 idées de plus sur leur liste','Mardi',False,True,'V3OffreAilleurs.dc.html'))}
    <ul style="{UL}">{irow(BELLI,'Choisir ce qui me prévient','Tout s’efface au bout de trente jours','',True,'NotifReglage.dc.html')}</ul>
  </main>"""
NAVN=nav('news').replace('</a><a ','</a>'+TABC+'<a ',1)
_qp=page('V3 · quoi de neuf',_qn,1060); assert _qp.count(nav())==1; _qp=_qp.replace(nav(),NAVN)
put('V3QuoiDeNeuf',_qp,1060,'« Quoi de neuf » · regroupé par fête, la plus récente en haut ; une liste publique où j’ai coché a sa section ; en gras et avec un point tant que ce n’est pas ouvert',0,7)

# Le résultat quand la liste de la personne tirée a bougé (remplace PistesResultatNouvelles)
_tn=V['V3TirageVersListe'][0]; _a='Le mode anonyme y sera activé pour toi.'
assert _tn.count(_a)==1; _tn=_tn.replace(_a,'2 nouvelles idées depuis ta dernière visite')
_tn=re.sub(r'<title>[^<]*</title>','<title>V3 · le résultat, sa liste a bougé</title>',_tn,count=1)
put('V3TirageNouvelles',_tn,V['V3TirageVersListe'][1],'Secret Santa · le résultat quand la liste de la personne tirée a de nouvelles idées : la ligne de sa liste le dit',3,7)

# D12 · « Qui verra ta liste ? » rouvert par « Modifier », pour une liste dans deux fêtes ; retirer sa liste d'une fête
_qm=qui(0,True); _a='<a href="V3ListeNouvelle.dc.html" style="'+BTN+'">Continuer</a>'
assert _qm.count(_a)==1; _qm=_qm.replace(_a,'<a href="V3Liste.dc.html" style="'+BTN+'">Enregistrer</a>')
_lp=V['V3Liste'][0]
put('V3ListeQuiModifier',re.sub(r'<title>[^<]*</title>','<title>V3 · qui verra ta liste ? par « Modifier »</title>',sheet(_lp,_qm,250,'Qui verra ta liste ?'),count=1),None,'Liste · « Modifier » touché sur une liste dans deux fêtes : les mêmes cases, « Enregistrer » ; décocher une fête en retire la liste',4,13)
_qr=qui(0,False); _i=_qr.index('<div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 20px">')
_qr=_qr[:_i]+(f'<div role="alertdialog" aria-label="Retirer ta liste de Chez Mamie" style="margin: 0 16px; padding: 14px; border-radius: 14px; box-shadow: 0 0 0 1px {LINE}; display: flex; flex-direction: column; gap: 10px"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 18px">Retirer ta liste de « Chez Mamie » ?</h3>'
      f'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: {INK}">Ses 9 membres ne la verront plus. Les 2 cadeaux qu’ils ont cochés restent prévus.</p>'
      f'<div style="display: flex; gap: 8px"><a href="V3ListeQuiModifier.dc.html" style="{BTN2}; flex: 1">Annuler</a><button style="flex: 1; height: 44px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 15px; font-weight: 700">Retirer</button></div></div>')
put('V3ListeQuiRetirer',re.sub(r'<title>[^<]*</title>','<title>V3 · retirer sa liste d’une fête</title>',sheet(_lp,_qr,250,'Qui verra ta liste ?'),count=1),None,'Liste · retirer sa liste d’une fête : la conséquence avant le geste ; les cadeaux cochés restent prévus',4,14)

# =================== « SECRET SANTA », PAS « TIRAGE » ===================
# Retour de Julien : la chose s'appelle « Secret Santa », même hors de Noël ; « tirage » reste le geste (tirer au sort).
SS=[('>Le tirage<','>Le Secret Santa<'),('>Le tirage 2026<','>Le Secret Santa 2026<'),('>Le tirage 2027<','>Le Secret Santa 2027<'),
    ('>Les tirages<','>Les Secret Santa<'),('>Un tirage<','>Un Secret Santa<'),('>Un autre tirage<','>Un autre Secret Santa<'),
    ('Organiser un tirage','Organiser un Secret Santa'),('Créer le tirage','Créer le Secret Santa'),
    ('membres repris du tirage 2026.','membres repris du Secret Santa 2026.'),
    ('rejoint la fête, et son tirage tant qu’il n’a pas eu lieu.','rejoint la fête, et son Secret Santa tant que le tirage n’a pas eu lieu.'),
    ('tu verras son tirage et les listes de ses membres','tu verras son Secret Santa et les listes de ses membres'),
    ('c’est l’organisateur qui lance le tirage.','c’est l’organisateur qui lance le Secret Santa.'),
    ('Elle se crée avec le tirage : un nom, une date','Elle se crée avec le Secret Santa : un nom, une date'),
    ('déjà un tirage cette année','déjà un Secret Santa cette année'),
    ('Tu ne participeras plus à son tirage l’an prochain.','Tu ne participeras plus à son Secret Santa l’an prochain.'),
    ('>Un tirage dans quelle fête ?<','>Pour quelle occasion ?<'),
    ('Camille te demande des pistes','Quelqu’un te demande des idées')]
_seen=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for x,y in SS:
        if x in h: _seen.add(x); h=h.replace(x,y)
    V[k]=(h,ht,t,row,col)
assert all(x in _seen for x,_ in SS),[x for x,_ in SS if x not in _seen]
def retitle(k,t): h,ht,_,row,col=V[k]; V[k]=(h,ht,t,row,col)
retitle('V3TirageNeutre','Secret Santa · hors de Noël (catégorie « Autre ») : il garde son nom, « Secret Santa » ; aucun « Père Noël »')
retitle('V3FeteRejoindre','Fête · le lien d’invitation, sans compte : on rejoint une fête, et son Secret Santa s’il y en a un')
retitle('V3TirageNouveau','Secret Santa · celui de l’année : la date de la fête est déjà là, et se change')
retitle('V3TirageVersListe','Secret Santa · du résultat à la liste de cadeaux d’Inès, sans lien ; le mode anonyme s’active seul')
retitle('V3TirageQuelleFete','Secret Santa · première étape : « Pour quelle occasion ? », une fête que j’organise ou une autre occasion')
retitle('V3FeteOrganisateur','Fête · vue par son organisateur : « Inviter », les réglages, « Un autre Secret Santa »')
retitle('V3FeteAnniversaire','Fête · « pour quelqu’un » (un anniversaire) : sa liste d’abord ; un Secret Santa reste possible')
retitle('V3Fete','Fête · vue par un membre : ses membres, son Secret Santa, les listes, les années passées, « Quitter »')
retitle('V3Accueil','Accueil · mes fêtes : leurs Secret Santa et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs')
retitle('V3FeteInviter','Secret Santa · inviter par lien : on s’inscrit au Secret Santa, et l’on devient membre de son événement')
retitle('V3FeteRejoindre','Secret Santa · son lien d’invitation, sans compte : « On t’invite au Secret Santa »')
retitle('V3FeteOrganisateur','Fête · vue par son organisateur : les réglages, « Un autre Secret Santa » ; la ligne des membres ouvre « Membres »')

# =================== MOINS DE PHRASES ===================
# Julien, 20 novembre 2026 : aucune phrase écrite pour expliquer la maquette au concepteur ; ne reste que ce qui sert à l'utilisateur, là où il est.
RM=['Tu l’organises. Les 8 membres de l’an dernier sont repris.',
    'Dans une de tes fêtes, ou dans une nouvelle','Dans une de tes fêtes, ou publique avec un lien',
    'Chaque réglage s’enregistre dès qu’il est validé.','Plus personne ne pourra s’inscrire',
    'L’historique de ceux qui ne participent plus est conservé.',
    'Ses réglages : mot des messages, rappels','Envoyé à chaque organisateur, dans sa langue.','Il se connecte avec son adresse, sans mot de passe',
    'La croix supprime un proche qui n’est sur aucune liste.',
    'La liste sera alors rangée par personne. Les idées déjà écrites iront à la première.',
    'Une liste publique : pour un mariage, ou quelqu’un hors de tes fêtes',
    'Les listes publiques où tu as coché quelque chose.','Ouvrir une liste sans rien cocher ne laisse aucune trace ici.',
    'Elle se crée avec le Secret Santa : un nom, une date','Dans tes autres fêtes, c’est l’organisateur qui lance le Secret Santa.',
    'Plus la période est longue, plus le tirage est contraint.']
RP=[('Chacun s’inscrit avec son adresse email et rejoint la fête, et son Secret Santa tant que le tirage n’a pas eu lieu.','Ceux qui s’inscrivent rejoignent aussi le Secret Santa, tant que le tirage n’a pas eu lieu.'),
    ('pour la rejoindre : tu verras son Secret Santa et les listes de ses membres.','pour la rejoindre.'),
    ('Elle crée ton compte, sans mot de passe : tu reçois un lien pour la confirmer. ','Tu reçois un lien pour la confirmer. '),
    (' Tu ajusteras la liste sur l’écran suivant.',''),
    ('>Le Secret Santa 2026</span><span style="font-size: 13px; line-height: 1.35; color: '+MUT+'">Ses réglages : mot des messages, rappels</span>','>Réglages du Secret Santa 2026</span>')]
_rs=set(); _ps=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for x,y in RP:
        if x in h: _ps.add(x); h=h.replace(x,y)
    for x in RM:
        h2=re.sub(r'\s*<(p|span)\b[^<>]*>'+re.escape(x)+r'</\1>','',h)
        if h2!=h: _rs.add(x); h=h2
    h2=re.sub(r'\s*<p\b[^<>]*>Touche un prénom : il s’ajoute à la liste.*?</p>','',h,flags=re.S)
    if h2!=h: _rs.add('touche'); h=h2
    V[k]=(h,ht,t,row,col)
_miss=[x for x in RM if x not in _rs and x!='Ses réglages : mot des messages, rappels']+[x for x,_ in RP if x not in _ps]+([] if 'touche' in _rs else ['touche'])
assert not _miss,_miss

# =================== LE PARTAGE D'UNE LISTE, PAR STADES (D14, réponses de Julien du 21 novembre 2026) ===================
# Brouillon au départ ; « celui qui m'a tiré » ; des événements ; publique. Le lien existe toujours : la barre le montre à chaque stade.
LOCK=ic('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',20)
GLOBE2=ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',20)
def bar2(ico,t,sub,btn='Modifier',href='V3ListeQuiModifier.dc.html'):
    # Le nom et la phrase tiennent chacun sur une ligne, coupés par « … » s'il le faut (Julien, 23 novembre).
    # Julien, 22 novembre 2026 : la barre est repliée, une ligne ; son bouton la déroule sur place (BARRE_LIEN et les choix sont dedans)
    b=f'<a href="{href}" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">{btn}</a>'
    return (f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); min-height: 52px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 10px">'
            f'<span style="display: flex; color: #274e34">{ico}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 14px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{t}</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{sub}</span></span>{b}</div>')
BARRE_LIEN=(f'<div style="margin: 0 8px; display: flex; align-items: center; gap: 10px; padding: 6px 6px 6px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/l/k3Fq9xT2</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Copier le lien</button></div>')
B_EVT=bar2(PEOPLE,'Famille Camille, Chez Mamie','21 membres la voient')
B_BRO=bar2(LOCK,'Brouillon','Toi seul la vois','Partager','V3ListeQui.dc.html')
B_SEC=bar2(PEOPLE,'Famille Camille','Seul celui qui t’a tiré la voit','Modifier','V3ListeQuiSecret.dc.html')
B_PUB=bar2(GLOBE2,'Publique','Toute personne qui a le lien la voit','Modifier','V3ListeQuiLien.dc.html')
B_AID=bar2(PEOPLE,'Famille Camille, Chez Mamie','21 membres la voient','Le lien','V3ListeAideLien.dc.html')   # « choisi par Camille » enlevé (Julien, 23 novembre)
def _bartxt(h):
    i=h.index('<div data-pub="1"'); d=0
    for mm in re.finditer(r'<div\b|</div>',h[i:]):
        d+=1 if mm.group(0)!='</div>' else -1
        if d==0: j=i+mm.end(); break
    return i,j,' / '.join(x.strip() for x in re.findall(r'>([^<>]+)<',re.sub(r'<svg.*?</svg>','',h[i:j],flags=re.S)) if x.strip())
_BMAP={'Famille Camille, Chez Mamie / 21 membres la voient / Modifier':B_EVT,'Famille Camille, Chez Mamie / 21 membres la verront / Modifier':B_BRO,
       'Famille Camille / Seul celui qui m’a tiré la voit / Modifier':B_SEC,'Publique, avec un lien / Et dans la fête « Notre mariage » / Modifier / under-the-tree.party/l/k3Fq9xT2 / Partager':B_PUB}
_bs={}
for k in list(V):
    h,ht,t,row,col=V[k]
    if '<div data-pub="1"' not in h: continue
    i,j,tx=_bartxt(h); assert tx in _BMAP,(k,tx)
    nb=B_BRO if k=='V3ListeReprise' else _BMAP[tx]
    V[k]=(h[:i]+nb+h[j:],ht,t,row,col); _bs[k]=tx[:20]
assert {'V3Liste','V3ListeSecret','V3ListePublique','V3ListeNouvelle','V3ListeReprise'}<=set(_bs),_bs
# les mots du partage
_PQ=[('>Toute la fête<','>Tous les membres<'),('Tout le monde, avec un lien','Tout le monde, avec le lien'),
     ('Ses 9 membres ne la verront plus. Les 2 cadeaux qu’ils ont cochés restent prévus.','Ses 9 membres ne la verront plus. 2 d’entre eux ont coché un cadeau et ne pourront plus ouvrir la liste. Leurs cadeaux restent prévus.')]
_pq=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for a,b in _PQ:
        if a in h: h=h.replace(a,b); _pq.add(a)
    V[k]=(h,ht,t,row,col)
assert len(_pq)==len(_PQ),[a for a,b in _PQ if a not in _pq]
# « Qui verra ta liste ? » n'est plus la première étape : on l'ouvre depuis le brouillon, par « Partager »
_h=V['V3ListeQui'][0]; _i=_h.index('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45)'); _z=_h.rindex('</div>\n</x-dc>'); _dlg=_h[_i:_z]
_a='<a href="V3ListeNouvelle.dc.html" style="'+BTN+'">Continuer</a>'; assert _dlg.count(_a)==1; _dlg=_dlg.replace(_a,'<a href="V3Liste.dc.html" style="'+BTN+'">Partager</a>')
_b=rel(V['V3ListeNouvelle'][0]); _z=_b.rindex('</div>\n</x-dc>')
V['V3ListeQui']=(re.sub(r'<title>[^<]*</title>','<title>V3 · partager sa liste</title>',_b[:_z]+_dlg+_b[_z:],count=1),V['V3ListeNouvelle'][1],'Liste · « Partager » touché sur un brouillon : « Qui verra ta liste ? », un ou plusieurs de mes événements, celui qui m’a tiré, ou tout le monde',4,0)
retitle('V3ListeNouvelle','Liste · nouvelle : elle naît en brouillon, moi seul la vois ; son nom, sa date et son icône viennent de l’événement ; le lien est déjà là')
retitle('V3Liste','Liste · la mienne, partagée dans deux événements : la barre dit qui la voit, « Modifier », et « Copier le lien »')
retitle('V3ListeSecret','Liste · la mienne, montrée seulement à celui qui m’a tiré')
retitle('V3ListePublique','Liste · publique, le dernier stade : quiconque a le lien la voit et coche, sans compte')
retitle('V3ListeReprise','Liste · reprise de l’an dernier : un brouillon le temps du tri, les idées pas offertes marquées pour moi seul')
# La première étape d'une liste : « Pour quelle occasion ? »
_oc=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px">Pour quelle occasion ?</h2>'
     '<ul role="radiogroup" aria-label="L’occasion de la liste" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'; border-bottom: 1px solid '+SOFT+'">'
     +rad(cat('Noël'),'Famille Camille','Noël · 25 décembre',True,True)+rad(cat('Noël'),'Chez Mamie','Noël · 24 décembre',False)+rad(cat('Noël'),'Bureau, 3e étage','Noël · 19 décembre',False)+rad(cat('Anniversaire'),'Les 40 ans de Tonton','Anniversaire · 8 février',False)
     +rad(NEWF,'Une autre occasion','',False)+'</ul>'
     '<div style="padding: 0 16px"><a href="V3ListeNouvelle.dc.html" style="'+BTN+'">Continuer</a></div>')
put('V3ListeOccasion',re.sub(r'<title>[^<]*</title>','<title>V3 · une liste, pour quelle occasion ?</title>',sheetb(V['V3Accueil'][0],_oc,'Pour quelle occasion ?'),count=1),V['V3Accueil'][1],'Liste · première étape : « Pour quelle occasion ? », un de mes événements ou une autre occasion ; la liste y naît en brouillon',4,15)
# Arriver par le lien sans y avoir droit
def _ferme(t,p,btn):
    return f"""<main style="flex-grow: 1; display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 80px 32px 24px; text-align: center">
    <span aria-hidden="true" style="width: 64px; height: 64px; border-radius: 50%; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center">{ic('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',28)}</span>
    <h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 26px; line-height: 1.15">{t}</h1>
    <p style="margin: 0; font-size: 16px; line-height: 1.5; color: {MUT}">{p}</p>{btn}
  </main>"""
_fp=page('V3 · une liste qui ne m’est pas ouverte, sans être connecté',_ferme('Cette liste n’est pas ouverte à tout le monde','Si elle a été partagée avec toi, connecte-toi pour l’ouvrir.',f'<a href="Connexion.dc.html" style="{BTN}; align-self: stretch">Se connecter</a>'),844,withnav=False)
_fp,_n=re.subn(r'<button aria-label="Mon compte".*?</button>','<span></span>',_fp,count=1,flags=re.S); assert _n==1
put('V3ListeFermee',_fp,844,'Liste · arriver par le lien sans être connecté, quand elle n’est pas publique : on le dit, et on propose de se connecter',4,16)
put('V3ListeFermeeConnecte',page('V3 · une liste qui ne m’est pas ouverte',_ferme('Cette liste n’est pas partagée avec toi','Demande à la personne qui t’a envoyé le lien de te l’ouvrir.',''),844),844,'Liste · arriver par le lien, connecté, sans y avoir droit (un brouillon, une liste réservée à celui qui a tiré)',4,17)
# Julien, 21 novembre 2026 : on n'ajoute personne à un événement ; on entre par un Secret Santa ou par une liste.
_PP='<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>'
_inv=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><p style="margin: 0; font-size: 14px; font-weight: 700; color: {MUT}">🎄 Noël 2026</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Inviter quelqu’un</h1><p style="margin: 6px 0 0; font-size: 15px; line-height: 1.4; color: {MUT}">Il verra ta liste et deviendra membre de l’événement.</p></div>
    <ul style="{UL}">{irow(ICO('<path d="M10 14a4.500 4.500 0 0 0 6.400 0l3-3a4.500 4.500 0 0 0-6.400-6.400l-1 1"/><path d="M14 10a4.500 4.500 0 0 0-6.400 0l-3 3a4.500 4.500 0 0 0 6.400 6.400l1-1"/>'),'Copier le lien','under-the-tree.party/l/k3Fq9xT2','',True)}{irow(ICO('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),'Par son adresse email','Cette personne reçoit un email à ton nom','',False,'V3ListeInviterEmail.dc.html')}{irow(ICO('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.870"/><path d="M16 3.130a4 4 0 0 1 0 7.750"/>'),'Reprendre ceux d’un autre événement','','',False,'V3FeteMembresReprendre.dc.html')}{irow(ICO('<path d="M12 5v14M5 12h14"/>'),'Dans une autre occasion','Un nouvel événement, où partager ta liste','',False,'V3FeteNouvelle.dc.html')}</ul>
  </main>'''
put('V3ListeInviter',page('V3 · inviter quelqu’un à voir une liste',_inv,844,withnav=False).replace(HEADER,hd,1),844,'Liste · « Inviter quelqu’un » : par le lien de la liste, par une adresse email, ou en reprenant ceux d’un autre événement ; il devient membre de l’événement',4,18)
_em=R('ListeInvitationEmail')
for _a,_b in [('Camille t’invite à tenir la liste « Noël 2026 »','Camille a partagé sa liste « Noël 2026 » avec toi'),
              ('Camille t’invite à tenir avec elle la liste de cadeaux « Noël 2026 » : écrire les idées de tout le monde, et voir qui offre quoi.','Camille a partagé avec toi sa liste de cadeaux « Noël 2026 ». Coche ce que tu offres, et personne n’aura la même idée.'),
              ('Voir l’invitation','Voir la liste')]:
    assert _em.count(_a)>=1,_a; _em=_em.replace(_a,_b)
_em,_n=re.subn(r'\s*<p\b[^>]*>Elle vaut 7 jours[^<]*</p>','',_em,count=1); assert _n==1
_em=re.sub(r'<title>[^<]*</title>','<title>V3 · l’email reçu par celui qu’on invite à voir une liste</title>',_em,count=1)
_ie=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><p style="margin: 0; font-size: 14px; font-weight: 700; color: {MUT}">🎄 Noël 2026</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Inviter quelqu’un</h1></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son prénom</label><div style="{FIELD}">Tata</div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son adresse email</label><div style="{FIELD}">tata-demo@example.com</div><p style="margin: 0; font-size: 13px; line-height: 1.4; color: {MUT}">Cette personne reçoit un email à ton nom, et devient membre de « Famille Camille ».</p></div>
    <a href="V3ListeInviteEnvoyee.dc.html" style="{BTN}">Inviter</a>
  </main>'''
put('V3ListeInviterEmail',page('V3 · inviter quelqu’un par son adresse email',_ie,844,withnav=False).replace(HEADER,hd,1),844,'Liste · « Par son adresse email » : un prénom, une adresse, « Inviter » ; il reçoit un email à mon nom et devient membre de l’événement',4,26)
put('V3ListePartageEmail',_em,None,'Liste · l’email reçu par celui qu’on invite par son adresse : il ouvre la liste et devient membre de l’événement',4,19)
retitle('V3FeteMembresReprendre','Secret Santa ou liste · « Reprendre ceux d’un autre événement » : on coche qui ; c’est là qu’on reprend des gens, pas à la création de l’événement')
retitle('V3FeteMembres','Fête · ses membres, et par où chacun est entré (un Secret Santa, une liste) ; « Ajouter quelqu’un » mène au Secret Santa ou à ma liste, jamais à l’événement lui-même')
retitle('V3FeteMembresComplet','Fête · complète, vue par l’organisateur : 30 membres, le lien du Secret Santa en pause')
retitle('V3FeteNouvelle','Première étape d’un Secret Santa ou d’une liste, quand l’occasion est nouvelle : « Pour quelle occasion ? », la catégorie d’abord, qui remplit le reste ; pas d’étape « membres »')
# Q-021 (Julien, 22 novembre 2026) : une liste d'une année passée reste ouverte ; un bandeau dit de quelle année elle est
_lp=V['V3ListeMembre'][0]
_k=_lp.index('🎄 Famille Camille'); _e=_lp.index('</a>',_k)+4
_band=(f'\n    <div role="note" style="display: flex; align-items: center; gap: 12px; padding: 10px 10px 10px 14px; border-radius: 14px; background: #efe7fb; color: {INK}">'
       f'<span aria-hidden="true" style="display: flex; color: #5f37a6; flex-shrink: 0">{ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',20)}</span>'
       f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 700">Liste de Noël 2025</span><span style="font-size: 13px; color: {MUT}">Une année passée</span></span>'
       f'<a href="V3ListeMembre.dc.html" style="height: 36px; padding: 0 10px 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 4px; flex-shrink: 0">Noël 2026{ic('<path d="m9 6 6 6-6 6"/>',12,2.8)}</a></div>')
_lp=_lp[:_e]+_band+_lp[_e:]
assert _lp.count('>Noël 2026</h1>')==1,_lp.count('>Noël 2026</h1>'); _lp=_lp.replace('>Noël 2026</h1>','>Noël 2025</h1>',1)
_lp=re.sub(r'<title>[^<]*</title>','<title>V3 · une liste d’une année passée</title>',_lp,count=1)
put('V3ListeAnneePassee',_lp,None,'Liste · celle d’une année passée : elle reste ouverte ; un bandeau dit de quelle année elle est, et mène à celle de cette année',4,20)
# Les squelettes des nouveaux écrans (Julien, 22 novembre 2026 : « on a pensé aux squelettes ? il en manque déjà pour le nouvel accueil »)
# Des pièces grises à la place et à la taille de ce qui arrive ; la barre du haut et la barre du bas sont déjà là.
def _pc(w,h,r=8,c='#e9dcc5',x=''): return f'<span style="display: block; width: {w}; height: {h}px; border-radius: {r}px; background: {c}; flex-shrink: 0;{x}"></span>'
def _skrow(first=False,w1='55%',w2='38%'):
    return (f'<li style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"}">'
            f'{_pc("36px",36,10,"#f1e8d8")}<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 7px">{_pc(w1,16,8,"#f1e8d8")}{_pc(w2,11,8,"#f1e8d8")}</span></li>')
def _skcard(n):
    return (f'<section style="{CARDS}; overflow: hidden"><div style="min-height: 56px; box-sizing: border-box; padding: 10px 16px; display: flex; align-items: center; gap: 10px">{_pc("32px",32,9,"#f1e8d8")}{_pc("48%",18,8,"#f1e8d8")}<span style="flex-grow: 1"></span>{_pc("48px",12,8,"#f1e8d8")}</div>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">'+''.join(_skrow(i==0,("55%","62%","45%")[i%3],("38%","30%","44%")[i%3]) for i in range(n))+'</ul></section>')
_BUSY='aria-busy="true" aria-label="Chargement" '
_ska=f'''<main {_BUSY}style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    <div style="padding: 4px 4px 0">{_pc("52%",30)}</div>
    <div style="padding: 0 4px">{_pc("44%",13)}</div>
    {_skcard(1)}{_skcard(2)}{_skcard(3)}
  </main>'''
put('V3ChargementAccueil',page('V3 · l’accueil arrive',_ska,844),844,'Chargement · le nouvel accueil : le bonjour, le titre de la saison, des cartes d’événement avec leurs lignes',0,9)
_skn=f'''<main {_BUSY}style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="padding: 4px 4px 0">{_pc("58%",30)}</div>
    <section style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; align-items: center; gap: 8px; padding: 0 4px">{_pc("26px",26,8)}{_pc("46%",18)}</div><ul style="{UL}">{_skrow(True)}{_skrow(False,"62%","30%")}{_skrow(False,"45%","44%")}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; align-items: center; gap: 8px; padding: 0 4px">{_pc("26px",26,8)}{_pc("38%",18)}</div><ul style="{UL}">{_skrow(True,"50%","36%")}{_skrow(False)}</ul></section>
  </main>'''
put('V3ChargementQuoiDeNeuf',page('V3 · « Quoi de neuf » arrive',_skn,844),844,'Chargement · « Quoi de neuf » : le titre, puis une section par événement avec ses lignes',0,10)
_skf=f'''<main {_BUSY}style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 10px; padding: 4px 4px 0">{_pc("130px",26,999)}{_pc("64%",30)}{_pc("52%",14)}</div>
    <div style="{CARDS}; min-height: 56px; padding: 0 14px; display: flex; align-items: center; gap: 12px"><span style="display: flex; flex-shrink: 0">{_pc("26px",26,999,"#f1e8d8")}{_pc("26px",26,999,"#f1e8d8"," margin-left: -7px; box-shadow: 0 0 0 2px #fffdf9;")}{_pc("26px",26,999,"#f1e8d8"," margin-left: -7px; box-shadow: 0 0 0 2px #fffdf9;")}</span>{_pc("36%",16,8,"#f1e8d8")}</div>
    <section style="display: flex; flex-direction: column; gap: 6px"><div style="padding: 0 4px">{_pc("34%",12)}</div><ul style="{UL}">{_skrow(True)}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px"><div style="padding: 0 4px">{_pc("26%",12)}</div><ul style="{UL}">{_skrow(True,"62%","30%")}{_skrow(False,"48%","40%")}</ul></section>
  </main>'''
put('V3ChargementFete',page('V3 · la page d’un événement arrive',_skf,844).replace(HEADER,hd,1),844,'Chargement · la page d’un événement : la catégorie, le nom, la date, les membres, puis les Secret Santa et les listes',1,7)
# Cocher pour quelqu'un (ticket 099, à faire sur main, demandé par Julien le 21 novembre 2026) : deux maquettes, remplies à la fin depuis « ListeTeneur » et « ListeDecocher »
put('ListeCocherPourMoi',V['V3Liste'][0],None,'Cocher pour quelqu’un · 1. Je coche : c’est à mon nom, comme aujourd’hui',6,0)
put('ListeCocherPourDepart',V['V3Liste'][0],844,'Cocher pour quelqu’un · 2. Je touche « Tu l’offres › » : « Qui l’offre ? ». Une personne, et c’est moi',6,1)
put('ListeCocherPourChoix',V['V3Liste'][0],844,'Cocher pour quelqu’un · 3. Je touche Mamie : elle prend ma place. Un seul rond à la fois',6,2)
put('ListeCocherPourLigne',V['V3Liste'][0],None,'Cocher pour quelqu’un · 4. Enregistré : la ligne dit « Mamie ». Pour celui qui tient la liste, les prénoms se touchent et rouvrent le panneau',6,3)
put('ListeCocherPour',V['V3Liste'][0],844,'Cocher pour quelqu’un · 5. À plusieurs : je choisis « Plusieurs », les ronds deviennent des cases et j’en coche autant que je veux. « On est au complet » ferme le groupe',6,4)
put('ListeCocherPourAutre',V['V3Liste'][0],844,'Cocher pour quelqu’un · 6. « Quelqu’un d’autre… » : un prénom, et son adresse email si je veux le relier à un compte',6,5)
# « Ce que j'offre ailleurs » : plus de liste fermée
_h=V['V3OffreAilleurs'][0]; _i=_h.index('Cette liste n’est plus partagée'); _x=_h.rindex('<li>',0,_i); _y=_h.index('</li>',_i)+5
V['V3OffreAilleurs']=(_h[:_x]+_h[_y:],)+V['V3OffreAilleurs'][1:]

# =================== RÉPONSES À Q-010, Q-012 ET Q-014 (21 novembre 2026) ===================
# Q-014 : l'accueil est un calendrier. Une fête qui vient avant la saison de Noël est au-dessus d'elle, sans titre.
_av=V['V3Accueil'][0]; _se=season('Noël 2026','dans 35 jours'); assert _av.count(_se)==1
_av=_av.replace(_se,fcard2('Crémaillère','La crémaillère d’Inès','28 nov.',irow(ll(),'La liste d’Inès','Tu offres 1 cadeau','',True),href='#')+_se)
_av=re.sub(r'<title>[^<]*</title>','<title>V3 · accueil, une fête avant Noël</title>',_av,count=1)
put('V3AccueilAvantNoel',_av,1460,'Accueil · une fête qui n’est pas Noël et qui vient avant : elle est au-dessus de la saison de Noël, sans titre ; l’accueil suit les dates',0,8)
# Q-010 et Q-012 : les textes sous les lignes, et le nom d'une fête jamais derrière « chez » ou « dans »
_RQ=[('Tu sais à qui tu offres · tu l’organises','Tu sais à qui tu offres'),('aussi dans Famille Camille','aussi : Famille Camille'),('aussi chez Mamie','aussi : Chez Mamie'),
     ('Elle vient de la créer · 4 idées','4 nouvelles idées'),('Tu offrais à Zoé · 12 cadeaux offerts','Tu offrais à Zoé'),('>Tu n’y verras plus les listes<','><'),
     ('>Le Secret Santa 2026<','>Le Secret Santa<'),('>Le Secret Santa 2025<','>Le Secret Santa<'),('Elle reste chez Mamie.','Elle reste dans tes autres fêtes.')]
_rq=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for a,b in _RQ:
        if a in h: h=h.replace(a,b); _rq.add(a)
    V[k]=(h,ht,t,row,col)
assert len(_rq)==len(_RQ),[a for a,b in _RQ if a not in _rq]

# =================== ONGLET « CRÉER » ===================
_nv=0
for k in list(V):
    h,ht,t,row,col=V[k]
    if nav() in h: _nv+=1; h=h.replace(nav(),NAVP)
    V[k]=(h,ht,t,row,col)
assert _nv>=5,_nv
retitle('V3Accueil','Accueil · mes fêtes : leurs Secret Santa et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs ; l’onglet « Créer » dans la barre du bas')

# Les titres du canevas disent « événement » eux aussi (D15)
TITRES=[('Fête · ','Événement · '),('« Toute la fête »','« Tous les membres »'),('« Les fêtes passées »','« Les événements passés »'),('on ne parle pas de « fête »','on ne parle pas d’« événement »'),
 ('une fête qui n’est pas Noël et qui vient avant : elle est','un événement qui n’est pas Noël et qui vient avant : il est'),
 ('dans une fête, un Secret Santa dévoilé et son palmarès dans une autre','dans un événement, un Secret Santa dévoilé et son palmarès dans un autre'),
 ('la fête est la première étape','l’événement est la première étape'),('d’une autre fête','d’un autre événement'),('on rejoint une fête','on rejoint un événement'),
 ('une fête qui revient y laisse','un événement qui revient y laisse'),('on y arrive par la fête, sans lien ; la fête est rappelée en haut','on y arrive par l’événement, sans lien ; l’événement est rappelé en haut'),
 ('décocher une fête en retire','décocher un événement en retire'),('d’une fête :','d’un événement :'),('regroupé par fête, la plus récente en haut','regroupé par événement, le plus récent en haut'),
 ('la date de la fête est déjà là','la date est déjà là'),('une fête que j’organise','un événement que j’organise'),
 ('mes fêtes','mes événements'),('ses fêtes','ses événements'),('des fêtes','des événements'),('deux fêtes','deux événements'),
 ('Événement · complète','Événement · complet'),('Événement · nouvelle, suite','Événement · nouveau, suite'),
 ('dans la conversation de la fête','dans la conversation WhatsApp'),('Le score de la fête','Le score de l’événement'),('Dévoiler avant la fête','Dévoiler avant le jour J'),('Fêter, à dévoiler','Jour J, à dévoiler'),
 ('Dévoilé avant la fête','Dévoilé avant le jour J'),('Membres, grande fête','Membres, grand événement'),('Le mot de la fête','Le mot de l’événement'),('Supprimer la fête','Supprimer l’événement'),
 ('Après la fête, sans jeu','Après le jour J, sans jeu'),('À la fête : l’invitation','Le jour J : l’invitation'),('Rejoindre une fête par lien','Rejoindre un événement par lien'),('Étape 3 · Fêter','Étape 3 · Le jour J'),
 ('Grandes fêtes (100','Grands événements (100'),('Journal de la fête','Journal de l’événement'),('Comptes et fêtes','Comptes et événements'),('avant puis après la fête','avant puis après le jour J'),
 ('V3 · La fête','V3 · L’événement'),('Organisateur · fête','Organisateur · événement'),('Date de la fête','Date')]
def _tit(t):
    if t=='Fêtes': return 'Événements'
    for a,b in TITRES: t=t.replace(a,b)
    return t
json.dump(TITRES,open('/tmp/titres.json','w'),ensure_ascii=False)
# La barre du haut se déroule sur place (Julien, 22 novembre 2026) : les hauteurs et les titres des écrans où elle est déroulée ; le dessin se fait à la fin, sur les fichiers
_DER={'V3ListeQui':(844,'Liste · « Partager » touché sur un brouillon : la barre se déroule par-dessus la liste ; personne ne la voit encore, « Ajouter » est ouvert sur mes événements'),
      'V3ListeQuiModifier':(900,'Liste · « Modifier » touché : deux choix, « Qui je veux » ou « Tout le monde » ; dessous, seulement ceux qui la voient, chacun avec sa croix, « Ajouter », et « Changer de lien »'),
      'V3ListeQuiSecret':(900,'Liste · « Modifier » touché sur une liste montrée à celui qui m’a tiré : lui seul est dans « Qui je veux »'),
      'V3ListeQuiRetirer':(900,'Liste · la croix touchée : un niveau plus loin dans la barre, la conséquence, « Retirer » ; le retour annule'),
      'V3ListeQuiLien':(900,'Liste · « Tout le monde » choisi : plus personne à choisir, il reste « Changer de lien »'),
      'V3ListeLienChanger':(900,'Liste · « Changer de lien » touché : un niveau plus loin dans la barre, la conséquence, « Changer » ; le retour annule'),
      'V3ListeQuiAjouter':(900,'Liste · « Ajouter » touché : mes autres événements, « Celui qui m’a tiré » et « Quelqu’un d’autre », en pastilles ; en toucher une l’ajoute'),
      'V3ListeQuiOuvrir':(900,'Liste · « Tout le monde » touché : un niveau plus loin dans la barre, la conséquence, « Ouvrir » ; le retour annule')}
put('V3ListeQuiAjouter',V['V3ListeQuiModifier'][0],900,'x',4,23); put('V3ListeQuiOuvrir',V['V3ListeQuiModifier'][0],900,'x',4,24)
put('V3ListeLienNouveau',V['V3ListeQuiLien'][0],900,'Liste · publique, le lien vient de changer : la nouvelle adresse est dans la barre, « Nouveau lien créé »',4,25)
put('V3ListeInviteEnvoyee',V['V3ListeQuiModifier'][0],900,'x',4,27); put('V3ListeInviterReprendre',V['V3ListeQuiModifier'][0],900,'x',4,28)
for _k,_tt in [('V3ListeInviter','Liste · « Quelqu’un d’autre » touché : on reste dans la barre, un niveau plus loin, avec un retour ; son prénom, son adresse, « Inviter », et « Reprendre ceux d’un autre événement »'),
               ('V3ListeInviterEmail','Liste · « Quelqu’un d’autre », le prénom et l’adresse écrits : « Inviter »'),
               ('V3ListeInviterReprendre','Liste · « Reprendre ceux d’un autre événement », toujours dans la barre : l’événement, ceux qu’on coche, « Inviter · 3 personnes »'),
               ('V3ListeInviteEnvoyee','Liste · l’invitation est partie : la barre est revenue à « Qui voit ta liste ? », un membre de plus, « Invitation envoyée »')]:
    h,ht,t,row,col=V[_k]; V[_k]=(re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":900}',V['V3ListeQuiModifier'][0]),900,_tt,row,col)
for _k,(_hh,_tt) in _DER.items():
    h,ht,t,row,col=V[_k]; V[_k]=(re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%_hh,h),_hh,_tt,row,col)
# Le Secret Santa et ma partie d'une liste (Julien, 22 novembre 2026) : dessinés à la fin, sur les fichiers
put('V3ListeSecretNouvelle',V['V3ListeNouvelle'][0],1150,'Liste · créée depuis mon Secret Santa : j’y suis déjà, en premier ; sous mon prénom, le Secret Santa ; « Repartir d’une liste » reste proposé tant qu’il n’y a aucune idée',4,22)
put('V3TirageQuelleListe',V['V3TirageVersListe'][0],844,'Secret Santa · « Ma liste de cadeaux » touché quand je tiens déjà une liste où je figure : celle-là, ou une nouvelle',3,8)
put('V3ListeSurligneTout',V['V3ListeSurligne'][0],1674,'Secret Santa · la liste de la personne tirée, « Toute la liste » choisi : tout le monde, elle en premier',3,9)
h,ht,t,row,col=V['V3ListeSurligne']; V['V3ListeSurligne']=(re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1000}',h),1000,'Secret Santa · la liste de la personne tirée, filtrée sur elle : sa partie seule, deux choix en haut (« Inès », « Toute la liste »), le mode anonyme déjà activé',row,col)
for _i,(_k,_hh,_tt) in enumerate([
  ('V3ListeSecretLie',844,'Liste · la pastille « Secret Santa · Famille Camille » touchée : mes Secret Santa de l’année, à cocher ; décocher délie'),
  ('V3ListeSecretLier',1700,'Liste · j’y figure, et un de mes Secret Santa de l’année n’a pas de liste : « Lier à un Secret Santa », dans le menu « … » de ma partie'),
  ('V3ListeSecretLierConfirmer',844,'Liste · « Lier à un Secret Santa » touché : mes Secret Santa de l’année, à cocher ; l’un est lié à une autre liste'),
  ('V3ListeVisiteSecret1',1150,'Visite · liste créée depuis un Secret Santa, 1 sur 6 : ma partie'),
  ('V3ListeVisiteSecret2',1150,'Visite · depuis un Secret Santa, 2 sur 6 : une idée par ligne'),
  ('V3ListeVisiteSecret3',1150,'Visite · depuis un Secret Santa, 3 sur 6 : qui la voit'),
  ('V3ListeVisiteSecret4',1150,'Visite · depuis un Secret Santa, 4 sur 6 : le nom et la date'),
  ('V3ListeVisiteSecret5',1150,'Visite · depuis un Secret Santa, 5 sur 6 : repartir d’une liste (seulement s’il y en a une)'),
  ('V3ListeVisiteSecret6',1150,'Visite · depuis un Secret Santa, 6 sur 6 : ajouter quelqu’un, « Compris »'),
  ('V3ListeVisiteCreer1',844,'Visite · liste créée depuis « Créer », 1 sur 3 : le nom et la date'),
  ('V3ListeVisiteCreer2',844,'Visite · depuis « Créer », 2 sur 3 : pour qui ?'),
  ('V3ListeVisiteCreer3',844,'Visite · depuis « Créer », 3 sur 3 : personne ne la voit encore, « Compris »'),
  ('V3ListeVisiteIdee',900,'Visite · depuis « Créer », la première personne ajoutée : une note sur sa première ligne, une seule fois')]):
    put(_k,V['V3ListeNouvelle'][0],_hh,_tt,4,30+_i)
put('V3TirageNouveauQui',V['V3TirageNouveau'][0],900,'Secret Santa · nouveau, « Devine qui » sur « Qui m’offre ? » : la phrase dit ce qui va se passer',3,10); put('V3TirageNouveauSans',V['V3TirageNouveau'][0],900,'Secret Santa · nouveau, « Devine qui » sur « Sans » : le jeu est éteint',3,11); put('V3TirageNouveauSeul',V['V3TirageNouveau'][0],900,'Secret Santa · nouveau, dans un événement où je suis seul : « Il n’y a que toi pour l’instant. Tu ajoutes les participants juste après. »',3,12)
put('V3AccueilSansSecret',V['V3Accueil'][0],V['V3Accueil'][1],'Accueil · un événement que j’organise n’a pas de Secret Santa cette année : sa carte propose « Créer un Secret Santa », puis « Créer une liste de cadeaux »',0,12)
for _i,(_k,_hh,_tt) in enumerate([
  ('V3ListeLigneMenu',844,'Liste · la poignée de la ligne qu’on écrit, touchée : « Envie » et ses trois étoiles, « En faire un titre », « Supprimer la ligne »'),
  ('V3ListeLigneEtoiles',844,'Liste · trois étoiles choisies : elles se posent au bout de la ligne, on continue d’écrire'),
  ('V3ListeLigneTitre',844,'Liste · « En faire un titre » touché : le point, le texte plus grand, plus de lien ; sa poignée propose « En refaire une idée »'),
  ('V3ListeLigneDeplacer',844,'Liste · « Déplacer vers… » touché : les autres personnes de la liste ; en toucher une y envoie la ligne'),
  ('V3ListeTitres',1100,'Liste · ce que tout le monde lit : un titre sur la ligne de la personne, les étoiles au bout des idées')]):
    put(_k,V['V3ListeNouvelle'][0],_hh,_tt,4,43+_i)
put('V3ListeMotAccueil',V['V3ListeNouvelle'][0],844,'Liste · « Ajouter un mot d’accueil » touché : le mot de départ de la catégorie est proposé, prêt à être changé ; vidé, la liste n’a pas de mot',4,29)
put('V3ListeAideLien',V['V3Liste'][0],844,'Liste · pour celui qui « aide à écrire » : « Le lien » déroule la barre, qui ne contient que le lien à copier',4,21)
names=json.load(open('/tmp/names.json')); meta={}
for k,(h,ht,t,row,col) in V.items():
    if ht is None: ht=int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1))
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
    meta[k]=dict(h=ht,title=_tit(t),x=col*470,y=row*2000)
json.dump(names,open('/tmp/names.json','w')); json.dump(meta,open('/tmp/v3meta.json','w'),ensure_ascii=False,indent=0)
print(len(V),list(V))

# La table de « événement » (D15) est ici parce que la section des textes, plus bas, doit reconnaître un texte déjà passé à « événement ».
EV=[('Fête le 25 décembre, dans 40 jours.','Le 25 décembre, dans 40 jours.'),('Fête le 25 décembre','Le 25 décembre'),('Fête le 19 décembre','Le 19 décembre'),
 ('>Fête le<','>Le<'),('>Fête le <strong','>Le <strong'),('>Fête · dans ','>Jour J · dans '),('>Fêter<','>Jour J<'),('>Fêté<','>Passé<'),('>Fête passée<','>Jour J passé<'),
 ('Date de la fête','Date'),('· fêté le 25 décembre','· le 25 décembre'),('· fête dans ','· dans '),('>Fête dans 36 jours<','>Dans 36 jours<'),
 ('date de la fête à préciser','date à préciser'),('Quand a lieu la fête ?','À quelle date ?'),('La fête est prévue le 25 décembre','Le jour J est le 25 décembre'),
 ('La fête est passée','Le jour J est passé'),('La fête a eu lieu','Le jour J est passé'),('jusqu’à la fête','jusqu’au jour J'),('Attendre la fête','Attendre le jour J'),
 ('la surprise de la fête','la surprise du jour J'),
 ('invité à la fête','invité à l’événement'),('Revenir à la fête','Revenir à l’événement'),('à toute la fête','à tous les membres'),
 ('vant la fête','vant le jour J'),('à la fête','le jour J'),
 ('ournal de la fête','ournal de l’événement'),('Les fêtes passées','Les événements passés'),
 ('pour toute la fête ou seulement','pour tous les membres ou seulement'),('pour toute la fête','pour tout le monde'),('dans toute la fête','pour tout le monde'),
 ('des fêtes que tu rejoins','des événements que tu rejoins'),('rejoint la fête','rejoint l’événement'),('ejoindre la fête','ejoindre l’événement'),
 ('dans la fête mais','dans l’événement mais'),('membres de la fête','membres de l’événement'),('e seuil de la fête','e seuil de l’événement'),
 ('4 fêtes ·','4 événements ·'),('· 2 fêtes','· 2 événements'),('· 1 fête','· 1 événement'),('aucune fête','aucun événement'),
 ('Fêtes à 30 membres','Événements à 30 membres'),('>Fêtes<','>Événements<'),('>fêtes<','>événements<'),
 ('Chercher une fête','Chercher un événement'),('Créer une fête pour','Créer un événement pour'),('ni nouvelle fête','ni nouvel événement'),
 ('La fête, les exclusions','L’événement, les exclusions'),('Quitter cette fête','Quitter cet événement'),('Quitter la fête','Quitter l’événement'),
 ('Supprimer la fête','Supprimer l’événement'),('Garder la fête','Garder l’événement'),('Réglages de la fête','Réglages de l’événement'),
 ('>La fête<','>L’événement<'),('La fête du Secret Santa','L’événement du Secret Santa'),('quelle que soit la fête','quel que soit l’événement'),
 ('d’une fête, ou seulement','d’un événement, ou seulement'),('l’adresse, les fêtes,','l’adresse, les événements,'),('de tes fêtes','de tes événements'),
 ('Dans les fêtes, il reste','Dans les événements, il reste'),('mes fêtes, mes listes','mes événements, mes listes'),('des fêtes où est la liste','des événements où est la liste'),
 ('La fête peut encore accueillir','L’événement peut encore accueillir'),('Créer la fête','Créer l’événement'),('créé la fête','créé l’événement'),('Qui est de la fête ?','Qui en fait partie ?'),
 ('Email de la fête','Email de l’événement'),('la fête est complète','l’événement est complet'),('La fête est complète','L’événement est complet'),
 ('dans une petite fête','dans un petit événement'),('L’exclusion de la fête','L’exclusion de l’événement'),('dans cette fête.','dans cet événement.'),
 ('l’identifiant de la fête','l’identifiant de l’événement'),('Retirer de la fête','Retirer de l’événement'),
 ('sortira de cette fête. Elle reste dans tes autres fêtes.','sortira de cet événement. Elle reste dans tes autres événements.')]
def _evs(x):
    for a,b in EV: x=x.replace(a,b)
    return x

# =================== LA BARRE DU HAUT DES LISTES D'AVANT (D04) ===================
# Les maquettes Liste* gardées disaient encore « Partage par lien » : elles disent où est la liste, comme V3Liste. Se relance sans risque (rien à faire la deuxième fois).
import glob,os
from v3perimees import perimee,intacte
def _bar(h):
    i=h.index('<div data-pub="1"'); d=0
    for mm in re.finditer(r'<div\b|</div>',h[i:]):
        d+=1 if mm.group(0)!='</div>' else -1
        if d==0: return i,i+mm.end()
_VB=vbar('Famille Camille, Chez Mamie','21 membres la voient').replace('FeteChoisir.dc.html','V3ListeQui.dc.html')
_VA=vbar('Famille Camille, Chez Mamie','21 membres la voient · choisi par Camille'); _VA=_VA[:_VA.index('<a href="FeteChoisir.dc.html"')]+'</div>'
_done=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if n in V or perimee(n) or intacte(n): continue
    h=open(f,encoding='utf-8').read()
    if '<div data-pub="1"' not in h: continue
    i,j=_bar(h); t=' / '.join(x.strip() for x in re.findall(r'>([^<>]+)<',re.sub(r'<svg.*?</svg>','',h[i:j],flags=re.S)) if x.strip())
    if t in ('Partage par lien','Famille Camille, Chez Mamie / 21 membres la voient / Modifier'): h=h[:i]+B_EVT+h[j:]
    elif t in ('Partage par lien / Activé par Camille / Partager','Famille Camille, Chez Mamie / 21 membres la voient · choisi par Camille'): h=h[:i]+B_AID+h[j:]
    else: continue
    open(f,'w',encoding='utf-8').write(h); _done.append(n)
json.dump(_done,open('/tmp/v3barre_changed.json','w')); print('barres',len(_done),_done)

# =================== LES TEXTES D'AVANT QUE LA V3 CHANGE SUR LE FOND (D07) ===================
# « Tes données, en clair » et la page de présentation : qui voit une liste a changé, et les pistes n'existent plus. Se relance sans risque.
_TX=[('Tes goûts et tes idées de cadeaux','Ta liste de cadeaux et tes goûts'),
     ('Seulement celui qui t’offre un cadeau.','Ceux que tu choisis dans « Qui verra ta liste ? » : les membres d’une fête, ou seulement celui qui t’a tiré. Avec un lien public, toute personne qui a le lien.'),
     ('Il peut aussi dévoiler le tirage à tout le groupe, et le journal le dit.','Il peut aussi dévoiler le tirage à toute la fête, et le journal le dit.'),
     ('Seuls ceux qui ont le lien les voient, et celui qui tient la liste peut changer ce lien à tout moment.','Seuls les membres des fêtes où est la liste les voient. Si elle est publique, toute personne qui a le lien : celui qui la tient peut changer ce lien, ou l’arrêter.'),
     ('Des anciens tirages, il ne reste','Des anciens Secret Santa, il ne reste'),
     ('Ne peut ni partager la liste, ni inviter, ni la supprimer.','Ne peut ni choisir qui la voit, ni inviter, ni la supprimer.'),
     ('Tout, comme toi : en plus, partager le lien, inviter ou retirer quelqu’un, supprimer la liste.','Tout, comme toi : en plus, choisir qui la voit, inviter ou retirer quelqu’un, supprimer la liste.'),
     ('En plus : partager, inviter, supprimer la liste.','En plus : choisir qui la voit, inviter, supprimer la liste.'),
     ('Partager la liste, inviter quelqu’un, la supprimer : ça reste à Camille.','Choisir qui voit la liste, inviter quelqu’un, la supprimer : ça reste à Camille.'),
     ('Voir la liste telle qu’elle est partagée','Voir la liste telle que le lien la montre'),
     ('Arrêter le partage de cette liste','Arrêter le lien public de cette liste'),
     ('Arrêter le partage et prévenir','Arrêter le lien et prévenir'),
     ('Le partage par lien de cette liste a été arrêté par l’administrateur.','Le lien public de cette liste a été arrêté par l’administrateur.'),
     ('L’interrupteur « Partage par lien » est bloqué tant que l’administrateur ne l’a pas rouvert.','« Tout le monde, avec un lien » reste bloqué tant que l’administrateur ne l’a pas rouvert. Les membres de tes fêtes voient toujours la liste.'),
     ('Le partage de ta liste « Noël chez Camille » a été arrêté','Le lien public de ta liste « Noël chez Camille » a été arrêté'),
     ('a arrêté le partage par lien de ta liste','a arrêté le lien public de ta liste'),
     ('Pour la partager de nouveau :','Pour la rouvrir à tous :'),
     ('Inès reçoit un email qui l’invite à noter ses goûts et ce qu’il vaut mieux éviter.','Inès reçoit un email qui l’invite à écrire sa liste et ses goûts.'),
     ('Aide-la : six questions à choix, trente secondes, et quelques mots si tu veux.','Aide-la : écris ta liste de cadeaux, ou quelques mots sur ce que tu aimes.'),
     ('>Écrire quelques idées<','>Écrire ma liste<'),
     ('>Camille te demande ta liste<','>Quelqu’un te demande des idées<'),
     ('Le Secret Santa de la famille, et les listes de cadeaux qui vont avec.','Le Secret Santa et les listes de cadeaux, pour toutes les occasions.'),
     ('@@SHOT:PistesResultat:','@@SHOT:V3TirageVersListe:'),
     ('Six questions, trente secondes. Chacun dit ce qui lui ferait plaisir et ce qu’il vaut mieux éviter. Son Père Noël les lit en ouvrant son enveloppe.','Chacun écrit sa liste et ses goûts, pour toute la fête ou seulement pour celui qui l’a tiré.')]
_tx=[]; _seen=set()
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if n in V or perimee(n) or intacte(n): continue
    h0=open(f,encoding='utf-8').read(); h=h0
    for a,b in _TX:
        if a in h: h=h.replace(a,b); _seen.add(a)
        elif b in h or _evs(b) in h or _evs(a) in h: _seen.add(a)
    if h!=h0: open(f,'w',encoding='utf-8').write(h); _tx.append(n)
assert len(_seen)==len(_TX),[a for a,b in _TX if a not in _seen]
_PU='Une liste se tient à deux, et tout se met à jour en direct.'; _PN='Tes proches la voient sans lien à envoyer : tu les invites une fois, pas à chaque liste.'
for n in ('Landing','LandingDesktop'):
    h=open(PJ+n+'.dc.html',encoding='utf-8').read()
    if _PN in h: continue
    m=re.search(r'<li style="[^"]*">(?:(?!</li>).)*?<span>'+re.escape(_PU)+r'</span></li>',h,re.S); assert m,n
    h=h[:m.end()]+m.group(0).replace(_PU,_PN)+h[m.end():]; open(PJ+n+'.dc.html','w',encoding='utf-8').write(h); _tx.append(n)
print('textes',len(_tx),_tx)

# =================== PLUS AUCUN LIEN VERS UNE MAQUETTE PÉRIMÉE ===================
# Les périmées ont quitté le canevas (Julien, 20 novembre 2026) : ce qui y menait mène à ce qui les remplace. Toutes les maquettes gardées, V3 et Futur comprises.
_LK={'AccueilFetes2':'V3Accueil','GroupeInvitation':'V3FeteInviter','ListeNouvelle':'V3ListeNouvelle','Admin':'V3Admin','AdminComptes':'V3AdminComptes','AdminCompte':'V3AdminCompte',
     'TiragesPasses':'V3FetesPassees','NotifCentre':'V3QuoiDeNeuf','PistesResultat':'V3TirageVersListe','PistesResultatListe':'V3TirageVersListe','PistesResultatNouvelles':'V3TirageNouvelles','Groupe':'V3FeteOrganisateur','PanneauDemandeGroupe':'V3TirageQuelleFete','ListeEtatPubliee':'V3ListePublique','ListeChangerLien':'V3ListeLienChanger',
     'ListeEtatBrouillon':'V3ListeNouvelle','FeteChoisir':'V3ListeQui','GroupeReglages':'V3FeteReglages','GroupeMembres':'V3FeteMembres','EditionReglages':'V3TirageReglages','GroupeNouveau':'V3FeteNouvelle','PropEditionReglages':'V3TirageReglages','EditionNouvelle':'V3TirageNouveau','SouhaitsIdee':'ListeIdee','AdminDemande':'V3Admin','AdminDemandes':'V3Admin','Accueil':'V3Accueil','ListesAccueil':'V3Accueil','Pistes':'V3ListeSecret','Rejoindre':'V3FeteRejoindre'}
_lk=[]; _rest={}; _NM=set(json.load(open('/tmp/names.json')))
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if perimee(n) or n+'.dc.html' not in _NM or n.startswith('Style'): continue
    h0=open(f,encoding='utf-8').read(); h=h0
    for a,b in _LK.items(): h=h.replace('href="'+a+'.dc.html"','href="'+b+'.dc.html"')
    for m in set(re.findall(r'href="([A-Za-z0-9]+)\.dc\.html"',h)):
        if perimee(m): _rest.setdefault(m,[]).append(n)
    if h!=h0: open(f,'w',encoding='utf-8').write(h); _lk.append(n)
print('liens',len(_lk),_lk); assert not _rest,_rest

# =================== « ÉVÉNEMENT », PAS « FÊTE » (D15, Julien, 21 novembre 2026) ===================
# Le nom commun de la chose est « événement ». Le jour lui-même n'est pas « l'événement » : la date seule, ou « le jour J ».
# Toutes les maquettes gardées, V3 comprises. L'ordre compte (le plus précis d'abord). Se relance sans risque.
_ev=[]; _reste={}
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if perimee(n) or n+'.dc.html' not in _NM or n.startswith('Style'): continue
    h0=open(f,encoding='utf-8').read(); k=h0.index('<x-dc>') if '<x-dc>' in h0 else 0; h=h0[k:]
    for a,b in EV: h=h.replace(a,b)
    t=re.sub(r'<svg.*?</svg>|<style.*?</style>|<script.*?</script>','',h,flags=re.S)
    for x in re.findall(r'>([^<>]*[Ff]êt[^<>]*)<',t)+re.findall(r'(?:aria-label|placeholder|value)="([^"]*[Ff]êt[^"]*)"',h): _reste.setdefault(x.strip(),[]).append(n)
    if h0[:k]+h!=h0: open(f,'w',encoding='utf-8').write(h0[:k]+h); _ev.append(n)
print('événement',len(_ev)); print('reste',{k:len(v) for k,v in _reste.items()})

# =================== LE LIEN D'INVITATION EST CELUI D'UN SECRET SANTA (Julien, 21 novembre 2026, contre la réponse à Q-017) ===================
# On s'inscrit à un Secret Santa, et du coup à son événement. Il n'y a plus de lien d'invitation d'un événement.
# Sur les fichiers finis, après « événement ». Se relance sans risque : un texte déjà passé est reconnu.
_INV='<span style="font-size: 14px; font-weight: 700; color: #8a2f27">Inviter</span>'
_LIEN={
 'V3FeteInviter':[('>Famille Camille</a></nav>','>Famille Camille · Secret Santa 2026</a></nav>'),
                  ('Ceux qui s’inscrivent rejoignent aussi le Secret Santa, tant que le tirage n’a pas eu lieu.','Ceux qui s’inscrivent participent au Secret Santa et deviennent membres de l’événement.'),
                  ('Tu es invité à l’événement « Famille Camille »','Tu es invité au Secret Santa « Famille Camille »')],
 'V3FeteRejoindre':[('Tu es invité à l’événement','Tu es invité au Secret Santa'),('· 5 membres','· 5 inscrits'),('pour la rejoindre.','pour participer.')],
 'RejoindreConnecte':[('Rejoindre l’événement','Participer')],
 'PanneauNombre':[('peuvent encore rejoindre l’événement par ce lien','peuvent encore s’inscrire par ce lien')],
 'ChargementReglage':[('Quelqu’un rejoint l’événement par le lien','Quelqu’un s’inscrit par le lien')],
 'V3TirageReglages':[('Quelqu’un rejoint l’événement par le lien','Quelqu’un s’inscrit par le lien')],
 'V3FeteOrganisateur':[(_INV,'')],'V3FeteAnniversaire':[(_INV,'')],
}
for _n in ['V3FeteMembres','V3FeteMembresComplet','GroupeMembres100','GroupeMembres100Deplie']:
    _LIEN[_n]=[('>Inviter par lien</span>','>Au Secret Santa</span>'),('>Inviter au Secret Santa</span>','>Au Secret Santa</span>')]
_LIEN['V3FeteMembres']+=[('Ou laisse-les s’inscrire','Ajouter quelqu’un'),('Actif · 10 places restantes','5 participants · lien actif')]
_SUB=[('camille-demo@example.com · ne tire pas Hugo','Secret Santa · ne tire pas Hugo'),('hugo-demo@example.com · ne tire pas Camille','Secret Santa · ne tire pas Camille'),('>ines-demo@example.com<','>Secret Santa<'),('>louis-demo@example.com<','>La liste de Camille<'),('>Pas d’adresse email<','>Secret Santa · pas d’adresse email<')]
_LIEN['V3FeteMembres']+=_SUB; _LIEN['V3FeteMembresComplet']+=_SUB
_LIEN['V3FeteMembresReprendre']=[('Qui en fait partie ?','Qui reprendre ?'),('Reprendre les membres de','Ceux de'),('Inviter d’autres personnes','Inviter par lien'),('Par un lien, après avoir créé l’événement','Chacun s’inscrit lui-même'),('Créer l’événement · 5 membres','Ajouter · 4 personnes')]
_LIEN['V3FeteNouvelle']=[('href="V3FeteMembresReprendre.dc.html"','href="V3TirageNouveau.dc.html"')]
_li=[]
for _n,_p in _LIEN.items():
    f=PJ+_n+'.dc.html'; h0=open(f,encoding='utf-8').read(); h=h0; _miss=[]
    for a,b in _p:
        if a in h: assert h.count(a)==1 or a.startswith('Quelqu’un rejoint'),(_n,a,h.count(a)); h=h.replace(a,b)
        else: _miss.append((a,b))
    for a,b in _miss: assert (not b) or b in h,(_n,a)
    if h!=h0: open(f,'w',encoding='utf-8').write(h); _li.append(_n)
def _lirow(h,key):
    i=h.index(key); a=h.rindex('<li',0,i); return a,h.index('</li>',i)+5
# « Membres » : plus d'« Ajouter une personne » ; sous « Ajouter quelqu'un », le Secret Santa et ma liste
_LSVG='<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'
for _n in ['V3FeteMembres','GroupeMembres100','GroupeMembres100Deplie']:
    f=PJ+_n+'.dc.html'; h=open(f,encoding='utf-8').read()
    if 'Ajouter une personne' in h:
        a,b=_lirow(h,'Ajouter une personne'); h=h[:a].rstrip()+h[b:]
    if _n=='V3FeteMembres' and '>À ma liste<' not in h:
        a,b=_lirow(h,'>Au Secret Santa<'); li=h[a:b]
        c=li.replace('>Au Secret Santa<','>À ma liste<',1).replace('5 participants · lien actif','Léo, Zoé et moi',1).replace('href="V3FeteInviter.dc.html"','href="V3ListeInviter.dc.html"',1).replace('box-sizing: border-box; text-decoration: none','box-sizing: border-box; border-top: 1px solid #e9dcc5; text-decoration: none',1)
        k=c.index('<path d="M10 13a5'); c=c[:k]+_LSVG+c[c.index('</svg>',k):]
        assert c!=li; h=h[:b]+'\n        '+c+h[b:]
        h=h.replace('href="V3FeteInviter.dc.html"','href="AjouterParticipants.dc.html"',1)
    open(f,'w',encoding='utf-8').write(h)
# « Choisir les participants » : reprendre ceux d'un autre événement
f=PJ+'AjouterParticipants.dc.html'; h=open(f,encoding='utf-8').read()
if 'Reprendre ceux d’un autre événement' not in h:
    a,b=_lirow(h,'>Inviter par lien<'); li=h[a:b]
    c=li.replace('>Inviter par lien<','>Reprendre ceux d’un autre événement<',1).replace('Chacun s’inscrit lui-même','Tu coches qui',1).replace('href="V3FeteInviter.dc.html"','href="V3FeteMembresReprendre.dc.html"',1)
    k=c.index('<path d="M10 13a5'); c=c[:k]+'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.870"/><path d="M16 3.130a4 4 0 0 1 0 7.750"/>'+c[c.index('</svg>',k):]
    h=h[:b]+'\n        '+c+h[b:]; open(f,'w',encoding='utf-8').write(h)
# « Qui verra ta liste ? » : « Inviter quelqu'un », après « Une autre occasion »
_qv=[]
for f in sorted(glob.glob(PJ+'V3Liste*.dc.html')):
    h=open(f,encoding='utf-8').read()
    if 'Qui verra ta liste' not in h or '>Inviter quelqu’un<' in h or '>Une autre occasion<' not in h: continue
    a,b=_lirow(h,'>Une autre occasion<'); li=h[a:b]
    c=li.replace('>Une autre occasion<','>Inviter quelqu’un<',1).replace('href="V3FeteNouvelle.dc.html"','href="V3ListeInviter.dc.html"',1).replace('<path d="M12 5v14M5 12h14"/>',_PP,1).replace('border: 1.5px dashed #cdb48a','border: 1.5px solid #cdb48a',1)
    assert c.count('Inviter quelqu’un')==1 and _PP in c
    open(f,'w',encoding='utf-8').write(h[:b]+c+h[b:]); _qv.append(os.path.basename(f)[:-8])
print('qui verra',_qv)
for f in sorted(glob.glob(PJ+'*.dc.html')):
    n=os.path.basename(f)[:-8]
    if perimee(n) or n+'.dc.html' not in _NM or n.startswith('Style'): continue
    h=open(f,encoding='utf-8').read()
    for x in ['invité à l’événement','rejoint l’événement par le lien','rejoindre l’événement par']: assert x not in h,(n,x)
print('lien',len(_li),_li)


# =================== « LISTE DE CADEAUX », EN TOUTES LETTRES (Julien, 22 novembre 2026) ===================
# « Une liste » et « Ma liste » ne disaient ni de quoi, ni pour qui : « Une liste de cadeaux », « Ma liste de cadeaux », et dessous « Pour Léo, Zoé et moi ».
_lc=[]
for f in sorted(glob.glob(PJ+'V3*.dc.html')):
    h0=open(f,encoding='utf-8').read(); h=h0
    for a,b in [('>Une liste<','>Une liste de cadeaux<'),('>Ma liste<','>Ma liste de cadeaux<'),('>Léo, Zoé et moi','>Pour Léo, Zoé et moi')]:
        h=h.replace(a,b)
    if h!=h0: open(f,'w',encoding='utf-8').write(h); _lc.append(os.path.basename(f)[:-8])
print('liste de cadeaux',len(_lc),_lc)

# =================== « REPARTIR D'UNE LISTE » : SEULEMENT CELLES QUI RESSEMBLENT (Julien, 22 novembre 2026) ===================
# Une liste de Noël ne propose pas « Les 6 ans de Léo » : le même événement une autre année, la même catégorie, ou une personne en commun. Les prénoms, pas « 4 personnes ».
f=PJ+'ListeNouvelleReprendre.dc.html'; h=open(f,encoding='utf-8').read()
if 'Les 6 ans de Léo' in h:
    i=h.index('Les 6 ans de Léo'); a=h.rindex('<a href',0,i); b=h.index('</a>',i)+4; h=h[:a]+h[b:]
for x,y in [('4 personnes · 6 idées pas encore offertes','Léo, Zoé et moi · 6 idées pas encore offertes'),('>Nom de l’événement<','>Noël 2026<'),('>Ajouter une date<','>Le 25 décembre<'),('>🎁<','>🎄<')]:
    if x in h: assert h.count(x)==1,(x,h.count(x)); h=h.replace(x,y)
    else: assert y in h,x
open(f,'w',encoding='utf-8').write(h)

# =================== COCHER POUR QUELQU'UN (ticket 099, sur main) ===================
# Le pendant de « Décocher pour quelqu'un ». Six écrans, dans l'ordre du parcours, faits sur les fichiers finis.
_PAS='<span style="display: inline-block; text-decoration: none; font-size: 12px; line-height: 20px; font-weight: 600; letter-spacing: 0.01em; color: #57534e; background: #f1e8d8; border-radius: 999px; padding: 1px 9px">'
_CH12='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="m9 6 6 6-6 6"/></svg>'
def _touch(h):
    # pour celui qui tient la liste, les prénoms se touchent (un filet, une flèche sur le dernier) ; pas « Anonyme », pas un cadeau hors liste
    out=[]; pos=0; nb=0
    for m in re.finditer(re.escape(_PAS)+r'([^<]*)</span>',h):
        li=h.rindex('<li',0,m.start()); out.append(h[pos:m.start()]); pos=m.end()
        if m.group(1)=='Anonyme' or 'Hors liste' in h[li:m.start()]: out.append(m.group(0)); continue
        last=not h.startswith(_PAS,m.end())
        out.append('<span style="display: inline-flex; align-items: center; gap: 3px; text-decoration: none; font-size: 12px; line-height: 20px; font-weight: 600; letter-spacing: 0.01em; color: #57534e; background: #f1e8d8; border-radius: 999px; padding: 1px %s 1px 9px; box-shadow: inset 0 0 0 1.5px #cdb48a">%s%s</span>'%('6px' if last else '9px',m.group(1),_CH12 if last else '')); nb+=1
    assert nb>=4,nb; return ''.join(out)+h[pos:]
_T=open(PJ+'ListeTeneur.dc.html',encoding='utf-8').read()
_i=_T.index('Draisienne'); _k=_T.index(_PAS+'Mamie</span>',_i); _T=_T[:_k]+_PAS+'Tata</span>'+_T[_k+len(_PAS+'Mamie</span>'):]
_T=_touch(_T)
def _tit2(h,t): return re.sub(r'<title>[^<]*</title>','<title>'+t+'</title>',h,count=1)
def _li(h,key):
    i=h.index(key); a=h.rindex('<li',0,i); return a,h.index('</li>',i)+5
_LIV='Livres sur les dinosaures (il les a presque tous, demandez-nous)'
# 1. je coche : c'est à mon nom
_chip=re.search(r'<span data-chip="etat".*?Tu l’offres<svg.*?</svg></span>',open(PJ+'ListeCocheGuide.dc.html',encoding='utf-8').read(),re.S).group(0)
_a,_b=_li(_T,_LIV); _l=_T[_a:_b]
_c='border: 2px solid #a8a29e; background: #fffdf9"></span>'; assert _l.count(_c)==1
_t='<span style="color: #292524">'+_LIV+'</span>'; assert _l.count(_t)==1
_l1=_l.replace(_c,'background: #2f613f; color: #ffffff"><svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg></span>',1).replace(_t,_t.replace('color: #292524','color: #292524; font-weight: 600')+'<span data-par="1" style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; text-decoration: none">'+_chip+'</span>',1)
_MOI=_T[:_a]+_l1+_T[_b:]
open(PJ+'ListeCocherPourMoi.dc.html','w',encoding='utf-8').write(_tit2(_MOI,'Cocher pour quelqu’un : je coche, c’est à mon nom'))
# 4. enregistré : la ligne dit « Mamie »
_ca,_cb=_li(_T,'Circuit de billes, le grand modèle'); _cl=_T[_ca:_cb]
_cl,_n=re.subn(r'<span data-lien="\d+".*?</span></span>','',_cl,count=1,flags=re.S); assert _n==1 and _cl.count('Circuit de billes, le grand modèle')==1
_l4=_cl.replace('Circuit de billes, le grand modèle',_LIV,1)
_LIG=_T[:_a]+_l4+_T[_b:]
open(PJ+'ListeCocherPourLigne.dc.html','w',encoding='utf-8').write(_tit2(_LIG,'Cocher pour quelqu’un : enregistré, les prénoms se touchent'))
# le panneau « Qui l'offre ? »
_neutre=f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 50%; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',18)}</span>'
_plus=f'<span aria-hidden="true" style="width: 36px; height: 36px; box-sizing: border-box; border-radius: 50%; border: 1.5px dashed #cdb48a; color: #8a2f27; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M12 5v14M5 12h14"/>',16,2.4)}</span>'
def _mark(on,rond,nom='qui'):
    # les composants de l'application : le bouton radio et la case à cocher natifs, à la couleur du thème (comme « Choisir les participants »)
    if rond: return '<input type="radio" name="'+nom+'"'+(' checked' if on else '')+' style="width: 22px; height: 22px; margin: 0; accent-color: #b8483a; flex-shrink: 0">'
    return '<input type="checkbox"'+(' checked' if on else '')+' style="width: 24px; height: 24px; margin: 0; accent-color: #b8483a; flex-shrink: 0">'
def _pr(lead,t,sub,on,rond,first=False,nom='qui'):
    sb=f'<span style="font-size: 13px; color: {MUT}">{sub}</span>' if sub else ''
    return (f'<li><label style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 6px 20px 6px 16px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} color: {INK}">'
            f'{lead}<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">{t}</span>{sb}</span>{_mark(on,rond,nom)}</label></li>')
def _pill(t,on):  # le composant UiSegmented : une piste grise, le choix fait en blanc et en gras ; les coins s'emboîtent (rayon du choix = rayon de la piste moins la marge)
    return ('<button role="radio" aria-checked="true" style="height: 40px; border: 0; border-radius: 8px; background: #fffdf9; box-shadow: 0 1px 2px rgba(60, 30, 10, 0.12); color: #292524; font-family: inherit; font-size: 14px; font-weight: 700">'+t+'</button>' if on
            else '<button role="radio" aria-checked="false" style="height: 40px; border: 0; border-radius: 8px; background: transparent; color: #57534e; font-family: inherit; font-size: 14px; font-weight: 600">'+t+'</button>')
def _panneau(idee,trace,plusieurs,qui,nom='qui'):
    rond=not plusieurs
    P=[(av('🦌',36),'Moi',''),(av('🧶',36),'Mamie',''),(av('🎸',36),'Tonton',''),(av('🐧',36),'Hugo','Tient la liste avec toi'),(_neutre,'Tata','Pas d’adresse email'),(_neutre,'Parrain','parrain-demo@example.com')]
    bas=(f'<div style="display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 0 20px"><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">On est au complet</span><span style="font-size: 13px; color: {MUT}">D’autres peuvent encore se joindre</span></span>{SWOFF.replace("Tout le monde, avec un lien","On est au complet")}</div>') if plusieurs else ''
    return (f'<div style="display: flex; flex-direction: column; gap: 2px; padding: 0 20px"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px">Qui l’offre ?</h2><p style="margin: 0; font-size: 14px; color: {MUT}">{idee} · pour Léo</p><p style="margin: 0; font-size: 13px; color: {MUT}">{trace}</p></div>'
            f'<div style="padding: 0 16px"><div role="radiogroup" aria-label="Combien l’offrent" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 12px; background: #f1e8d8">{_pill("Une personne",not plusieurs)}{_pill("Plusieurs",plusieurs)}</div></div>'
            f'<ul role="{"radiogroup" if rond else "group"}" aria-label="Qui l’offre" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'
            +''.join(_pr(l,t,sb,t in qui,rond,k==0,nom) for k,(l,t,sb) in enumerate(P))
            +f'<li><div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 6px 16px; box-sizing: border-box; border-top: 1px solid {SOFT}; color: {MUT}">{_plus}<span style="flex-grow: 1; font-size: 16px">Quelqu’un d’autre…</span></div></li></ul>'
            +bas+f'<div style="padding: 0 16px"><button style="{BTN}; width: 100%">Enregistrer</button></div>')
def _fond(h): return re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":844}',h)
_FM=_fond(_MOI); _FL=_fond(_LIG)
open(PJ+'ListeCocherPourDepart.dc.html','w',encoding='utf-8').write(_tit2(sheet(_FM,_panneau('Livres sur les dinosaures','Coché par toi, aujourd’hui',False,{'Moi'},'qui-depart'),120,'Qui l’offre ?'),'Cocher pour quelqu’un : qui l’offre ? Une personne, moi'))
open(PJ+'ListeCocherPourChoix.dc.html','w',encoding='utf-8').write(_tit2(sheet(_FM,_panneau('Livres sur les dinosaures','Coché par toi, aujourd’hui',False,{'Mamie'},'qui-choix'),120,'Qui l’offre ?'),'Cocher pour quelqu’un : je touche Mamie'))
open(PJ+'ListeCocherPour.dc.html','w',encoding='utf-8').write(_tit2(sheet(_FL,_panneau('Vélo 16 pouces','Proposé par Mamie, le 12 novembre',True,{'Mamie','Tonton'}),90,'Qui l’offre ?'),'Cocher pour quelqu’un : à plusieurs'))
# 6. quelqu'un d'autre
_qa=(f'<div style="display: flex; flex-direction: column; gap: 2px; padding: 0 20px"><h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px">Quelqu’un d’autre</h2><p style="margin: 0; font-size: 14px; color: {MUT}">Livres sur les dinosaures · pour Léo</p></div>'
     f'<div style="display: flex; flex-direction: column; gap: 14px; padding: 0 16px">'
     f'<div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son prénom</label><div style="{FIELD}">Parrain</div></div>'
     f'<div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son adresse email <span style="font-weight: 400; color: {MUT}">(facultatif)</span></label><div style="{FIELD}; color: {MUT}">prenom@exemple.fr</div><p style="margin: 0; font-size: 13px; line-height: 1.4; color: {MUT}">Avec son adresse, il retrouvera ce cadeau en se connectant. Aucun email ne lui est envoyé.</p></div>'
     f'<button style="{BTN}; width: 100%">Ajouter</button></div>')
open(PJ+'ListeCocherPourAutre.dc.html','w',encoding='utf-8').write(_tit2(sheet(_FM,_qa,430,'Quelqu’un d’autre'),'Cocher pour quelqu’un : quelqu’un d’autre'))
print('cocher pour quelqu’un : 6 maquettes')


# =================== LA BARRE DU HAUT SE DÉROULE SUR PLACE (Julien, 22 novembre 2026) ===================
# Repliée : une ligne (bar2). Son bouton la déroule là où elle est : le lien et « Copier le lien », puis « Qui verra ta liste ? ». Plus de panneau du bas.
# Déroulée, elle reste collée en haut (Julien, 13 h) ; plus haute que l'écran, c'est son contenu qui défile.
# Elle passe par-dessus la liste, elle ne la pousse pas (Julien, 17 h, après l'avoir essayée) : la place de la barre repliée reste, la carte déroulée flotte au-dessus.
# Fait sur les fichiers finis : le panneau « Qui verra ta liste ? » des six écrans est versé dans la barre.
_OUV=(f'<div data-pub="1" data-deroulee="1" style="position: sticky; top: 8px; z-index: 5; height: 52px">'
      f'<div style="position: absolute; left: 0; right: 0; top: 0; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 18px 40px rgba(41, 37, 36, 0.24); padding: 0 0 8px; display: flex; flex-direction: column; gap: 10px; overflow: hidden">')
def _entete(cb,ferme):
    head=cb[cb.index('>')+1:-6]
    head,n=re.subn(r'<a href="[^"]*"( style="[^"]*">)[^<]*</a>',lambda m:'<a href="'+ferme+'.dc.html"'+m.group(1)+'Fermer</a>',head,count=1)
    return '<div style="min-height: 52px; margin-bottom: -6px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 10px">'+head+'</div>'
def _dans(x):
    for a,b,must in [('padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px','padding: 4px 14px 0; font-family: '+F+'; font-weight: 700; font-size: 18px',True),
                     ('min-height: 60px; padding: 8px 16px;','min-height: 56px; padding: 6px 14px;',True),
                     ('min-height: 56px; padding: 0 20px','min-height: 52px; padding: 0 14px',False),
                     ('<div style="padding: 0 16px">','<div style="padding: 0 8px">',False),
                     ('style="margin: 0 16px; padding: 14px;','style="margin: 0 8px; padding: 14px;',False),
                     ('padding: 6px 16px 6px 20px;','padding: 6px 14px;',False)]:
        assert (a in x) or not must,a; x=x.replace(a,b)
    # le lien est déjà en haut de la barre déroulée : on ne le redit pas sous « Tout le monde, avec le lien »
    k=x.find('<div style="margin: 0 16px; display: flex; align-items: center; gap: 10px; padding: 6px 6px 6px 12px; border-radius: 14px; background: #f1e8d8">')
    if k>=0: x=x[:k]+x[x.index('</button></div>',k)+15:]
    # « Tous les membres » / « Celui qui m'a tiré » : le composant UiSegmented
    k=x.find('<div role="radiogroup" aria-label="Dans Famille Camille, qui la verra"')
    if k>=0:
        e=x.index('</div>',k)+6; on=x[k:e].index('aria-checked="true"')<x[k:e].index('Tous les membres')
        x=x[:k]+'<div role="radiogroup" aria-label="Dans Famille Camille, qui la verra" style="margin: 0 14px 12px 58px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 12px; background: #f1e8d8">'+_pill('Tous les membres',on)+_pill('Celui qui m’a tiré',not on)+'</div>'+x[e:]
    return x
def _deroule(n,ferme,dedans=None,lien=True):
    f=PJ+n+'.dc.html'; h=open(f,encoding='utf-8').read()
    if 'role="dialog"' in h:
        i=h.index('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45)'); z=h.rindex('</div>\n</x-dc>')
        k=h.index('</span>',h.index('<div role="dialog"',i))+7; vieux=h[k:z]; assert vieux.endswith('</div>'); h=h[:i]+h[z:]
        if dedans is None: dedans=_dans(vieux[:-6])
    elif dedans is None: return False
    a,b=_bar(h); cb=h[a:b]; assert 'data-deroulee' not in cb,n
    h=h[:a]+_OUV+_entete(cb,ferme)+(globals().get('_LIENC',BARRE_LIEN) if lien else '')+dedans+'</div></div>'+h[b:]
    # la barre déroulée pousse la page : le fond suit jusqu'en bas de l'aperçu
    P=int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1)); k=h.index('<div style="width: 390px; height: ',h.index('<x-dc>'))+len('<div style="width: 390px; height: '); e=h.index('px',k)
    if int(h[k:e])<P: h=h[:k]+str(P)+h[e:]
    open(f,'w',encoding='utf-8').write(h); return True
# « Qui verra ta liste ? », redessiné (Julien, 22 novembre 2026 : « c'est incompréhensible », puis « un mixte entre la 1 et la 3 », « que 2 entrées »).
# En haut, deux choix qui s'excluent : « Qui je veux » ou « Tout le monde ». Sous le premier, seulement ceux qui la voient, chacun avec sa croix,
# et « Ajouter », qui déroule le reste en pastilles. Sous le second, ce qui ne concerne que le lien public. Plus de bouton « Enregistrer » : chaque geste s'applique.
def _tu(svg,bg,fg): return f'<span aria-hidden="true" style="width: 28px; height: 28px; border-radius: 9px; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{svg}</span>'
_T_SS=_tu(ic(I_TIR,15,2.2),'#efe3ec','#5b3a55')
_c=lambda c: cat(c,28)
_BTNC=BTN.replace('height: 48px','height: 44px'); assert _BTNC!=BTN
_LIENC=BARRE_LIEN.replace('padding: 6px 6px 6px 12px','padding: 4px 4px 4px 12px').replace('height: 36px','height: 34px'); assert _LIENC.count('height: 34px')==1
assert _LIENC.count('border-radius: 999px')==1; _LIENC=_LIENC.replace('border-radius: 999px','border-radius: 11px')   # le bouton s'emboîte dans le champ de l'adresse
_XI=ic('<path d="M6 6l12 12M18 6 6 18"/>',16,2.2); _CHD=ic('<path d="m6 9 6 6 6-6"/>',18); _CHU=ic('<path d="m6 15 6-6 6 6"/>',18)
def _vu(lead,t,sub,first=False):
    return (f'<li><div style="display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 2px 4px 2px 14px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} color: {INK}">{lead}'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 15px">{t}</span><span style="font-size: 13px; color: {MUT}">{sub}</span></span>'
            f'<button aria-label="Retirer {t}" style="width: 44px; height: 44px; border: 0; border-radius: 50%; background: transparent; color: {MUT}; display: flex; align-items: center; justify-content: center; padding: 0; flex-shrink: 0">{_XI}</button></div></li>')
def _pa(e,t): return (f'<button style="height: 36px; padding: 0 12px 0 10px; border: 1px solid {LINE}; border-radius: 999px; background: {CARD}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; white-space: nowrap"><span aria-hidden="true" style="display: flex; font-size: 14px">{e}</span>{t}</button>')
_PA_SS=_pa(f'<span style="display: flex; color: #5b3a55">{ic(I_TIR,16,2.2)}</span>','Celui qui m’a tiré')
_PA_AUTRE=f'<a href="V3ListeInviter.dc.html" style="height: 36px; box-sizing: border-box; padding: 0 12px; border: 1px dashed #cdb48a; border-radius: 999px; color: {DRED}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px; white-space: nowrap">{PLUS}Quelqu’un d’autre</a>'
def _aj(ouvert,pastilles,first=False,autre=True):
    tete=(f'<li><button aria-expanded="{"true" if ouvert else "false"}" style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 2px 14px; box-sizing: border-box; border: 0;{"" if first else f" border-top: 1px solid {SOFT};"} background: transparent; font-family: inherit; text-align: left; color: {INK}"><span aria-hidden="true" style="width: 28px; height: 28px; box-sizing: border-box; border-radius: 8px; border: 1.5px dashed #cdb48a; color: {DRED}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{PLUS}</span><span style="flex-grow: 1; font-weight: 600; font-size: 15px">Ajouter</span><span style="color: #78716c; display: flex">{_CHU if ouvert else _CHD}</span></button>')
    return tete+(f'<div style="display: flex; flex-wrap: wrap; gap: 8px; padding: 0 12px 10px">{"".join(pastilles)}{_PA_AUTRE if autre else ""}</div>' if ouvert else '')+'</li>'
def _pill2(t,on):
    x=_pill(t,on).replace('height: 40px','height: 34px'); assert x.count('border-radius: 8px')==1; return x.replace('border-radius: 8px','border-radius: 11px')
def _seg2(tous): return (f'<div role="radiogroup" aria-label="Qui voit ta liste" style="margin: 0 8px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 3px; padding: 3px; border-radius: 14px; background: #f1e8d8">'+_pill2('Qui je veux',not tous)+_pill2('Tout le monde',tous)+'</div>')
def _sr(t,href,first=False): return (f'<li><a href="{href}" style="display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 2px 14px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}"><span style="flex-grow: 1; font-size: 15px; font-weight: 600">{t}</span><span style="color: #78716c; display: flex">{CHEV}</span></a></li>')
def _conf(lab,titre,texte,non,oui): return (f'<div role="alertdialog" aria-label="{lab}" style="margin: 0 8px; padding: 14px; border-radius: 14px; box-shadow: 0 0 0 1px {LINE}; display: flex; flex-direction: column; gap: 10px"><h3 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 18px">{titre}</h3>'
      f'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: {INK}">{texte}</p><div style="display: flex; gap: 8px"><a href="{non}.dc.html" style="{BTN2}; flex: 1">Annuler</a><button style="flex: 1; height: 44px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 15px; font-weight: 700">{oui}</button></div></div>')
_UL=f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">'
def _qui3(tous,dedans,bas=''):
    return (f'<h2 style="margin: 0; padding: 4px 14px 0; font-family: {F}; font-weight: 700; font-size: 16px">Qui voit ta liste ?</h2>'+_seg2(tous)+_UL+dedans+'</ul>'+bas)
_V_SS=lambda first=False:_vu(_T_SS,'Celui qui m’a tiré','Secret Santa · Famille Camille',first)
_V_FC=lambda first=False:_vu(_c('Noël'),'Famille Camille','12 membres',first); _V_CM=lambda first=False:_vu(_c('Noël'),'Chez Mamie','9 membres',first)
_P_FC=_pa('🎄','Famille Camille'); _P_CM=_pa('🎄','Chez Mamie'); _P_BU=_pa('🎄','Bureau, 3e étage'); _P_TO=_pa('🎂','Les 40 ans de Tonton')
_PUB=_sr('Changer de lien','V3ListeLienChanger.dc.html',True); _CL=_sr('Changer de lien','V3ListeLienChanger.dc.html')
_Q2={'V3ListeQui':('V3ListeNouvelle',_qui3(False,_aj(True,[_PA_SS,_P_FC,_P_CM,_P_BU,_P_TO],True,False))),
     'V3ListeQuiModifier':('V3Liste',_qui3(False,_V_FC(True)+_V_CM()+_aj(False,[])+_CL)),
     'V3ListeQuiAjouter':('V3Liste',_qui3(False,_V_FC(True)+_V_CM()+_aj(True,[_PA_SS,_P_BU,_P_TO])+_CL)),
     'V3ListeQuiSecret':('V3ListeSecret',_qui3(False,_V_SS(True)+_aj(False,[]))),
     'V3ListeQuiLien':('V3ListePublique',_qui3(True,_PUB))}
# « Quelqu'un d'autre » ne quitte plus l'encart (Julien, 23 novembre 2026) : une navigation interne, avec un retour. Le lien n'est qu'au premier niveau.
_CHL=ic('<path d="m15 6-6 6 6 6"/>',20)
def _niv(titre,retour,dedans): return (f'<a href="{retour}.dc.html" aria-label="Retour" data-niveau="1" style="align-self: flex-start; display: flex; align-items: center; gap: 4px; min-height: 44px; padding: 0 14px 0 8px; text-decoration: none; color: {INK}"><span style="display: flex; color: #78716c">{_CHL}</span><span style="font-family: {F}; font-weight: 700; font-size: 16px">{titre}</span></a>'+dedans)
_LABC=LAB.replace('font-size: 14px','font-size: 13px'); _FIELDC=FIELD.replace('height: 52px','height: 44px').replace('padding: 0 14px','padding: 0 12px'); assert _FIELDC.count('height: 44px')==1
def _ch(l,v,vide=False): return f'<div style="display: flex; flex-direction: column; gap: 4px"><label style="{_LABC}">{l}</label><div style="{_FIELDC}{"; color: #a8a29e" if vide else ""}">{v}</div></div>'
def _confn(titre,retour,texte,oui): return _niv(titre,retour,f'<p style="margin: 0; padding: 0 14px; font-size: 14px; line-height: 1.45; color: {INK}">{texte}</p><div style="padding: 0 8px"><button style="width: 100%; height: 44px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 15px; font-weight: 700">{oui}</button></div>')
# Les champs, dans la barre, sont des lignes (Julien, 23 novembre : « j'ai pas l'impression qu'ils sont plus petits ») : le libellé à gauche, ce qu'on écrit à droite, 48 px.
def _lg(l,v,vide,first=False,curseur=False):
    val=(f'<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: {RED}"></span>' if curseur else v)
    return (f'<li><label style="display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 2px 14px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} color: {INK}"><span style="width: 104px; flex-shrink: 0; font-size: 15px; font-weight: 600">{l}</span>'
            f'<span role="textbox" style="flex-grow: 1; min-width: 0; display: flex; align-items: center; font-size: 16px; color: {"#a8a29e" if vide else INK}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{val}</span></label></li>')
def _inv2(prenom,adresse,vide):
    return _niv('Quelqu’un d’autre','V3ListeQuiAjouter',
        f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">{_lg("Prénom",prenom,vide,True,vide)}{_lg("Adresse email",adresse,vide)}</ul>'
        f'<p style="margin: -2px 0 0; padding: 0 14px; font-size: 13px; line-height: 1.4; color: {MUT}">Cette personne reçoit un email à ton nom, et devient membre de « Famille Camille ».</p>'
        f'<div style="padding: 0 8px"><a href="V3ListeInviteEnvoyee.dc.html" style="{_BTNC}{"; opacity: 0.45" if vide else ""}">Inviter</a></div>'
        +_UL+_sr('Reprendre ceux d’un autre événement','V3ListeInviterReprendre.dc.html',True)+'</ul>')
def _pch(e,t,on): return (f'<button aria-pressed="{"true" if on else "false"}" style="height: 36px; padding: 0 12px 0 10px; border: {"2px solid "+RED if on else "1px solid "+LINE}; border-radius: 999px; background: {"#fbf3f1" if on else CARD}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; white-space: nowrap"><span aria-hidden="true" style="display: flex; font-size: 14px">{e}</span>{t}</button>')
def _rp(e,t,sub,on):
    x=_pr(av(e,32),t,sub,on,False,False); a='min-height: 56px; padding: 6px 20px 6px 16px;'; assert x.count(a)==1; return x.replace(a,'min-height: 48px; padding: 2px 14px;').replace('font-weight: 600; font-size: 16px','font-weight: 600; font-size: 15px')
_REP=_niv('Reprendre ceux de','V3ListeInviter',
     f'<div style="display: flex; flex-wrap: wrap; gap: 8px; padding: 0 12px">{_pch("🎄","Bureau, 3e étage",True)}{_pch("🎂","Les 40 ans de Tonton",False)}</div>'
     +_UL+_rp('🦊','Nadia','nadia@exemple.fr',True)+_rp('🐻','Karim','karim@exemple.fr',True)+_rp('🦉','Sophie','sophie@exemple.fr',True)+_rp('⛄','Tom','Pas d’adresse email',False)+'</ul>'
     f'<div style="padding: 0 8px"><a href="V3ListeInviteEnvoyee.dc.html" style="{_BTNC}">Inviter · 3 personnes</a></div>')
_V_FC13=_vu(_c('Noël'),'Famille Camille','13 membres',True)
for _n in ['V3ListeQuiAjouter','V3ListeQuiOuvrir','V3ListeInviter','V3ListeInviterEmail','V3ListeInviterReprendre','V3ListeInviteEnvoyee']:   # sur le fond de V3ListeQuiModifier tel qu'il vient d'être écrit
    open(PJ+_n+'.dc.html','w',encoding='utf-8').write(open(PJ+'V3ListeQuiModifier.dc.html',encoding='utf-8').read())
open(PJ+'V3ListeLienNouveau.dc.html','w',encoding='utf-8').write(open(PJ+'V3ListeQuiLien.dc.html',encoding='utf-8').read())
_Q2['V3ListeLienNouveau']=('V3ListePublique',_qui3(True,_PUB))
_dr=[n for n,(fe,de) in _Q2.items() if _deroule(n,fe,de)]
for _n,_fe,_d in [('V3ListeInviter','V3Liste',_inv2('&nbsp;','prenom@exemple.fr',True)),('V3ListeInviterEmail','V3Liste',_inv2('Tata','tata-demo@example.com',False)),('V3ListeInviterReprendre','V3Liste',_REP),
        ('V3ListeQuiRetirer','V3Liste',_confn('Retirer « Chez Mamie » ?','V3ListeQuiModifier','Ses 9 membres ne verront plus ta liste. 2 d’entre eux ont coché un cadeau et ne pourront plus l’ouvrir. Leurs cadeaux restent prévus.','Retirer')),
        ('V3ListeQuiOuvrir','V3Liste',_confn('Ouvrir à tout le monde ?','V3ListeQuiModifier','Toute personne qui a le lien pourra voir ta liste et cocher un cadeau, sans compte.','Ouvrir')),
        ('V3ListeLienChanger','V3ListePublique',_confn('Changer de lien ?','V3ListeQuiLien','L’ancien lien ne marchera plus : il faudra renvoyer le nouveau. Ceux qui ont déjà coché un cadeau gardent la liste.','Changer'))]:
    assert _deroule(_n,_fe,_d,False); _dr.append(_n)
assert _deroule('V3ListeInviteEnvoyee','V3Liste',_qui3(False,_V_FC13+_V_CM()+_aj(False,[])+_CL)); _dr.append('V3ListeInviteEnvoyee')
# un message de l'application se met toujours en bas de l'écran (Julien, 23 novembre), jamais sous la barre
def _toast(h,t,top):
    x=f'<div role="status" style="position: absolute; left: 16px; right: 16px; top: {top}px; z-index: 6; min-height: 48px; box-sizing: border-box; padding: 12px 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; font-size: 15px; font-weight: 600">{t}</div>'
    if 'position: relative">' not in h[h.index('<x-dc>'):h.index('<x-dc>')+600]: h=rel(h)
    z=h.rindex('</div>\n</x-dc>'); return h[:z]+x+h[z:]
f=PJ+'V3ListeLienNouveau.dc.html'; h=open(f,encoding='utf-8').read(); assert h.count('under-the-tree.party/l/k3Fq9xT2')>=1
h=_tit2(_toast(h.replace('under-the-tree.party/l/k3Fq9xT2','under-the-tree.party/l/Qm7vZ2pLx'),'Nouveau lien créé',836),'V3 · le lien d’une liste publique a changé'); open(f,'w',encoding='utf-8').write(h)
f=PJ+'V3ListeInviteEnvoyee.dc.html'; h=open(f,encoding='utf-8').read()
for x,y in [('>21 membres la voient<','>22 membres la voient<')]:
    assert h.count(x)==1,x; h=h.replace(x,y)
open(f,'w',encoding='utf-8').write(_tit2(_toast(h,'Invitation envoyée',836),'V3 · l’invitation est partie'))
# celui qui « aide à écrire » : la barre déroulée ne contient que le lien
h=open(PJ+'ListeAidePartage.dc.html',encoding='utf-8').read()
h=re.sub(r'<title>[^<]*</title>','<title>V3 · la barre déroulée de celui qui aide à écrire</title>',_fond(h),count=1); open(PJ+'V3ListeAideLien.dc.html','w',encoding='utf-8').write(h)
_deroule('V3ListeAideLien','ListeAidePartage','')
print('barre déroulée',_dr)

# =================== LE SECRET SANTA ET MA PARTIE D'UNE LISTE (Julien, 22 novembre 2026) ===================
# Ce qui est lié au Secret Santa, c'est moi dans la liste. Créée depuis le Secret Santa, la liste m'a déjà dedans ; si je tiens déjà une liste où je figure, on me la propose.
# Sous mon prénom, le Secret Santa. Celui qui m'a tiré ouvre la liste filtrée sur ma partie ; « Toute la liste » montre le reste.
def _sect(h,nom):
    c=h.index('>'+nom+'</h2>'); return h.rindex('<section',0,c),h.index('</section>',c)+10
_SS=('<a href="V3TirageVersListe.dc.html" data-secret="1" style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; min-height: 24px; font-size: 13px; font-weight: 700; color: #5b3a55; text-decoration: none">'+ic(I_TIR,14,2.2)+'Secret Santa · Famille Camille</a>')
_MOIP='<p style="margin: 0; font-size: 14px; line-height: 1.4; color: #57534e">Moi</p>'
_ssl=[]
for n in ['V3ListeSecret','V3ListeQuiSecret','V3ListeCompteCree']:
    f=PJ+n+'.dc.html'; h=open(f,encoding='utf-8').read()
    if 'data-secret="1"' in h: continue
    a,b=_sect(h,'Camille'); sec=h[a:b]; assert sec.count(_MOIP)==1,n
    open(f,'w',encoding='utf-8').write(h[:a]+sec.replace(_MOIP,_MOIP+_SS)+h[b:]); _ssl.append(n)
# la liste créée depuis le Secret Santa : moi, en premier
h=open(PJ+'V3ListeNouvelle.dc.html',encoding='utf-8').read(); a,b=_bar(h)
h=h[:a]+B_SEC+h[b:]
_src=open(PJ+'V3ListeSecret.dc.html',encoding='utf-8').read(); a,b=_sect(_src,'Hugo'); moi=_src[a:b]
k=moi.index('<a href="PanneauAvatarGrand.dc.html"'); e=moi.index('</a>',k)+4
moi=moi[:k]+'<span aria-hidden="true" style="width: 52px; height: 52px; border-radius: 50%; background: #ead2e2; box-shadow: 0 0 0 1px #c493b4; display: flex; align-items: center; justify-content: center; font-size: 23px; flex-shrink: 0">🦌</span>'+moi[e:]
for x,y in [('>Hugo</h2>','>Camille</h2>'+_MOIP+_SS),('Options pour Hugo','Options pour Camille'),('Écrire une idée pour Hugo','Écrire une idée pour Camille'),('Une idée pour Hugo…','Une idée pour Camille…'),('margin-top: 44px','margin-top: 8px')]:
    assert moi.count(x)==1,x; moi=moi.replace(x,y)
k=h.index('>Ajouter quelqu’un</h2>'); a=h.rindex('<section',0,k); h=h[:a]+moi+'\n    '+h[a:]
# « Repartir d'une liste » reste proposé tant que la liste n'a aucune idée, même si j'y suis déjà (Julien, Q-032)
_rp=open(PJ+'ListeNouvelleReprendre.dc.html',encoding='utf-8').read(); _i=_rp.index('>Repartir d’une liste</h2>'); _ra=_rp.rindex('<section',0,_i); _rb=_rp.index('</section>',_i)+10
k=h.index('>Ajouter quelqu’un</h2>'); a=h.rindex('<section',0,k); h=h[:a]+_rp[_ra:_rb]+'\n    '+h[a:]
k=h.index('🦌</span>Camille</button>'); a=h.rindex('<button',0,k); h=h[:a]+h[k+len('🦌</span>Camille</button>'):]
k=h.index('>Une liste sans personne</a>'); a=h.rindex('<a href="ListeSansPersonne.dc.html"',0,k); h=h[:a]+h[k+len('>Une liste sans personne</a>'):]
h=re.sub(r'<title>[^<]*</title>','<title>V3 · ma liste, créée depuis mon Secret Santa</title>',h,count=1)
h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1150}',h)
k=h.index('<div style="width: 390px; height: ',h.index('<x-dc>'))+len('<div style="width: 390px; height: '); e=h.index('px',k)
if int(h[k:e])<1150: h=h[:k]+'1150'+h[e:]
open(PJ+'V3ListeSecretNouvelle.dc.html','w',encoding='utf-8').write(h)
# « Ma liste de cadeaux » touché, quand je tiens déjà une liste où je figure
_ql=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px; line-height: 1.2">Quelle liste pour ton Secret Santa ?</h2>'
     '<ul role="radiogroup" aria-label="La liste que verra celui qui t’a tiré" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'; border-bottom: 1px solid '+SOFT+'">'
     +_pr(ll(),'Noël 2026','Pour Léo, Zoé et moi · Chez Mamie',True,True,True,'quelle-liste')
     +_pr(NEWF,'Une nouvelle liste','',False,True,False,'quelle-liste')+'</ul>'
     '<div style="padding: 0 16px"><a href="V3ListeSecretNouvelle.dc.html" style="'+BTN+'">Continuer</a></div>')
h=open(PJ+'V3TirageVersListe.dc.html',encoding='utf-8').read()
open(PJ+'V3TirageQuelleListe.dc.html','w',encoding='utf-8').write(_tit2(sheet(_fond(h),_ql,556,'Quelle liste pour ton Secret Santa ?'),'V3 · quelle liste pour mon Secret Santa ?'))
# celui qui m'a tiré : la liste filtrée sur ma partie ; « Toute la liste » montre le reste
h=open(PJ+'V3ListeSurligne.dc.html',encoding='utf-8').read()
if 'data-filtre' not in h:
    a1,b1=_sect(h,'Léo'); a2,b2=_sect(h,'Zoé'); a3,b3=_sect(h,'Inès'); assert a1<a2<a3
    ines=h[a3:b3]; k=ines.index('margin-top: '); e=ines.index('px',k); ines=ines[:k]+'margin-top: 8'+ines[e:]
    ines=ines.replace('Camille','Inès')
    def _gp(on): return ('<div data-filtre="1" role="radiogroup" aria-label="Ce que tu vois de la liste" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px; padding: 4px; border-radius: 12px; background: #f1e8d8">'+_pill('Inès',on)+_pill('Toute la liste',not on)+'</div>\n    ')
    tout=h[:a1]+_gp(False)+ines+'\n    '+h[a1:a3]+h[b3:]
    seul=h[:a1]+_gp(True)+ines+h[b3:]
    seul=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":1000}',seul)
    open(PJ+'V3ListeSurligne.dc.html','w',encoding='utf-8').write(seul)
    open(PJ+'V3ListeSurligneTout.dc.html','w',encoding='utf-8').write(re.sub(r'<title>[^<]*</title>','<title>V3 · la liste de la personne tirée, toute la liste</title>',tout,count=1))
print('secret santa et ma partie',_ssl)

# =================== UN ORGANISATEUR EST MEMBRE (Julien, 22 novembre 2026, Q-031) ===================
# Dans « Membres », la ligne d'un organisateur commence par « Organise » (pas « Organisateur » : l'application ne connaît pas le genre).
_og=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read()
    if '>Secret Santa · ne tire pas Hugo<' in h:
        open(f,'w',encoding='utf-8').write(h.replace('>Secret Santa · ne tire pas Hugo<','>Organise · Secret Santa · ne tire pas Hugo<')); _og.append(os.path.basename(f)[:-8])
print('organise',_og)

# =================== LA LIGNE QU'ON ÉCRIT : UNE CARTE BLANCHE (Julien, 23 novembre 2026, piste C) ===================
# Plus de bandeau blanc bord à bord avec un trait rouge : une carte blanche aux coins arrondis, une ombre légère.
_ec=[]; _ecr=re.compile(r'<li style="margin: 0 -16px 0 -(\d+)px; padding: 0 16px 10px \1px; background: #fffdf9; box-shadow: inset 3px 0 0 #(?:b8483a|2f613f)">')
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read()
    if 'inset 3px 0 0' not in h: continue
    h2=_ecr.sub('<li data-ecrit="1" style="margin: 4px -8px 4px -10px; padding: 0 8px 8px 10px; background: #fffdf9; border-radius: 10px; box-shadow: 0 0 0 1px #efe6d6, 0 6px 16px rgba(184, 72, 58, 0.10)">',h)
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _ec.append(os.path.basename(f)[:-8])
print('ligne écrite',_ec)
# La ligne soulevée quand on la déplace ressemble à la ligne qu'on écrit : la même carte blanche, l'ombre plus marquée ; l'endroit où elle va tomber est un trait pêche.
_f=PJ+'ListeGlisser.dc.html'; h=open(_f,encoding='utf-8').read()
_a='margin: 0 -12px; padding: 10px 12px; box-sizing: border-box; text-decoration: none; border-radius: 14px; background: #fffdf9; box-shadow: 0 0 0 1.5px #b8483a, 0 14px 30px rgba(41, 37, 36, 0.22)'
_b='<li aria-hidden="true" style="height: 4px; margin: 2px 0; border-radius: 999px; background: #b8483a"'
if _a in h:
    assert h.count(_a)==1 and h.count(_b)==1
    h=h.replace(_a,'margin: 0 -8px 0 -10px; padding: 10px 8px 10px 10px; box-sizing: border-box; text-decoration: none; border-radius: 10px; background: #fffdf9; box-shadow: 0 0 0 1px #efe6d6, 0 12px 26px rgba(184, 72, 58, 0.20)').replace(_b,'<li aria-hidden="true" data-tombe="1" style="height: 4px; margin: 2px 0; border-radius: 999px; background: #a8a29e"')
    open(_f,'w',encoding='utf-8').write(h); print('ligne soulevée')

# =================== TOURNURES NEUTRES (Q-035, 23 novembre 2026) ===================
# L'application ne connaît pas le genre : « Cette personne reçoit… », pas « Il reçoit… ».
_tn=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read(); h2=h.replace('Il reçoit un email, et peut refuser.','Cette personne reçoit un email, et peut refuser.').replace('Il reçoit un email à ton nom','Cette personne reçoit un email à ton nom').replace('Elle sert à lui envoyer l’invitation. Il verra que c’est toi qui l’invites.','Elle sert à envoyer l’invitation, qui dit que c’est toi qui invites.').replace('Ce qu’il pourra faire','Ce que cette personne pourra faire').replace('>Il pourra gérer ','>Cette personne pourra gérer ').replace('Salut ! Tu es invité au Secret Santa','Salut ! Je t’invite au Secret Santa').replace('Salut ! Tu es invité à la fête','Salut ! Je t’invite à la fête').replace('Tu es invité au Secret Santa','On t’invite au Secret Santa')
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _tn.append(os.path.basename(f)[:-8])
print('tournures neutres',_tn)

# =================== « CAMILLE (MOI) » ET LA TUILE DU SECRET SANTA (Julien, 23 novembre 2026, piste C) ===================
# « Moi » n'est plus une ligne sous le prénom : « (moi) », entre parenthèses, à côté. Dessous, le Secret Santa : la tuile de l'événement, le texte, une flèche.
_ga,_gb=GRAD['Noël']
_SS2=('<a href="V3ListeSecretLie.dc.html" data-secret="2" style="align-self: flex-start; max-width: 100%; box-sizing: border-box; display: inline-flex; align-items: center; gap: 4px; height: 20px; padding: 0 8px 0 6px; border-radius: 999px; background: #efe6d6; font-size: 11.5px; font-weight: 700; color: #57534e; text-decoration: none">'
      '<span aria-hidden="true" style="font-size: 11px; flex-shrink: 0">🎄</span>'
      '<span style="min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">Secret Santa · Famille Camille</span></a>')
_moi=re.compile(r'(<h2 style="[^"]*">)([^<]+)</h2>(\s*)<p style="margin: 0; font-size: 14px; line-height: 1\.4; color: #57534e">Moi</p>')
_mo=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read()
    h2=_moi.sub(lambda m: m.group(1)+m.group(2)+' <span data-moi="1" style="font-family: \'Nunito\', system-ui, sans-serif; font-weight: 500; font-size: 16px; color: #57534e">(moi)</span></h2>',h).replace(_SS,_SS2)
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _mo.append(os.path.basename(f)[:-8])
print('(moi)',len(_mo),_mo)

# =================== « UNE IDÉE POUR TOI… » ET LE MOT D'ACCUEIL EN OPTION (Julien, 23 novembre 2026) ===================
# Dans ma partie, la ligne vide dit « Une idée pour toi… ». Une liste neuve n'a pas de mot d'accueil : « Ajouter un mot d'accueil » en propose un.
_PEN='<svg aria-hidden="true" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>'
_MOTADD=('<a href="V3ListeMotAccueil.dc.html" data-mot="ajouter" style="align-self: flex-start; min-height: 32px; display: flex; align-items: center; gap: 5px; font-size: 14px; line-height: 1.4; font-style: italic; color: #a8a29e; text-decoration: none">'+_PEN+'Ajouter un mot d’accueil</a>')
_motre=re.compile(r'<div style="[^"]*border: 1px dashed #cdb48a[^"]*"><span[^>]*>(?:(?!</span>).)*Ton mot d’accueil</span><p role="textbox"[^>]*>(?:(?!</p>).)*</p><span[^>]*>Un texte de départ[^<]*</span></div>',re.S)
_to=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read(); h2=h
    if 'data-moi="1"' in h2:
        h2=h2.replace('Une idée pour Camille…','Une idée pour toi…').replace('Écrire une idée pour Camille','Écrire une idée pour toi').replace('Une autre idée pour Camille…','Une autre idée pour toi…')
    h2=h2.replace('idée pour moi…','idée pour toi…')
    h2=_motre.sub(_MOTADD,h2)
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _to.append(os.path.basename(f)[:-8])
print('pour toi, mot en option',_to)
h=open(PJ+'V3ListeNouvelle.dc.html',encoding='utf-8').read(); assert h.count(_MOTADD)==1
_car='<span aria-hidden="true" style="display: inline-block; width: 2px; height: 20px; background: #b8483a; vertical-align: -4px; margin-left: 1px"></span>'
_motw=('<div data-ecrit="1" style="margin: 4px -8px 4px -10px; padding: 10px 8px 10px 10px; background: #fffdf9; border-radius: 10px; box-shadow: 0 0 0 1px #efe6d6, 0 6px 16px rgba(184, 72, 58, 0.10)"><p role="textbox" aria-label="Ton mot d’accueil" style="margin: 0; font-size: 16px; line-height: 1.5">Quelques idées pour t’éviter de chercher. Coche ce que tu offres, et personne n’aura la même idée. Tu en as une autre ? Elle est la bienvenue.'+_car+'</p></div>')
h=h.replace(_MOTADD,_motw)
h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":844}',h)
open(PJ+'V3ListeMotAccueil.dc.html','w',encoding='utf-8').write(re.sub(r'<title>[^<]*</title>','<title>V3 · une liste neuve, le mot d’accueil ajouté</title>',h,count=1))

# =================== LA PHRASE SOUS LE MOT D'ACCUEIL, POUR UN VISITEUR, N'EST PLUS LÀ (Julien, 23 novembre 2026) ===================
# « La liste de Lou. Tu offres 1 cadeau : personne d'autre que Lou ne sait que c'est toi. » redit ce qu'on voit ailleurs et alourdit la page.
_vis=re.compile(r'\s*<p style="[^"]*">(?:La liste de [^<]*|Tu offres \d+ cadeaux? : [^<]*)</p>')
_vi=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read(); h2=_vis.sub('',h)
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _vi.append(os.path.basename(f)[:-8])
print('phrase du visiteur retirée',_vi)
# « C'est toi », sous le prénom de celui qui figure dans la liste d'un autre : « (moi) », à côté, comme partout
_f=PJ+'ListeVueReliee.dc.html'; h=open(_f,encoding='utf-8').read()
h2=re.sub(r'(<h2 style="[^"]*">)([^<]+)</h2>(\s*)<p style="margin: 0; font-size: 14px; line-height: 1\.4; color: #57534e">C’est toi</p>',lambda m: m.group(1)+m.group(2)+' <span data-moi="1" style="font-family: \'Nunito\', system-ui, sans-serif; font-weight: 500; font-size: 16px; color: #57534e">(moi)</span></h2>',h)
if h2!=h: open(_f,'w',encoding='utf-8').write(h2)

# =================== LIER ET DÉLIER, LE NOM, LA VISITE GUIDÉE (Julien, 23 novembre 2026) ===================
def _pv(h,ht): return re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
_NB=[]
# le nom d'une liste créée depuis un Secret Santa
_f=PJ+'V3ListeSecretNouvelle.dc.html'; h=open(_f,encoding='utf-8').read(); _a='></span>Noël 2026</h1>'; assert h.count(_a)==1
h=h.replace(_a,'></span>Idées pour le Secret Santa</h1>'); open(_f,'w',encoding='utf-8').write(h); _SN=h
# « Touche un texte pour le modifier. » : la visite le dit, la phrase s'en va
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read(); h2=h.replace(' Touche un texte pour le modifier.','').replace('Touche un texte pour le modifier.','')
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _NB.append(os.path.basename(f)[:-8])
# --- lier et délier
_tuile=lambda sz: f'<span aria-hidden="true" data-evt="1" style="width: {sz}px; height: {sz}px; border-radius: 9px; background: linear-gradient(150deg, {_ga} 0%, {_gb} 115%); box-shadow: 0 0 0 1.5px #ffffff, 0 1px 3px rgba(90, 40, 60, 0.2); display: flex; align-items: center; justify-content: center; font-size: {round(sz*0.52)}px; flex-shrink: 0">🎄</span>'
_lig=lambda t,chev,first=False: (f'<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 2px 20px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">{t}</span>'+(f'<span style="color: #78716c; display: flex">{CHEV}</span>' if chev else '')+'</a></li>')
# un seul panneau pour lier et délier : mes Secret Santa de l'année, à cocher (Julien, 24 novembre 2026 : « une liste où on choisit tous les Secret Santa qui sont liés ou pas »)
def _pan(rows): return (f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Lier à un Secret Santa</h2>'
      f'<p style="margin: 0; padding: 0 20px; font-size: 15px; line-height: 1.45; color: {MUT}">Celui qui t’a tiré verra cette liste pour choisir ton cadeau.</p>'
      f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'+''.join(_pr(_tuile(36),t,sub,on,False,i==0) for i,(t,sub,on) in enumerate(rows))+'</ul>')
_lie=_pan([('Famille Camille','',True),('Bureau, 3e étage','',False)])
h=open(PJ+'V3ListeSecret.dc.html',encoding='utf-8').read()
open(PJ+'V3ListeSecretLie.dc.html','w',encoding='utf-8').write(_tit2(sheet(_fond(h),_lie,585,'Lier à un Secret Santa'),'V3 · mes Secret Santa, liés ou non à cette liste'))
# « Lier à un Secret Santa » est dans le menu « … » de ma partie, plus sous mon prénom (Julien, 24 novembre 2026 : « ça fait bizarre, surtout quand c'est déjà lié à un autre »)
h=open(PJ+'V3Liste.dc.html',encoding='utf-8').read()
_pm=open(PJ+'ListePersonneMenu.dc.html',encoding='utf-8').read(); _a=_pm.index('<div role="menu"'); _b=_pm.index('</div>',_a)+6; _men=_pm[_a:_b]
_its=re.findall(r'<a role="menuitem".*?</a>',_men,flags=re.S); assert len(_its)==3
_lier=re.sub(r'<svg.*?</svg>',ic(I_TIR,18,2),_its[1],count=1,flags=re.S).replace('Retirer de cette liste','Lier à un Secret Santa').replace('href="#"','href="V3ListeSecretLierConfirmer.dc.html"')
_men=_men[:_men.index('<a role="menuitem"')]+_its[0].replace('Sa fiche et ses goûts','Ma fiche et mes goûts')+_lier+_its[1]+'</div>'
_bt=re.search(r'<button data-pmenu="1" aria-label="Options pour Camille" aria-expanded="false" style="margin-left: auto; ([^"]*)">(.*?)</button>',h,flags=re.S); assert _bt
h=h[:_bt.start()]+'<div style="position: relative; margin-left: auto; flex-shrink: 0"><button data-pmenu="1" aria-label="Options pour Camille" aria-expanded="true" style="'+_bt.group(1)+'">'+_bt.group(2)+'</button>'+_men+'</div>'+h[_bt.end():]
h=_tit2(_pv(h,1700),'V3 · une liste où je figure, à lier à mon Secret Santa'); open(PJ+'V3ListeSecretLier.dc.html','w',encoding='utf-8').write(h)
_cf=_pan([('Famille Camille','',False),('Bureau, 3e étage','Lié à « Noël 2026 »',False)])
h=open(PJ+'V3Liste.dc.html',encoding='utf-8').read()   # le menu se ferme quand le panneau s'ouvre
open(PJ+'V3ListeSecretLierConfirmer.dc.html','w',encoding='utf-8').write(_tit2(sheet(_fond(h),_cf,585,'Lier à un Secret Santa'),'V3 · lier une liste à un de mes Secret Santa'))
# --- la visite guidée : le voile, un élément dans la lumière, une note
def _voile(h):
    if 'position: relative">' not in h[h.index('<x-dc>'):h.index('<x-dc>')+600]: h=rel(h)
    z=h.rindex('</div>\n</x-dc>'); return h[:z]+'<span aria-hidden="true" data-voile="1" style="position: absolute; inset: 0; z-index: 4; background: rgba(43, 27, 61, 0.35); pointer-events: none"></span>'+h[z:]
def _note(n,total,titre,texte,dessus=False):
    pos='bottom: calc(100% + 8px)' if dessus else 'top: calc(100% + 8px)'
    bec=('bottom: -7px; border-right: 1.5px solid #292524; border-bottom: 1.5px solid #292524' if dessus else 'top: -7px; border-left: 1.5px solid #292524; border-top: 1.5px solid #292524')
    dernier=(n==total)
    cpt='' if total==1 else f'<span style="font-size: 12px; font-weight: 700; color: {MUT}">{n} sur {total}</span>'
    passer='' if dernier else f'<button style="min-height: 40px; padding: 0 4px; border: 0; background: transparent; color: {MUT}; font-family: inherit; font-size: 15px; font-weight: 600">Passer</button>'
    return (f'<div data-note="visite" style="position: absolute; {pos}; left: 10px; right: 10px; z-index: 3">'
      '<div role="dialog" aria-label="'+titre+'" style="position: relative; padding: 14px 16px 6px; border-radius: 16px; background: #fffdf9; color: #292524; box-shadow: 0 0 0 1.5px #292524, 0 14px 44px 6px rgba(43, 27, 61, 0.4); display: flex; flex-direction: column; gap: 6px">'
      f'<span aria-hidden="true" style="position: absolute; {bec}; left: 42px; width: 12px; height: 12px; background: #fffdf9; transform: rotate(45deg)"></span>'
      f'<div style="display: flex; align-items: baseline; justify-content: space-between; gap: 12px"><p style="margin: 0; font-size: 15px; font-weight: 700; line-height: 1.35; color: #292524">{titre}</p>{cpt}</div>'
      f'<p style="margin: 0; font-size: 14px; line-height: 1.45; color: #57534e">{texte}</p>'
      f'<div style="display: flex; align-items: center; justify-content: {"flex-end" if dernier else "space-between"}">{passer}<button style="min-height: 40px; padding: 0 4px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 15px; font-weight: 700">{"Compris" if dernier else "Suivant"}</button></div></div></div>')
def _lum(h,a,b,note):
    return _voile(h[:a]+'<div data-visite="1" style="position: relative; z-index: 5; margin: -6px -10px; padding: 6px 10px; border-radius: 10px; background: #f7f2e9">'+h[a:b]+note+'</div>'+h[b:])
def _z_nom(h): a=h.index('<h1'); b=h.index('</a>',h.index('</h1>',a))+4; return a,b
def _z_moi(h): m=re.search(r'Camille <span data-moi="1"',h); a=h.rindex('<div style="display: flex; align-items: center; gap: 12px">',0,m.start()); b=h.index('<ul',m.start()); return a,b
def _z_ligne(h): k=h.index('Une idée pour toi…'); a=h.rindex('<li',0,k); b=h.index('</li>',k)+5; return a,b
def _z_sec(h,t): k=h.index('>'+t+'</h2>'); return h.rindex('<section',0,k),h.index('</section>',k)+10
_VS=[(_z_moi,'Ta partie','Elle est liée à ton Secret Santa : celui qui t’a tiré la lit dès que tu écris.',False),
     (_z_ligne,'Une idée par ligne','Ajoute un lien si tu as trouvé l’objet.',False),
     (_bar,'Qui la voit','Pour l’instant, celui qui t’a tiré, et lui seul. « Modifier » l’ouvre à d’autres.',False),
     (_z_nom,'Le nom et la date','Touche un texte pour le changer.',False),
     (lambda h:_z_sec(h,'Repartir d’une liste'),'Tes idées d’avant','Reprends celles qui n’ont pas été offertes.',True),
     (lambda h:_z_sec(h,'Ajouter quelqu’un'),'Une liste pour plusieurs','Ajoute tes enfants ou un proche : chacun a sa partie.',True)]
for _n,(_z,_t,_x,_d) in enumerate(_VS,1):
    a,b=_z(_SN); open(PJ+f'V3ListeVisiteSecret{_n}.dc.html','w',encoding='utf-8').write(_tit2(_lum(_SN,a,b,_note(_n,len(_VS),_t,_x,_d)),f'V3 · la visite d’une liste créée depuis un Secret Santa, {_n} sur {len(_VS)}'))
_LN=_pv(open(PJ+'V3ListeNouvelle.dc.html',encoding='utf-8').read(),844)
_VC=[(_z_nom,'Le nom et la date','Ils viennent de l’occasion. Touche un texte pour le changer.',False),
     (lambda h:_z_sec(h,'Ajouter quelqu’un'),'Pour qui ?','Une partie par personne : toi, tes enfants, un proche.',True),
     (_bar,'Personne ne la voit encore','« Partager » choisit qui, quand tu veux.',False)]
for _n,(_z,_t,_x,_d) in enumerate(_VC,1):
    a,b=_z(_LN); open(PJ+f'V3ListeVisiteCreer{_n}.dc.html','w',encoding='utf-8').write(_tit2(_lum(_LN,a,b,_note(_n,len(_VC),_t,_x,_d)),f'V3 · la visite d’une liste créée depuis « Créer », {_n} sur {len(_VC)}'))
# la première personne ajoutée : une note sur sa première ligne
h=_SN.replace('></span>Idées pour le Secret Santa</h1>','></span>Noël 2026</h1>').replace(_SS2,'')
a,b=_bar(h); a2,b2=_bar(_LN); h=h[:a]+_LN[a2:b2]+h[b:]
k=h.index('>Repartir d’une liste</h2>'); a=h.rindex('<section',0,k); b=h.index('</section>',k)+10; h=h[:a]+h[b:]
a,b=_z_ligne(h); open(PJ+'V3ListeVisiteIdee.dc.html','w',encoding='utf-8').write(_tit2(_lum(_pv(h,900),a,b,_note(1,1,'Une idée par ligne','Ajoute un lien si tu as trouvé l’objet.')),'V3 · la première personne ajoutée : une note sur sa première ligne'))
print('lier, nom, visite ; phrase retirée dans',len(_NB))

# =================== « DEVINE QUI » MIS EN AVANT, LES DEUX MOTS EXPLIQUÉS (Julien, 23 novembre 2026) ===================
# À la création d'un Secret Santa, le jeu sort de la liste : une carte vert clair, la loupe, trois choix, et une phrase qui dit ce qui va se passer.
# « Découvrir le palmarès » prend le même vert clair et la même loupe.
_LOUPE=lambda sz: f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg>'
_VERT='#0b7a5b'; _VCL='#e9f7f1'; _VLI='#bfe6d6'; _VPI='#d2eee2'; _VTX='#4d6b60'
def _sg3(t,on): return (f'<span role="radio" aria-checked="{"true" if on else "false"}" style="height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 13.5px; font-weight: 700; '+('background: #fffdf9; color: #0b5c45; box-shadow: 0 1px 3px rgba(20, 60, 45, 0.22)' if on else f'color: {_VTX}')+f'">{t}</span>')
def _jeu(choix,phrase):
    return (f'<section data-jeu="1" style="background: {_VCL}; border-radius: 16px; box-shadow: 0 0 0 1.5px {_VLI}; padding: 14px 16px 16px; display: flex; flex-direction: column; gap: 12px">'
      f'<div style="display: flex; align-items: center; gap: 12px"><span aria-hidden="true" style="width: 38px; height: 38px; border-radius: 50%; background: {_VERT}; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{_LOUPE(19)}</span>'
      f'<div style="display: flex; flex-direction: column; gap: 1px"><h2 style="margin: 0; font-family: {F}; font-size: 18px; font-weight: 700; color: #292524">Devine qui</h2><span style="font-size: 13px; line-height: 1.35; color: {_VTX}">Le jeu qui pimente le Secret Santa.</span></div></div>'
      f'<div role="radiogroup" aria-label="Devine qui" style="display: grid; grid-template-columns: 0.7fr 1fr 1.25fr; gap: 4px; padding: 4px; border-radius: 12px; background: {_VPI}">'+''.join(_sg3(t,t==choix) for t in ('Sans','Qui m’offre ?','Toutes les paires'))+'</div>'
      f'<p style="margin: 0; padding: 0 2px; font-size: 13px; line-height: 1.4; color: {_VTX}">{phrase}</p></section>')
_f=PJ+'V3TirageNouveau.dc.html'; h=open(_f,encoding='utf-8').read()
if '>Devine qui</span>' in h:
    k=h.index('>Devine qui</span>'); a=h.rindex('<li',0,k); b=h.index('</li>',k)+5; e=h.index('</ul>',b)+5
    h=h[:a]+h[b:e]+'\n    '+_jeu('Toutes les paires','Tout le monde enquête : qui offre à qui ? Le jour J, les masques tombent et le palmarès sacre les meilleurs détectives.')+h[e:]
    open(_f,'w',encoding='utf-8').write(h)
    for _n,_c,_p in (('V3TirageNouveauQui','Qui m’offre ?','Chacun essaie de démasquer qui lui offre. Verdict le jour J.'),('V3TirageNouveauSans','Sans','Pas de jeu : le mystère reste entier.')):
        x=re.sub(r'<section data-jeu="1".*?</section>',lambda m:_jeu(_c,_p),h,count=1,flags=re.S)
        open(PJ+_n+'.dc.html','w',encoding='utf-8').write(_tit2(x,'V3 · un nouveau Secret Santa, « Devine qui » sur « '+_c+' »'))
# la carte « Découvrir le palmarès »
_pa=[]
for f in sorted(glob.glob(PJ+'Devine*.dc.html')):
    h=open(f,encoding='utf-8').read()
    m=re.search(r'<a href="[^"]*" style="display: flex; align-items: center; gap: 14px; padding: 16px 20px; border-radius: 16px; background: #274e34; color: #fffdf9; text-decoration: none">.*?</a>',h,re.S)
    if not m or 'Découvrir le palmarès' not in m.group(0): continue
    c=m.group(0)
    c=c.replace('background: #274e34; color: #fffdf9; text-decoration: none',f'background: {_VCL}; box-shadow: 0 0 0 1.5px {_VLI}; color: #292524; text-decoration: none',1)
    c=c.replace('background: rgba(255, 253, 249, 0.16); display: flex',f'background: {_VERT}; color: #ffffff; display: flex',1)
    c=re.sub(r'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2\.2 7\.8L22 12l-7\.8 2\.2L12 22l-2\.2-7\.8L2 12l7\.8-2\.2z"/></svg>',_LOUPE(22),c,count=1)
    c=c.replace('color: #cfe2d3',f'color: {_VTX}',1)
    open(f,'w',encoding='utf-8').write(h[:m.start()]+c+h[m.end():]); _pa.append(os.path.basename(f)[:-8])
# les deux mots : où ils apparaissent
_lab=lambda t: f'<h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #57534e">{t}</h2>'
_mk=lambda t: f'<span data-mot="1" style="background: #fbf0cf; border-radius: 5px; padding: 1px 4px; font-weight: 600">{t}</span>'
_f=PJ+'GroupeMot.dc.html'; h=open(_f,encoding='utf-8').read()
# le mot ajouté aux messages : la phrase suffit, pas d'aperçu (Julien)
h2=h.replace('Ajouté tel quel à chaque message et email envoyé aux participants. Tu peux encore le modifier au moment d’envoyer.','Quand tu envoies son lien à quelqu’un, ou un rappel, ton mot part avec. Tu peux encore le changer au moment d’envoyer.')
h2=re.sub(r'<div data-apercu="1".*?</div></div>','',h2,count=1,flags=re.S); h2=_pv(h2,900)
if h2!=h: open(_f,'w',encoding='utf-8').write(h2)
_f=PJ+'EditionMot.dc.html'; h=open(_f,encoding='utf-8').read()
# le petit mot : la phrase sous le titre suffit, pas d'aperçu (Julien, après l'avoir vu : « ce n'est pas une bonne idée »)
h2=re.sub(r'<div data-apercu="1".*?</span></div></div>','',h,count=1,flags=re.S)
h2=re.sub(r'<div data-apercu="2".*?</main></div></div></div></div></div>','',h2,count=1,flags=re.S)
h2=re.sub(r'width: 390px; height: (?:980|920)px','width: 390px; height: 844px',h2,count=1); h2=_pv(h2,844)
h2=h2.replace('<span>Affiché avec le résultat de chacun.</span>','<span></span>')
_PM='Chaque participant le lit sous le résultat de son tirage, avec le titre « Le mot de l’organisateur ».'
h2=h2.replace('Chacun le lit sur sa page, en découvrant à qui il offre.',_PM)
if _PM not in h2:
    k=h2.index('>Petit mot</h1>'); z=h2.index('</h1>',k)+5
    h2=h2[:z]+'<p style="margin: 0; font-size: 15px; line-height: 1.45; color: #57534e">'+_PM+'</p>'+h2[z:]
if h2!=h: open(_f,'w',encoding='utf-8').write(h2)
print('devine qui, palmarès',_pa)

# =================== « CRÉER UNE LISTE DE CADEAUX », « CRÉER UN SECRET SANTA » (Julien, 23 novembre 2026) ===================
# Les lignes d'ajout disent « Créer… », la liste en toutes lettres. La carte d'un événement sans Secret Santa propose aussi d'en créer un.
_cr=[]
for f in sorted(glob.glob(PJ+'*.dc.html')):
    h=open(f,encoding='utf-8').read(); h2=h.replace('>Nouvelle liste<','>Créer une liste de cadeaux<').replace('</svg>Nouvelle liste</a>','</svg>Créer une liste de cadeaux</a>').replace('>Organiser un Secret Santa<','>Créer un Secret Santa<').replace('</svg>Organiser un Secret Santa</a>','</svg>Créer un Secret Santa</a>')
    if h2!=h: open(f,'w',encoding='utf-8').write(h2); _cr.append(os.path.basename(f)[:-8])
h=open(PJ+'V3Accueil.dc.html',encoding='utf-8').read()
k=h.index('Bureau, 3e étage'); a=h.rindex('<section',0,k); b=h.index('</section>',k)+10; c=h[a:b]
u=c.index('<ul'); l1=c.index('<li>',u); l2=c.index('<li>',l1+4); e=c.index('</ul>',l2)
add=c[l2:e]; assert 'Créer une liste de cadeaux' in add
add1=add.replace('Créer une liste de cadeaux','Créer un Secret Santa').replace('border-top: 1px solid #e9dcc5; ','',1)
carte=(c[:l1]+add1+add+c[e:]).replace('Bureau, 3e étage','Noël du boulot').replace('19 déc.','25 déc.')
open(PJ+'V3AccueilSansSecret.dc.html','w',encoding='utf-8').write(_tit2(h[:a]+carte+'\n      '+h[a:],'V3 · accueil, un événement sans Secret Santa'))
print('créer',len(_cr))

# =================== LA POIGNÉE ET SON MENU, LES ÉTOILES, LES TITRES (Julien, 23 novembre 2026) ===================
# La ligne qu'on écrit a une poignée au bout : on la tient pour déplacer, on la touche pour ouvrir un menu.
# Dans le menu : « Envie », une à trois étoiles (pêche soutenu) ; « En faire un titre » ; « Supprimer la ligne ».
_PECHE='#f08a6c'
def _et(on,sz): return (f'<svg aria-hidden="true" width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="{_PECHE if on else "none"}" stroke="{_PECHE if on else "#f5b8a5"}" stroke-width="{0 if on else 1.8}" stroke-linejoin="round" style="flex-shrink: 0"><path d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.4l-5.8 3.1 1.1-6.5L2.6 9.4l6.5-.9z"/></svg>')
_ets=lambda n: f'<span data-etoiles="{n}" aria-label="Envie : {n} sur 3" style="margin-left: 6px; white-space: nowrap; display: inline-flex; gap: 1px; vertical-align: -3px">'+_et(True,17)*n+'</span>'
_GRIP='<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.7"/><circle cx="15" cy="6" r="1.7"/><circle cx="9" cy="12" r="1.7"/><circle cx="15" cy="12" r="1.7"/><circle cx="9" cy="18" r="1.7"/><circle cx="15" cy="18" r="1.7"/></svg>'
_hand=lambda on: f'<button data-poignee="1" aria-label="Déplacer, ou ouvrir les options de cette ligne" aria-expanded="{"true" if on else "false"}" style="display: flex; width: 32px; height: 32px; margin: -5px -4px 0 0; padding: 0; border: 0; align-items: center; justify-content: center; border-radius: 7px; color: #78716c; flex-shrink: 0; background: {"#efe6d6" if on else "transparent"}">{_GRIP}</button>'
_T_IC='<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 6h14M12 6v13"/></svg>'
_POUB='<svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>'
_CASE='<span aria-hidden="true" style="width: 16px; height: 16px; box-sizing: border-box; border-radius: 4px; border: 2px solid #a8a29e"></span>'
def _mi(ico,t,col=INK,icol='#78716c'): return f'<button role="menuitem" style="display: flex; align-items: center; gap: 10px; height: 44px; padding: 0 10px; border: 0; border-radius: 7px; background: transparent; font-family: inherit; font-size: 15px; font-weight: 600; color: {col}; text-align: left"><span style="display: flex; width: 18px; justify-content: center; color: {icol}">{ico}</span>{t}</button>'
def _envie(n): return (f'<div style="display: flex; flex-direction: column; gap: 0; padding: 6px 10px 2px"><span style="font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {MUT}">Envie</span>'
                       '<span role="radiogroup" aria-label="Envie" style="display: flex; align-items: center; margin-left: -8px">'+''.join(f'<span role="radio" aria-checked="{"true" if i==n-1 else "false"}" style="width: 44px; height: 44px; display: flex; align-items: center; justify-content: center">{_et(i<n,26)}</span>' for i in range(3))+'</span></div>')
_sep=f'<span aria-hidden="true" style="height: 1px; margin: 4px 0; background: {SOFT}"></span>'
def _menu(items,w=236): return (f'<div role="menu" style="position: absolute; right: 0; top: 40px; z-index: 3; width: {w}px; padding: 6px; border-radius: 10px; background: {CARD}; box-shadow: 0 0 0 1px {SOFT}, 0 12px 28px rgba(90, 40, 60, 0.22); display: flex; flex-direction: column">'+''.join(items)+'</div>')
_fl=lambda d: f'<svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="{d}"/></svg>'
_UP=_fl('M12 19V5M6 11l6-6 6 6'); _DOWN=_fl('M12 5v14M6 13l6 6 6-6'); _VERS=_fl('M4 12h13M12 6l6 6-6 6')
_BOUGE=[_mi(_UP,'Monter'),_mi(_DOWN,'Descendre'),_mi(_VERS,'Déplacer vers…')]
_M_IDEE=lambda n: _menu([_envie(n),_sep,_mi(_T_IC,'En faire un titre')]+_BOUGE+[_sep,_mi(_POUB,'Supprimer la ligne','#8a2f27','#8a2f27')])
_M_TITRE=_menu([_mi(_CASE,'En refaire une idée')]+_BOUGE+[_sep,_mi(_POUB,'Supprimer la ligne','#8a2f27','#8a2f27')])
def _tronc(h):
    # la ligne qui part de l'icône de la personne et traverse les cases (elle est dans l'application ; les maquettes de l'écriture ne l'avaient pas)
    k=h.index('>Léo</h2>'); a=h.rindex('<section',0,k); e=h.index('</section>',k); sec=h[a:e]
    o='<section style="display: flex; flex-direction: column; gap: 2px">'; assert sec.startswith(o)
    sec=sec.replace(o,'<section style="position: relative; display: flex; flex-direction: column; gap: 2px"><span aria-hidden="true" data-tronc="1" style="position: absolute; left: 25px; top: 58px; bottom: 30px; width: 2px; border-radius: 2px; background: #dccbad"></span>',1)
    sec=sec.replace('padding: 0 0 0 6px">','padding: 0 0 0 15px">',1).replace('gap: 12px; min-height: 44px','gap: 27px; min-height: 44px')
    sec=sec.replace('<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px;','<span aria-hidden="true" style="width: 22px; height: 22px; box-sizing: border-box; border-radius: 5px; position: relative; z-index: 1; background: #f7f2e9;')
    sec=sec.replace('<li data-ecrit="1" style="','<li data-ecrit="1" style="position: relative; z-index: 2; ',1).replace('<div style="padding-left: 34px">','<div style="padding-left: 49px">')
    return h[:a]+sec+h[e:]
h=_tronc(open(PJ+'ListeIdee.dc.html',encoding='utf-8').read()); a=h.index('<li data-ecrit="1"'); b=h.index('</li>',a)+5; li=h[a:b]
assert 'Puzzle 100 pièces, avec des dinosaures' in li
li=li.replace('Puzzle 100 pièces, avec des dinosaures','Le camion de pompiers')
_k=li.index('<div style="padding-left: 49px">'); _p=li.rindex('</div>',0,_k)
def _ligne(n,menu): return li[:_p]+(f'<span style="display: flex; height: 22px; align-items: center; margin-top: 1px; gap: 1px; flex-shrink: 0">{_et(True,17)*n}</span>' if n else '')+_hand(bool(menu))+li[_p:-5]+menu+'</li>'
_bx=li[li.index('<span aria-hidden="true" style="width: 22px; height: 22px;'):li.index('</span>',li.index('<span aria-hidden="true" style="width: 22px; height: 22px;'))+7]
_dot='<span aria-hidden="true" style="width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px"><span style="width: 10px; height: 10px; border-radius: 50%; background: #f5b8a5"></span></span>'
_tx=li[li.index('<span role="textbox"'):li.index('>',li.index('<span role="textbox"'))+1]
_titre_li=(li[:_p].replace(_bx,_dot,1).replace(_tx,f'<span role="textbox" aria-label="Un titre" style="flex-grow: 1; min-width: 0; font-family: {F}; font-size: 19px; line-height: 1.3; font-weight: 700">',1).replace('Le camion de pompiers','Playmobil',1).replace('padding: 0 8px 8px 10px','padding: 0 8px 2px 10px',1)+_hand(True)+'</div>'+_M_TITRE+'</li>')
for _n,_x,_t in (('V3ListeLigneMenu',_ligne(0,_M_IDEE(0)),'V3 · la poignée d’une ligne, son menu'),('V3ListeLigneEtoiles',_ligne(3,''),'V3 · une ligne à trois étoiles'),('V3ListeLigneTitre',_titre_li,'V3 · une ligne devenue un titre')):
    _y=h[:a]+_x+h[b:]
    if 'role="menu"' in _x:   # le menu ouvert, le clavier se replie
        _m1=_y.index('</main>')+7; _m2=_y.rindex('</div>\n</x-dc>'); _y=_y[:_m1]+'\n'+_y[_m2:]
    open(PJ+_n+'.dc.html','w',encoding='utf-8').write(_tit2(_y,_t))
# « Déplacer vers… » : les autres personnes de la liste
_pl=lambda e,n,first=False: (f'<li><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 6px 20px; box-sizing: border-box;{"" if first else f" border-top: 1px solid {SOFT};"} text-decoration: none; color: {INK}">{av(e,36)}<span style="flex-grow: 1; font-size: 16px; font-weight: 600">{n}</span></a></li>')
_dv=(f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Déplacer vers</h2>'
     f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'+_pl('🦄','Zoé',True)+_pl('🦌','Camille <span style="font-weight: 500; font-size: 14px; color: #57534e">(moi)</span>')+_pl('🐧','Hugo')+'</ul>')
_y=h[:a]+_ligne(0,'')+h[b:]; _m1=_y.index('</main>')+7; _m2=_y.rindex('</div>\n</x-dc>'); _y=_y[:_m1]+'\n'+_y[_m2:]
open(PJ+'V3ListeLigneDeplacer.dc.html','w',encoding='utf-8').write(_tit2(sheet(_fond(_y),_dv,560,'Déplacer vers'),'V3 · déplacer une ligne vers une autre personne'))
# ce que tout le monde lit : le titre sur la ligne de la personne, les étoiles au bout des idées
h=open(PJ+'V3ListeMembre.dc.html',encoding='utf-8').read(); k=h.index('>Léo</h2>'); u=h.index('<ul',k); e=h.index('</ul>',u); ul=h[u:e]
_lis=re.findall(r'<li>.*?</li>',ul,flags=re.S); _fr=_lis[3]; _tk=_lis[1]; assert 'Livres sur les dinosaures' in _fr and 'Déguisement de pompier' in _tk
_f=lambda t,n=0: _fr.replace('Livres sur les dinosaures (il les a presque tous, demandez-nous)</span>',t+'</span>'+(_ets(n) if n else ''))
_tl=(f'<li><div data-titre="1" style="display: flex; align-items: center; gap: 19px; min-height: 42px; padding: 14px 0 2px; box-sizing: border-box"><span aria-hidden="true" style="width: 22px; display: flex; justify-content: center; position: relative; z-index: 1; flex-shrink: 0"><span style="width: 10px; height: 10px; border-radius: 50%; background: #f5b8a5; box-shadow: 0 0 0 4px #f7f2e9"></span></span>'
     f'<h3 style="margin: 0; font-family: {F}; font-size: 19px; line-height: 1.3; font-weight: 700; color: {INK}">Playmobil</h3></div></li>')
_new=ul[:ul.index('<li>')]+_f('Vélo 16 pouces',2)+_tl+_f('Le camion de pompiers',3)+_tk.replace('Déguisement de pompier (taille 6 ans)','La clinique vétérinaire')+_f('Le bateau pirate',1)+_f('La ferme')+_lis[5]
open(PJ+'V3ListeTitres.dc.html','w',encoding='utf-8').write(_tit2(h[:u]+_new+h[e:],'V3 · une liste avec un titre et des étoiles'))
print('poignée, étoiles, titres')

# =================== LES PARTICIPANTS S'AJOUTENT JUSTE APRÈS (Julien, 24 novembre 2026) ===================
_REP='<strong style="color: #292524">5 membres repris du Secret Santa 2026.</strong>'
for _n in ('V3TirageNouveau','V3TirageNouveauQui','V3TirageNouveauSans'):
    h=open(PJ+_n+'.dc.html',encoding='utf-8').read(); assert h.count(_REP)==1
    open(PJ+_n+'.dc.html','w',encoding='utf-8').write(h.replace(_REP,_REP+'<br>Tu en ajoutes ou en retires juste après.'))
h=open(PJ+'V3TirageNouveau.dc.html',encoding='utf-8').read()
for _a,_b in (('Famille Camille','Noël du boulot'),('Le Secret Santa 2027','Le Secret Santa 2026'),('Noël 2027','Noël 2026'),('25 décembre 2027','25 décembre 2026'),('30 €','15 €'),
              ('Tout le monde enquête : qui offre à qui ? Le jour J, les masques tombent et le palmarès sacre les meilleurs détectives.','À partir de quatre participants.'),
              ('5 membres repris du Secret Santa 2026.</strong><br>Tu en ajoutes ou en retires juste après.','Il n’y a que toi pour l’instant.</strong><br>Tu ajoutes les participants juste après.')):
    assert h.count(_a)==1,_a; h=h.replace(_a,_b)
_i=h.index('Il n’y a que toi'); _s=h.rfind('<section',0,_i); _k=h.index('<span aria-hidden="true" style="display: flex; align-items: center; flex-shrink: 0">',_s); _p=h.index('<p ',_k)
_moi=re.search(r'<span aria-hidden="true" style="[^"]*">🐧</span>',h[_k:_p]); assert _moi
h=h[:_k]+_moi.group(0).replace(' margin-left: -8px;','')+'\n      '+h[_p:]
open(PJ+'V3TirageNouveauSeul.dc.html','w',encoding='utf-8').write(_tit2(h,'V3 · un nouveau Secret Santa, je suis seul dans l’événement'))
print('les participants juste après')

# =================== SUR L'ACCUEIL, CE QUE J'ORGANISE : « GÉRER L'ÉVÉNEMENT », « TU L'ORGANISES » (Julien, 24 novembre 2026) ===================
I_GERER='<path d="M4 6h8M16 6h4M4 12h2M10 12h10M4 18h10M18 18h2"/><circle cx="14" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/>'
_txt2=lambda t,x: f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 15px">{t}</span><span style="font-size: 13px; line-height: 1.35; color: {MUT}">{x}</span></span><span style="color: #78716c; display: flex">{CHEV}</span>'
def _gerer(n): return f'<li><a href="V3FeteOrganisateur.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; box-sizing: border-box; text-decoration: none; color: {INK}">{_trait(I_GERER,MUT)}{_txt2("Gérer l’événement",n)}</a></li>'
# la ligne de l'organisateur : accrochée à celle du Secret Santa (pas de trait entre les deux), alignée sous son titre, haute comme une ligne
def _orga(etat): return f'<li data-orga="1"><a href="#" style="display: flex; align-items: center; gap: 12px; min-height: 54px; padding: 0 16px 8px 72px; box-sizing: border-box; text-decoration: none; color: {INK}">{_txt2("Tu l’organises",etat)}</a></li>'
_MEM={'Bureau, 3e étage':'8 membres','Noël du boulot':'6 membres'}
_meta=json.load(open('/tmp/v3meta.json')); _nb=0
for f in sorted(glob.glob(PJ+'V3*.dc.html')):
    h=open(f,encoding='utf-8').read(); n=os.path.basename(f)[:-8]; d=0; pos=0; out=''
    for m in re.finditer(r'<section[^>]*><a href="V3FeteOrganisateur\.dc\.html" style="min-height: 66px.*?</section>',h,flags=re.S):
        t=m.group(0); nom=re.search(r'<h3[^>]*>(.*?)</h3>',t).group(1); u=t.index('<ul'); u2=t.index('>',u)+1; e=t.rindex('</ul>')
        lis=re.findall(r'<li.*?</li>',t[u2:e],flags=re.S); assert ''.join(lis)==t[u2:e],n
        a0=lis[0].index('style="')+7; lis[0]=lis[0][:a0]+f'border-top: 1px solid {SOFT}; '+lis[0][a0:]
        new=[_gerer(_MEM[nom])]; d+=58
        for li in lis:
            new.append(li)
            if '>Le Secret Santa<' in li: new.append(_orga('Dévoilé' if 'Dévoilé' in li else 'Fait · 6 sur 8 ont découvert')); d+=54
        out+=h[pos:m.start()]+t[:u2]+''.join(new)+t[e:]; pos=m.end()
    if not d: continue
    h=out+h[pos:]; k=h.index('<div style="width: 390px;',h.index('<x-dc>')); mh=re.search(r'min-height: (\d+)px',h[k:k+200]); H0=int(mh.group(1))
    h=h[:k]+h[k:k+200].replace(mh.group(0),'min-height: %dpx'%(H0+d),1)+h[k+200:]; P0=int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1)); h=_pv(h,P0+d)
    open(f,'w',encoding='utf-8').write(h); _nb+=1
    if n in _meta: _meta[n]['h']=P0+d
json.dump(_meta,open('/tmp/v3meta.json','w'),ensure_ascii=False,indent=0)
print('ce que j’organise',_nb)
