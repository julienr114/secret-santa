# V3 : le jeu de maquettes de la fête, sur sa page de canevas (Julien, 20 novembre 2026, après la séance de questions).
# Les maquettes V2 ne sont pas touchées. Tous les fichiers s'appellent V3*.
import json,re
src=open('/home/claude/gen/v3.py',encoding='utf-8').read()
exec(src.split("P7={}")[0])
CAT.pop('Pot de départ',None); CAT['Crémaillère']=('🏡','#f3d3cc')
CAT={k:CAT[k] for k in ('Noël','Anniversaire','Naissance','Mariage','Crémaillère','Autre')}
AV.update({'🍭':('#f3d3cc','#e09e92'),'🎄':('#cfe2d3','#8db898'),'⛄':('#d6e6ef','#94bbd0')})
V={}
def put(k,h,ht,t,row,col):
    if ht is not None: h=re.sub(r'"\$preview":\{"width":\d+,"height":\d+\}','"$preview":{"width":390,"height":%d}'%ht,h)
    V[k]=(h,ht,t,row,col)
def rel(h):
    k=h.index('<div style="width: 390px;',h.index('<x-dc>')); e=h.index('">',k)
    return h[:e]+'; position: relative'+h[e:]
def sheet(h,inner,top,label):
    S=(f'<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
       f'<div role="dialog" aria-label="{label}" style="position: absolute; left: 0; right: 0; top: {top}px; min-height: {844-top}px; box-sizing: border-box; z-index: 5; background: {CARD}; border-radius: 20px 20px 0 0; padding: 10px 0 24px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
       f'<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>{inner}</div>')
    h=rel(h); z=h.rindex('</div>\n</x-dc>'); return h[:z]+S+h[z:]
def chip(c,t,color='#274e34'): return f'<span style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 10px 0 8px; border-radius: 999px; background: {CAT[c][1]}; font-size: 13px; font-weight: 700; color: {color}">{CAT[c][0]} {t}</span>'
def fhead(c,ct,name,when):
    return f'<div style="display: flex; flex-direction: column; gap: 8px; padding: 4px 4px 0">{chip(c,ct)}<h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 30px; line-height: 1.1">{name}</h1><p style="margin: 0; font-size: 15px; font-weight: 700; color: {DRED}">{when}</p></div>'
def members(es,n,invite=False):
    inv=f'<span style="font-size: 14px; font-weight: 700; color: {DRED}">Inviter</span>' if invite else ''
    return f'<a href="V3FeteMembres.dc.html" style="{CARDS}; min-height: 56px; padding: 0 14px; display: flex; align-items: center; gap: 12px; text-decoration: none; color: {INK}">{stack(es)}<span style="flex-grow: 1; font-weight: 600">{n} membres</span>{inv}<span style="color: #78716c; display: flex">{CHEV}</span></a>'
ICO=lambda p: f'<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic(p,18)}</span>'
GIFTI=ICO('<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8"/><path d="M12 8c-1.5-4-6-4.5-6-1.5C6 8 9 8 12 8zm0 0c1.5-4 6-4.5 6-1.5C18 8 15 8 12 8z"/>')
GEAR=ic('<circle cx="12" cy="12" r="3"/><path d="M19.400 15a1.700 1.700 0 0 0 .300 1.800l.100.100a2 2 0 1 1-2.800 2.800l-.100-.100a1.700 1.700 0 0 0-2.800 1.200V21a2 2 0 1 1-4 0v-.100a1.700 1.700 0 0 0-2.900-1.200l-.100.100a2 2 0 1 1-2.800-2.800l.100-.100a1.700 1.700 0 0 0-1.200-2.800H3a2 2 0 1 1 0-4h.100a1.700 1.700 0 0 0 1.200-2.900l-.100-.100a2 2 0 1 1 2.800-2.800l.100.100a1.700 1.700 0 0 0 2.900-1.200V3a2 2 0 1 1 4 0v.100a1.700 1.700 0 0 0 2.800 1.200l.100-.100a2 2 0 1 1 2.800 2.800l-.100.100a1.700 1.700 0 0 0 1.200 2.900H21a2 2 0 1 1 0 4h-.100a1.700 1.700 0 0 0-1.500 1z"/>',20)
def foot(): return f'<div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="V3FeteNouvelle.dc.html" style="{BTN2}">{PLUS}Nouvelle fête</a></div>'
def propose(c,name,when,act,href):
    return (f'<section style="border-radius: 16px; border: 1.5px dashed #cdb48a; padding: 12px 12px 12px 16px; display: flex; align-items: center; gap: 10px">{cat(c)}'
            f'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-family: {F}; font-weight: 700; font-size: 17px; line-height: 1.2">{name}</span><span style="font-size: 13px; color: {MUT}">{when}</span></span>'
            f'<a href="{href}" style="{BTN2}; height: 40px; padding: 0 12px; font-size: 14px; flex-shrink: 0">{act}</a></section>')

# « Une fête » en général (pas une catégorie) : une icône au trait, comme le tirage et la liste (retour de Julien)
I_FETE='<path d="M5.8 11.3 2 22l10.7-3.79"/><path d="M4 3h.01"/><path d="M22 8h.01"/><path d="M15 2h.01"/><path d="M22 20h.01"/><path d="m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10"/><path d="m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17"/><path d="m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7"/><path d="M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z"/>'
fl=lambda: '<span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #dcefe0; color: #274e34; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+ic(I_FETE,18)+'</span>'
# Une date = les trois listes du téléphone, comme la date de naissance d'un proche (retour de Julien) : plus de calendrier dessiné
_pn=open(PJ+'ProcheNaissance.dc.html',encoding='utf-8').read()
_i=_pn.index('<div role="group" aria-label="Date de naissance"'); _j=_pn.index('</label></div>',_i)+len('</label></div>')
_G=_pn[_i:_j]
assert _G.count('>14<span')==1 and _G.count('>mars<span')==1 and _G.count('>2020<span')==1
def date3(d,m,y,label):
    return _G.replace('aria-label="Date de naissance"','aria-label="'+label+'"',1).replace('>14<span','>'+d+'<span',1).replace('>mars<span','>'+m+'<span',1).replace('>2020<span','>'+y+'<span',1)
# L'en-tête d'une fête se touche aussi : même flèche que les lignes (retour de Julien)
def fcard2(c,title,when,rows,add='',href='V3Fete.dc.html'):
    body=rows+((addrow(add).replace(f"border-top: 1px solid {SOFT}; ","",1) if not rows else addrow(add)) if add else '')
    return (f'<section style="{CARDS}; overflow: hidden"><a href="{href}" style="min-height: 56px; box-sizing: border-box; padding: 10px 16px; display: flex; align-items: center; gap: 10px; text-decoration: none; color: {INK}">{cat(c)}<h3 style="flex-grow: 1; min-width: 0; margin: 0; font-family: {F}; font-weight: 700; font-size: 18px; line-height: 1.2">{title}</h3><span style="font-size: 13px; font-weight: 700; color: {MUT}; white-space: nowrap">{when}</span><span style="color: #78716c; display: flex">{CHEV}</span></a>'
            f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}">{body}</ul></section>')
# =================== ACCUEIL ===================
NOEL=(season('Noël 2026','dans 35 jours')
  +fcard2('Noël','Bureau, 3e étage','19 déc.',irow(tl(),'Le tirage','Tu sais à qui tu offres · tu l’organises','',True),'Nouvelle liste',href='V3FeteOrganisateur.dc.html')
  +fcard2('Noël','Chez Mamie','24 déc.',irow(ll(),'La liste de Mamie','Tu offres 2 cadeaux','',True)+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi dans Famille Camille','',False,'V3Liste.dc.html'),href='V3Fete.dc.html')
  +fcard2('Noël','Famille Camille','25 déc.',irow(tl(),'Le tirage','Camille te demande des pistes',dot(),True,'V3TirageVersListe.dc.html')+irow(ll(),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',False,'V3Liste.dc.html')+irow(ll(),'La liste de Camille','Tu offres 1 cadeau','',False,'V3ListeMembre.dc.html'),href='V3Fete.dc.html'))
BIENTOT=(f'<div style="padding-top: 10px">{SEC("Bientôt")}</div>'+propose('Anniversaire','L’anniversaire de Zoé','14 décembre · dans 24 jours · ses 4 ans','Préparer','V3FeteNouvelle.dc.html'))
TARD=(f'<div style="padding-top: 10px">{SEC("Plus tard")}</div>'+fcard2('Anniversaire','Les 40 ans de Tonton','8 févr.',irow(ll(),'La liste de Tonton','3 nouvelles idées',dot(),True),href='V3FeteAnniversaire.dc.html'))
BAS=f'<ul style="{UL}; margin-top: 10px">'+irow(CLOCKI,'Les fêtes passées','Noël 2025, les 6 ans de Léo et 2 autres','',True)+irow(GIFTI,'Ce que j’offre ailleurs','Le mariage de Karim et Sofia · 1 cadeau','',False,'V3OffreAilleurs.dc.html')+'</ul>'
MAINA=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}{NOEL}{BIENTOT}{TARD}{BAS}
  </main>'''
HA=1320
put('V3Accueil',page('V3 · accueil',MAINA,HA),HA,'Accueil · mes fêtes : leurs tirages et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs',0,0)
def big(c,title,txt,btn,href,primary=False):
    return (f'<section style="{CARDS}; padding: 18px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; align-items: center; gap: 12px">{c}<h2 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">{title}</h2></div>'
            f'<p style="margin: 0; font-size: 15px; line-height: 1.45; color: {MUT}">{txt}</p><a href="{href}" style="{BTN if primary else BTN2}">{btn}</a></section>')
put('V3AccueilVide',page('V3 · accueil d’un compte tout neuf',f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo','Par quoi on commence ?')}
    {big(tl(),'Un Secret Santa','Chacun tire au sort la personne à qui il offre un cadeau.','Organiser un Secret Santa','V3FeteNouvelle.dc.html',True)}
    {big(ll(),'Une liste de cadeaux','Tes idées, que tes proches cochent pour ne pas offrir deux fois la même chose.','Écrire ma liste','V3FeteNouvelle.dc.html')}
  </main>''',844),844,'Accueil · un compte tout neuf : un Secret Santa ou une liste ; on ne parle pas de « fête », c’est leur première étape',0,1)
MAINY=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 14px; padding: 8px 16px 28px">
    {H1('Bonjour Hugo')}
    {season('Noël 2027','dans 61 jours')}
    {fcard2('Noël','Bureau, 3e étage','19 déc.','',add='Préparer Noël 2027',href='V3TirageNouveau.dc.html')}
    <p style="margin: -6px 4px 0; font-size: 13px; line-height: 1.4; color: {MUT}">Tu l’organises. Les 8 membres de l’an dernier sont repris.</p>
    {fcard2('Noël','Chez Mamie','24 déc.','',add='Reprendre ma liste de l’an dernier',href='V3Fete.dc.html')}
    {fcard2('Noël','Famille Camille','25 déc.',irow(ll(),'La liste de Camille','Elle vient de la créer · 4 idées',dot(),True),add='Reprendre ma liste de l’an dernier',href='V3Fete.dc.html')}
    <ul style="{UL}; margin-top: 10px">{irow(CLOCKI,'Les fêtes passées','Noël 2026, les 40 ans de Tonton et 3 autres','',True)}</ul>
  </main>'''
put('V3AccueilAnnee',page('V3 · accueil, l’année suivante',MAINY,980),980,'Accueil · l’année suivante (fin octobre 2027) : « Préparer Noël 2027 », « Reprendre ma liste de l’an dernier »',0,2)

# =================== FÊTE ===================
def fete_main(extra_bottom=''):
    return f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {fhead('Noël','Noël · tous les ans','Famille Camille','25 décembre 2026 · dans 35 jours')}
    {members(['🦌','👵','🎸','🍭','🐧'],12)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Le tirage')}<ul style="{UL}">{irow(tl(),'Le tirage 2026','Camille te demande des pistes',dot(),True,'V3TirageVersListe.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les listes')}<ul style="{UL}">{irow(av('🐧',36),'Ma liste','Léo, Zoé et moi · aussi chez Mamie','',True,'V3Liste.dc.html')}{irow(av('🦌',36),'La liste de Camille','Tu offres 1 cadeau','',False,'V3ListeMembre.dc.html')}{irow(av('👵',36),'La liste de Mamie','Tu offres 2 cadeaux · 1 nouvelle idée',dot())}</ul>
      <div style="padding-top: 8px; display: flex"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Zoé · 12 cadeaux offerts','',True)}{irow(yr('2024'),'Noël 2024','Tu offrais à Camille')}</ul></section>
    <ul style="{UL}">{irow(ICO('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>'),'Quitter cette fête','Tu n’y verras plus les listes','',True,'V3FeteQuitter.dc.html')}</ul>{extra_bottom}
  </main>'''
HF=980
fete_page=page('V3 · une fête, vue par un membre',fete_main(),HF).replace(HEADER,hd,1)
put('V3Fete',fete_page,HF,'Fête · vue par un membre : ses membres, son tirage, les listes, les années passées, « Quitter »',1,0)
QUIT=(f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px; line-height: 1.2">Quitter « Famille Camille » ?</h2>'
      f'<ul style="margin: 0; padding: 0 20px 0 38px; display: flex; flex-direction: column; gap: 8px; font-size: 15px; line-height: 1.45; color: {INK}"><li>Ta liste sortira de cette fête. Elle reste chez Mamie.</li><li>Les cadeaux que tu as cochés restent prévus.</li><li>Tu ne participeras plus à son tirage l’an prochain.</li></ul>'
      f'<div style="padding: 4px 16px 0; display: flex; flex-direction: column; gap: 6px"><button style="height: 52px; border: 1px solid #e0b4ab; border-radius: 6px; background: {CARD}; color: {DRED}; font-family: inherit; font-size: 17px; font-weight: 700">Quitter la fête</button><a href="V3Fete.dc.html" style="min-height: 46px; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 700; color: {MUT}; text-decoration: none">Rester</a></div>')
put('V3FeteQuitter',sheet(fete_page,QUIT,430,'Quitter la fête'),HF,'Fête · quitter : ce qui sort, ce qui reste',1,5)
orga=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; align-items: flex-start; gap: 8px"><div style="flex-grow: 1">{fhead('Noël','Noël · tous les ans','Bureau, 3e étage','19 décembre 2026 · dans 29 jours')}</div><a href="V3FeteReglages.dc.html" aria-label="Réglages de la fête" style="width: 44px; height: 44px; border-radius: 50%; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{GEAR}</a></div>
    {members(['🧶','🍭','🎄','⛄','🐧'],8,True)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les tirages')}<ul style="{UL}">{irow(tl(),'Le tirage 2026','Fait · 6 sur 8 ont découvert','',True)}{addrow('Un autre tirage','V3TirageNouveau.dc.html')}</ul></section>
    <section style="display: flex; flex-direction: column; gap: 8px">{SEC('Les listes')}<p style="margin: 0; padding: 0 4px; font-size: 15px; line-height: 1.45; color: {MUT}">Personne n’a encore mis de liste dans cette fête.</p><div style="display: flex"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a></div></section>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Noël 2025','Tu offrais à Inès','',True)}</ul></section>
  </main>'''
put('V3FeteOrganisateur',page('V3 · une fête, vue par son organisateur',orga,900).replace(HEADER,hd,1),900,'Fête · vue par son organisateur : « Inviter », les réglages, « Un autre tirage »',1,1)
anniv=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {fhead('Anniversaire','Anniversaire · tous les ans','L’anniversaire de Zoé','14 décembre 2026 · dans 24 jours · ses 4 ans')}
    {members(['🐧','🦌','👵','🎸'],6,True)}
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Sa liste')}<ul style="{UL}">{irow(av('🦄',36),'La liste de Zoé','Tu la tiens · 5 idées, 1 cadeau prévu','',True,'V3Liste.dc.html')}</ul></section>
    <div style="display: flex; gap: 10px; flex-wrap: wrap"><a href="V3ListeQui.dc.html" style="{BTN2}">{PLUS}Nouvelle liste</a><a href="V3TirageNouveau.dc.html" style="{BTN2}">{PLUS}Organiser un tirage</a></div>
    <section style="display: flex; flex-direction: column; gap: 6px">{SEC('Les années passées')}<ul style="{UL}">{irow(yr('2025'),'Ses 3 ans','7 cadeaux offerts à Zoé','',True)}</ul></section>
  </main>'''
put('V3FeteAnniversaire',page('V3 · une fête pour quelqu’un',anniv,844).replace(HEADER,hd,1),844,'Fête · « pour quelqu’un » (un anniversaire) : sa liste d’abord ; un tirage reste possible',1,2)
def tile2(c,sel=False):
    e,bg=CAT[c]
    return (f'<button role="radio" aria-checked="{"true" if sel else "false"}" style="height: 84px; border: 0; border-radius: 14px; background: {bg if sel else CARD}; box-shadow: {"0 0 0 2px "+RED if sel else "0 0 0 1px "+LINE}; font-family: inherit; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; color: {INK}"><span aria-hidden="true" style="font-size: 26px; line-height: 1">{e}</span><span style="font-size: 13px; font-weight: 700">{c}</span></button>')
nouv=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 20px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Pour quelle occasion ?</h1>
    <div role="radiogroup" aria-label="C’est pour" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px">{"".join(tile2(c,c=="Anniversaire") for c in CAT)}</div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Pour qui ?</span><div style="display: flex; flex-wrap: wrap; gap: 8px">{"".join(f'<span style="height: 40px; padding: 0 12px 0 6px; border-radius: 999px; background: {"#f6e3ad" if n=="Zoé" else CARD}; box-shadow: {"0 0 0 2px "+RED if n=="Zoé" else "0 0 0 1px "+LINE}; display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 700">{av(e,28)}{n}</span>' for e,n in (("🚀","Léo"),("🦄","Zoé"),("🐧","Moi")))}<span style="height: 40px; padding: 0 12px; border-radius: 999px; border: 1px dashed #cdb48a; display: flex; align-items: center; font-size: 15px; font-weight: 700; color: {DRED}">Quelqu’un d’autre</span></div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><label style="{LAB}">Son nom</label><div style="{FIELD}">L’anniversaire de Zoé</div></div>
    <div style="display: flex; flex-direction: column; gap: 6px"><span style="{LAB}">Sa date</span>{date3('14','décembre','2026','Date de la fête')}</div>
    <div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 4px"><span style="flex-grow: 1; font-size: 16px; font-weight: 600">Elle revient chaque année</span>{SW}</div>
    <a href="V3FeteMembresReprendre.dc.html" style="{BTN}; margin-top: 4px">Continuer</a>
  </main>'''
put('V3FeteNouvelle',page('V3 · une nouvelle fête',nouv,1000,withnav=False).replace(HEADER,hd,1),1000,'Première étape d’un Secret Santa ou d’une liste, quand l’occasion est nouvelle : « Pour quelle occasion ? », la catégorie d’abord, qui remplit le reste',1,3)
def pick(n,sel): return f'<span style="height: 40px; padding: 0 14px 0 10px; border-radius: 999px; background: {"#dcefe0" if sel else CARD}; box-shadow: {"0 0 0 2px #2f613f" if sel else "0 0 0 1px "+LINE}; display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 700; white-space: nowrap">🎄 {n}</span>'
mem=''.join(chk(av(e,36),n,s,on,i==0) for i,(e,n,s,on) in enumerate((('🦌','Camille','camille@exemple.fr',True),('👵','Mamie','mamie@exemple.fr',True),('🎸','Tonton','tonton@exemple.fr',True),('🍭','Inès','ines@exemple.fr',True),('🎄','Louis','louis@exemple.fr',False),('⛄','Tom','Pas d’adresse email',False))))
rep=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    <div style="display: flex; flex-direction: column; gap: 2px; padding: 4px 4px 0"><p style="margin: 0; font-size: 14px; font-weight: 700; color: {MUT}">🎂 L’anniversaire de Zoé</p><h1 style="margin: 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Qui est de la fête ?</h1></div>
    <div style="display: flex; flex-direction: column; gap: 8px">{SEC('Reprendre les membres de')}<div style="display: flex; gap: 8px; overflow: hidden; margin: 0 -16px; padding: 2px 16px">{pick('Famille Camille',True)}{pick('Chez Mamie',False)}{pick('Bureau, 3e étage',False)}</div></div>
    <ul style="{UL}">{mem}</ul>
    <ul style="{UL}">{irow(ICO('<path d="M10 14a4.500 4.500 0 0 0 6.400 0l3-3a4.500 4.500 0 0 0-6.400-6.400l-1 1"/><path d="M14 10a4.500 4.500 0 0 0-6.400 0l-3 3a4.500 4.500 0 0 0 6.400 6.400l1-1"/>'),'Inviter d’autres personnes','Par un lien, après avoir créé la fête','',True)}</ul>
    <a href="V3FeteAnniversaire.dc.html" style="{BTN}">Créer la fête · 5 membres</a>
  </main>'''
put('V3FeteMembresReprendre',page('V3 · reprendre les membres d’une autre fête',rep,900,withnav=False).replace(HEADER,hd,1),900,'Fête · nouvelle, suite : « Reprendre les membres d’une autre fête », on coche qui',1,4)

# =================== pages dérivées du groupe ===================
CALI=ICO('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>')
h=fete_words(R('GroupeReglages')).replace('>Réglages<','>Réglages de la fête<',1)
SET=f'''<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: {MUT}">La fête</h2><ul style="{UL}">
      {irow(cat('Noël',36),'Catégorie','Noël','',True)}
      {irow(CALI,'Date','Le 25 décembre · proposée chaque année')}
      <li><div style="display: flex; align-items: center; gap: 12px; min-height: 58px; padding: 8px 16px; border-top: 1px solid {SOFT}"><span aria-hidden="true" style="width: 36px; height: 36px; border-radius: 10px; background: #f1e8d8; color: {MUT}; display: flex; align-items: center; justify-content: center; flex-shrink: 0">{ic('<path d="M3 12a9 9 0 0 1 15.500-6.300L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.500 6.300L3 16"/><path d="M3 21v-5h5"/>',18)}</span><span style="flex-grow: 1; font-weight: 600; font-size: 15px">Revient chaque année</span>{SW}</div></li>
    </ul></section>'''
m=re.search(r'<main[^>]*>',h); k=h.index('</h1>',m.end()); k=h.index('</div>',k)+6
h=h[:k]+'\n    '+SET+h[k:]
put('V3FeteReglages',v3(h,'V3 · réglages d’une fête'),1420,'Fête · réglages : la catégorie, la date, la récurrence, puis ceux du groupe d’aujourd’hui',2,0)
put('V3FeteMembres',v3(fete_words(R('GroupeMembres')),'V3 · membres d’une fête'),930,'Fête · ses membres (certains sans compte : ils participent au tirage, ils ne voient pas les listes)',2,1)
put('V3FeteInviter',v3(fete_words(R('GroupeInvitation')),'V3 · inviter dans une fête'),960,'Fête · inviter par lien',2,2)
rj=R('Rejoindre')
for a,b in [('Tu es invité au Secret Santa','Tu es invité à la fête'),('Noël 2026 · échange le 25 décembre · 5 personnes inscrites','🎄 Noël · le 25 décembre 2026 · 5 membres'),('Connecte-toi avec ton adresse email pour le rejoindre.','Connecte-toi avec ton adresse email pour la rejoindre : tu verras son tirage et les listes de ses membres.'),('Les organisateurs des groupes que tu rejoins la voient','Les organisateurs des fêtes que tu rejoins la voient'),('Rejoindre un groupe — sans session','V3 · rejoindre une fête')]:
    assert a in rj,a; rj=rj.replace(a,b)
put('V3FeteRejoindre',rj,900,'Fête · le lien d’invitation, sans compte : plus de « Secret Santa », on rejoint une fête',2,3)

# =================== TIRAGE ===================
h=R('EditionNouvelle')
for a,b in [('Nouvelle édition','Le tirage 2027'),('Nom de l’édition','Nom du tirage'),('Créer l’édition','Créer le tirage'),('participants repris.','membres repris du tirage 2026.')]: h=h.replace(a,b)
h=h.replace('<input id="dt" type="text" placeholder="jj/mm/aaaa"','<input id="dt" type="text" value="25/12/2027" placeholder="jj/mm/aaaa"',1)
h=re.sub(r'<button style="align-self: flex-start; min-height: 44px;[^>]*>Proposer le 25 décembre 2027</button>','',h,count=1)
_a=h.index('<div style="position: relative">',h.index('<label for="dt"')); _b=h.index('</div>',h.index('aria-label="Ouvrir le calendrier"'))+len('</div>')
h=h[:_a]+date3('25','décembre','2027','Date de la fête')+h[_b:]
h=h.replace('<label for="dt" style=','<span style=',1)
assert h.count('Date de la fête</label>')==1; h=h.replace('Date de la fête</label>','Date de la fête</span>',1)
# Retour de Julien : les pistes de cadeaux et le mot des messages se règlent dès la création
_i=h.index('<li><a href="EditionMot.dc.html"'); _j=h.index('</li>',_i)+5; _li=h[_i:_j]
assert _li.count('Petit mot pour les participants')==1 and _li.count('>Aucun<')==1
_bt=_li.replace('min-height: 56px;','min-height: 56px; border-top: 1px solid #dccbad;',1); assert _bt!=_li
_pistes=_li.replace('Petit mot pour les participants','Pistes de cadeaux',1).replace('Facultatif. Affiché avec le résultat.','Portrait et idées précises',1).replace('<span style="font-size: 15px; color: #57534e">Aucun</span>','',1).replace('EditionMot.dc.html','#',1)
_mot=_bt.replace('Petit mot pour les participants','Mot ajouté aux messages',1).replace('<span style="font-size: 13px; color: #57534e">Facultatif. Affiché avec le résultat.</span>','',1).replace('EditionMot.dc.html','#',1)
assert 'Aucun' not in _pistes and 'Facultatif' not in _mot
h=h[:_i]+_pistes+_bt+_mot+h[_j:]
# Retour de Julien : le nom, la date et le budget ont la même tête que les autres lignes (une ligne, sa valeur, un chevron ; toucher ouvre une page, comme la fiche d'un proche)
_SUB='<span style="font-size: 13px; color: #57534e">Facultatif. Affiché avec le résultat.</span>'
_VAL='<span style="font-size: 15px; color: #57534e">Aucun</span>'
assert _li.count(_SUB)==1 and _li.count(_VAL)==1
def _row(t,val='',sub='',first=False):
    x=(_li if first else _bt).replace('EditionMot.dc.html','#',1).replace('Petit mot pour les participants',t,1)
    x=x.replace(_SUB,'<span style="font-size: 13px; color: #57534e">'+sub+'</span>' if sub else '',1)
    return x.replace(_VAL,'<span style="font-size: 15px; color: #57534e">'+val+'</span>' if val else '',1)
_ROWS=(_row('Nom','Noël 2027',first=True)+_row('Date de la fête','25 décembre 2027')+_row('Budget','30 €')+_row('Devine qui','Qui m’offre ?')
       +_row('Petit mot pour les participants','Aucun')+_row('Mot ajouté aux messages','Aucun'))
_u=h.rindex('<ul',0,h.index('Pistes de cadeaux')); _u2=h.index('>',_u)+1; _v=h.index('</ul>',_u)
h=h[:_u2]+_ROWS+h[_v:]
_a=h.rindex('<div',0,h.index('<label for="nm"')); _b=h.index('</div>',h.index('id="bg"'))+6
assert h[_a:_b].count('<label for="nm"')==1 and h[_a:_b].count('role="group"')==1
h=h[:_a]+h[_b:].lstrip()
h=re.sub(r'\s*<p\b[^>]*>[^<]*Affiché avec le résultat\.</p>','',h)
_n=1
h=re.sub(r'\s*<p\b[^>]*>[^<]*Affiché avec le résultat\.</p>','',h,count=1)
put('V3TirageNouveau',v3(h,'V3 · le tirage de l’année'),900,'Tirage · celui de l’année : la date de la fête est déjà là, et se change',3,0)
# Plus de demande pendant la bêta (Julien, 20 novembre 2026) : la limite de 3 Secret Santa par compte suffit
_lim=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 16px; padding: 8px 16px 28px">
    <h1 style="margin: 0; padding: 4px 4px 0; font-family: {F}; font-weight: 700; font-size: 28px; line-height: 1.1">Tu organises déjà 3 Secret Santa</h1>
    <p style="margin: 0; padding: 0 4px; font-size: 15px; line-height: 1.45; color: {MUT}">C’est le maximum pour un compte.</p>
    <ul style="{UL}">{irow(tl(),'Bureau, 3e étage','Noël 2026 · tirage fait','',True)}{irow(tl(),'Les cousins','Week-end d’été 2027 · pas encore tiré')}{irow(tl(),'Le club de lecture','Noël 2026 · tirage fait')}</ul>
  </main>'''
put('V3TirageLimite',page('V3 · la limite de 3 Secret Santa',_lim,844,withnav=False).replace(HEADER,hd,1),844,'Secret Santa · la limite : 3 par compte, sans demande à personne',3,1)
h=R('PistesResultatListe')
for a,b in [('Sa liste de cadeaux : Noël 2026','La liste de cadeaux d’Inès'),('Journal du groupe','Journal de la fête'),('>Mes pistes de cadeaux<','>Ma liste de cadeaux<'),('Remplies, modifiables jusqu\'à la fête','Vue seulement par celui qui m’a tiré'),('href="Pistes.dc.html"','href="V3ListeSecret.dc.html"'),('href="ListeVisiteurTirage.dc.html"','href="V3ListeSurligne.dc.html"')]:
    assert a in h,a; h=h.replace(a,b)
put('V3TirageVersListe',v3(h,'V3 · du tirage à la liste'),1422,'Tirage · du résultat à la liste : celle d’Inès est dans la même fête, le mode anonyme s’active seul',3,2)
RESULT=h
for a,b in [('Famille Camille · Noël 2026','Les cousins · Week-end d’été 2027'),('ven. 25 décembre','sam. 12 juin'),('Fête · dans 40 jours','Fête · dans 23 jours'),('On ouvre les cadeaux après le dessert !','On s’offre ça le samedi soir, au bord du lac.')]:
    assert a in h,a; h=h.replace(a,b)
put('V3TirageNeutre',v3(h,'V3 · un Secret Santa hors de Noël'),1426,'Tirage · hors de Noël (catégorie « Autre ») : aucun mot de Noël, ni « Père Noël » ni « Secret Santa »',3,3)

PEOPLE=ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',20)
def vbar(t,sub):
    return (f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); min-height: 52px; padding: 0 8px 0 14px; display: flex; align-items: center; gap: 10px">'
            f'<span style="display: flex; color: #274e34">{PEOPLE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; min-height: 48px"><span style="font-size: 14px; font-weight: 700">{t}</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">{sub}</span></span>'
            f'<a href="FeteChoisir.dc.html" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">Modifier</a></div>')
def swap_bar(h,new):
    i=h.index('<div data-pub="1"'); j=i; d=0
    for mm in re.finditer(r'<div\b|</div>',h[i:]):
        d+=1 if mm.group(0)!='</div>' else -1
        if d==0: j=i+mm.end(); break
    return h[:i]+new+h[j:]

# =================== LISTES ===================
def seg(sel):
    def b(t,on): return ('<button role="radio" aria-checked="'+('true' if on else 'false')+'" style="height: 40px; padding: 0 14px; border: 0; border-radius: 999px; background: '+('#f1e8fc' if on else CARD)+'; box-shadow: '+('0 0 0 2px '+RED if on else '0 0 0 1px '+LINE)+'; font-family: inherit; font-size: 14px; font-weight: 700; color: '+INK+'">'+t+'</button>')
    return '<li><div role="radiogroup" aria-label="Dans Famille Camille, qui la verra" style="display: flex; flex-wrap: wrap; gap: 8px; padding: 0 16px 14px 64px">'+b('Toute la fête',sel==0)+b('Celui qui m’a tiré',sel==1)+'</div></li>'
def qui(sel,mamie):
    return (QUI0.replace('<!--SEG-->',seg(sel),1) if mamie else QUI0.replace('<!--SEG-->',seg(sel),1).replace(chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',True),chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',False),1))
QUI0=(f'<h2 style="margin: 0; padding: 0 20px; font-family: {F}; font-weight: 700; font-size: 22px">Qui verra ta liste ?</h2>'
     f'<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid {SOFT}; border-bottom: 1px solid {SOFT}">'
     +chk(cat('Noël'),'Famille Camille','Noël · 12 membres',True,True)+'<!--SEG-->'+chk(cat('Noël'),'Chez Mamie','Noël · 9 membres',True)+chk(cat('Noël'),'Bureau, 3e étage','Noël · 8 membres',False)+chk(cat('Anniversaire'),'Les 40 ans de Tonton','Anniversaire · 15 membres',False)+'<li><a href="V3FeteNouvelle.dc.html" style="display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border-top: 1px solid '+SOFT+'; text-decoration: none; color: '+INK+'"><span aria-hidden="true" style="width: 32px; height: 32px; box-sizing: border-box; border-radius: 9px; border: 1.5px dashed #cdb48a; color: '+DRED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+PLUS+'</span><span style="flex-grow: 1; font-weight: 600; font-size: 16px">Une autre occasion</span><span style="color: #78716c; display: flex">'+CHEV+'</span></a></li>'+'</ul>'
     f'<div style="display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 0 20px"><span style="display: flex; color: {MUT}">{GLOBE}</span><span style="flex-grow: 1; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 600">Tout le monde, avec un lien</span><span style="font-size: 13px; color: {MUT}">Une liste publique : pour un mariage, ou quelqu’un hors de tes fêtes</span></span>{SWOFF}</div>'
     f'<div style="padding: 0 16px"><a href="V3ListeNouvelle.dc.html" style="{BTN}">Continuer</a></div>')
put('V3ListeQui',sheet(page('V3 · qui verra ta liste ?',MAINA,HA),qui(0,True),250,'Qui verra ta liste ?'),HA,'Liste · première étape : « Qui verra ta liste ? », une ou plusieurs de mes fêtes ou une autre occasion ; en plus, tout le monde avec un lien',4,0)
put('V3Liste',v3(swap_bar(R('ListeTeneur'),vbar('Famille Camille, Chez Mamie','21 membres la voient').replace('FeteChoisir.dc.html','V3ListeQui.dc.html')),'V3 · ma liste, dans ses fêtes'),None,'Liste · la mienne : la barre dit dans quelles fêtes elle est ; « Modifier » rouvre « Qui verra ta liste ? »',4,1)
pubbar=(f'<div data-pub="1" style="position: sticky; top: 8px; z-index: 2; border-radius: 24px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}, 0 4px 14px rgba(41, 37, 36, 0.08); padding: 6px 8px 8px 14px; display: flex; flex-direction: column; gap: 6px">'
        f'<div style="display: flex; align-items: center; gap: 10px; min-height: 44px"><span style="display: flex; color: #274e34">{GLOBE}</span><span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 14px; font-weight: 700">Publique, avec un lien</span><span style="font-size: 13px; line-height: 1.3; color: {MUT}">Et dans la fête « Notre mariage »</span></span><a href="V3ListeQui.dc.html" style="height: 36px; padding: 0 12px; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-size: 14px; font-weight: 700; text-decoration: none; display: flex; align-items: center; flex-shrink: 0">Modifier</a></div>'
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 6px 6px 6px 12px; border-radius: 14px; background: #f1e8d8"><span style="flex-grow: 1; min-width: 0; font-size: 14px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">under-the-tree.party/l/k3Fq9xT2</span><button style="height: 36px; padding: 0 12px; border: 0; border-radius: 999px; background: {CARD}; box-shadow: 0 0 0 1px {LINE}; color: {INK}; font-family: inherit; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 6px; flex-shrink: 0">{SHARE}Partager</button></div></div>')
put('V3ListePublique',v3(swap_bar(R('ListeSansPersonne'),pubbar),'V3 · une liste publique'),None,'Liste · publique (un mariage) : dans sa fête, et ouverte à tous par un lien, sans compte pour cocher',4,3)
h=swap_bar(R('ListeNouvelle'),vbar('Famille Camille, Chez Mamie','21 membres la verront').replace('FeteChoisir.dc.html','V3ListeQui.dc.html'))
h=h.replace('>Nom de l’événement<','>Noël 2026<',1).replace('>Ajouter une date<','>Le 25 décembre<',1).replace('>🎁<','>🎄<',1)
put('V3ListeNouvelle',v3(h,'V3 · une nouvelle liste, dans une fête'),None,'Liste · nouvelle : le nom, la date et l’icône viennent de la fête',4,2)
h=R('ListeGroupeFil')
FRB=re.compile(r'<button aria-label="Langue : français"[^>]*>FR</button>')
h=FRB.sub(AVB,h,count=1)
m=re.search(r'<main[^>]*>',h)
CHR12=ic('<path d="m9 6 6 6-6 6"/>',12,2.8)
NOELBG=CAT['Noël'][1]
h=h[:m.end()]+'\n    <a href="V3Fete.dc.html" style="align-self: flex-start; display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 10px 0 8px; border-radius: 999px; background: '+NOELBG+'; font-size: 13px; font-weight: 700; color: #274e34; text-decoration: none">🎄 Famille Camille'+CHR12+'</a>'+h[m.end():]
h=re.sub(r'<title>[^<]*</title>','<title>V3 · la liste d’un autre membre</title>',h,count=1)
put('V3ListeMembre',h,None,'Liste · celle d’un autre membre : on y arrive par la fête, sans lien ; la fête est rappelée en haut',4,4)
ail=f'''<main style="flex-grow: 1; display: flex; flex-direction: column; gap: 18px; padding: 8px 16px 28px">
    {H1('Ce que j’offre ailleurs','Les listes publiques où tu as coché quelque chose.')}
    <ul style="{UL}">{irow(cat('Mariage',36),'Le mariage de Karim et Sofia','Le 12 juin · tu offres : un plaid en laine','',True,'V3ListePublique.dc.html')}{irow(cat('Crémaillère',36),'La crémaillère d’Inès','Cette liste n’est plus partagée · tu offrais : une plante')}</ul>
    <p style="margin: 0; padding: 0 4px; font-size: 14px; line-height: 1.45; color: {MUT}">Ouvrir une liste sans rien cocher ne laisse aucune trace ici.</p>
  </main>'''
put('V3OffreAilleurs',page('V3 · ce que j’offre ailleurs',ail,844).replace(HEADER,hd,1),844,'Liste · « Ce que j’offre ailleurs » : les listes publiques où j’ai coché, pas celles que j’ai seulement ouvertes',4,5)

# =================== LE « + » DE L'ACCUEIL ===================
MAINB=MAINA
PLUS24=ic('<path d="M12 5v14M5 12h14"/>',24,2.4)
ROND='border-radius: 999px; background: '+RED+'; color: #ffffff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; text-decoration: none'
# Julien n'aime ni le rond rouge en bas, ni le rond rouge à côté du titre : deux autres pistes, sans rond rouge
PLUSC=ic('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',22)
TABC=('<a href="V3AccueilPlusOuvert.dc.html" style="flex: 1; min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; text-decoration: none; color: '+MUT+'; font-size: 12px; font-weight: 600"><span style="position: relative; display: flex">'+PLUSC+'</span>Créer</a>')
assert nav().count('</a><a ')==1
NAVP=nav().replace('</a><a ','</a>'+TABC+'<a ',1)
def pagep(title,main,h):
    x=page(title,main,h); assert x.count(nav())==1
    return x.replace(nav(),NAVP,1)
H1P=('<div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 4px 4px 0"><h1 style="margin: 0; font-family: '+F+'; font-weight: 700; font-size: 30px; line-height: 1.1">Bonjour Hugo</h1>'
     '<a href="V3AccueilPlusOuvert.dc.html" style="height: 40px; padding: 0 14px 0 10px; border-radius: 999px; background: '+CARD+'; box-shadow: 0 0 0 1px '+LINE+'; color: '+INK+'; font-size: 15px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px; flex-shrink: 0">'+PLUS+'Créer</a></div>')
assert MAINB.count(H1('Bonjour Hugo'))==1
MAINC=MAINB.replace(H1('Bonjour Hugo'),H1P,1)
# Retenu par Julien : la piste D seule, l'onglet « Créer » ; il est posé sur toutes les pages qui ont la barre du bas, à la fin (voir « ONGLET CRÉER »)
CREER=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px">Créer</h2>'
       '<ul style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'">'
       +irow(tl(),'Un tirage','Dans une de tes fêtes, ou dans une nouvelle','',True,'V3TirageQuelleFete.dc.html')
       +irow(ll(),'Une liste','Dans une de tes fêtes, ou publique avec un lien','',False,'V3ListeQui.dc.html')+'</ul>')
def sheetb(h,inner,label):
    S=('<div aria-hidden="true" style="position: absolute; inset: 0; background: rgba(41, 37, 36, 0.45); z-index: 4"></div>'
       '<div role="dialog" aria-label="'+label+'" style="position: absolute; left: 0; right: 0; bottom: 0; box-sizing: border-box; z-index: 5; background: '+CARD+'; border-radius: 20px 20px 0 0; padding: 10px 0 28px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -8px 24px rgba(60, 30, 10, 0.18)">'
       '<span aria-hidden="true" style="align-self: center; width: 40px; height: 4px; border-radius: 999px; background: #d6d3d1"></span>'+inner+'</div>')
    h=rel(h); z=h.rindex('</div>\n</x-dc>'); return h[:z]+S+h[z:]
put('V3AccueilPlusOuvert',sheetb(page('V3 · accueil, « Créer » touché',MAINB,1320),CREER,'Créer'),1320,'Accueil · l’onglet « Créer » touché : un Secret Santa ou une liste ; la fête est la première étape des deux',0,3)

# =================== UN TIRAGE : DANS QUELLE FÊTE ? ===================
def rad(lead,t,sub,on,first=False):
    b=('<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; border: 2px solid '+RED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0"><span style="width: 12px; height: 12px; border-radius: 50%; background: '+RED+'"></span></span>' if on else
       '<span aria-hidden="true" style="width: 24px; height: 24px; box-sizing: border-box; border-radius: 50%; border: 2px solid #a8a29e; flex-shrink: 0"></span>')
    return ('<li><button role="radio" aria-checked="'+('true' if on else 'false')+'" style="width: 100%; display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 8px 16px; box-sizing: border-box; border: 0;'+('' if first else ' border-top: 1px solid '+SOFT+';')+' background: transparent; font-family: inherit; text-align: left; color: '+INK+'">'
            +lead+'<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-weight: 600; font-size: 16px">'+t+'</span><span style="font-size: 13px; line-height: 1.35; color: '+MUT+'">'+sub+'</span></span>'+b+'</button></li>')
NEWF='<span aria-hidden="true" style="width: 36px; height: 36px; box-sizing: border-box; border-radius: 10px; border: 1.5px dashed #cdb48a; color: '+DRED+'; display: flex; align-items: center; justify-content: center; flex-shrink: 0">'+PLUS+'</span>'
QUELLE=('<h2 style="margin: 0; padding: 0 20px; font-family: '+F+'; font-weight: 700; font-size: 22px">Un tirage dans quelle fête ?</h2>'
        '<ul role="radiogroup" aria-label="La fête du Secret Santa" style="list-style: none; margin: 0; padding: 0; border-top: 1px solid '+SOFT+'; border-bottom: 1px solid '+SOFT+'">'
        +rad(cat('Noël'),'Bureau, 3e étage','Noël · 8 membres · déjà un tirage cette année',True,True)
        +rad(NEWF,'Une autre occasion','Elle se crée avec le tirage : un nom, une date',False)+'</ul>'
        '<p style="margin: 0; padding: 0 20px; font-size: 13px; line-height: 1.4; color: '+MUT+'">Dans tes autres fêtes, c’est l’organisateur qui lance le tirage.</p>'
        '<div style="padding: 0 16px"><a href="V3TirageNouveau.dc.html" style="'+BTN+'">Continuer</a></div>')
put('V3TirageQuelleFete',sheetb(page('V3 · un tirage dans quelle fête ?',MAINB,1320),QUELLE,'Pour quelle occasion ?'),1320,'x',0,4)

# =================== PISTES ET LISTES FUSIONNÉES ===================
# Julien, 20 novembre 2026 : plus de « pistes » ; celui qui m'a tiré voit ma liste, que je peux ne montrer qu'à lui.
put('V3ListeQuiSecret',sheet(v3(RESULT,'V3 · qui verra ta liste ? depuis le Secret Santa'),qui(1,False),250,'Qui verra ta liste ?'),1422,'Liste · depuis mon Secret Santa : « Celui qui m’a tiré » est choisi d’avance ; « Toute la fête » reste possible',4,6)
_ls=swap_bar(R('ListeTeneur'),vbar('Famille Camille','Seul celui qui m’a tiré la voit').replace('FeteChoisir.dc.html','V3ListeQuiSecret.dc.html'))
put('V3ListeSecret',v3(_ls,'V3 · ma liste, pour celui qui m’a tiré'),None,'Liste · la mienne, montrée seulement à celui qui m’a tiré : les anciennes « pistes de cadeaux »',4,7)
_T=('<div role="status" style="position: sticky; bottom: 16px; z-index: 6; margin: 0 16px 16px; min-height: 52px; padding: 10px 8px 10px 16px; border-radius: 14px; background: #292524; color: #ffffff; box-shadow: 0 10px 28px rgba(41, 37, 36, 0.3); display: flex; align-items: center; gap: 12px; font-size: 15px; font-weight: 600">'
    '<span style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span>C’est enregistré</span><span style="font-size: 13px; font-weight: 400; line-height: 1.35">Un compte a été créé avec ton adresse, pour retrouver ta liste.</span></span>'
    '<button style="height: 40px; padding: 0 14px; border: 0; border-radius: 999px; background: rgba(255, 255, 255, 0.16); color: #ffffff; font-family: inherit; font-size: 14px; font-weight: 700; flex-shrink: 0">Compris</button></div>')
_lc=v3(_ls,'V3 · le compte se crée à la première idée'); _z=_lc.rindex('</div>\n</x-dc>')
put('V3ListeCompteCree',_lc[:_z]+_T+_lc[_z:],None,'Liste · sans compte, par son lien : le compte se crée tout seul à la première chose écrite, et on le dit',4,8)

# Sans adresse email (lien copié) : pas de liste sans adresse, on la demande au moment d'écrire sa liste (Julien)
_ad=R('ProcheAdresse')
for _x,_y in [('Mes proches · Léo','Famille Camille · Secret Santa 2026'),('>Son adresse email<','>Ton adresse email, pour écrire ta liste<'),('href="ListePersonne.dc.html"','href="V3ListeSecret.dc.html"')]:
    assert _ad.count(_x)==1,_x; _ad=_ad.replace(_x,_y)
_MENU=re.search(r'<button aria-label="Menu"[^>]*>.*?</button>',_ad,re.S).group(0)
_FR='<button aria-label="Langue : français" style="justify-self: end; height: 44px; min-width: 44px; border: 0; background: transparent; color: #292524; font-family: inherit; font-size: 14px; font-weight: 600">FR</button>'
_ad=_ad.replace(_MENU,_FR,1)
_k=_ad.index('</main>')
_ad=_ad[:_k]+'  <p style="margin: 0; font-size: 13px; line-height: 1.4; color: #57534e">Elle crée ton compte, sans mot de passe : tu reçois un lien pour la confirmer. <a href="Confidentialite.dc.html" style="color: #8a2f27; text-decoration: underline">Tes données, en clair</a></p>\n  '+_ad[_k:]
_ad=re.sub(r'<title>[^<]*</title>','<title>V3 · une adresse pour écrire sa liste</title>',_ad,count=1)
put('V3ListeAdresse',_ad,None,'Liste · arrivé par un lien copié, sans adresse email : on la demande au moment d’écrire sa liste ; pas de liste sans adresse',4,9)
# Celui qui m'a tiré arrive sur la liste entière, ma partie surlignée (Julien)
_sl=V['V3ListeMembre'][0]
_tv=open(PJ+'ListeVisiteurTirage.dc.html',encoding='utf-8').read()
_i=_tv.index('<div data-mode="anonyme"'); _d=0
for _mm in re.finditer(r'<div\b|</div>',_tv[_i:]):
    _d+=1 if _mm.group(0)!='</div>' else -1
    if _d==0: _j=_i+_mm.end(); break
_bar=_tv[_i:_j]; _n=_bar.index('<div data-note="tirage"'); _d=0
for _mm in re.finditer(r'<div\b|</div>',_bar[_n:]):
    _d+=1 if _mm.group(0)!='</div>' else -1
    if _d==0: _bar=_bar[:_n]+_bar[_n+_mm.end():]; break
_m=re.search(r'<main[^>]*>',_sl); _sl=_sl[:_m.end()]+'\n    '+_bar+_sl[_m.end():]
_c=_sl.index('>Camille</h2>'); _s0=_sl.rindex('<section',0,_c); _s1=_sl.index('</section>',_c)+10
_sec=_sl[_s0:_s1]
for _x,_y in [('>Camille</h2>','>Inès</h2>'),('>🦌</span>','>🍭</span>')]:
    assert _sec.count(_x)==1,(_x,_sec.count(_x)); _sec=_sec.replace(_x,_y)
_sl=_sl[:_s0]+_sec+_sl[_s1:]
for _x,_y in [('La liste de Camille et Hugo. Camille seule voit qui a coché quoi.','La liste d’Inès.')]:
    assert _sl.count(_x)==1,_x; _sl=_sl.replace(_x,_y)
_sl=re.sub(r'<title>[^<]*</title>','<title>V3 · la liste de la personne tirée</title>',_sl,count=1)
put('V3ListeSurligne',_sl,None,'Secret Santa · la liste de la personne tirée : la liste entière, la page s’ouvre calée sur sa partie (ici Inès, en bas), le mode anonyme déjà activé',3,5)

# =================== RÉGLAGES : ceux de la fête, ceux du Secret Santa ===================
# Retour de Julien : les pistes de cadeaux (et ce qui ne concerne que le tirage) ne sont plus un réglage de la fête.
_h,_ht,_t,_row,_col=V['V3FeteReglages']
_secs=list(re.finditer(r'<section\b.*?</section>',_h,re.S)); assert len(_secs)==6
def _name(x): return re.search(r'<h2[^>]*>([^<]*)</h2>',x).group(1) if '<h2' in x else ''
_by={_name(m.group(0)):m.group(0) for m in _secs}
assert set(_by)=={'La fête','Tirage','Participants','M’écrire par email','Organisateurs',''},set(_by)
_mail=_by['M’écrire par email']; _lis=re.findall(r'<li\b.*?</li>',_mail,re.S); assert len(_lis)==3
def _keep(sec,lis):
    i=sec.index(_lis[0]); j=sec.index(_lis[2])+len(_lis[2]); return sec[:i]+'\n        '.join(lis)+sec[j:]
_pre=_h[:_secs[0].start()]; _post=_h[_secs[-1].end():]
_SSROW=('<section style="display: flex; flex-direction: column; gap: 6px"><h2 style="margin: 0; padding: 0 4px; font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: '+MUT+'">Secret Santa</h2><ul style="'+UL+'">'
        +irow(tl(),'Le Secret Santa 2026','Ses réglages : mot des messages, rappels','',True,'V3TirageReglages.dc.html')+'</ul></section>')
_f=_pre+'\n    '.join([_by['La fête'],_SSROW,_keep(_mail,[_lis[0]]),_by['Organisateurs'],_by['']])+_post
V['V3FeteReglages']=(_f,1000,'Fête · réglages : la catégorie, la date, la récurrence, les organisateurs ; ceux du Secret Santa sont sur le Secret Santa',_row,_col)
_NOTE='<p style="margin: 0; padding: 0 4px; font-size: 13px; line-height: 1.4; color: #57534e">Repris tels quels quand tu prépares le Secret Santa de l’année suivante.</p>'
_pl=re.findall(r'<li\b.*?</li>',_by['Participants'],re.S); assert len(_pl)==2 and 'Pistes de cadeaux' in _pl[0]
_part=_by['Participants'].replace(_pl[0],'',1).replace('>Participants</h2>','>Les messages</h2>',1)
_dq=_by['Tirage']; assert _dq.count('Éviter la même personne')==1 and _dq.count('Que l’an dernier')==1
_dq=re.sub(r'\s*<p\b[^>]*>Plus la période est longue[^<]*</p>','',_dq.replace('>Tirage</h2>','>Devine qui</h2>',1).replace('Éviter la même personne','Pronostics',1).replace('Que l’an dernier','Qui m’offre ?',1))
_g=_pre+'\n    '.join([_by['Tirage'].replace('>Tirage</h2>','>Le tirage au sort</h2>',1),_dq,_part,_keep(_mail,[_lis[1],_lis[2]])])+_post
assert _g.count('>Réglages de la fête<')==1 and _g.count('>Famille Camille</a></nav>')==1
_g=_g.replace('>Réglages de la fête<','>Réglages<',1).replace('>Famille Camille</a></nav>','>Famille Camille · Secret Santa 2026</a></nav>',1)
_g=re.sub(r'<title>[^<]*</title>','<title>V3 · réglages d’un Secret Santa</title>',_g,count=1)
put('V3TirageReglages',_g,900,'Secret Santa · ses réglages : éviter la même personne, les pistes de cadeaux, le mot des messages, les emails du tirage',3,4)

# =================== « SECRET SANTA », PAS « TIRAGE » ===================
# Retour de Julien : la chose s'appelle « Secret Santa », même hors de Noël ; « tirage » reste le geste (tirer au sort).
SS=[('>Le tirage<','>Le Secret Santa<'),('>Le tirage 2026<','>Le Secret Santa 2026<'),('>Le tirage 2027<','>Le Secret Santa 2027<'),
    ('>Les tirages<','>Les Secret Santa<'),('>Un tirage<','>Un Secret Santa<'),('>Un autre tirage<','>Un autre Secret Santa<'),
    ('Organiser un tirage','Organiser un Secret Santa'),('Créer le tirage','Créer le Secret Santa'),
    ('membres repris du tirage 2026.','membres repris du Secret Santa 2026.'),
    ('rejoint la fête, et son tirage tant qu’il n’a pas eu lieu.','rejoint la fête, et son Secret Santa tant que le tirage n’a pas eu lieu.'),
    ('tu verras son tirage et les listes de ses membres','tu verras son Secret Santa et les listes de ses membres'),
    ('c’est l’organisateur qui lance le tirage.','c’est l’organisateur qui lance le Secret Santa.'),
    ('Elle se crée avec le tirage : un nom, une date','Elle se crée avec le Secret Santa : un nom, une date'),
    ('déjà un tirage cette année','déjà un Secret Santa cette année'),
    ('Tu ne participeras plus à son tirage l’an prochain.','Tu ne participeras plus à son Secret Santa l’an prochain.'),
    ('>Un tirage dans quelle fête ?<','>Pour quelle occasion ?<'),
    ('Camille te demande des pistes','Camille te demande ta liste')]
_seen=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for x,y in SS:
        if x in h: _seen.add(x); h=h.replace(x,y)
    V[k]=(h,ht,t,row,col)
assert all(x in _seen for x,_ in SS),[x for x,_ in SS if x not in _seen]
def retitle(k,t): h,ht,_,row,col=V[k]; V[k]=(h,ht,t,row,col)
retitle('V3TirageNeutre','Secret Santa · hors de Noël (catégorie « Autre ») : il garde son nom, « Secret Santa » ; aucun « Père Noël »')
retitle('V3FeteRejoindre','Fête · le lien d’invitation, sans compte : on rejoint une fête, et son Secret Santa s’il y en a un')
retitle('V3TirageNouveau','Secret Santa · celui de l’année : la date de la fête est déjà là, et se change')
retitle('V3TirageVersListe','Secret Santa · du résultat à la liste de cadeaux d’Inès, sans lien ; le mode anonyme s’active seul')
retitle('V3TirageQuelleFete','Secret Santa · première étape : « Pour quelle occasion ? », une fête que j’organise ou une autre occasion')
retitle('V3FeteOrganisateur','Fête · vue par son organisateur : « Inviter », les réglages, « Un autre Secret Santa »')
retitle('V3FeteAnniversaire','Fête · « pour quelqu’un » (un anniversaire) : sa liste d’abord ; un Secret Santa reste possible')
retitle('V3Fete','Fête · vue par un membre : ses membres, son Secret Santa, les listes, les années passées, « Quitter »')
retitle('V3Accueil','Accueil · mes fêtes : leurs Secret Santa et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs')
retitle('V3FeteMembres','Fête · ses membres (certains sans compte : ils participent au Secret Santa, ils ne voient pas les listes)')

# =================== MOINS DE PHRASES ===================
# Julien, 20 novembre 2026 : aucune phrase écrite pour expliquer la maquette au concepteur ; ne reste que ce qui sert à l'utilisateur, là où il est.
RM=['Tu l’organises. Les 8 membres de l’an dernier sont repris.',
    'Dans une de tes fêtes, ou dans une nouvelle','Dans une de tes fêtes, ou publique avec un lien',
    'Chaque réglage s’enregistre dès qu’il est validé.','Plus personne ne pourra s’inscrire',
    'L’historique de ceux qui ne participent plus est conservé.',
    'Ses réglages : mot des messages, rappels','Envoyé à chaque organisateur, dans sa langue.','Il se connecte avec son adresse, sans mot de passe',
    'La croix supprime un proche qui n’est sur aucune liste.',
    'La liste sera alors rangée par personne. Les idées déjà écrites iront à la première.',
    'Une liste publique : pour un mariage, ou quelqu’un hors de tes fêtes',
    'Les listes publiques où tu as coché quelque chose.','Ouvrir une liste sans rien cocher ne laisse aucune trace ici.',
    'Elle se crée avec le Secret Santa : un nom, une date','Dans tes autres fêtes, c’est l’organisateur qui lance le Secret Santa.',
    'Plus la période est longue, plus le tirage est contraint.']
RP=[('Chacun s’inscrit avec son adresse email et rejoint la fête, et son Secret Santa tant que le tirage n’a pas eu lieu.','Ceux qui s’inscrivent rejoignent aussi le Secret Santa, tant que le tirage n’a pas eu lieu.'),
    ('pour la rejoindre : tu verras son Secret Santa et les listes de ses membres.','pour la rejoindre.'),
    ('Elle crée ton compte, sans mot de passe : tu reçois un lien pour la confirmer. ','Tu reçois un lien pour la confirmer. '),
    (' Tu ajusteras la liste sur l’écran suivant.',''),
    ('>Le Secret Santa 2026</span><span style="font-size: 13px; line-height: 1.35; color: '+MUT+'">Ses réglages : mot des messages, rappels</span>','>Réglages du Secret Santa 2026</span>')]
_rs=set(); _ps=set()
for k in list(V):
    h,ht,t,row,col=V[k]
    for x,y in RP:
        if x in h: _ps.add(x); h=h.replace(x,y)
    for x in RM:
        h2=re.sub(r'\s*<(p|span)\b[^<>]*>'+re.escape(x)+r'</\1>','',h)
        if h2!=h: _rs.add(x); h=h2
    h2=re.sub(r'\s*<p\b[^<>]*>Touche un prénom : il s’ajoute à la liste.*?</p>','',h,flags=re.S)
    if h2!=h: _rs.add('touche'); h=h2
    V[k]=(h,ht,t,row,col)
_miss=[x for x in RM if x not in _rs and x!='Ses réglages : mot des messages, rappels']+[x for x,_ in RP if x not in _ps]+([] if 'touche' in _rs else ['touche'])
assert not _miss,_miss

# =================== ONGLET « CRÉER » ===================
_nv=0
for k in list(V):
    h,ht,t,row,col=V[k]
    if nav() in h: _nv+=1; h=h.replace(nav(),NAVP)
    V[k]=(h,ht,t,row,col)
assert _nv>=5,_nv
retitle('V3Accueil','Accueil · mes fêtes : leurs Secret Santa et les listes de leurs membres ; un anniversaire proposé ; ce que j’offre ailleurs ; l’onglet « Créer » dans la barre du bas')

names=json.load(open('/tmp/names.json')); meta={}
for k,(h,ht,t,row,col) in V.items():
    if ht is None: ht=int(re.search(r'"\$preview":\{"width":\d+,"height":(\d+)\}',h).group(1))
    open(PJ+k+'.dc.html','w',encoding='utf-8').write(h)
    if k+'.dc.html' not in names: names.append(k+'.dc.html')
    meta[k]=dict(h=ht,title=t,x=col*470,y=row*2000)
json.dump(names,open('/tmp/names.json','w')); json.dump(meta,open('/tmp/v3meta.json','w'),ensure_ascii=False,indent=0)
print(len(V),list(V))
