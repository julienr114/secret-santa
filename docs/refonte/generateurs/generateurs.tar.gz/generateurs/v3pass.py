# Passage de toutes les maquettes d'avant sur les mots et l'habillage de la V3 (20 novembre 2026).
# Lit la copie d'avant (/home/claude/utt/v2), écrit dans /home/claude/utt/project. Se relance sans risque.
import re,json,sys,io,contextlib
sys.path.insert(0,'/home/claude/gen')
with contextlib.redirect_stdout(io.StringIO()): exec(open('/home/claude/gen/v3all.py').read())
from v3perimees import *
V2='/home/claude/utt/v2/'
names=sorted(n[:-8] for n in json.load(open('/tmp/names.json')))
S=[n for n in names if not perimee(n) and not intacte(n)]
# --- sous-chaînes sûres, partout
SUB=[('Journal du groupe','Journal de la fête'),('journal du groupe','journal de la fête'),('Réglages de l’édition','Réglages du Secret Santa'),
 ('Mes pistes de cadeaux','Ma liste de cadeaux'),('Lui demander des pistes','Lui demander des idées'),
 ('organisateurs des groupes que tu rejoins','organisateurs des fêtes que tu rejoins'),('tout le groupe le lit alors','tous les membres le lisent alors'),
 ('e seuil du groupe','e seuil de la fête'),('pour les prochaines éditions','pour les prochains Secret Santa')]
# --- nœuds de texte entiers
M={
'4 groupes · 3 tirages en cours':'4 fêtes · 3 Secret Santa en cours','Chercher un groupe ou un organisateur':'Chercher une fête ou un organisateur',
'Créer un groupe pour quelqu’un':'Créer une fête pour quelqu’un','Paul · 3 membres · pas de tirage en cours':'Paul · 3 membres · pas de Secret Santa en cours',
'Email du groupe « Bureau 3e »':'Email de la fête « Bureau 3e »','8 membres du groupe':'8 membres de la fête',
'Elle rejoint le groupe et cette édition':'Elle rejoint la fête et ce Secret Santa',
'Affiché dans le journal, visible de tout le groupe.':'Affiché dans le journal, visible de tous les membres.',
'Ce que le groupe lira dans le journal':'Ce que les membres liront dans le journal','Les pistes de cadeaux sont conservées.':'Les listes de cadeaux sont conservées.',
'Ajouter et changer des idées sur tes listes, tes pistes':'Ajouter et changer des idées sur tes listes',
'Tes listes, tes pistes, où en sont tes tirages':'Tes listes, où en sont tes Secret Santa',
'Ajoute ce tirage à ton compte pour le retrouver depuis ton accueil.':'Ajoute ce Secret Santa à ton compte pour le retrouver depuis ton accueil.',
'Crée un compte avec ton adresse email : tu retrouveras ce tirage sans chercher le lien.':'Crée un compte avec ton adresse email : tu retrouveras ce Secret Santa sans chercher le lien.',
'Déjà connecté, tirage pas encore rattaché':'Déjà connecté, Secret Santa pas encore rattaché','Garde tes tirages au même endroit':'Garde tes Secret Santa au même endroit',
'Un lien de connexion, et ce tirage est dans ton compte, avec les suivants.':'Un lien de connexion, et ce Secret Santa est dans ton compte, avec les suivants.',
"Elle est dans le groupe mais pas dans cette édition. Après le tirage, il faudra l'annuler pour l'ajouter.":"Elle est dans la fête mais pas dans ce Secret Santa. Après le tirage, il faudra l'annuler pour l'ajouter.",
'Quelqu’un rejoint le groupe par le lien':'Quelqu’un rejoint la fête par le lien','Supprimer le groupe':'Supprimer la fête',
"Clôturer l'édition":"Clôturer le Secret Santa","Fige l'édition et les pistes de cadeaux":"Fige le Secret Santa",
"Les pistes de cadeaux restent modifiables jusqu'à la clôture de l'édition.":"Les listes de cadeaux restent modifiables.",
"Préparer l'édition suivante":"Préparer le Secret Santa suivant",'Édition clôturée':'Secret Santa clôturé',
'Ton prénom et ton icône sont repris dans tes tirages. La langue est celle de tes emails.':'Ton prénom et ton icône sont repris dans tes Secret Santa. La langue est celle de tes emails.',
'Mon adresse, mes pistes et mes listes sont effacées. Dans les groupes, il reste mon prénom, sans rien d’autre.':'Mon adresse et mes listes sont effacées. Dans les fêtes, il reste mon prénom, sans rien d’autre.',
'Un fichier, tout de suite : mon profil, mes groupes, mes pistes, mes listes.':'Un fichier, tout de suite : mon profil, mes fêtes, mes listes.',
'En tant qu’administrateur, il voit les comptes : l’adresse, les groupes, la date de la dernière visite.':'En tant qu’administrateur, il voit les comptes : l’adresse, les fêtes, la date de la dernière visite.',
'Les organisateurs des groupes que tu rejoins. Elle sert à te connecter et à te prévenir.':'Les organisateurs des fêtes que tu rejoins. Elle sert à te connecter et à te prévenir.',
'Tes pistes de cadeaux':'Tes goûts et tes idées de cadeaux','Ton groupe, et ceux qui ouvrent une liste où tu figures.':'Les membres de tes fêtes, et ceux qui ouvrent une liste où tu figures.',
'Tout le groupe : qui a ouvert son enveloppe, et quand. Jamais qui a tiré qui.':'Tous les membres : qui a ouvert son enveloppe, et quand. Jamais qui a tiré qui.',
'Léa, Tom, Zoé et 4 autres sont dans le groupe mais pas dans cette édition.':'Léa, Tom, Zoé et 4 autres sont dans la fête mais pas dans ce Secret Santa.',
'Celui que verront les autres dans tes tirages.':'Celui que verront les autres dans tes Secret Santa.',
'Si un organisateur t’a déjà ajouté avec cette adresse, tes tirages t’attendent dans ton compte.':'Si un organisateur t’a déjà ajouté avec cette adresse, tes Secret Santa t’attendent dans ton compte.',
'L’édition Noël 2026 a été créée':'Le Secret Santa Noël 2026 a été créé','Tout le groupe voit ce journal. Il ne dit jamais qui offre à qui.':'Tous les membres voient ce journal. Il ne dit jamais qui offre à qui.',
'Au groupe':'À tous','Sans adresse ? Passe par « Au groupe ». Dernier rappel : aucun.':'Sans adresse ? Passe par « À tous ». Dernier rappel : aucun.',
'Le jeu de cette édition':'Le jeu de ce Secret Santa','Revoir mon résultat et ses pistes':'Revoir mon résultat et ses idées',
'Ses pistes de cadeaux t’attendent à l’intérieur. Assure-toi que personne ne regarde ton écran.':'Ses idées de cadeaux t’attendent à l’intérieur. Assure-toi que personne ne regarde ton écran.',
'Qui a offert à qui, dans tout le groupe':'Qui a offert à qui, dans toute la fête','Une surprise attend le groupe à la fête.':'Une surprise attend tout le monde à la fête.',
"C'est définitif, et le journal du groupe l'indique. Les pistes de cadeaux restent modifiables.":"C'est définitif, et le journal de la fête l'indique.",
'Le journal l’affichera à tout le groupe.':'Le journal l’affichera à tous les membres.',
'Tu pourras ensuite lui envoyer son lien par email. Elle servira aussi à Rose pour retrouver ses tirages.':'Tu pourras ensuite lui envoyer son lien par email. Elle servira aussi à Rose pour retrouver ses Secret Santa.',
'Ce n’est pas ton groupe : l’application a atteint sa limite. Il reprendra tout seul.':'Ça ne vient pas de toi : l’application a atteint sa limite. L’envoi reprendra tout seul.',
'On n’arrive pas à charger l’édition':'On n’arrive pas à charger le Secret Santa','Revenir au groupe':'Revenir à la fête',
"C'est facultatif, et définitif. Les pistes de cadeaux restent modifiables tant que l'édition n'est pas clôturée.":"C'est facultatif, et définitif.",
'Les exclusions se modifient jusqu’au tirage. Ensuite, l’édition garde celles qui ont servi.':'Les exclusions se modifient jusqu’au tirage. Ensuite, le Secret Santa garde celles qui ont servi.',
'Se règle dans les réglages du groupe':'Se règle dans les réglages du Secret Santa',
'Hugo ne sera plus repris dans les prochaines éditions. Son historique est conservé.':'Hugo ne sera plus repris dans les prochains Secret Santa. Son historique est conservé.',
'Pour lui envoyer son lien, et pour qu’il retrouve ses tirages en se connectant.':'Pour lui envoyer son lien, et pour qu’il retrouve ses Secret Santa en se connectant.',
'Retirer du groupe':'Retirer de la fête','Qui offre à qui, ni les pistes de cadeaux de chacun.':'Qui offre à qui, ni les listes de cadeaux de chacun.',
'Tout le groupe le voit':'Tous les membres le voient',
'En cas de doute ou de désaccord, il faut pouvoir vérifier. L’organisateur doit recopier une phrase et accepter que tout le groupe le sache.':'En cas de doute ou de désaccord, il faut pouvoir vérifier. L’organisateur doit recopier une phrase et accepter que tous les membres le sachent.',
'Chacun ouvre son enveloppe sur son téléphone. L’organisateur ne voit pas qui offre à qui. S’il regarde un résultat en dernier recours, tout le groupe le sait.':'Chacun ouvre son enveloppe sur son téléphone. L’organisateur ne voit pas qui offre à qui. S’il regarde un résultat en dernier recours, tous les membres le savent.',
'Des pistes pour ne pas tomber à côté':'Des idées pour ne pas tomber à côté','Le groupe, les exclusions et les tirages passés sont gardés.':'La fête, les exclusions et les Secret Santa passés sont gardés.',
'Les pistes':'Les idées','Un compte suffit pour tenir une liste. Pour organiser un tirage, tu demandes la création de ton groupe.':'Un compte suffit, pour tenir une liste comme pour organiser un Secret Santa.',
'Un journal que tout le groupe peut lire : la triche se voit.':'Un journal que tous les membres peuvent lire : la triche se voit.',
'Tu offres un cadeau dans un tirage à quelqu’un de cette liste : tes coches ne diront pas ton prénom. Tu peux le désactiver là-haut, par exemple pour offrir aussi un cadeau sous ton prénom.':'Tu offres un cadeau dans un Secret Santa à quelqu’un de cette liste : tes coches ne diront pas ton prénom. Tu peux le désactiver là-haut, par exemple pour offrir aussi un cadeau sous ton prénom.',
'A laissé des pistes':'A écrit sa liste','Facultatif : chacun peut déjà laisser ses pistes':'Facultatif : chacun peut déjà écrire sa liste',
'Personne ne voit de pistes de cadeaux avant que tout le monde ait répondu et que tu aies validé.':'Personne ne voit la liste de sa personne avant que tout le monde ait répondu et que tu aies validé.',
'L’exclusion du groupe (Camille et Hugo) n’est pas vérifiée':'L’exclusion de la fête (Camille et Hugo) n’est pas vérifiée',
'Pistes de cadeaux, relances, historique pour l’an prochain.':'Listes de cadeaux, relances, historique pour l’an prochain.',
'Sur papier ou avec une autre application : ici, chacun dit à qui il offre, et profite des pistes de cadeaux.':'Sur papier ou avec une autre application : ici, chacun dit à qui il offre, et profite des listes de cadeaux.',
'Tu valides, et c’est un tirage comme les autres':'Tu valides, et c’est un Secret Santa comme les autres',
'Chacun verra ensuite les pistes de cadeaux de la personne à qui il offre.':'Chacun verra ensuite la liste de cadeaux de la personne à qui il offre.',
'Tu verras les pistes de cadeaux de ta personne quand tout le monde aura répondu. 3 réponses sur 5 pour l’instant.':'Tu verras la liste de cadeaux de ta personne quand tout le monde aura répondu. 3 réponses sur 5 pour l’instant.',
'Le tirage a été fait hors de l’application. Dis-le ici pour voir ses pistes de cadeaux. Assure-toi que personne ne regarde ton écran.':'Le tirage a été fait hors de l’application. Dis-le ici pour voir sa liste de cadeaux. Assure-toi que personne ne regarde ton écran.',
'Chacun verra les pistes de cadeaux de sa personne':'Chacun verra la liste de cadeaux de sa personne',
'Camille te demande des pistes':'Camille te demande ta liste','Donner des pistes':'Écrire ma liste','Mes tirages':'Mes Secret Santa',
'Seulement ce qui te concerne : ton enveloppe, une invitation, une demande de pistes. Jamais de publicité.':'Seulement ce qui te concerne : ton enveloppe, une invitation, une demande d’idées. Jamais de publicité.',
'Camille a laissé de nouvelles pistes':'Camille a ajouté des idées','Camille te demande des pistes de cadeaux':'Camille te demande des idées de cadeaux',
'Camille a laissé de nouvelles pistes de cadeaux.':'Camille a ajouté des idées de cadeaux.',
'Ton enveloppe t’attend, une invitation, la réponse à une demande de groupe, quelqu’un te demande des pistes : avec le résumé, ces emails-là partent quand même tout de suite, sauf si tu as déjà vu la nouveauté.':'Ton enveloppe t’attend, une invitation, quelqu’un te demande des idées : avec le résumé, ces emails-là partent quand même tout de suite, sauf si tu as déjà vu la nouveauté.',
'Le tirage devient très contraint dans un petit groupe':'Le tirage devient très contraint dans une petite fête',
'Combien de personnes peuvent encore rejoindre le groupe par ce lien.':'Combien de personnes peuvent encore rejoindre la fête par ce lien.',
'Le groupe peut encore accueillir 10 personnes au plus.':'La fête peut encore accueillir 10 personnes au plus.','Garder le groupe':'Garder la fête',
'Les 3 éditions, leurs tirages et les pistes de cadeaux.':'Les 3 années, leurs Secret Santa et leurs tirages.',
'Recopie l’identifiant du groupe : famille-camille':'Recopie l’identifiant de la fête : famille-camille',
'Demander des pistes à Inès ?':'Demander des idées à Inès ?','Une seule demande par tirage':'Une seule demande par Secret Santa','Donner quelques pistes':'Écrire quelques idées',
'Inès vient de recevoir un email, sans savoir que ça vient de toi. Tu recevras un email dès que des pistes arrivent.':'Inès vient de recevoir un email, sans savoir que ça vient de toi. Tu recevras un email dès que des idées arrivent.',
'Pistes mises à jour le 16 novembre':'Idées mises à jour le 16 novembre','Inès n’a pas encore laissé de pistes.':'Inès n’a encore rien écrit.',
'Il en faut au moins trois pour un tirage. Choisis-les parmi les membres du groupe, ou envoie un lien pour qu’ils s’inscrivent.':'Il en faut au moins trois pour un Secret Santa. Choisis-les parmi les membres de la fête, ou envoie un lien pour qu’ils s’inscrivent.',
'Personne ne lit tes listes ni tes tirages pour les surveiller : on n’agit que sur signalement.':'Personne ne lit tes listes ni tes Secret Santa pour les surveiller : on n’agit que sur signalement.',
'Rejoindre le groupe':'Rejoindre la fête','Groupes':'Fêtes','Pour Noël, un anniversaire ou toute l’année. Tu écris les idées de chacun, tu envoies un lien, et la famille coche ce qu’elle offre.':'Pour Noël, un anniversaire, une naissance, un mariage ou une crémaillère. Tu écris les idées de chacun, et tes proches cochent ce qu’ils offrent.','Pour les listes de cadeaux, je tenais une page à la main chaque année. Elle est devenue l’onglet « Listes ».':'Pour les listes de cadeaux, je tenais une page à la main chaque année. Elle est devenue les listes de l’application.',"Étapes de l'édition":"Étapes du Secret Santa",'Demander des pistes':'Demander des idées','Tirage':'Secret Santa','Pistes de cadeaux':'Devine qui','Portrait seulement':'Qui m’offre ?','Laisser mes pistes de cadeaux':'Écrire ma liste de cadeaux',
', quel que soit le groupe, la liste ou la personne qui t’ajoute.':', quelle que soit la fête, la liste ou la personne qui t’ajoute.',
'Cette édition est clôturée. Tu peux encore revoir à qui tu as offert un cadeau.':'Ce Secret Santa est clôturé. Tu peux encore revoir à qui tu as offert un cadeau.',
'Cette édition est clôturée. Rendez-vous l’an prochain !':'Ce Secret Santa est clôturé. Rendez-vous l’an prochain !',
'Le tirage est fait, et des pistes de cadeaux t’attendent à l’intérieur. Assure-toi que personne ne regarde ton écran avant de l’ouvrir.':'Le tirage est fait, et des idées de cadeaux t’attendent à l’intérieur. Assure-toi que personne ne regarde ton écran avant de l’ouvrir.',
'Qui offre à qui, pour tout le groupe':'Qui offre à qui, pour toute la fête','De nouvelles pistes t’attendent':'De nouvelles idées t’attendent',
'Pas encore de pistes. Tu pourras lui en demander.':'Pas encore d’idées. Tu pourras lui en demander.',
"Je comprends que tout le groupe saura que j'ai regardé":"Je comprends que tous les membres sauront que j'ai regardé",
"Tout le groupe le saura : c'est inscrit au journal, avec le prénom.":"Tous les membres le sauront : c'est inscrit au journal, avec le prénom.",
"Cacher et revenir à l'édition":"Cacher et revenir au Secret Santa",
}
ETATS=[("Remplies, modifiables jusqu'à la fête",'Vue seulement par celui qui m’a tiré'),('Remplies, plus modifiables','Vue seulement par celui qui m’a tiré'),('Modifiables jusqu’à la fête','Vue seulement par celui qui m’a tiré'),('Plus modifiables','Vue seulement par celui qui m’a tiré'),('Remplies','Vue seulement par celui qui m’a tiré'),('À remplir','À écrire')]
HREF={'PropEditionReglages':'V3TirageReglages','Pistes':'V3ListeSecret','PistesQuestion':'V3ListeSecret','EditionReglages':'V3TirageReglages','GroupeInvitation':'V3FeteInviter','Groupe':'V3FeteOrganisateur','GroupeReglages':'V3FeteReglages','GroupeNouveau':'V3FeteNouvelle','GroupeMembres':'V3FeteMembres','EditionNouvelle':'V3TirageNouveau','Rejoindre':'V3FeteRejoindre','Accueil':'V3Accueil','AccueilPlusieurs':'V3Accueil','AccueilOrganisateur':'V3Accueil','AccueilVide':'V3AccueilVide','TiragesPasses':'V3Accueil','ListesAccueil':'V3Accueil'}
NAVADM=re.compile(r'<a\b(?:(?!</a>).)*?>Admin(?:(?!</a>).)*?</a>',re.S)
def navnew(old,active='home'):
    n=nav(active); assert n.count('</a><a ')==1; n=n.replace('</a><a ','</a>'+TABC+'<a ',1)
    m=NAVADM.search(old)
    return n.replace('</nav>',m.group(0)+'</nav>',1) if m else n
stats=dict(burger=0,nav=0,mots=0,fichiers=0); used=set(); changed=[]
for n in S:
    h0=open(V2+n+'.dc.html',encoding='utf-8').read(); h=h0
    k=h.index('<x-dc>') if '<x-dc>' in h else 0; head,body=h[:k],h[k:]
    if BURG.search(body): body=BURG.sub(AVB,body,count=1); stats['burger']+=1
    m=NAVRE.search(body)
    if m: body=body[:m.start()]+navnew(m.group(0),'news' if n=='NotifCentre' else 'home')+body[m.end():]; stats['nav']+=1
    def node(mm):
        t=mm.group(2); s=t.strip()
        if s in M: used.add(s); stats['mots']+=1; return mm.group(1)+t.replace(s,M[s])+mm.group(3)
        return mm.group(0)
    body=re.sub(r'(>)([^<>]+)(<)',node,body)
    for a,b in SUB:
        if a in body: stats['mots']+=body.count(a); body=body.replace(a,b)
    def attr(mm):
        v=mm.group(2)
        if v in M: used.add(v); stats['mots']+=1; return mm.group(1)+'="'+M[v]+'"'
        return mm.group(0)
    body=re.sub(r'\b(placeholder|value|aria-label)="([^"]*)"',attr,body)
    # l'état de « Ma liste de cadeaux » sur la page de celui qui tire
    def etat(mm):
        z=mm.group(0)
        for o,nw in ETATS:
            if '>'+o+'<' in z: stats['mots']+=1; return z.replace('>'+o+'<','>'+nw+'<',1)
        return z
    body=re.sub(r'>Ma liste de cadeaux<.{0,1200}?</a>',etat,body,flags=re.S)
    for o,nw in HREF.items():
        if 'href="'+o+'.dc.html"' in body: body=body.replace('href="'+o+'.dc.html"','href="'+nw+'.dc.html"')
    h=head+body
    if h!=h0: changed.append(n); stats['fichiers']+=1
    open(PJ+n+'.dc.html','w',encoding='utf-8').write(h)
json.dump(changed,open('/tmp/v3pass_changed.json','w'))
print(stats,'| à passer',len(S),'| règles inutilisées',[k[:40] for k in M if k not in used])
